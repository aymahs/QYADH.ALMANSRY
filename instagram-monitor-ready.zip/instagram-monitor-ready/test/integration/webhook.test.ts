import { describe, it, expect } from 'vitest';

import { createWebhookServer } from '../../src/app/webhook-server';
import type { WebhookServerOptions } from '../../src/app/webhook-server';
import type { TelegramUpdate } from '../../src/domain/telegram';
import { createLogger, nullLogger } from '../../src/logging/logger';

const SECRET = 'correct-webhook-secret-token-9876';
const WEBHOOK_PATH = '/telegram/webhook';
const SECRET_HEADER = 'x-telegram-bot-api-secret-token';

const VALID_UPDATE: TelegramUpdate = {
  update_id: 7001,
  message: {
    message_id: 1,
    chat: { id: 555, type: 'private' },
    date: 1_700_000_000,
    text: '/ping',
  },
};

interface Harness {
  server: ReturnType<typeof createWebhookServer>;
  received: TelegramUpdate[];
}

function makeServer(overrides: Partial<WebhookServerOptions> = {}): Harness {
  const received: TelegramUpdate[] = [];
  const server = createWebhookServer({
    secretToken: SECRET,
    onUpdate: async (update) => {
      received.push(update);
    },
    healthz: async () => ({ ok: true }),
    logger: nullLogger(),
    ...overrides,
  });
  return { server, received };
}

describe('createWebhookServer — POST /telegram/webhook', () => {
  it('replies 401 and does not process when the secret header is wrong', async () => {
    const { server, received } = makeServer();
    const res = await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { [SECRET_HEADER]: 'wrong-secret-value' },
      payload: VALID_UPDATE,
    });
    expect(res.statusCode).toBe(401);
    expect(res.json()).toEqual({ ok: false });
    expect(received).toHaveLength(0);
  });

  it('replies 401 when the secret header is missing', async () => {
    const { server, received } = makeServer();
    const res = await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      payload: VALID_UPDATE,
    });
    expect(res.statusCode).toBe(401);
    expect(res.json()).toEqual({ ok: false });
    expect(received).toHaveLength(0);
  });

  it('replies 200 and dispatches the update when the secret matches', async () => {
    const { server, received } = makeServer();
    const res = await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { [SECRET_HEADER]: SECRET },
      payload: VALID_UPDATE,
    });
    expect(res.statusCode).toBe(200);
    expect(res.json()).toEqual({ ok: true });
    expect(received).toHaveLength(1);
    expect(received[0]).toEqual(VALID_UPDATE);
  });

  it('still replies 200 when the update handler throws', async () => {
    const { server } = makeServer({
      onUpdate: async () => {
        throw new Error('handler exploded');
      },
    });
    const res = await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { [SECRET_HEADER]: SECRET },
      payload: VALID_UPDATE,
    });
    expect(res.statusCode).toBe(200);
    expect(res.json()).toEqual({ ok: true });
  });

  it('ignores (200, no dispatch) a body without a numeric update_id', async () => {
    const { server, received } = makeServer();

    const missing = await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { [SECRET_HEADER]: SECRET },
      payload: { hello: 'world' },
    });
    expect(missing.statusCode).toBe(200);
    expect(missing.json()).toEqual({ ok: true });

    const nonNumeric = await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { [SECRET_HEADER]: SECRET },
      payload: { update_id: 'not-a-number' },
    });
    expect(nonNumeric.statusCode).toBe(200);
    expect(nonNumeric.json()).toEqual({ ok: true });

    expect(received).toHaveLength(0);
  });

  it('does not register the webhook route when webhookEnabled is false', async () => {
    const { server, received } = makeServer({ webhookEnabled: false });

    const webhook = await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { [SECRET_HEADER]: SECRET },
      payload: VALID_UPDATE,
    });
    expect(webhook.statusCode).toBe(404);
    expect(received).toHaveLength(0);

    const health = await server.inject({ method: 'GET', url: '/healthz' });
    expect(health.statusCode).toBe(200);
  });
});

describe('createWebhookServer — GET /healthz', () => {
  it('returns 200 with the healthz JSON when ok', async () => {
    const { server } = makeServer({ healthz: async () => ({ ok: true, db: 'up' }) });
    const res = await server.inject({ method: 'GET', url: '/healthz' });
    expect(res.statusCode).toBe(200);
    expect(res.json()).toEqual({ ok: true, db: 'up' });
  });

  it('returns 503 when the probe reports ok:false', async () => {
    const { server } = makeServer({ healthz: async () => ({ ok: false, db: 'down' }) });
    const res = await server.inject({ method: 'GET', url: '/healthz' });
    expect(res.statusCode).toBe(503);
    expect(res.json()).toEqual({ ok: false, db: 'down' });
  });
});

describe('createWebhookServer — secret hygiene', () => {
  it('never writes the secret or a received header value into log lines', async () => {
    const lines: string[] = [];
    const logger = createLogger({
      level: 'debug',
      secrets: [SECRET],
      write: (line) => {
        lines.push(line);
      },
    });
    const attackerGuess = 'attacker-guessed-header-value-000';
    const { server } = makeServer({
      logger,
      onUpdate: async () => {
        throw new Error('boom'); // exercise the error-logging path too
      },
    });

    await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { [SECRET_HEADER]: attackerGuess },
      payload: VALID_UPDATE,
    });
    await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { [SECRET_HEADER]: SECRET },
      payload: VALID_UPDATE,
    });
    await server.inject({
      method: 'POST',
      url: WEBHOOK_PATH,
      headers: { [SECRET_HEADER]: SECRET },
      payload: { bogus: true },
    });

    for (const line of lines) {
      expect(line).not.toContain(SECRET);
      expect(line).not.toContain(attackerGuess);
    }
  });
});
