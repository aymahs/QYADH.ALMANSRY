import { describe, it, expect, beforeEach, afterEach } from 'vitest';

import { SqliteDatabase } from '../../src/persistence/sqlite-database';
import { CircuitBreaker, EGRESS_BREAKER_NAME } from '../../src/instagram/circuit-breaker';
import type { Repositories } from '../../src/domain';
import type { NewCaseInput, SchedulerHealth } from '../../src/domain';
import { isAppError } from '../../src/domain';

const NOW = '2026-07-17T00:00:00.000Z';
const PAST = '2026-07-16T00:00:00.000Z';
const PAST_LATER = '2026-07-16T00:30:00.000Z';
const LEASE_EXP = '2026-07-17T01:00:00.000Z';
const CLEARED_AT = '2026-07-17T02:00:00.000Z';

function makeInput(username: string, nextCheckAtUtc = PAST): NewCaseInput {
  return {
    normalizedUsername: username,
    originalInput: `@${username}`,
    startedAtUtc: NOW,
    nextCheckAtUtc,
  };
}

describe('SqliteDatabase persistence', () => {
  let db: SqliteDatabase;
  let repos: Repositories;

  beforeEach(async () => {
    db = new SqliteDatabase(':memory:');
    await db.migrate();
    repos = db.repositories();
  });

  afterEach(async () => {
    await db.close();
  });

  describe('cases.create + unique active constraint', () => {
    it('creates a case and rejects a duplicate active username', async () => {
      const created = await repos.cases.create(makeInput('alice'), NOW);
      expect(created.normalizedUsername).toBe('alice');
      expect(created.status).toBe('MONITORING');
      expect(created.id).toBeTruthy();

      let threw: unknown = null;
      try {
        await repos.cases.create(makeInput('alice'), NOW);
      } catch (err) {
        threw = err;
      }
      expect(isAppError(threw)).toBe(true);
      expect(isAppError(threw) && threw.code).toBe('DUPLICATE_CASE');
    });

    it('allows re-creating a username after the prior case is cleared', async () => {
      await repos.cases.create(makeInput('alice'), NOW);
      const cleared = await repos.cases.clearByNormalizedUsername('alice', CLEARED_AT);
      expect(cleared).not.toBeNull();
      // Now a fresh case for the same username must succeed.
      const again = await repos.cases.create(makeInput('alice'), NOW);
      expect(again.status).toBe('MONITORING');
    });
  });

  it('migrate() is idempotent and never mutates an existing ERROR_BACKOFF case', async () => {
    // Regression guard: a blanket ERROR_BACKOFF -> UNKNOWN_BACKOFF reclassify used to
    // re-fire on every startup and silently demote genuine operational-failure cases.
    const created = await repos.cases.create(makeInput('legacy-user'), NOW);
    await repos.cases.save({
      ...created,
      status: 'ERROR_BACKOFF',
      lastResult: 'UNKNOWN',
      consecutiveUnknownCount: 3,
      errorBackoffUntilUtc: '2026-07-17T00:04:00.000Z',
      nextCheckAtUtc: '2026-07-17T00:04:00.000Z',
    });

    await db.migrate();
    await db.migrate();
    const after = await repos.cases.findById(created.id);
    expect(after?.status).toBe('ERROR_BACKOFF');
    expect(after?.startedAtUtc).toBe(NOW);
    expect(after?.nextCheckAtUtc).toBe('2026-07-17T00:04:00.000Z');
  });

  describe('reads', () => {
    it('findActiveByNormalizedUsername / listByStatuses / countByStatuses', async () => {
      const created = await repos.cases.create(makeInput('bob'), NOW);
      const found = await repos.cases.findActiveByNormalizedUsername('bob');
      expect(found?.id).toBe(created.id);

      const byId = await repos.cases.findById(created.id);
      expect(byId?.id).toBe(created.id);

      const listed = await repos.cases.listByStatuses(['MONITORING']);
      expect(listed).toHaveLength(1);
      expect(listed[0]?.normalizedUsername).toBe('bob');

      expect(await repos.cases.countByStatuses(['MONITORING'])).toBe(1);
      expect(await repos.cases.countByStatuses(['CONFIRMING'])).toBe(0);
      expect(await repos.cases.findActiveByNormalizedUsername('ghost')).toBeNull();
    });
  });

  describe('claimDueCases leasing', () => {
    it('claims a due case, then a same-instant re-claim returns nothing', async () => {
      const created = await repos.cases.create(makeInput('carol', PAST), NOW);

      const first = await repos.cases.claimDueCases({
        nowUtc: NOW,
        leaseOwner: 'w1',
        leaseExpiresUtc: LEASE_EXP,
        limit: 10,
      });
      expect(first).toHaveLength(1);
      expect(first[0]?.id).toBe(created.id);
      expect(first[0]?.leaseOwner).toBe('w1');
      expect(first[0]?.leaseExpiresAtUtc).toBe(LEASE_EXP);

      const second = await repos.cases.claimDueCases({
        nowUtc: NOW,
        leaseOwner: 'w2',
        leaseExpiresUtc: LEASE_EXP,
        limit: 10,
      });
      expect(second).toHaveLength(0);
    });

    it('releaseLease frees a case for re-claim', async () => {
      const created = await repos.cases.create(makeInput('dave', PAST), NOW);
      const first = await repos.cases.claimDueCases({
        nowUtc: NOW,
        leaseOwner: 'w1',
        leaseExpiresUtc: LEASE_EXP,
        limit: 10,
      });
      expect(first).toHaveLength(1);

      await repos.cases.releaseLease(created.id, NOW);

      const reclaim = await repos.cases.claimDueCases({
        nowUtc: NOW,
        leaseOwner: 'w2',
        leaseExpiresUtc: LEASE_EXP,
        limit: 10,
      });
      expect(reclaim).toHaveLength(1);
      expect(reclaim[0]?.leaseOwner).toBe('w2');
    });

    it('returns CONFIRMING cases before MONITORING cases', async () => {
      // MONITORING with the EARLIER next-check time; would sort first without priority.
      await repos.cases.create(makeInput('mon', PAST), NOW);
      // CONFIRMING with a LATER next-check time; must still come first.
      await repos.cases.create(makeInput('conf', PAST_LATER), NOW);
      const conf = await repos.cases.findActiveByNormalizedUsername('conf');
      expect(conf).not.toBeNull();
      await repos.cases.save({ ...conf!, status: 'CONFIRMING' });

      const claimed = await repos.cases.claimDueCases({
        nowUtc: NOW,
        leaseOwner: 'w1',
        leaseExpiresUtc: LEASE_EXP,
        limit: 10,
      });
      expect(claimed).toHaveLength(2);
      expect(claimed[0]?.normalizedUsername).toBe('conf');
      expect(claimed[0]?.status).toBe('CONFIRMING');
      expect(claimed[1]?.normalizedUsername).toBe('mon');
    });
  });

  describe('clearByNormalizedUsername', () => {
    it('clears an active case and returns it; returns null for unknown username', async () => {
      await repos.cases.create(makeInput('erin'), NOW);
      const cleared = await repos.cases.clearByNormalizedUsername('erin', CLEARED_AT);
      expect(cleared?.status).toBe('CLEARED');
      expect(cleared?.clearedAtUtc).toBe(CLEARED_AT);
      expect(cleared?.nextCheckAtUtc).toBeNull();
      expect(cleared?.leaseOwner).toBeNull();

      const persisted = await repos.cases.findById(cleared!.id);
      expect(persisted?.status).toBe('CLEARED');
      expect(persisted?.nextCheckAtUtc).toBeNull();

      expect(await repos.cases.clearByNormalizedUsername('nobody', CLEARED_AT)).toBeNull();
    });
  });

  describe('claimNotification single-winner', () => {
    it('first claim wins, second loses', async () => {
      const created = await repos.cases.create(makeInput('frank'), NOW);
      expect(await repos.cases.claimNotification(created.id, NOW)).toBe(true);
      expect(await repos.cases.claimNotification(created.id, NOW)).toBe(false);
    });
  });

  describe('updates.registerIfNew dedup', () => {
    it('returns true once then false for the same update id', async () => {
      expect(await repos.updates.registerIfNew(500100, NOW)).toBe(true);
      expect(await repos.updates.registerIfNew(500100, NOW)).toBe(false);
    });
  });

  describe('outbox queue', () => {
    it('enqueue is idempotent per (case, kind); claim/markSent lifecycle works', async () => {
      const c = await repos.cases.create(makeInput('grace'), NOW);

      const first = await repos.outbox.enqueue({
        caseId: c.id,
        kind: 'RECOVERY_PHOTO',
        createdAtUtc: NOW,
      });
      const dup = await repos.outbox.enqueue({
        caseId: c.id,
        kind: 'RECOVERY_PHOTO',
        createdAtUtc: NOW,
      });
      expect(dup.id).toBe(first.id);
      expect(await repos.outbox.countPending()).toBe(1);

      const claimed = await repos.outbox.claimNextPending(NOW);
      expect(claimed?.id).toBe(first.id);
      expect(claimed?.status).toBe('CLAIMED');
      expect(claimed?.attempts).toBe(1);
      expect(await repos.outbox.countPending()).toBe(0);

      // Nothing left to claim.
      expect(await repos.outbox.claimNextPending(NOW)).toBeNull();

      await repos.outbox.markSent(first.id, CLEARED_AT, 4242);
      const items = await repos.outbox.findByCase(c.id);
      expect(items).toHaveLength(1);
      expect(items[0]?.status).toBe('SENT');
      expect(items[0]?.sentAtUtc).toBe(CLEARED_AT);
      expect(items[0]?.telegramMessageId).toBe(4242);
    });

    it('requeueStale resets a stuck CLAIMED item and reports oldest pending age', async () => {
      const c = await repos.cases.create(makeInput('heidi'), NOW);
      await repos.outbox.enqueue({ caseId: c.id, kind: 'RECOVERY_TEXT', createdAtUtc: PAST });
      const claimed = await repos.outbox.claimNextPending(PAST);
      expect(claimed?.status).toBe('CLAIMED');
      expect(await repos.outbox.countPending()).toBe(0);

      const requeued = await repos.outbox.requeueStale(NOW, NOW);
      expect(requeued).toBe(1);
      expect(await repos.outbox.countPending()).toBe(1);

      const ageMs = await repos.outbox.oldestPendingAgeMs(NOW);
      expect(ageMs).toBe(Date.parse(NOW) - Date.parse(PAST));
    });
  });

  describe('checks', () => {
    it('inserts a check and counts by case', async () => {
      const c = await repos.cases.create(makeInput('ivan'), NOW);
      const rec = await repos.checks.insert({
        caseId: c.id,
        checkedAtUtc: NOW,
        classification: 'GONE',
        finalUrl: 'https://www.instagram.com/ivan/',
        responseStatus: 200,
        durationMs: 137,
        activeSignals: [],
        goneSignals: ['unavailable_message_present'],
        errorCode: null,
        confirmationSeq: null,
      });
      expect(rec.id).toBeTruthy();
      expect(await repos.checks.countByCase(c.id)).toBe(1);
      expect(await repos.checks.countByCase('other')).toBe(0);
    });
  });

  describe('scheduler_health', () => {
    it('upsert then get round-trips values (including boolean)', async () => {
      const health: SchedulerHealth = {
        name: 'main',
        lastSchedulerRunUtc: NOW,
        lastSuccessfulCheckUtc: NOW,
        lastControlOkUtc: NOW,
        recentUnknownRate: 0.25,
        browserRestarts: 2,
        detectorUnhealthy: true,
        lastWarningSentUtc: null,
        updatedAtUtc: NOW,
      };
      await repos.health.upsert(health);
      expect(await repos.health.get('main')).toEqual(health);

      // Second upsert overwrites.
      await repos.health.upsert({ ...health, browserRestarts: 5, detectorUnhealthy: false });
      const updated = await repos.health.get('main');
      expect(updated?.browserRestarts).toBe(5);
      expect(updated?.detectorUnhealthy).toBe(false);

      expect(await repos.health.get('missing')).toBeNull();
    });
  });

  describe('breaker_state durability', () => {
    // The whole chain, through the real database: an OPEN breaker must still be OPEN with the
    // same time left after a process restart. Nothing here hand-writes the stored row — the
    // first breaker PRODUCES it through the same transition -> repository path the app wires up.
    it('an OPEN breaker resumes its remaining cooldown after a simulated restart', async () => {
      const store = repos.breakerState;
      expect(store).toBeDefined();
      let t = Date.parse(NOW);
      const now = (): number => t;
      const writes: Promise<void>[] = [];
      const options = { threshold: 2, initialCooldownMs: 600_000, maxCooldownMs: 3_600_000 };

      const first = new CircuitBreaker({
        ...options,
        now,
        onTransition: (state) => {
          writes.push(
            store!.save({
              name: EGRESS_BREAKER_NAME,
              ...state,
              egressRoute: 'direct',
              updatedAtUtc: new Date(t).toISOString(),
            }),
          );
        },
      });
      first.record(true);
      first.record(true);
      expect(first.currentState()).toBe('OPEN');
      await Promise.all(writes);

      // Four of the ten minutes elapse, then the process dies.
      t += 4 * 60_000;
      const stored = await store!.get(EGRESS_BREAKER_NAME);
      expect(stored?.state).toBe('OPEN');
      expect(stored?.cooldownMs).toBe(600_000);
      expect(stored?.consecutive).toBe(2);
      expect(stored?.egressRoute).toBe('direct');
      expect(stored?.openedAtUtc).toBe(NOW);

      const second = new CircuitBreaker({ ...options, now });
      second.rehydrate(stored);
      expect(second.currentState()).toBe('OPEN');
      expect(second.retryAfterMs()).toBe(6 * 60_000);
      expect(second.allowRequest()).toBe(false);
    });

    it('an absent row leaves the breaker CLOSED rather than wedged', async () => {
      const stored = await repos.breakerState!.get(EGRESS_BREAKER_NAME);
      expect(stored).toBeNull();
      const breaker = new CircuitBreaker({ threshold: 2, initialCooldownMs: 600_000 });
      breaker.rehydrate(stored);
      expect(breaker.currentState()).toBe('CLOSED');
      expect(breaker.allowRequest()).toBe(true);
    });

    it('save overwrites by name', async () => {
      const store = repos.breakerState!;
      await store.save({
        name: EGRESS_BREAKER_NAME,
        state: 'OPEN',
        openedAtUtc: NOW,
        cooldownMs: 600_000,
        consecutive: 5,
        egressRoute: 'proxy 10.0.0.1:8080',
        updatedAtUtc: NOW,
      });
      await store.save({
        name: EGRESS_BREAKER_NAME,
        state: 'CLOSED',
        openedAtUtc: null,
        cooldownMs: 600_000,
        consecutive: 0,
        egressRoute: 'direct',
        updatedAtUtc: CLEARED_AT,
      });
      const stored = await store.get(EGRESS_BREAKER_NAME);
      expect(stored?.state).toBe('CLOSED');
      expect(stored?.openedAtUtc).toBeNull();
      expect(stored?.egressRoute).toBe('direct');
      expect(stored?.updatedAtUtc).toBe(CLEARED_AT);
    });
  });

  describe('owner pairing', () => {
    it('first claim wins, later claims return false', async () => {
      expect(await repos.owner.getOwnerTelegramId()).toBeNull();
      expect(await repos.owner.claimOwner(12345, NOW)).toBe(true);
      expect(await repos.owner.getOwnerTelegramId()).toBe(12345);
      expect(await repos.owner.claimOwner(67890, NOW)).toBe(false);
      expect(await repos.owner.getOwnerTelegramId()).toBe(12345);
    });
  });

  describe('ping', () => {
    it('performs a write+read round-trip and returns true', async () => {
      expect(await db.ping()).toBe(true);
    });
  });
});
