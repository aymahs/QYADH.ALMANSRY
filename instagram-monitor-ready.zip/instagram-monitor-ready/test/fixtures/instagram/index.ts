/** Read a sibling Instagram HTML fixture by name (with or without the `.html` suffix). */

import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const FIXTURE_DIR = dirname(fileURLToPath(import.meta.url));

export function readFixture(name: string): string {
  const file = name.endsWith('.html') ? name : `${name}.html`;
  return readFileSync(join(FIXTURE_DIR, file), 'utf8');
}
