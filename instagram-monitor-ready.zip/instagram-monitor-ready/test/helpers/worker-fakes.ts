/**
 * In-memory test fakes for the scheduler/outbox/health workers. These are
 * faithful to the repository contracts that matter for reliability:
 *  - `claimDueCases` enforces job-lease semantics (two workers never claim the
 *    same row) and returns CONFIRMING cases before baseline cases;
 *  - `claimNotification` is a single-winner compare-and-set;
 *  - the outbox is unique per (caseId, kind), `claimNextPending` increments
 *    `attempts`, and `requeueStale` resets abandoned CLAIMED rows.
 *
 * Note: `claimNextPending` intentionally does NOT skip items whose case was
 * cleared (a SQL implementation may), so tests exercise the outbox worker's own
 * cleared-case guard.
 */

import type {
  CaseRepository,
  CaseStatus,
  CheckRecord,
  CheckRepository,
  ClaimDueParams,
  Classification,
  Detector,
  DetectorErrorCode,
  EnqueueOutbox,
  MonitoringCase,
  NewCaseInput,
  NewCheckInput,
  OutboxItem,
  OutboxKind,
  OutboxRepository,
  OwnerRepository,
  ProbeOptions,
  ProbeResult,
  Repositories,
  SchedulerHealth,
  SchedulerHealthRepository,
  TelegramUpdateRepository,
  BusinessConnectionRepository,
  ClientChatLinkRepository,
  BusinessConnection,
  ClientChatLink,
  NewClientChatLink,
  BusinessDeliveryStatus,
  DeletionWatchRepository,
  DeletionWatch,
  NewDeletionWatchInput,
  DeletionClaimParams,
  ClientsRepository,
  ClientIdentity,
  NewClientIdentity,
} from '../../src/domain';
import {
  ACTIVE_STATUSES,
  SIGNALS_VERSION,
  TERMINAL_STATUSES,
  DELETION_TERMINAL_STATUSES,
} from '../../src/domain';
import type { AppConfig } from '../../src/config';

/** A tiny but valid-looking PNG payload (magic bytes 89 50 4E 47 0D 0A 1A 0A). */
export const FAKE_PNG: Buffer = Buffer.from([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
]);

/** Instant sleep for tests: never touches real timers. */
export const instantSleep = (_ms: number): Promise<void> => Promise.resolve();

/** Deterministic AppConfig for worker tests (rand 0.5 => zero jitter). */
export function makeTestConfig(overrides: Partial<AppConfig['scheduling']> = {}): AppConfig {
  return {
    telegram: {
      botToken: 'test-token-1234567890',
      webhookSecret: 'test-webhook-secret',
      mode: 'polling',
      publicBaseUrl: null,
    },
    ownerPairingSecret: 'test-pairing-secret',
    controlUsername: 'instagram',
    browserWsEndpoint: null,
    igStorageState: null,
    browserProxy: null,
    proxyMode: 'direct',
    detection: {
      fastProbe: false,
      breakerThreshold: 5,
      breakerCooldownSeconds: 600,
      breakerMaxCooldownSeconds: 3600,
      browserLoadsPerHour: 120,
      browserLoadRoutineFraction: 0.75,
    },
    discord: {
      botToken: null,
      ownerUserId: null,
      guildId: null,
      channels: { unbans: null, deletions: null, status: null, commands: null },
    },
    db: { driver: 'sqlite', sqlitePath: ':memory:', databaseUrl: null },
    displayTimezone: 'Asia/Kolkata',
    scheduling: {
      baselineIntervalSeconds: 60,
      // Deletion watches are browser-only, so they get their own (much slower) cadence.
      deletionIntervalSeconds: 300,
      confirmationIntervalSeconds: 5,
      confirmationRequiredCount: 3,
      confirmationDeadlineSeconds: 30,
      maxBrowserConcurrency: 1,
      jobLeaseSeconds: 120,
      checkTimeoutMs: 25000,
      baselineJitterMaxSeconds: 2,
      retryDelaysSeconds: [5, 10, 15, 30],
      unknownBackoffBaseSeconds: 60,
      unknownBackoffMaxSeconds: 1800,
      errorBackoffInitialSeconds: 15,
      errorBackoffMaxSeconds: 30,
      ...overrides,
    },
    server: { port: 8080 },
    logLevel: 'error',
  };
}

class InMemoryOwnerRepository implements OwnerRepository {
  ownerId: number | null = null;

  async getOwnerTelegramId(): Promise<number | null> {
    return this.ownerId;
  }

  async claimOwner(telegramUserId: number, _pairedAtUtc: string): Promise<boolean> {
    if (this.ownerId !== null) return false;
    this.ownerId = telegramUserId;
    return true;
  }
}

class InMemoryCaseRepository implements CaseRepository {
  private readonly rows = new Map<string, MonitoringCase>();
  private seq = 0;

  /** Direct snapshot for assertions (clone; never the stored row). */
  snapshot(id: string): MonitoringCase | null {
    const row = this.rows.get(id);
    return row === undefined ? null : structuredClone(row);
  }

  async create(input: NewCaseInput, nowUtc: string): Promise<MonitoringCase> {
    const row: MonitoringCase = {
      id: `case-${++this.seq}`,
      normalizedUsername: input.normalizedUsername,
      originalInput: input.originalInput,
      startedAtUtc: input.startedAtUtc,
      status: 'MONITORING',
      confirmationCount: 0,
      nextCheckAtUtc: input.nextCheckAtUtc,
      lastCheckedAtUtc: null,
      lastResult: null,
      consecutiveUnknownCount: 0,
      errorBackoffUntilUtc: null,
      confirmedAtUtc: null,
      clearedAtUtc: null,
      notificationClaimedAtUtc: null,
      notificationSentAtUtc: null,
      telegramMessageId: null,
      screenshotStatus: 'NONE',
      leaseOwner: null,
      leaseExpiresAtUtc: null,
      createdAtUtc: nowUtc,
      updatedAtUtc: nowUtc,
    };
    this.rows.set(row.id, row);
    return structuredClone(row);
  }

  async findById(id: string): Promise<MonitoringCase | null> {
    return this.snapshot(id);
  }

  async findActiveByNormalizedUsername(username: string): Promise<MonitoringCase | null> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === username && !TERMINAL_STATUSES.includes(row.status)) {
        return structuredClone(row);
      }
    }
    return null;
  }

  async listByStatuses(statuses: readonly CaseStatus[]): Promise<MonitoringCase[]> {
    return [...this.rows.values()]
      .filter((row) => statuses.includes(row.status))
      .map((row) => structuredClone(row));
  }

  async countByStatuses(statuses: readonly CaseStatus[]): Promise<number> {
    return [...this.rows.values()].filter((row) => statuses.includes(row.status)).length;
  }

  async claimDueCases(params: ClaimDueParams): Promise<MonitoringCase[]> {
    const due = [...this.rows.values()].filter(
      (row) =>
        ACTIVE_STATUSES.includes(row.status) &&
        row.nextCheckAtUtc !== null &&
        row.nextCheckAtUtc <= params.nowUtc &&
        (row.leaseOwner === null ||
          (row.leaseExpiresAtUtc !== null && row.leaseExpiresAtUtc <= params.nowUtc)),
    );
    due.sort((a, b) => {
      const confA = a.status === 'CONFIRMING' ? 0 : 1;
      const confB = b.status === 'CONFIRMING' ? 0 : 1;
      if (confA !== confB) return confA - confB;
      return (a.nextCheckAtUtc ?? '').localeCompare(b.nextCheckAtUtc ?? '');
    });
    const taken = due.slice(0, params.limit);
    for (const row of taken) {
      row.leaseOwner = params.leaseOwner;
      row.leaseExpiresAtUtc = params.leaseExpiresUtc;
      row.updatedAtUtc = params.nowUtc;
    }
    return taken.map((row) => structuredClone(row));
  }

  async save(next: MonitoringCase): Promise<void> {
    this.rows.set(next.id, structuredClone(next));
  }

  async releaseLease(id: string, nowUtc: string): Promise<void> {
    const row = this.rows.get(id);
    if (row === undefined) return;
    row.leaseOwner = null;
    row.leaseExpiresAtUtc = null;
    row.updatedAtUtc = nowUtc;
  }

  async clearByNormalizedUsername(
    username: string,
    clearedAtUtc: string,
  ): Promise<MonitoringCase | null> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === username && !TERMINAL_STATUSES.includes(row.status)) {
        row.status = 'CLEARED';
        row.clearedAtUtc = clearedAtUtc;
        row.nextCheckAtUtc = null;
        row.leaseOwner = null;
        row.leaseExpiresAtUtc = null;
        row.updatedAtUtc = clearedAtUtc;
        return structuredClone(row);
      }
    }
    return null;
  }

  async claimNotification(caseId: string, claimedAtUtc: string): Promise<boolean> {
    const row = this.rows.get(caseId);
    if (row === undefined) return false;
    if (row.notificationClaimedAtUtc !== null) return false;
    row.notificationClaimedAtUtc = claimedAtUtc;
    row.updatedAtUtc = claimedAtUtc;
    return true;
  }
}

class InMemoryCheckRepository implements CheckRepository {
  readonly rows: CheckRecord[] = [];
  private seq = 0;

  async insert(input: NewCheckInput): Promise<CheckRecord> {
    const record: CheckRecord = { id: `check-${++this.seq}`, ...input };
    this.rows.push(structuredClone(record));
    return record;
  }

  async countByCase(caseId: string): Promise<number> {
    return this.rows.filter((r) => r.caseId === caseId).length;
  }
}

class InMemoryTelegramUpdateRepository implements TelegramUpdateRepository {
  private readonly seen = new Set<number>();

  async registerIfNew(updateId: number, _receivedAtUtc: string): Promise<boolean> {
    if (this.seen.has(updateId)) return false;
    this.seen.add(updateId);
    return true;
  }
}

class InMemoryOutboxRepository implements OutboxRepository {
  private readonly rows = new Map<string, OutboxItem>();
  private seq = 0;

  /** All items (clones) for assertions. */
  all(): OutboxItem[] {
    return [...this.rows.values()].map((row) => structuredClone(row));
  }

  async enqueue(item: EnqueueOutbox): Promise<OutboxItem> {
    for (const row of this.rows.values()) {
      if (row.caseId === item.caseId && row.kind === item.kind) {
        return structuredClone(row); // unique (caseId, kind)
      }
    }
    const row: OutboxItem = {
      id: `outbox-${++this.seq}`,
      caseId: item.caseId,
      kind: item.kind,
      status: 'PENDING',
      attempts: 0,
      claimedAtUtc: null,
      sentAtUtc: null,
      lastError: null,
      telegramMessageId: null,
      createdAtUtc: item.createdAtUtc,
      updatedAtUtc: item.createdAtUtc,
    };
    this.rows.set(row.id, row);
    return structuredClone(row);
  }

  async findByCase(caseId: string): Promise<OutboxItem[]> {
    return this.all().filter((row) => row.caseId === caseId);
  }

  async claimNextPending(nowUtc: string): Promise<OutboxItem | null> {
    const pending = [...this.rows.values()]
      .filter((row) => row.status === 'PENDING')
      .sort((a, b) => a.createdAtUtc.localeCompare(b.createdAtUtc) || a.id.localeCompare(b.id));
    const row = pending[0];
    if (row === undefined) return null;
    row.status = 'CLAIMED';
    row.claimedAtUtc = nowUtc;
    row.attempts += 1;
    row.updatedAtUtc = nowUtc;
    return structuredClone(row);
  }

  async markSent(id: string, sentAtUtc: string, telegramMessageId: number | null): Promise<void> {
    const row = this.rows.get(id);
    if (row === undefined) return;
    row.status = 'SENT';
    row.sentAtUtc = sentAtUtc;
    row.telegramMessageId = telegramMessageId;
    row.updatedAtUtc = sentAtUtc;
  }

  async markFailed(id: string, error: string, nowUtc: string): Promise<void> {
    const row = this.rows.get(id);
    if (row === undefined) return;
    row.status = 'FAILED';
    row.lastError = error;
    row.updatedAtUtc = nowUtc;
  }

  async reopenFailed(caseId: string, kind: OutboxKind, nowUtc: string): Promise<boolean> {
    for (const row of this.rows.values()) {
      if (row.caseId !== caseId || row.kind !== kind) continue;
      if (row.status !== 'FAILED') return false; // in flight or already delivered
      row.status = 'PENDING';
      row.attempts = 0;
      row.claimedAtUtc = null;
      row.lastError = null;
      row.createdAtUtc = nowUtc;
      row.updatedAtUtc = nowUtc;
      return true;
    }
    return false;
  }

  async requeueStale(olderThanUtc: string, nowUtc: string): Promise<number> {
    let count = 0;
    for (const row of this.rows.values()) {
      if (
        row.status === 'CLAIMED' &&
        row.claimedAtUtc !== null &&
        row.claimedAtUtc <= olderThanUtc
      ) {
        row.status = 'PENDING';
        row.claimedAtUtc = null;
        row.updatedAtUtc = nowUtc;
        count++;
      }
    }
    return count;
  }

  async countPending(): Promise<number> {
    return [...this.rows.values()].filter((row) => row.status === 'PENDING').length;
  }

  async oldestPendingAgeMs(nowUtc: string): Promise<number | null> {
    const pending = [...this.rows.values()].filter((row) => row.status === 'PENDING');
    if (pending.length === 0) return null;
    const oldest = pending.reduce((a, b) => (a.createdAtUtc <= b.createdAtUtc ? a : b));
    return new Date(nowUtc).getTime() - new Date(oldest.createdAtUtc).getTime();
  }
}

class InMemorySchedulerHealthRepository implements SchedulerHealthRepository {
  private readonly rows = new Map<string, SchedulerHealth>();

  async get(name: string): Promise<SchedulerHealth | null> {
    const row = this.rows.get(name);
    return row === undefined ? null : structuredClone(row);
  }

  async upsert(health: SchedulerHealth): Promise<void> {
    this.rows.set(health.name, structuredClone(health));
  }
}

class InMemoryBusinessConnectionRepository implements BusinessConnectionRepository {
  private readonly byId = new Map<string, BusinessConnection>();
  async upsert(c: BusinessConnection): Promise<void> {
    this.byId.set(c.id, structuredClone(c));
  }
  async findById(id: string): Promise<BusinessConnection | null> {
    const c = this.byId.get(id);
    return c === undefined ? null : structuredClone(c);
  }
  async findLatestEnabled(): Promise<BusinessConnection | null> {
    const list = [...this.byId.values()]
      .filter((c) => c.isEnabled)
      .sort((a, b) => b.updatedAtUtc.localeCompare(a.updatedAtUtc));
    return list[0] ? structuredClone(list[0]) : null;
  }
}

class InMemoryClientLinkRepository implements ClientChatLinkRepository {
  private readonly byMonitor = new Map<string, ClientChatLink>();
  private seq = 0;
  async create(input: NewClientChatLink, nowUtc: string): Promise<ClientChatLink> {
    const link: ClientChatLink = {
      id: `link-${++this.seq}`,
      monitorId: input.monitorId,
      sourceType: input.sourceType,
      clientChatId: input.clientChatId,
      businessConnectionId: input.businessConnectionId,
      ownerTelegramUserId: input.ownerTelegramUserId,
      sourceMessageId: input.sourceMessageId,
      clientDeliveryStatus: 'BUSINESS_DELIVERY_NOT_REQUIRED',
      createdAtUtc: nowUtc,
      updatedAtUtc: nowUtc,
    };
    this.byMonitor.set(input.monitorId, link);
    return structuredClone(link);
  }
  async findByMonitorId(monitorId: string): Promise<ClientChatLink | null> {
    const l = this.byMonitor.get(monitorId);
    return l === undefined ? null : structuredClone(l);
  }
  async listAll(): Promise<ClientChatLink[]> {
    return [...this.byMonitor.values()].map((l) => structuredClone(l));
  }
  async updateDeliveryStatus(
    monitorId: string,
    status: BusinessDeliveryStatus,
    nowUtc: string,
  ): Promise<void> {
    const l = this.byMonitor.get(monitorId);
    if (l !== undefined) {
      l.clientDeliveryStatus = status;
      l.updatedAtUtc = nowUtc;
    }
  }
}

class InMemoryClientsRepository implements ClientsRepository {
  readonly byChat = new Map<number, ClientIdentity>();
  async upsert(identity: NewClientIdentity, nowUtc: string): Promise<void> {
    this.byChat.set(identity.clientChatId, { ...identity, updatedAtUtc: nowUtc });
  }
  async findByChatId(clientChatId: number): Promise<ClientIdentity | null> {
    const c = this.byChat.get(clientChatId);
    return c === undefined ? null : { ...c };
  }
  async listAll(): Promise<ClientIdentity[]> {
    return [...this.byChat.values()].map((c) => ({ ...c }));
  }
}

/** In-memory deletion-watch repo for deletion-worker tests. */
export class InMemoryDeletionWatchRepository implements DeletionWatchRepository {
  readonly rows = new Map<string, DeletionWatch>();
  private nextId = 1;

  private isActive(w: DeletionWatch): boolean {
    return !DELETION_TERMINAL_STATUSES.includes(w.status);
  }

  async create(input: NewDeletionWatchInput, nowUtc: string): Promise<DeletionWatch> {
    const created: DeletionWatch = {
      id: `del-${this.nextId++}`,
      normalizedUsername: input.normalizedUsername,
      originalInput: input.originalInput,
      startedAtUtc: input.startedAtUtc,
      status: 'WATCHING',
      confirmationCount: 0,
      consecutiveUnknownCount: 0,
      nextCheckAtUtc: input.nextCheckAtUtc,
      lastCheckedAtUtc: null,
      lastResult: null,
      confirmedAtUtc: null,
      clearedAtUtc: null,
      notifiedAtUtc: null,
      telegramMessageId: null,
      leaseOwner: null,
      leaseExpiresAtUtc: null,
      createdAtUtc: nowUtc,
      updatedAtUtc: nowUtc,
    };
    this.rows.set(created.id, { ...created });
    return { ...created };
  }

  async findById(id: string): Promise<DeletionWatch | null> {
    const row = this.rows.get(id);
    return row ? { ...row } : null;
  }

  async findActiveByNormalizedUsername(username: string): Promise<DeletionWatch | null> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === username && this.isActive(row)) return { ...row };
    }
    return null;
  }

  async listActive(): Promise<DeletionWatch[]> {
    return [...this.rows.values()].filter((r) => this.isActive(r)).map((r) => ({ ...r }));
  }

  async countActive(): Promise<number> {
    return [...this.rows.values()].filter((r) => this.isActive(r)).length;
  }

  async claimDue(params: DeletionClaimParams): Promise<DeletionWatch[]> {
    const due = [...this.rows.values()].filter((r) => {
      if (!this.isActive(r)) return false;
      if (r.nextCheckAtUtc === null || r.nextCheckAtUtc > params.nowUtc) return false;
      return (
        r.leaseOwner === null ||
        (r.leaseExpiresAtUtc !== null && r.leaseExpiresAtUtc <= params.nowUtc)
      );
    });
    due.sort((a, b) => {
      const ac = a.status === 'CONFIRMING' ? 0 : 1;
      const bc = b.status === 'CONFIRMING' ? 0 : 1;
      if (ac !== bc) return ac - bc;
      return (a.nextCheckAtUtc ?? '').localeCompare(b.nextCheckAtUtc ?? '');
    });
    const claimed = due.slice(0, params.limit);
    for (const row of claimed) {
      row.leaseOwner = params.leaseOwner;
      row.leaseExpiresAtUtc = params.leaseExpiresUtc;
      row.updatedAtUtc = params.nowUtc;
    }
    return claimed.map((r) => ({ ...r }));
  }

  async save(next: DeletionWatch): Promise<void> {
    this.rows.set(next.id, { ...next });
  }

  async releaseLease(id: string, nowUtc: string): Promise<void> {
    const row = this.rows.get(id);
    if (!row) return;
    row.leaseOwner = null;
    row.leaseExpiresAtUtc = null;
    row.updatedAtUtc = nowUtc;
  }

  async clearByNormalizedUsername(
    username: string,
    clearedAtUtc: string,
  ): Promise<DeletionWatch | null> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === username && this.isActive(row)) {
        row.status = 'CLEARED';
        row.clearedAtUtc = clearedAtUtc;
        row.nextCheckAtUtc = null;
        row.leaseOwner = null;
        row.leaseExpiresAtUtc = null;
        row.updatedAtUtc = clearedAtUtc;
        return { ...row };
      }
    }
    return null;
  }
}

/** The full in-memory repository bundle used by worker tests. */
export class InMemoryRepositories implements Repositories {
  readonly owner = new InMemoryOwnerRepository();
  readonly cases = new InMemoryCaseRepository();
  readonly checks = new InMemoryCheckRepository();
  readonly updates = new InMemoryTelegramUpdateRepository();
  readonly outbox = new InMemoryOutboxRepository();
  readonly health = new InMemorySchedulerHealthRepository();
  readonly businessConnections = new InMemoryBusinessConnectionRepository();
  readonly clientLinks = new InMemoryClientLinkRepository();
  readonly clients = new InMemoryClientsRepository();
  readonly deletionWatches = new InMemoryDeletionWatchRepository();
}

/** One scripted probe outcome for the {@link FakeDetector}. */
export interface ScriptedProbe {
  classification: Classification;
  /** Screenshot bytes returned when the probe asks for a capture. */
  screenshot?: Buffer | null;
  errorCode?: DetectorErrorCode | null;
  finalUrl?: string | null;
  responseStatus?: number | null;
  /** Hook run inside the probe — used to simulate mid-check races (/clear). */
  onProbe?: () => void | Promise<void>;
  /**
   * Simulate a check the detector DECLINED to make: circuit breaker open, or governor deferred.
   * The real detector pairs this with UNKNOWN/HTTP_429 and zero network traffic.
   */
  notObserved?: boolean;
}

/**
 * Scriptable detector with a per-username result queue. When a queue runs dry
 * the last served entry is repeated (sticky), and a never-scripted username
 * yields UNKNOWN.
 */
export class FakeDetector implements Detector {
  private readonly queues = new Map<string, ScriptedProbe[]>();
  private readonly sticky = new Map<string, ScriptedProbe>();
  /** Every probe call in order, for assertions. */
  readonly probes: Array<{ username: string; options: ProbeOptions | undefined }> = [];

  script(username: string, ...entries: Array<Classification | ScriptedProbe>): void {
    const queue = this.queues.get(username) ?? [];
    for (const entry of entries) {
      queue.push(typeof entry === 'string' ? { classification: entry } : entry);
    }
    this.queues.set(username, queue);
  }

  async probe(username: string, options?: ProbeOptions): Promise<ProbeResult> {
    this.probes.push({ username, options });
    const queue = this.queues.get(username) ?? [];
    const entry: ScriptedProbe = queue.shift() ??
      this.sticky.get(username) ?? { classification: 'UNKNOWN', errorCode: 'UNKNOWN_ERROR' };
    this.sticky.set(username, entry);

    if (entry.onProbe !== undefined) {
      await entry.onProbe();
    }

    const classification = entry.classification;
    const result: ProbeResult = {
      result: {
        classification,
        evidence: {
          signalsVersion: SIGNALS_VERSION,
          activeSignals:
            classification === 'ACTIVE'
              ? ['url_on_username_path', 'canonical_matches_username']
              : [],
          goneSignals: classification === 'GONE' ? ['unavailable_message_present'] : [],
          identitySignalMatched: classification === 'ACTIVE',
          finalUrl:
            entry.finalUrl !== undefined
              ? entry.finalUrl
              : `https://www.instagram.com/${username}/`,
          responseStatus:
            entry.responseStatus !== undefined
              ? entry.responseStatus
              : classification === 'GONE'
                ? 404
                : 200,
          errorCode:
            entry.errorCode !== undefined
              ? entry.errorCode
              : classification === 'UNKNOWN'
                ? 'UNKNOWN_ERROR'
                : null,
        },
        durationMs: 12,
      },
      screenshot:
        options?.captureScreenshot === true &&
        entry.screenshot !== null &&
        entry.screenshot !== undefined
          ? { buffer: entry.screenshot, format: 'png', width: 1280, height: 720 }
          : null,
      ...(entry.notObserved === true ? { notObserved: true } : {}),
    };
    return result;
  }
}
