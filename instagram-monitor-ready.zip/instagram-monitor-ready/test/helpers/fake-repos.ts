/**
 * Dependency-free in-memory implementation of the full {@link Repositories} +
 * {@link Database} contracts for unit tests. Faithful to the SQL semantics that
 * matter: partial-unique active username on create (DUPLICATE_CASE), single-winner
 * notification claims, idempotent outbox enqueue per (case, kind), and update dedup.
 */

import type {
  CaseRepository,
  CaseStatus,
  CheckRecord,
  CheckRepository,
  ClaimDueParams,
  Database,
  EnqueueOutbox,
  MonitoringCase,
  NewCaseInput,
  NewCheckInput,
  OutboxItem,
  OutboxKind,
  OutboxRepository,
  OwnerRepository,
  Repositories,
  SchedulerHealth,
  SchedulerHealthRepository,
  TelegramUpdateRepository,
  BusinessConnectionRepository,
  ClientChatLinkRepository,
  BusinessConnection,
  ClientChatLink,
  NewClientChatLink,
  BusinessDeliveryStatus,
  DeletionWatchRepository,
  DeletionWatch,
  NewDeletionWatchInput,
  DeletionClaimParams,
  ClientsRepository,
  ClientIdentity,
  NewClientIdentity,
} from '../../src/domain';
// Not re-exported by the domain barrel yet, so it is imported from the module that owns it.
import type { BreakerStateRecord, BreakerStateRepository } from '../../src/domain/repositories';
import { AppError, TERMINAL_STATUSES, DELETION_TERMINAL_STATUSES } from '../../src/domain';

function isActiveStatus(status: CaseStatus): boolean {
  return !TERMINAL_STATUSES.includes(status);
}

function copyCase(c: MonitoringCase): MonitoringCase {
  return { ...c };
}

class FakeOwnerRepository implements OwnerRepository {
  private ownerId: number | null = null;

  async getOwnerTelegramId(): Promise<number | null> {
    return this.ownerId;
  }

  async claimOwner(telegramUserId: number, _pairedAtUtc: string): Promise<boolean> {
    if (this.ownerId !== null) return false;
    this.ownerId = telegramUserId;
    return true;
  }
}

class FakeCaseRepository implements CaseRepository {
  readonly rows = new Map<string, MonitoringCase>();
  private nextId = 1;

  async create(input: NewCaseInput, nowUtc: string): Promise<MonitoringCase> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === input.normalizedUsername && isActiveStatus(row.status)) {
        throw new AppError(
          'DUPLICATE_CASE',
          `An active case already exists for ${input.normalizedUsername}`,
          'already monitoring',
        );
      }
    }
    const created: MonitoringCase = {
      id: `case-${this.nextId++}`,
      normalizedUsername: input.normalizedUsername,
      originalInput: input.originalInput,
      startedAtUtc: input.startedAtUtc,
      status: 'MONITORING',
      confirmationCount: 0,
      nextCheckAtUtc: input.nextCheckAtUtc,
      lastCheckedAtUtc: null,
      lastResult: null,
      consecutiveUnknownCount: 0,
      errorBackoffUntilUtc: null,
      confirmedAtUtc: null,
      clearedAtUtc: null,
      notificationClaimedAtUtc: null,
      notificationSentAtUtc: null,
      telegramMessageId: null,
      screenshotStatus: 'NONE',
      leaseOwner: null,
      leaseExpiresAtUtc: null,
      createdAtUtc: nowUtc,
      updatedAtUtc: nowUtc,
    };
    this.rows.set(created.id, created);
    return copyCase(created);
  }

  async findById(id: string): Promise<MonitoringCase | null> {
    const row = this.rows.get(id);
    return row ? copyCase(row) : null;
  }

  async findActiveByNormalizedUsername(username: string): Promise<MonitoringCase | null> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === username && isActiveStatus(row.status)) {
        return copyCase(row);
      }
    }
    return null;
  }

  async listByStatuses(statuses: readonly CaseStatus[]): Promise<MonitoringCase[]> {
    return [...this.rows.values()].filter((r) => statuses.includes(r.status)).map(copyCase);
  }

  async countByStatuses(statuses: readonly CaseStatus[]): Promise<number> {
    return [...this.rows.values()].filter((r) => statuses.includes(r.status)).length;
  }

  async claimDueCases(params: ClaimDueParams): Promise<MonitoringCase[]> {
    const due = [...this.rows.values()].filter((r) => {
      if (!isActiveStatus(r.status)) return false;
      if (r.nextCheckAtUtc === null || r.nextCheckAtUtc > params.nowUtc) return false;
      const leaseFree =
        r.leaseOwner === null ||
        (r.leaseExpiresAtUtc !== null && r.leaseExpiresAtUtc <= params.nowUtc);
      return leaseFree;
    });
    // Confirmation cases first, then earliest due.
    due.sort((a, b) => {
      const aConfirming = a.status === 'CONFIRMING' ? 0 : 1;
      const bConfirming = b.status === 'CONFIRMING' ? 0 : 1;
      if (aConfirming !== bConfirming) return aConfirming - bConfirming;
      return (a.nextCheckAtUtc ?? '').localeCompare(b.nextCheckAtUtc ?? '');
    });
    const claimed = due.slice(0, params.limit);
    for (const row of claimed) {
      row.leaseOwner = params.leaseOwner;
      row.leaseExpiresAtUtc = params.leaseExpiresUtc;
      row.updatedAtUtc = params.nowUtc;
    }
    return claimed.map(copyCase);
  }

  async save(next: MonitoringCase): Promise<void> {
    this.rows.set(next.id, copyCase(next));
  }

  async releaseLease(id: string, nowUtc: string): Promise<void> {
    const row = this.rows.get(id);
    if (!row) return;
    row.leaseOwner = null;
    row.leaseExpiresAtUtc = null;
    row.updatedAtUtc = nowUtc;
  }

  async clearByNormalizedUsername(
    username: string,
    clearedAtUtc: string,
  ): Promise<MonitoringCase | null> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === username && isActiveStatus(row.status)) {
        row.status = 'CLEARED';
        row.clearedAtUtc = clearedAtUtc;
        row.nextCheckAtUtc = null;
        row.leaseOwner = null;
        row.leaseExpiresAtUtc = null;
        row.updatedAtUtc = clearedAtUtc;
        return copyCase(row);
      }
    }
    return null;
  }

  async claimNotification(caseId: string, claimedAtUtc: string): Promise<boolean> {
    const row = this.rows.get(caseId);
    if (!row || row.notificationClaimedAtUtc !== null) return false;
    row.notificationClaimedAtUtc = claimedAtUtc;
    row.updatedAtUtc = claimedAtUtc;
    return true;
  }
}

class FakeCheckRepository implements CheckRepository {
  private readonly rows: CheckRecord[] = [];
  private nextId = 1;

  async insert(input: NewCheckInput): Promise<CheckRecord> {
    const record: CheckRecord = {
      id: `check-${this.nextId++}`,
      caseId: input.caseId,
      checkedAtUtc: input.checkedAtUtc,
      classification: input.classification,
      finalUrl: input.finalUrl,
      responseStatus: input.responseStatus,
      durationMs: input.durationMs,
      activeSignals: [...input.activeSignals],
      goneSignals: [...input.goneSignals],
      errorCode: input.errorCode,
      confirmationSeq: input.confirmationSeq,
    };
    this.rows.push(record);
    return {
      ...record,
      activeSignals: [...record.activeSignals],
      goneSignals: [...record.goneSignals],
    };
  }

  async countByCase(caseId: string): Promise<number> {
    return this.rows.filter((r) => r.caseId === caseId).length;
  }
}

class FakeTelegramUpdateRepository implements TelegramUpdateRepository {
  private readonly seen = new Set<number>();

  async registerIfNew(updateId: number, _receivedAtUtc: string): Promise<boolean> {
    if (this.seen.has(updateId)) return false;
    this.seen.add(updateId);
    return true;
  }
}

class FakeOutboxRepository implements OutboxRepository {
  private readonly rows = new Map<string, OutboxItem>();
  private nextId = 1;

  constructor(private readonly cases: FakeCaseRepository) {}

  private key(caseId: string, kind: OutboxItem['kind']): string {
    return `${caseId}:${kind}`;
  }

  async enqueue(item: EnqueueOutbox): Promise<OutboxItem> {
    const key = this.key(item.caseId, item.kind);
    const existing = this.rows.get(key);
    if (existing) return { ...existing };
    const created: OutboxItem = {
      id: `outbox-${this.nextId++}`,
      caseId: item.caseId,
      kind: item.kind,
      status: 'PENDING',
      attempts: 0,
      claimedAtUtc: null,
      sentAtUtc: null,
      lastError: null,
      telegramMessageId: null,
      createdAtUtc: item.createdAtUtc,
      updatedAtUtc: item.createdAtUtc,
    };
    this.rows.set(key, created);
    return { ...created };
  }

  async findByCase(caseId: string): Promise<OutboxItem[]> {
    return [...this.rows.values()].filter((r) => r.caseId === caseId).map((r) => ({ ...r }));
  }

  async claimNextPending(nowUtc: string): Promise<OutboxItem | null> {
    const pending = [...this.rows.values()]
      .filter((r) => r.status === 'PENDING')
      .filter((r) => this.cases.rows.get(r.caseId)?.status !== 'CLEARED')
      .sort((a, b) => a.createdAtUtc.localeCompare(b.createdAtUtc));
    const next = pending[0];
    if (next === undefined) return null;
    next.status = 'CLAIMED';
    next.claimedAtUtc = nowUtc;
    next.attempts += 1;
    next.updatedAtUtc = nowUtc;
    return { ...next };
  }

  private byId(id: string): OutboxItem | undefined {
    return [...this.rows.values()].find((r) => r.id === id);
  }

  async markSent(id: string, sentAtUtc: string, telegramMessageId: number | null): Promise<void> {
    const row = this.byId(id);
    if (!row) return;
    row.status = 'SENT';
    row.sentAtUtc = sentAtUtc;
    row.telegramMessageId = telegramMessageId;
    row.updatedAtUtc = sentAtUtc;
  }

  async markFailed(id: string, error: string, nowUtc: string): Promise<void> {
    const row = this.byId(id);
    if (!row) return;
    if (row.status === 'SENT') return; // a delivered row is never demoted (see OutboxRepository)
    row.status = 'FAILED';
    row.lastError = error;
    row.updatedAtUtc = nowUtc;
  }

  async reopenFailed(caseId: string, kind: OutboxKind, nowUtc: string): Promise<boolean> {
    const row = this.rows.get(this.key(caseId, kind));
    if (row === undefined || row.status !== 'FAILED') return false;
    row.status = 'PENDING';
    row.attempts = 0;
    row.claimedAtUtc = null;
    row.lastError = null;
    row.createdAtUtc = nowUtc;
    row.updatedAtUtc = nowUtc;
    return true;
  }

  async requeueStale(olderThanUtc: string, nowUtc: string): Promise<number> {
    let count = 0;
    for (const row of this.rows.values()) {
      if (
        row.status === 'CLAIMED' &&
        row.claimedAtUtc !== null &&
        row.claimedAtUtc < olderThanUtc
      ) {
        row.status = 'PENDING';
        row.claimedAtUtc = null;
        row.updatedAtUtc = nowUtc;
        count += 1;
      }
    }
    return count;
  }

  async countPending(): Promise<number> {
    return [...this.rows.values()].filter((r) => r.status === 'PENDING').length;
  }

  async oldestPendingAgeMs(nowUtc: string): Promise<number | null> {
    const pending = [...this.rows.values()].filter((r) => r.status === 'PENDING');
    if (pending.length === 0) return null;
    const oldest = pending.reduce((a, b) => (a.createdAtUtc <= b.createdAtUtc ? a : b));
    return new Date(nowUtc).getTime() - new Date(oldest.createdAtUtc).getTime();
  }
}

class FakeBreakerStateRepository implements BreakerStateRepository {
  readonly rows = new Map<string, BreakerStateRecord>();

  async get(name: string): Promise<BreakerStateRecord | null> {
    const row = this.rows.get(name);
    return row ? { ...row } : null;
  }

  async save(record: BreakerStateRecord): Promise<void> {
    this.rows.set(record.name, { ...record });
  }
}

class FakeSchedulerHealthRepository implements SchedulerHealthRepository {
  private readonly rows = new Map<string, SchedulerHealth>();

  async get(name: string): Promise<SchedulerHealth | null> {
    const row = this.rows.get(name);
    return row ? { ...row } : null;
  }

  async upsert(health: SchedulerHealth): Promise<void> {
    this.rows.set(health.name, { ...health });
  }
}

/** In-memory {@link Database}; `pingResult`/`pingError` let tests break `/ping`. */
export class FakeDatabase implements Database {
  pingResult = true;
  pingError: Error | null = null;

  constructor(private readonly repos: Repositories) {}

  async migrate(): Promise<void> {
    // No schema in memory.
  }

  repositories(): Repositories {
    return this.repos;
  }

  async ping(): Promise<boolean> {
    if (this.pingError !== null) throw this.pingError;
    return this.pingResult;
  }

  async close(): Promise<void> {
    // Nothing to release.
  }
}

class FakeBusinessConnectionRepository implements BusinessConnectionRepository {
  readonly byId = new Map<string, BusinessConnection>();
  async upsert(c: BusinessConnection): Promise<void> {
    this.byId.set(c.id, structuredClone(c));
  }
  async findById(id: string): Promise<BusinessConnection | null> {
    const c = this.byId.get(id);
    return c === undefined ? null : structuredClone(c);
  }
  async findLatestEnabled(): Promise<BusinessConnection | null> {
    const enabled = [...this.byId.values()]
      .filter((c) => c.isEnabled)
      .sort((a, b) => b.updatedAtUtc.localeCompare(a.updatedAtUtc));
    return enabled[0] ? structuredClone(enabled[0]) : null;
  }
}

class FakeClientLinkRepository implements ClientChatLinkRepository {
  readonly byMonitor = new Map<string, ClientChatLink>();
  private seq = 0;
  async create(input: NewClientChatLink, nowUtc: string): Promise<ClientChatLink> {
    // Faithful to the drivers' guarded upsert: a link owned by a DIFFERENT client chat is left
    // exactly as it is and handed back, so the caller can see it lost and refuse.
    const owned = this.byMonitor.get(input.monitorId);
    if (owned !== undefined && owned.clientChatId !== input.clientChatId) {
      return structuredClone(owned);
    }
    const link: ClientChatLink = {
      id: owned?.id ?? `link-${++this.seq}`,
      monitorId: input.monitorId,
      sourceType: input.sourceType,
      clientChatId: input.clientChatId,
      businessConnectionId: input.businessConnectionId,
      ownerTelegramUserId: input.ownerTelegramUserId,
      sourceMessageId: input.sourceMessageId,
      // Re-running from the same chat must not undo a delivery status already reached.
      clientDeliveryStatus: owned?.clientDeliveryStatus ?? 'BUSINESS_DELIVERY_NOT_REQUIRED',
      createdAtUtc: owned?.createdAtUtc ?? nowUtc,
      updatedAtUtc: nowUtc,
    };
    this.byMonitor.set(input.monitorId, link);
    return structuredClone(link);
  }
  async findByMonitorId(monitorId: string): Promise<ClientChatLink | null> {
    const l = this.byMonitor.get(monitorId);
    return l === undefined ? null : structuredClone(l);
  }
  async listAll(): Promise<ClientChatLink[]> {
    return [...this.byMonitor.values()].map((l) => structuredClone(l));
  }
  async updateDeliveryStatus(
    monitorId: string,
    status: BusinessDeliveryStatus,
    nowUtc: string,
  ): Promise<void> {
    const l = this.byMonitor.get(monitorId);
    if (l !== undefined) {
      l.clientDeliveryStatus = status;
      l.updatedAtUtc = nowUtc;
    }
  }
}

class FakeClientsRepository implements ClientsRepository {
  readonly byChat = new Map<number, ClientIdentity>();
  async upsert(identity: NewClientIdentity, nowUtc: string): Promise<void> {
    this.byChat.set(identity.clientChatId, { ...identity, updatedAtUtc: nowUtc });
  }
  async findByChatId(clientChatId: number): Promise<ClientIdentity | null> {
    const c = this.byChat.get(clientChatId);
    return c === undefined ? null : { ...c };
  }
  async listAll(): Promise<ClientIdentity[]> {
    return [...this.byChat.values()].map((c) => ({ ...c }));
  }
}

class FakeDeletionWatchRepository implements DeletionWatchRepository {
  readonly rows = new Map<string, DeletionWatch>();
  private nextId = 1;

  private isActive(w: DeletionWatch): boolean {
    return !DELETION_TERMINAL_STATUSES.includes(w.status);
  }

  async create(input: NewDeletionWatchInput, nowUtc: string): Promise<DeletionWatch> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === input.normalizedUsername && this.isActive(row)) {
        throw new AppError(
          'DUPLICATE_CASE',
          `An active deletion watch already exists for ${input.normalizedUsername}`,
          'already watching',
        );
      }
    }
    const created: DeletionWatch = {
      id: `del-${this.nextId++}`,
      normalizedUsername: input.normalizedUsername,
      originalInput: input.originalInput,
      startedAtUtc: input.startedAtUtc,
      status: 'WATCHING',
      confirmationCount: 0,
      consecutiveUnknownCount: 0,
      nextCheckAtUtc: input.nextCheckAtUtc,
      lastCheckedAtUtc: null,
      lastResult: null,
      confirmedAtUtc: null,
      clearedAtUtc: null,
      notifiedAtUtc: null,
      telegramMessageId: null,
      leaseOwner: null,
      leaseExpiresAtUtc: null,
      createdAtUtc: nowUtc,
      updatedAtUtc: nowUtc,
    };
    this.rows.set(created.id, { ...created });
    return { ...created };
  }

  async findById(id: string): Promise<DeletionWatch | null> {
    const row = this.rows.get(id);
    return row ? { ...row } : null;
  }

  async findActiveByNormalizedUsername(username: string): Promise<DeletionWatch | null> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === username && this.isActive(row)) return { ...row };
    }
    return null;
  }

  async listActive(): Promise<DeletionWatch[]> {
    return [...this.rows.values()].filter((r) => this.isActive(r)).map((r) => ({ ...r }));
  }

  async countActive(): Promise<number> {
    return [...this.rows.values()].filter((r) => this.isActive(r)).length;
  }

  async claimDue(params: DeletionClaimParams): Promise<DeletionWatch[]> {
    const due = [...this.rows.values()].filter((r) => {
      if (!this.isActive(r)) return false;
      if (r.nextCheckAtUtc === null || r.nextCheckAtUtc > params.nowUtc) return false;
      return (
        r.leaseOwner === null ||
        (r.leaseExpiresAtUtc !== null && r.leaseExpiresAtUtc <= params.nowUtc)
      );
    });
    due.sort((a, b) => {
      const ac = a.status === 'CONFIRMING' ? 0 : 1;
      const bc = b.status === 'CONFIRMING' ? 0 : 1;
      if (ac !== bc) return ac - bc;
      return (a.nextCheckAtUtc ?? '').localeCompare(b.nextCheckAtUtc ?? '');
    });
    const claimed = due.slice(0, params.limit);
    for (const row of claimed) {
      row.leaseOwner = params.leaseOwner;
      row.leaseExpiresAtUtc = params.leaseExpiresUtc;
      row.updatedAtUtc = params.nowUtc;
    }
    return claimed.map((r) => ({ ...r }));
  }

  async save(next: DeletionWatch): Promise<void> {
    this.rows.set(next.id, { ...next });
  }

  async releaseLease(id: string, nowUtc: string): Promise<void> {
    const row = this.rows.get(id);
    if (!row) return;
    row.leaseOwner = null;
    row.leaseExpiresAtUtc = null;
    row.updatedAtUtc = nowUtc;
  }

  async clearByNormalizedUsername(
    username: string,
    clearedAtUtc: string,
  ): Promise<DeletionWatch | null> {
    for (const row of this.rows.values()) {
      if (row.normalizedUsername === username && this.isActive(row)) {
        row.status = 'CLEARED';
        row.clearedAtUtc = clearedAtUtc;
        row.nextCheckAtUtc = null;
        row.leaseOwner = null;
        row.leaseExpiresAtUtc = null;
        row.updatedAtUtc = clearedAtUtc;
        return { ...row };
      }
    }
    return null;
  }
}

/** Build a fresh in-memory Database + Repositories pair. */
export function makeFakeDb(): { db: FakeDatabase; repos: Repositories } {
  const cases = new FakeCaseRepository();
  const repos: Repositories = {
    owner: new FakeOwnerRepository(),
    cases,
    checks: new FakeCheckRepository(),
    updates: new FakeTelegramUpdateRepository(),
    outbox: new FakeOutboxRepository(cases),
    health: new FakeSchedulerHealthRepository(),
    breakerState: new FakeBreakerStateRepository(),
    businessConnections: new FakeBusinessConnectionRepository(),
    clientLinks: new FakeClientLinkRepository(),
    clients: new FakeClientsRepository(),
    deletionWatches: new FakeDeletionWatchRepository(),
  };
  return { db: new FakeDatabase(repos), repos };
}
