/**
 * Seedable {@link Detector} fake. Each `probe(username)` shifts the next queued
 * classification for that username (default UNKNOWN) and records the call. When a
 * screenshot is requested and the result is ACTIVE, it returns a fake 1x1 PNG buffer
 * that starts with the real PNG magic bytes.
 */

import type {
  Classification,
  Detector,
  DetectorResult,
  ProbeOptions,
  ProbeResult,
  Screenshot,
} from '../../src/domain';
import { ACTIVE_SIGNALS, GONE_SIGNALS, SIGNALS_VERSION } from '../../src/domain';

const PNG_MAGIC = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

/** Minimal but structurally valid PNG-looking buffer (magic bytes + padding). */
export function fakePngBuffer(): Buffer {
  return Buffer.concat([PNG_MAGIC, Buffer.alloc(56)]);
}

/** A fully-specified scripted probe outcome (for cases the bare classification can't express). */
export interface ScriptedProbeEntry {
  classification: Classification;
  /**
   * Override the returned screenshot. Omit for the default (a fake PNG when ACTIVE). Pass
   * `null` to force NO screenshot even when ACTIVE — e.g. a login-gated profile.
   */
  screenshot?: Buffer | null;
  /** Override evidence.activeSignals (e.g. to simulate a visibly-rendered vs login-gated page). */
  activeSignals?: string[];
}

export class FakeDetector implements Detector {
  /** Every probe call, in order. */
  readonly probes: { username: string; options: ProbeOptions | undefined }[] = [];

  private readonly queues = new Map<string, ScriptedProbeEntry[]>();

  /** Seed the next outcome(s) returned for `username` (FIFO). Accepts a bare classification. */
  queue(username: string, result: Classification | ScriptedProbeEntry): void {
    const entry: ScriptedProbeEntry =
      typeof result === 'string' ? { classification: result } : result;
    const existing = this.queues.get(username);
    if (existing) {
      existing.push(entry);
    } else {
      this.queues.set(username, [entry]);
    }
  }

  async probe(username: string, options?: ProbeOptions): Promise<ProbeResult> {
    this.probes.push({ username, options });
    const entry = this.queues.get(username)?.shift() ?? {
      classification: 'UNKNOWN' as Classification,
    };
    const classification = entry.classification;

    const result: DetectorResult = {
      classification,
      evidence: {
        signalsVersion: SIGNALS_VERSION,
        activeSignals:
          entry.activeSignals ??
          (classification === 'ACTIVE'
            ? [ACTIVE_SIGNALS.URL_ON_USERNAME_PATH, ACTIVE_SIGNALS.CANONICAL_MATCHES]
            : []),
        goneSignals: classification === 'GONE' ? [GONE_SIGNALS.UNAVAILABLE_MESSAGE] : [],
        identitySignalMatched: classification === 'ACTIVE',
        finalUrl: `https://www.instagram.com/${username}/`,
        responseStatus: classification === 'UNKNOWN' ? null : 200,
        errorCode: classification === 'UNKNOWN' ? 'UNKNOWN_ERROR' : null,
      },
      durationMs: 5,
    };

    // Screenshot: explicit override wins ('screenshot' key present); otherwise default to a fake
    // PNG for ACTIVE. A null override forces "no screenshot" (e.g. a login-gated control page).
    let screenshot: Screenshot | null = null;
    if (options?.captureScreenshot === true) {
      const bytes =
        'screenshot' in entry
          ? entry.screenshot
          : classification === 'ACTIVE'
            ? fakePngBuffer()
            : null;
      if (bytes) {
        screenshot = { buffer: bytes, format: 'png', width: 1, height: 1 };
      }
    }

    return { result, screenshot };
  }
}
