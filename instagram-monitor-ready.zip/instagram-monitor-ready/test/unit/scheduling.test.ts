import { describe, it, expect } from 'vitest';
import type { SchedulingParams } from '../../src/monitoring/scheduling';
import {
  applyJitter,
  baselineIntervalSeconds,
  nextBaselineCheckAt,
  nextConfirmationCheckAt,
  nextRetryCheckAt,
  retryDelaySeconds,
} from '../../src/monitoring/scheduling';

const params: SchedulingParams = {
  baselineIntervalSeconds: 15,
  baselineJitterMaxSeconds: 2,
  confirmationIntervalSeconds: 5,
  confirmationRequiredCount: 3,
  confirmationDeadlineSeconds: 30,
  retryDelaysSeconds: [5, 10, 15, 30],
  errorBackoffMaxSeconds: 30,
  unknownBackoffBaseSeconds: 60,
  unknownBackoffMaxSeconds: 1800,
  errorBackoffInitialSeconds: 15,
};

const NOW = new Date('2026-07-17T00:00:00.000Z');

describe('baselineIntervalSeconds', () => {
  it('is FLAT and fleet-independent — four accounts are not four times slower', () => {
    expect(baselineIntervalSeconds(1, params)).toBe(15);
    expect(baselineIntervalSeconds(2, params)).toBe(15);
    expect(baselineIntervalSeconds(5, params)).toBe(15);
    expect(baselineIntervalSeconds(10, params)).toBe(15);
    expect(baselineIntervalSeconds(0, params)).toBe(15);
  });
});

describe('baselineIntervalSeconds under browser-load pressure', () => {
  // The ONE thing allowed to stretch the baseline: the fleet-wide Chromium page-load budget, which
  // is a property of the shared residential IP rather than of the fleet size. Without this the
  // ESCALATION_STORM signal had nothing to drive — it only ever printed a line in /ping while the
  // fleet ran at 20-50x normal load, invisible to the circuit breaker because escalated browser
  // probes SUCCEED.
  it('stretches the baseline by the governor multiplier', () => {
    expect(baselineIntervalSeconds(1, { ...params, baselineIntervalMultiplier: 4 })).toBe(60);
    expect(baselineIntervalSeconds(9, { ...params, baselineIntervalMultiplier: 8 })).toBe(120);
  });

  it('is unchanged when there is no pressure, or no multiplier at all', () => {
    expect(baselineIntervalSeconds(1, params)).toBe(15);
    expect(baselineIntervalSeconds(1, { ...params, baselineIntervalMultiplier: 1 })).toBe(15);
  });

  it('clamps a garbage multiplier at both ends', () => {
    // Below 1 would SPEED THE FLEET UP under pressure — the opposite of the point — and an absurd
    // value would park every account for hours. Neither may be reachable from a bad reading.
    expect(baselineIntervalSeconds(1, { ...params, baselineIntervalMultiplier: 0 })).toBe(15);
    expect(baselineIntervalSeconds(1, { ...params, baselineIntervalMultiplier: -5 })).toBe(15);
    expect(baselineIntervalSeconds(1, { ...params, baselineIntervalMultiplier: Number.NaN })).toBe(
      15,
    );
    expect(baselineIntervalSeconds(1, { ...params, baselineIntervalMultiplier: 1e9 })).toBe(120);
  });

  it('does NOT slow the confirmation cadence or the retry ladder', () => {
    // Both are spent inside an event that has already happened, or chasing a check that failed.
    // Slowing them costs the client latency on the one path that matters and saves no load.
    const throttled: SchedulingParams = { ...params, baselineIntervalMultiplier: 8 };
    expect(nextConfirmationCheckAt(NOW, throttled)).toBe('2026-07-17T00:00:05.000Z');
    expect(nextRetryCheckAt(NOW, 1, throttled, () => 0)).toBe('2026-07-17T00:00:05.000Z');
    // ...and the baseline in the same params IS stretched, so this is a real distinction.
    expect(nextBaselineCheckAt(NOW, 1, throttled, () => 0)).toBe('2026-07-17T00:02:00.000Z');
  });
});

describe('retryDelaySeconds — short bounded ladder', () => {
  it('walks the ladder and repeats the last entry, capped at the max', () => {
    expect(retryDelaySeconds(1, params)).toBe(5);
    expect(retryDelaySeconds(2, params)).toBe(10);
    expect(retryDelaySeconds(3, params)).toBe(15);
    expect(retryDelaySeconds(4, params)).toBe(30);
    // Beyond the ladder, the last entry repeats and never exceeds the cap.
    expect(retryDelaySeconds(5, params)).toBe(30);
    expect(retryDelaySeconds(50, params)).toBe(30);
  });

  it('hard-caps a too-long ladder entry at errorBackoffMaxSeconds', () => {
    const capped: SchedulingParams = {
      ...params,
      retryDelaysSeconds: [5, 999],
      errorBackoffMaxSeconds: 30,
    };
    expect(retryDelaySeconds(2, capped)).toBe(30);
  });
});

describe('applyJitter — absolute [0, maxJitter]', () => {
  it('applies zero jitter at rand() === 0', () => {
    expect(applyJitter(100, 2, () => 0)).toBe(100);
  });

  it('adds up to maxJitter seconds', () => {
    expect(applyJitter(100, 2, () => 0.5)).toBe(101);
    expect(applyJitter(100, 2, () => 0.999)).toBeLessThanOrEqual(102);
    expect(applyJitter(100, 2, () => 0.999)).toBeGreaterThanOrEqual(100);
  });

  it('never returns below 1 second', () => {
    expect(applyJitter(1, 0, () => 0)).toBeGreaterThanOrEqual(1);
    expect(applyJitter(0, 0, () => 0)).toBeGreaterThanOrEqual(1);
  });
});

describe('nextConfirmationCheckAt', () => {
  it('is exactly now + confirmationIntervalSeconds with no jitter', () => {
    expect(nextConfirmationCheckAt(NOW, params)).toBe('2026-07-17T00:00:05.000Z');
  });
});

describe('nextBaselineCheckAt', () => {
  it('adds the flat baseline interval (exact at zero jitter)', () => {
    expect(nextBaselineCheckAt(NOW, 1, params, () => 0)).toBe('2026-07-17T00:00:15.000Z');
    expect(nextBaselineCheckAt(NOW, 4, params, () => 0)).toBe('2026-07-17T00:00:15.000Z');
  });
});

describe('nextRetryCheckAt', () => {
  it('schedules the ladder delay from now (exact at zero jitter)', () => {
    expect(nextRetryCheckAt(NOW, 1, params, () => 0)).toBe('2026-07-17T00:00:05.000Z');
    expect(nextRetryCheckAt(NOW, 2, params, () => 0)).toBe('2026-07-17T00:00:10.000Z');
    expect(nextRetryCheckAt(NOW, 4, params, () => 0)).toBe('2026-07-17T00:00:30.000Z');
  });
});
