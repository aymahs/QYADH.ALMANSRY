import { describe, it, expect } from 'vitest';

import { PollingLoop } from '../../src/app/polling';
import { MockTelegramClient } from '../../src/bot/telegram-client';
import type { TelegramUpdate } from '../../src/domain/telegram';
import { nullLogger } from '../../src/logging/logger';

function update(id: number): TelegramUpdate {
  return { update_id: id };
}

function getUpdatesOffsets(client: MockTelegramClient): number[] {
  return client.calls
    .filter((c) => c.method === 'getUpdates')
    .map((c) => (c.params as { offset: number }).offset);
}

describe('PollingLoop', () => {
  it('dispatches updates in order with advancing offsets, and stop() terminates', async () => {
    const client = new MockTelegramClient();
    client.enqueueUpdates([update(10)]);
    client.enqueueUpdates([update(11)]);

    const received: number[] = [];
    let resolveDone: () => void = () => undefined;
    const done = new Promise<void>((resolve) => {
      resolveDone = resolve;
    });

    const loop = new PollingLoop({
      client,
      onUpdate: async (u) => {
        received.push(u.update_id);
        if (received.length === 2) {
          resolveDone();
        }
      },
      logger: nullLogger(),
    });

    loop.start();
    await done;
    await loop.stop(); // must resolve — the loop exits (queue empty -> [] batches)

    expect(received).toEqual([10, 11]);

    const offsets = getUpdatesOffsets(client);
    // First poll starts at 0; after update 10 the offset advances to 11.
    expect(offsets[0]).toBe(0);
    expect(offsets[1]).toBe(11);
    // Any further (empty) polls before stop() landed must use the final offset 12.
    expect(offsets.slice(2).every((o) => o === 12)).toBe(true);

    // Loop is fully stopped: no more getUpdates calls occur afterwards.
    const callsAfterStop = client.calls.length;
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(client.calls.length).toBe(callsAfterStop);
  });

  it('keeps polling when an update handler throws (try/catch each)', async () => {
    const client = new MockTelegramClient();
    client.enqueueUpdates([update(1)]);
    client.enqueueUpdates([update(2)]);

    const received: number[] = [];
    let resolveDone: () => void = () => undefined;
    const done = new Promise<void>((resolve) => {
      resolveDone = resolve;
    });

    const loop = new PollingLoop({
      client,
      onUpdate: async (u) => {
        received.push(u.update_id);
        if (u.update_id === 2) {
          resolveDone();
        }
        if (u.update_id === 1) {
          throw new Error('handler failure');
        }
      },
      logger: nullLogger(),
    });

    loop.start();
    await done;
    await loop.stop();

    expect(received).toEqual([1, 2]);
    // The failed update was still acknowledged: offset advanced past it.
    const offsets = getUpdatesOffsets(client);
    expect(offsets[1]).toBe(2);
  });

  it('stop() before start() resolves immediately', async () => {
    const loop = new PollingLoop({
      client: new MockTelegramClient(),
      onUpdate: async () => undefined,
      logger: nullLogger(),
    });
    await expect(loop.stop()).resolves.toBeUndefined();
  });
});
