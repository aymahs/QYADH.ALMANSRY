import { describe, it, expect } from 'vitest';

import { DiscordCommands } from '../../src/bot/discord/discord-commands';
import type {
  DiscordCommandInvocation,
  DiscordResponder,
} from '../../src/bot/discord/discord-commands';
import type { DiscordEmbed } from '../../src/bot/discord/discord-embeds';
import { CommandRouter } from '../../src/bot/commands';
import { OwnerAuthorizer } from '../../src/bot/authorization';
import { MockTelegramClient } from '../../src/bot/telegram-client';
import { loadConfig } from '../../src/config';
import type { AppConfig } from '../../src/config';
import { FixedClock } from '../../src/domain';
import type { Repositories, TelegramUpdate } from '../../src/domain';
import { nullLogger } from '../../src/logging/logger';
import type { FastTierReport } from '../../src/instagram/detector/tiered-detector';
import { ProxySwitch } from '../../src/instagram/proxy-switch';
import type { ProxyMode } from '../../src/instagram/proxy-switch';
import { FakeDetector } from '../helpers/fake-detector';
import { makeFakeDb } from '../helpers/fake-repos';

const NOW = new Date('2026-07-17T12:00:00.000Z');
const TEST_ENV = {
  TELEGRAM_BOT_TOKEN: '123456789:AAtesttokenAAAAAAAAAAAAAAAAAAAAAAAA',
  OWNER_PAIRING_SECRET: 'pair-secret-123',
};

/** A detector that also exposes the fast-tier diagnostics surface (as TieredDetector does). */
class DiagnosticFakeDetector extends FakeDetector {
  fastTier: FastTierReport = {
    state: 'ok',
    detail: 'the control account resolves over the current egress route',
    canaryHealthy: true,
    breakerState: 'CLOSED',
    breakerRetryAfterMs: 0,
    answered: { fast: 0, browser: 0, blocked: 0, deferred: 0 },
    consecutiveEscalations: 0,
    browserBudget: null,
  };

  breakerSnapshot(): {
    state: 'CLOSED' | 'OPEN' | 'HALF_OPEN';
    consecutive: number;
    retryAfterMs: number;
  } {
    return {
      state: this.fastTier.breakerState,
      consecutive: 0,
      retryAfterMs: this.fastTier.breakerRetryAfterMs,
    };
  }

  browserBudget(): FastTierReport['browserBudget'] {
    return this.fastTier.browserBudget;
  }

  fastTierReport(): Promise<FastTierReport> {
    return Promise.resolve(this.fastTier);
  }
}

/**
 * A detector whose fast-tier report follows the route the shared ProxySwitch is ACTUALLY on when
 * it is asked — how Instagram behaves (per IP), and the reason `/proxy` must measure rather than
 * report from a boolean. The test states which routes the network serves, never the verdict for
 * a particular reply.
 */
class RouteAwareDetector extends FakeDetector {
  readonly seen: ProxyMode[] = [];

  constructor(
    private readonly proxySwitch: ProxySwitch,
    private readonly serving: readonly ProxyMode[],
  ) {
    super();
  }

  breakerSnapshot(): {
    state: 'CLOSED' | 'OPEN' | 'HALF_OPEN';
    consecutive: number;
    retryAfterMs: number;
  } {
    return { state: 'CLOSED', consecutive: 0, retryAfterMs: 0 };
  }

  browserBudget(): FastTierReport['browserBudget'] {
    return null;
  }

  fastTierReport(): Promise<FastTierReport> {
    const route = this.proxySwitch.state().mode;
    this.seen.push(route);
    const healthy = this.serving.includes(route);
    return Promise.resolve({
      state: healthy ? 'ok' : 'degraded',
      detail: healthy
        ? 'the control account resolves over the current egress route'
        : 'the control account did not resolve over the current egress route (HTTP_429)',
      canaryHealthy: healthy,
      breakerState: 'CLOSED',
      breakerRetryAfterMs: 0,
      answered: { fast: 0, browser: 0, blocked: 0, deferred: 0 },
      consecutiveEscalations: 0,
      browserBudget: null,
    });
  }
}

function setup(options?: {
  detector?: FakeDetector;
  config?: AppConfig;
  proxySwitch?: ProxySwitch;
}): {
  commands: DiscordCommands;
  repos: Repositories;
  detector: FakeDetector;
  clock: FixedClock;
} {
  const clock = new FixedClock(NOW);
  const { db, repos } = makeFakeDb();
  const detector = options?.detector ?? new FakeDetector();
  const config = options?.config ?? loadConfig(TEST_ENV);
  const commands = new DiscordCommands({
    repos,
    db,
    detector,
    config,
    clock,
    logger: nullLogger(),
    ...(options?.proxySwitch !== undefined ? { proxySwitch: options.proxySwitch } : {}),
    // Pacing protects a real residential IP; in tests it would only add wall time.
    bulkPrecheckLimits: { spacingMs: 0 },
  });
  return { commands, repos, detector, clock };
}

function makeResponder(): {
  res: DiscordResponder;
  replies: string[];
  embeds: DiscordEmbed[];
  photos: { caption: string; size: number }[];
} {
  const replies: string[] = [];
  const embeds: DiscordEmbed[] = [];
  const photos: { caption: string; size: number }[] = [];
  const res: DiscordResponder = {
    reply: async (text: string): Promise<void> => {
      replies.push(text);
    },
    replyEmbed: async (embed: DiscordEmbed): Promise<void> => {
      embeds.push(embed);
    },
    sendPhoto: async (buffer: Buffer, caption: string): Promise<void> => {
      photos.push({ caption, size: buffer.length });
    },
  };
  return { res, replies, embeds, photos };
}

function invoke(
  name: string,
  opts?: {
    strings?: Record<string, string>;
    integers?: Record<string, number>;
    userId?: string;
  },
): DiscordCommandInvocation {
  return {
    name,
    userId: opts?.userId ?? 'owner-1',
    getString: (n: string) => opts?.strings?.[n] ?? null,
    getInteger: (n: string) => opts?.integers?.[n] ?? null,
  };
}

async function seedFreshSchedulerHealth(repos: Repositories, iso: string): Promise<void> {
  await repos.health.upsert({
    name: 'scheduler',
    lastSchedulerRunUtc: iso,
    lastSuccessfulCheckUtc: iso,
    lastControlOkUtc: iso,
    recentUnknownRate: 0,
    browserRestarts: 0,
    detectorUnhealthy: false,
    lastWarningSentUtc: null,
    updatedAtUtc: iso,
  });
}

describe('DiscordCommands', () => {
  it('/unban starts monitoring and persists the case', async () => {
    const { commands, repos, detector } = setup();
    const { res, replies } = makeResponder();
    // A CONCLUSIVE pre-check, so this exercises the verified acceptance reply.
    detector.queue('foo', 'GONE');
    await commands.execute(invoke('unban', { strings: { username: 'foo' } }), res);
    expect(replies[0]).toContain('Monitoring Started');
    expect(replies[0]).toContain('@foo');
    expect(await repos.cases.findActiveByNormalizedUsername('foo')).not.toBeNull();
  });

  // H5, Discord side. Wording is at parity with Telegram by construction — the same formatter —
  // because an owner who reads one surface as "checked, and down" must not read the other as the
  // same thing when nothing was checked.
  it('/unban reports an inconclusive pre-check as NOT pre-checked, and still monitors', async () => {
    const { commands, repos, detector } = setup();
    const { res, replies } = makeResponder();
    detector.queue('foo', 'UNKNOWN'); // login wall / timeout / challenge — nothing observed

    await commands.execute(invoke('unban', { strings: { username: 'foo' } }), res);

    expect(replies[0]).toContain('NOT pre-checked');
    expect(replies[0]).not.toContain('👀 Monitoring Started');
    expect(replies[0]).toContain('/check foo');
    // Enrolment is UNCHANGED: probed, and monitored either way.
    expect(detector.probes.map((p) => p.username)).toEqual(['foo']);
    expect(await repos.cases.findActiveByNormalizedUsername('foo')).not.toBeNull();
  });

  it('/unban with the breaker OPEN monitors, never probes, and names the back-off', async () => {
    const detector = new DiagnosticFakeDetector();
    detector.fastTier = { ...detector.fastTier, breakerState: 'OPEN' };
    const { commands, repos } = setup({ detector });
    const { res, replies } = makeResponder();

    await commands.execute(invoke('unban', { strings: { username: 'foo' } }), res);

    expect(replies[0]).toContain('NOT pre-checked');
    expect(replies[0]).toContain('fleet-wide back-off');
    expect(detector.probes).toHaveLength(0);
    expect(await repos.cases.findActiveByNormalizedUsername('foo')).not.toBeNull();
  });

  it('/unban on an already-tracked account reports Already Monitoring', async () => {
    const { commands } = setup();
    const { res, replies } = makeResponder();
    await commands.execute(invoke('unban', { strings: { username: 'foo' } }), res);
    await commands.execute(invoke('unban', { strings: { username: 'foo' } }), res);
    expect(replies[1]).toContain('Already Monitoring');
  });

  it('/unban rejects the control account', async () => {
    const { commands } = setup();
    const { res, replies } = makeResponder();
    await commands.execute(invoke('unban', { strings: { username: 'instagram' } }), res);
    expect(replies[0]).toContain('control account');
  });

  it('/list shows a monitored account as an embed', async () => {
    const { commands } = setup();
    const { res, embeds } = makeResponder();
    await commands.execute(invoke('unban', { strings: { username: 'foo' } }), res);
    await commands.execute(invoke('list'), res);
    expect(embeds[0]!.title).toContain('Monitored accounts');
    expect(embeds[0]!.description).toContain('@foo');
  });

  it('/clear removes a monitor', async () => {
    const { commands, repos } = setup();
    const { res, replies } = makeResponder();
    await commands.execute(invoke('unban', { strings: { username: 'foo' } }), res);
    await commands.execute(invoke('clear', { strings: { username: 'foo' } }), res);
    expect(replies[1]).toContain('Monitoring Removed');
    expect(await repos.cases.findActiveByNormalizedUsername('foo')).toBeNull();
  });

  it('/clear points a deletion watch at /unwatch instead of a dead end', async () => {
    const { commands, detector } = setup();
    const { res, replies } = makeResponder();
    detector.queue('qux', 'ACTIVE');
    await commands.execute(invoke('ban', { strings: { username: 'qux' } }), res);
    await commands.execute(invoke('clear', { strings: { username: 'qux' } }), res);
    expect(replies[1]).toContain('/unwatch qux');
  });

  it('/check reports a live diagnostic and sends the screenshot', async () => {
    const { commands, detector } = setup();
    const { res, replies, photos } = makeResponder();
    detector.queue('bar', 'ACTIVE');
    await commands.execute(invoke('check', { strings: { username: 'bar' } }), res);
    expect(replies[0]).toContain('LIVE CHECK');
    expect(replies[0]).toContain('Result: ACTIVE');
    expect(photos).toHaveLength(1);
    expect(photos[0]!.size).toBeGreaterThan(0);
  });

  it('/check is rate-limited per user', async () => {
    const { commands, detector } = setup();
    const { res, replies } = makeResponder();
    detector.queue('bar', 'ACTIVE');
    detector.queue('baz', 'ACTIVE');
    await commands.execute(invoke('check', { strings: { username: 'bar' } }), res);
    await commands.execute(invoke('check', { strings: { username: 'baz' } }), res);
    expect(replies[1]).toContain('Please wait');
  });

  // DEFECT E, Discord side: the summary must always be deliverable, and an unverified account
  // must never be presented as one that was checked.
  it('/bulkunban acknowledges first, then edits in one summary', async () => {
    const { commands, repos, detector } = setup();
    const { res, replies } = makeResponder();
    detector.queue('nasa', 'ACTIVE');
    detector.queue('natgeo', 'GONE');

    await commands.execute(invoke('bulkunban', { strings: { usernames: 'natgeo nasa' } }), res);

    expect(replies[0]).toContain('Checking 2 accounts');
    expect(replies[1]).toContain('Bulk Monitoring Started');
    expect(replies[1]).toContain('Already active, not monitored');
    expect(await repos.cases.findActiveByNormalizedUsername('nasa')).toBeNull();
    expect(await repos.cases.findActiveByNormalizedUsername('natgeo')).not.toBeNull();
  });

  it('/bulkunban says plainly when an open breaker made verification impossible', async () => {
    const detector = new DiagnosticFakeDetector();
    detector.fastTier = { ...detector.fastTier, breakerState: 'OPEN' };
    const { commands, repos } = setup({ detector });
    const { res, replies } = makeResponder();

    await commands.execute(invoke('bulkunban', { strings: { usernames: 'natgeo nasa' } }), res);

    expect(replies[1]).toContain('NOT pre-checked');
    expect(replies[1]).toContain('fleet-wide back-off');
    expect(detector.probes).toHaveLength(0);
    expect(await repos.cases.findActiveByNormalizedUsername('natgeo')).not.toBeNull();
  });

  it('/ping reports the fast tier as degraded instead of claiming healthy', async () => {
    const detector = new DiagnosticFakeDetector();
    detector.fastTier = {
      ...detector.fastTier,
      state: 'degraded',
      detail: 'the control account did not resolve over the current egress route (LOGIN_WALL)',
      canaryHealthy: false,
    };
    const { commands, repos } = setup({ detector });
    await seedFreshSchedulerHealth(repos, NOW.toISOString());
    detector.queue('instagram', {
      classification: 'ACTIVE',
      activeSignals: ['NOT_REDIRECTED_AWAY', 'PROFILE_STRUCTURES_RENDERED'],
    });
    const { res, replies } = makeResponder();
    await commands.execute(invoke('ping'), res);

    expect(replies[0]).toContain('Monitoring System Unhealthy');
    expect(replies[0]).toContain('Fast probe: DEGRADED');
    expect(detector.probes).toHaveLength(1); // still exactly one browser page load
  });

  it('/ping reports healthy when the whole path is up', async () => {
    const { commands, repos, detector } = setup();
    await seedFreshSchedulerHealth(repos, NOW.toISOString());
    detector.queue('instagram', {
      classification: 'ACTIVE',
      activeSignals: ['NOT_REDIRECTED_AWAY', 'PROFILE_STRUCTURES_RENDERED'],
    });
    const { res, replies } = makeResponder();
    await commands.execute(invoke('ping'), res);
    expect(replies[0]).toContain('Monitoring System Healthy');
  });

  it('/ban requires the account to be currently active', async () => {
    const { commands, detector } = setup();
    const { res, replies } = makeResponder();
    detector.queue('baz', 'GONE');
    await commands.execute(invoke('ban', { strings: { username: 'baz' } }), res);
    expect(replies[0]).toContain('already inactive');
  });

  it('/ban → /banlist → /unwatch lifecycle', async () => {
    const { commands, detector } = setup();
    const { res, replies, embeds } = makeResponder();
    detector.queue('qux', 'ACTIVE');
    await commands.execute(invoke('ban', { strings: { username: 'qux' } }), res);
    expect(replies[0]).toContain('DELETION WATCH STARTED');
    await commands.execute(invoke('banlist'), res);
    expect(embeds[0]!.description).toContain('@qux');
    await commands.execute(invoke('unwatch', { strings: { username: 'qux' } }), res);
    expect(replies[1]).toContain('Stopped watching');
  });

  it('/clients groups direct (DM) monitors as an embed', async () => {
    const { commands } = setup();
    const { res, embeds } = makeResponder();
    await commands.execute(invoke('unban', { strings: { username: 'foo' } }), res);
    await commands.execute(invoke('clients'), res);
    expect(embeds[0]!.description).toContain('Direct');
    expect(embeds[0]!.description).toContain('@foo');
  });

  it('rejects unknown commands without throwing', async () => {
    const { commands } = setup();
    const { res, replies } = makeResponder();
    await commands.execute(invoke('nonsense'), res);
    expect(replies[0]).toContain('Unknown command');
  });
});

// ---------------------------------------------------------------------------
// /proxy on Discord. Same behaviour, same words as Telegram — the owner reads both surfaces as
// one system, and the message that matters most ("the fleet is now blind") must never be softer
// on one of them.
// ---------------------------------------------------------------------------
describe('DiscordCommands /proxy', () => {
  const PROXY_ENV = {
    ...TEST_ENV,
    BROWSER_PROXY_SERVER: 'http://gate.example.com:7000',
    BROWSER_PROXY_USERNAME: 'proxy-user-secret',
    BROWSER_PROXY_PASSWORD: 'proxy-pass-secret',
  };

  function proxySetup(options: {
    startOn: ProxyMode;
    serving: readonly ProxyMode[];
    configured?: boolean;
  }): {
    commands: DiscordCommands;
    proxySwitch: ProxySwitch;
    detector: RouteAwareDetector;
    config: AppConfig;
  } {
    const config = loadConfig(
      options.configured === false
        ? { ...TEST_ENV, PROXY_MODE: options.startOn }
        : { ...PROXY_ENV, PROXY_MODE: options.startOn },
    );
    const proxySwitch = new ProxySwitch(config);
    const detector = new RouteAwareDetector(proxySwitch, options.serving);
    const { commands } = setup({ config, detector, proxySwitch });
    return { commands, proxySwitch, detector, config };
  }

  it('confirms a switch only after the NEW route is verified against the control account', async () => {
    const { commands, proxySwitch, detector } = proxySetup({
      startOn: 'direct',
      serving: ['direct', 'proxy'],
    });
    const { res, replies } = makeResponder();

    await commands.execute(invoke('proxy', { strings: { route: 'mobile' } }), res);

    expect(replies[0]).toContain('VERIFIED');
    expect(replies[0]).toContain('gate.example.com:7000');
    expect(proxySwitch.state().mode).toBe('proxy');
    expect(detector.seen).toEqual(['proxy']);
  });

  it('REVERTS a switch to a route that cannot see Instagram, and says so loudly', async () => {
    const { commands, proxySwitch } = proxySetup({ startOn: 'proxy', serving: ['proxy'] });
    const { res, replies } = makeResponder();

    await commands.execute(invoke('proxy', { strings: { route: 'direct' } }), res);

    expect(replies[0]).toContain('EGRESS NOT SWITCHED');
    expect(replies[0]).toContain('BLIND');
    expect(proxySwitch.state().mode).toBe('proxy');
  });

  it('honours a deliberate repeat, and warns that the fleet is now blind', async () => {
    const { commands, proxySwitch } = proxySetup({ startOn: 'proxy', serving: ['proxy'] });
    const { res, replies } = makeResponder();

    await commands.execute(invoke('proxy', { strings: { route: 'direct' } }), res);
    await commands.execute(invoke('proxy', { strings: { route: 'direct' } }), res);

    expect(replies[1]).toContain('THE FLEET IS NOW BLIND');
    expect(replies[1]).toContain('NO RECOVERY WILL BE DETECTED');
    expect(proxySwitch.state().mode).toBe('direct');
  });

  it('does not claim a switch happened when already on that route', async () => {
    const { commands, proxySwitch } = proxySetup({
      startOn: 'proxy',
      serving: ['direct', 'proxy'],
    });
    const before = proxySwitch.gen();
    const { res, replies } = makeResponder();

    await commands.execute(invoke('proxy', { strings: { route: 'mobile' } }), res);

    expect(replies[0]).toContain('Already on that route');
    expect(replies[0]).not.toContain('Egress switched');
    expect(proxySwitch.gen()).toBe(before);
  });

  it('says mobile is unavailable when no proxy is configured, and changes nothing', async () => {
    const { commands, proxySwitch, detector } = proxySetup({
      startOn: 'direct',
      serving: ['direct'],
      configured: false,
    });
    const { res, replies } = makeResponder();

    await commands.execute(invoke('proxy', { strings: { route: 'mobile' } }), res);

    expect(replies[0]).toContain('unavailable');
    expect(proxySwitch.state().mode).toBe('direct');
    expect(detector.seen).toHaveLength(0);
  });

  it('keeps the "home" alias working', async () => {
    const { commands, proxySwitch } = proxySetup({
      startOn: 'proxy',
      serving: ['direct', 'proxy'],
    });
    const { res, replies } = makeResponder();

    await commands.execute(invoke('proxy', { strings: { route: 'home' } }), res);

    expect(replies[0]).toContain('VERIFIED');
    expect(proxySwitch.state().mode).toBe('direct');
  });

  it('never puts a proxy credential in any reply', async () => {
    const { commands } = proxySetup({ startOn: 'proxy', serving: ['proxy'] });
    const { res, replies } = makeResponder();

    await commands.execute(invoke('proxy'), res);
    await commands.execute(invoke('proxy', { strings: { route: 'direct' } }), res);
    await commands.execute(invoke('proxy', { strings: { route: 'direct' } }), res);
    await commands.execute(invoke('proxy', { strings: { route: 'mobile' } }), res);
    await commands.execute(invoke('proxy', { strings: { route: 'mobile' } }), res);
    await commands.execute(invoke('proxy', { strings: { route: 'nonsense' } }), res);

    expect(replies).toHaveLength(6);
    for (const reply of replies) {
      expect(reply).not.toContain('proxy-user-secret');
      expect(reply).not.toContain('proxy-pass-secret');
    }
    expect(replies.some((r) => r.includes('gate.example.com:7000'))).toBe(true);
  });

  // PARITY, asserted rather than maintained by hand. Both surfaces run the same scenario over
  // their own (identical) egress stack; a wording or behaviour change on one that is not made on
  // the other fails here.
  it('reads WORD FOR WORD the same as Telegram, on every outcome', async () => {
    const scenarios: { startOn: ProxyMode; serving: ProxyMode[]; routes: string[] }[] = [
      // verified switch, then a no-op on the same route
      { startOn: 'direct', serving: ['direct', 'proxy'], routes: ['mobile', 'mobile'] },
      // blind switch -> reverted, then the deliberate repeat -> kept blind
      { startOn: 'proxy', serving: ['proxy'], routes: ['direct', 'direct'] },
      // the bare status view and a bad argument
      { startOn: 'proxy', serving: ['proxy'], routes: ['', 'nonsense'] },
    ];

    for (const scenario of scenarios) {
      const config = loadConfig({ ...PROXY_ENV, PROXY_MODE: scenario.startOn });

      const dSwitch = new ProxySwitch(config);
      const { commands } = setup({
        config,
        detector: new RouteAwareDetector(dSwitch, scenario.serving),
        proxySwitch: dSwitch,
      });
      const { res, replies } = makeResponder();

      const tSwitch = new ProxySwitch(config);
      const client = new MockTelegramClient();
      const { db, repos } = makeFakeDb();
      await repos.owner.claimOwner(111, NOW.toISOString());
      const router = new CommandRouter({
        client,
        repos,
        db,
        detector: new RouteAwareDetector(tSwitch, scenario.serving),
        auth: new OwnerAuthorizer({
          owner: repos.owner,
          pairingSecret: config.ownerPairingSecret,
          logger: nullLogger(),
        }),
        config,
        clock: new FixedClock(NOW),
        logger: nullLogger(),
        proxySwitch: tSwitch,
      });

      let updateId = 1;
      for (const route of scenario.routes) {
        await commands.execute(
          invoke('proxy', route === '' ? undefined : { strings: { route } }),
          res,
        );
        const text = route === '' ? '/proxy' : `/proxy ${route}`;
        const telegramUpdate: TelegramUpdate = {
          update_id: updateId++,
          message: {
            message_id: 1,
            from: { id: 111, is_bot: false, first_name: 'Tester' },
            chat: { id: 111, type: 'private' },
            date: Math.floor(NOW.getTime() / 1000),
            text,
          },
        };
        await router.handleUpdate(telegramUpdate);
      }

      // The measured round-trip is the one thing that legitimately differs: each surface runs its
      // own stopwatch over its own probe. Parity is about the WORDING, so normalise just that.
      const normalise = (text: string): string => text.replace(/\b\d+ ms\b/g, 'N ms');
      const telegramTexts = client.sentMessages.map((m) => normalise(m.text));
      const discordTexts = replies.map(normalise);
      // Guard against a vacuous pass: both surfaces must actually have answered every command.
      expect(discordTexts).toHaveLength(scenario.routes.length);
      expect(telegramTexts).toHaveLength(scenario.routes.length);
      expect(discordTexts).toEqual(telegramTexts);
      // ...and the two surfaces ended in the same state, not just with the same words.
      expect(dSwitch.state().mode).toBe(tSwitch.state().mode);
    }
  });
});
