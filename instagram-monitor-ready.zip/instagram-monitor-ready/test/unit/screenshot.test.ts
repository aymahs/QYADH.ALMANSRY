﻿/**
 * Regression tests for TWO production incidents in the same delivery path, plus the
 * adversarial-review findings that followed each fix.
 *
 * INCIDENT 1 â€” the wrong picture. A client recovery alert for @odpcompetitions shipped a
 * screenshot of Instagram's logged-out SIGNUP interstitial instead of the profile, because the
 * guard matched on ARIA roles the real modal does not carry. Follow-ups: an unproven padding
 * band in the delivered clip, sub-threshold overlaps, click-through painted layers that are not
 * fixed/sticky, a fail-open DOM-scan cap, an after-shutter probe that never compared regions,
 * and false occlusions from behind-content / transparent layers.
 *
 * INCIDENT 2 â€” no picture at all, sold as one. Three live captures through the production host
 * produced one profile card and two BLANK WHITE IMAGES; all three classified ACTIVE, so both
 * blanks would have been delivered as proof of recovery. Root cause: `networkidle` never fires
 * on Instagram (not once in 120s on any account), so `waitForLoadState('networkidle')` always
 * timed out and the shutter fired ~5s in â€” while the header was measured to finish painting at
 * 9.9s / 85.4s / 96.4s depending on the account. The tests below pin the replacement: POLL the
 * measured paint predicate, ship nothing if it never holds, and check the captured BYTES as a
 * backstop.
 *
 * These run against a FAKE page/DOM (there is no browser in CI), but they execute the REAL
 * in-page probes: `FakePage.evaluate` installs the fake `document` / `getComputedStyle` on
 * `globalThis` and then CALLS the function the production code handed it. Nothing under test is
 * stubbed â€” only the DOM it reads and the shutter it drives. In particular the fake models the
 * three things the fixes actually depend on:
 *   - paint order (stacking layers by position + z-index, hit-testing that honours an inline
 *     `style.pointerEvents` override, full stacks via `elementsFromPoint`);
 *   - `innerText` as LAYOUT-AWARE text and `textContent` as the flat source text, which is the
 *     distinction that makes the paint predicate mean anything;
 *   - screenshot bytes that scale with the clip, so the blankness backstop is measured on real
 *     byte counts. An earlier test in this repo wrote the screenshot file by hand and hid a
 *     defect for weeks; nothing here fabricates the artefact it is judging.
 */

import { describe, expect, it } from 'vitest';
import type { Page } from 'playwright';

import { isAppError } from '../../src/domain';
import {
  assessImageDensity,
  captureProfileScreenshot,
  dismissOverlays,
  ensureHeaderVisible,
  hasBlockingOverlay,
  MIN_IMAGE_BYTES_PER_PIXEL,
  probeHeaderImages,
  probeHeaderVisibility,
  probeRenderReady,
  validateImage,
  waitForHeaderImages,
  waitForProfilePainted,
} from '../../src/instagram/screenshot/capture';

// --- Fake DOM ----------------------------------------------------------------

interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
  top: number;
  right: number;
  bottom: number;
  left: number;
}

function rect(x: number, y: number, width: number, height: number): Rect {
  return { x, y, width, height, left: x, top: y, right: x + width, bottom: y + height };
}

interface ElementInit {
  tag: string;
  box: Rect;
  /** Computed `position`; out-of-flow values are what mark overlay layers. */
  position?: string;
  /** `none` makes the element invisible to hit-testing while still being painted. */
  pointerEvents?: string;
  display?: string;
  visibility?: string;
  opacity?: string;
  /** Computed z-index (string, like getComputedStyle); 'auto' when omitted. */
  zIndex?: string;
  /** Computed background-color; browsers report 'rgba(0, 0, 0, 0)' for unset. */
  background?: string;
  /** A direct text child; an element with visible text is painted content. */
  text?: string;
  /** `HTMLImageElement.complete`. Left undefined for non-images, exactly like the real DOM. */
  complete?: boolean;
  attrs?: Record<string, string>;
}

class FakeElement {
  readonly tagName: string;
  readonly style = { overflow: '', pointerEvents: '' };
  readonly children: FakeElement[] = [];
  readonly computed: {
    position: string;
    display: string;
    visibility: string;
    opacity: string;
    pointerEvents: string;
    zIndex: string;
    backgroundColor: string;
    backgroundImage: string;
    boxShadow: string;
    borderTopWidth: string;
    borderRightWidth: string;
    borderBottomWidth: string;
    borderLeftWidth: string;
  };
  readonly attrs: Record<string, string>;
  readonly text: string | undefined;
  box: Rect;
  parentElement: FakeElement | null = null;
  clientWidth = 0;
  clientHeight = 0;
  /**
   * `HTMLImageElement.complete`: undefined on non-images, false while the bytes are still in
   * flight, true once the image has loaded OR failed. Mutable so a test can let an image ARRIVE
   * between polls instead of declaring the outcome up front.
   */
  complete: boolean | undefined;

  constructor(init: ElementInit) {
    this.tagName = init.tag.toUpperCase();
    this.box = init.box;
    this.attrs = init.attrs ?? {};
    this.text = init.text;
    this.complete = init.complete;
    this.computed = {
      position: init.position ?? 'static',
      display: init.display ?? 'block',
      visibility: init.visibility ?? 'visible',
      opacity: init.opacity ?? '1',
      pointerEvents: init.pointerEvents ?? 'auto',
      zIndex: init.zIndex ?? 'auto',
      backgroundColor: init.background ?? 'rgba(0, 0, 0, 0)',
      backgroundImage: 'none',
      boxShadow: 'none',
      borderTopWidth: '0px',
      borderRightWidth: '0px',
      borderBottomWidth: '0px',
      borderLeftWidth: '0px',
    };
  }

  append(child: FakeElement): FakeElement {
    child.parentElement = this;
    this.children.push(child);
    return child;
  }

  get parentNode(): { removeChild(child: FakeElement): void } | null {
    const parent = this.parentElement;
    if (parent === null) return null;
    return {
      removeChild: (child: FakeElement): void => {
        const index = parent.children.indexOf(child);
        if (index >= 0) parent.children.splice(index, 1);
        child.parentElement = null;
      },
    };
  }

  get childNodes(): Array<{ nodeType: number; textContent: string | null }> {
    return this.text !== undefined ? [{ nodeType: 3, textContent: this.text }] : [];
  }

  /**
   * RENDERED text, layout-aware exactly like the real `innerText`: an unrendered subtree
   * contributes nothing. This is the property that turns the header's text into a PAINT signal
   * rather than a markup signal, so the fake has to honour it or the predicate under test would
   * be meaningless here.
   */
  get innerText(): string {
    const c = this.computed;
    if (c.display === 'none' || c.visibility === 'hidden') return '';
    const parts: string[] = [];
    if (this.text !== undefined) parts.push(this.text);
    for (const child of this.children) {
      const rendered = child.innerText;
      if (rendered !== '') parts.push(rendered);
    }
    return parts.join(' ');
  }

  /** Flat SOURCE text, NOT layout-aware â€” the real `textContent` still sees hidden subtrees. */
  get textContent(): string {
    const parts: string[] = [];
    if (this.text !== undefined) parts.push(this.text);
    for (const child of this.children) {
      const raw = child.textContent;
      if (raw !== '') parts.push(raw);
    }
    return parts.join(' ');
  }

  /** Nearest positioned ancestor (body for in-flow chains), null for fixed â€” like the DOM. */
  get offsetParent(): FakeElement | null {
    if (this.computed.position === 'fixed') return null;
    let node = this.parentElement;
    while (node !== null) {
      if (node.tagName === 'BODY' || node.tagName === 'HTML') return node;
      if (node.computed.position !== 'static') return node;
      node = node.parentElement;
    }
    return null;
  }

  getAttribute(name: string): string | null {
    return this.attrs[name] ?? null;
  }

  getBoundingClientRect(): Rect {
    return this.box;
  }

  contains(other: FakeElement | null): boolean {
    let node: FakeElement | null = other;
    while (node !== null) {
      if (node === this) return true;
      node = node.parentElement;
    }
    return false;
  }

  /** Document-order descendants, iteratively (the scan-cap tests build 40k+ nodes). */
  descendants(): FakeElement[] {
    const out: FakeElement[] = [];
    const stack: FakeElement[] = [];
    for (let i = this.children.length - 1; i >= 0; i -= 1) {
      const child = this.children[i];
      if (child !== undefined) stack.push(child);
    }
    while (stack.length > 0) {
      const el = stack.pop();
      if (el === undefined) break;
      out.push(el);
      for (let i = el.children.length - 1; i >= 0; i -= 1) {
        const child = el.children[i];
        if (child !== undefined) stack.push(child);
      }
    }
    return out;
  }
}

class FakeDocument {
  readonly documentElement: FakeElement;
  readonly body: FakeElement;
  /** Simulates a DOM method blowing up mid-probe (detached frame, hostile page). */
  elementFromPointThrows = false;

  constructor(width = 1280, height = 900) {
    this.documentElement = new FakeElement({ tag: 'html', box: rect(0, 0, width, height) });
    this.documentElement.clientWidth = width;
    this.documentElement.clientHeight = height;
    this.body = this.documentElement.append(
      new FakeElement({ tag: 'body', box: rect(0, 0, width, height) }),
    );
  }

  querySelectorAll(selectors: string): FakeElement[] {
    const all = this.body.descendants();
    if (selectors === 'body *') return all;
    if (selectors === 'header') return all.filter((el) => el.tagName === 'HEADER');
    throw new Error(`fake DOM: unsupported selector ${selectors}`);
  }

  /**
   * Full hit-test stack at a point, topmost first, the way browsers order paint for this
   * page shape: the OUTERMOST positioned ancestor (self included) sets the layer via its
   * z-index (so `z-index: -9999` puts a whole subtree BEHIND in-flow content, and a fixed
   * overlay with z-index auto sits above it), and document order breaks ties. Hit-testing
   * honours an inline `style.pointerEvents` override over the computed value â€” that is the
   * contract the probe's paint-order oracle relies on.
   */
  private stackAt(x: number, y: number): FakeElement[] {
    if (this.elementFromPointThrows) throw new Error('elementFromPoint failed');
    const all: FakeElement[] = [this.documentElement, this.body, ...this.body.descendants()];
    const ordered: Array<{ el: FakeElement; score: number }> = [];
    for (let i = 0; i < all.length; i += 1) {
      const el = all[i];
      if (el === undefined) continue;
      const c = el.computed;
      if (c.display === 'none' || c.visibility === 'hidden') continue;
      const pe = el.style.pointerEvents !== '' ? el.style.pointerEvents : c.pointerEvents;
      if (pe === 'none') continue;
      const b = el.box;
      if (x < b.left || x >= b.right || y < b.top || y >= b.bottom) continue;
      let layer = 0;
      let node: FakeElement | null = el;
      while (node !== null) {
        if (node.computed.position !== 'static') {
          const zi = Number.parseInt(node.computed.zIndex, 10);
          layer = (Number.isNaN(zi) ? 0 : zi) * 1_000_000 + 500_000;
        }
        node = node.parentElement;
      }
      ordered.push({ el, score: layer + i - 2 });
    }
    ordered.sort((a, b) => b.score - a.score);
    return ordered.map((entry) => entry.el);
  }

  elementFromPoint(x: number, y: number): FakeElement | null {
    const stack = this.stackAt(x, y);
    return stack.length > 0 ? (stack[0] ?? null) : null;
  }

  elementsFromPoint(x: number, y: number): FakeElement[] {
    return this.stackAt(x, y);
  }
}

// --- Fake page ---------------------------------------------------------------

const PNG_MAGIC = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

/**
 * Bytes of PNG per CSS pixel that the fake shutter produces by default: the density MEASURED on
 * the production host for a good tight header crop. The two blanks that shipped to a client
 * measured 0.016 and 0.026 B/px; full-viewport captures taken after the predicate held measured
 * 1.16-1.96 B/px.
 */
const GOOD_CROP_BYTES_PER_PIXEL = 0.48;

interface Control {
  visible: boolean;
  clicks: number;
  onClick?: () => void;
}

/**
 * Rebuild a function from its own source, the way `page.evaluate` does. A function reconstructed
 * this way resolves free identifiers against globals ONLY, so anything it inherited from module
 * scope becomes a ReferenceError here instead of a silent, screenshot-less production.
 */
function reviveAsPageFunction(fn: (arg: unknown) => unknown): (arg: unknown) => unknown {
  const factory = new Function(`return (${fn.toString()})`) as () => (arg: unknown) => unknown;
  return factory();
}

class FakePage {
  readonly doc: FakeDocument;
  readonly screenshotClips: Array<{ x: number; y: number; width: number; height: number }> = [];
  readonly controls = new Map<string, Control>();
  /** Exactly what would be shipped to the browser, for the serialization-safety test. */
  readonly evaluatedSources: string[] = [];
  /** The argument each page function was called with, in order. */
  readonly evaluatedArgs: unknown[] = [];
  evaluateThrows = false;
  /** Countdown of TRANSIENT evaluate failures (hydration hiccup, context swapped mid-poll). */
  evaluateThrowsForNextCalls = 0;
  evaluateCalls = 0;
  escapePresses = 0;
  /** The root cause of incident 2: nothing in the capture path may wait on a load state. */
  waitForLoadStateCalls = 0;
  currentUrl = 'https://www.instagram.com/odpcompetitions/';
  /** Information density of the bytes the shutter returns; lower it to model a blank capture. */
  bytesPerPixel = GOOD_CROP_BYTES_PER_PIXEL;
  /** Hook to simulate an interstitial remounting the instant after the shutter fires. */
  afterScreenshot: (() => void) | null = null;
  /** Runs before every page function, so a test can let the page PAINT between polls. */
  beforeEvaluate: ((source: string, arg: unknown) => void) | null = null;

  readonly keyboard = {
    press: async (): Promise<void> => {
      this.escapePresses += 1;
      return Promise.resolve();
    },
  };

  constructor(doc: FakeDocument) {
    this.doc = doc;
  }

  /**
   * Executes the REAL in-page function against the fake DOM, across the same boundary
   * Playwright uses: the function is re-created FROM ITS SOURCE TEXT, so it only has access
   * to page globals. That is what makes these tests able to catch a page function that
   * accidentally references module scope â€” including the `__name` helper that esbuild's
   * keepNames injects around any nested function, which would throw in a real browser.
   */
  async evaluate(fn: (arg: unknown) => unknown, arg?: unknown): Promise<unknown> {
    this.evaluateCalls += 1;
    this.evaluatedSources.push(fn.toString());
    this.evaluatedArgs.push(arg);
    this.beforeEvaluate?.(fn.toString(), arg);
    if (this.evaluateThrowsForNextCalls > 0) {
      this.evaluateThrowsForNextCalls -= 1;
      throw new Error('Execution context was destroyed');
    }
    if (this.evaluateThrows) throw new Error('Execution context was destroyed');
    const hadDoc = 'document' in globalThis;
    const hadStyle = 'getComputedStyle' in globalThis;
    const prevDoc = Reflect.get(globalThis, 'document');
    const prevStyle = Reflect.get(globalThis, 'getComputedStyle');
    Reflect.set(globalThis, 'document', this.doc);
    Reflect.set(globalThis, 'getComputedStyle', (el: FakeElement) => el.computed);
    try {
      const revived = reviveAsPageFunction(fn);
      return await Promise.resolve(revived(arg));
    } finally {
      if (hadDoc) Reflect.set(globalThis, 'document', prevDoc);
      else Reflect.deleteProperty(globalThis, 'document');
      if (hadStyle) Reflect.set(globalThis, 'getComputedStyle', prevStyle);
      else Reflect.deleteProperty(globalThis, 'getComputedStyle');
    }
  }

  private locatorFor(key: string): unknown {
    const control = this.controls.get(key);
    const handle = {
      first: (): unknown => handle,
      isVisible: async (): Promise<boolean> => Promise.resolve(control?.visible === true),
      click: async (): Promise<void> => {
        if (control !== undefined) {
          control.clicks += 1;
          control.onClick?.();
        }
        return Promise.resolve();
      },
    };
    return handle;
  }

  locator(selector: string): unknown {
    return this.locatorFor(selector);
  }

  getByRole(role: string, options: { name: string }): unknown {
    return this.locatorFor(`role:${role}:${options.name}`);
  }

  async waitForLoadState(): Promise<void> {
    this.waitForLoadStateCalls += 1;
    return Promise.resolve();
  }

  url(): string {
    return this.currentUrl;
  }

  /**
   * Bytes proportional to the clip, so the blankness backstop is judged on a REAL byte count.
   * Handing back a fixed 8-byte stub would have made every density assertion vacuous.
   */
  async screenshot(options: {
    clip: { x: number; y: number; width: number; height: number };
  }): Promise<Buffer> {
    this.screenshotClips.push(options.clip);
    const area = options.clip.width * options.clip.height;
    const buffer = Buffer.alloc(Math.max(PNG_MAGIC.length, Math.round(area * this.bytesPerPixel)));
    PNG_MAGIC.copy(buffer, 0);
    this.afterScreenshot?.();
    return Promise.resolve(buffer);
  }

  asPage(): Page {
    return this as unknown as Page;
  }
}

// --- Scenario builders -------------------------------------------------------

const USERNAME = 'odpcompetitions';
/** The counters the measurement identified as part of the paint predicate. */
const COUNTERS = '12 posts 3,481 followers 210 following';
const BIO = 'Daily giveaways. Link in bio.';

const HEADER_BOX = rect(165, 80, 950, 300);
/** HEADER_BOX padded by 28px on each side, clamped to the 1280x900 viewport. */
const EXPECTED_CLIP = { x: 137, y: 52, width: 1006, height: 356 };

/**
 * A profile whose `<header>` is ATTACHED but has not laid out its content â€” the state the
 * production measurements found for 85.4s on @instagram and 96.4s on @trymaven, and the state
 * the old code photographed as a white rectangle.
 */
function buildUnpaintedProfile(): { doc: FakeDocument; header: FakeElement; main: FakeElement } {
  const doc = new FakeDocument();
  const main = doc.body.append(new FakeElement({ tag: 'main', box: rect(0, 0, 1280, 900) }));
  const header = main.append(new FakeElement({ tag: 'header', box: HEADER_BOX }));
  return { doc, header, main };
}

/** Lay the profile out inside an existing shell: what "the page finally painted" looks like. */
function paintProfile(header: FakeElement): void {
  header.append(new FakeElement({ tag: 'img', box: rect(190, 100, 150, 150) }));
  header.append(new FakeElement({ tag: 'h2', box: rect(400, 100, 300, 40), text: USERNAME }));
  header.append(new FakeElement({ tag: 'ul', box: rect(400, 160, 400, 40), text: COUNTERS }));
  header.append(new FakeElement({ tag: 'div', box: rect(400, 210, 500, 60), text: BIO }));
}

/** A normally rendered desktop profile: main > header > (pfp, name, counts, bio). */
function buildProfile(): { doc: FakeDocument; header: FakeElement; main: FakeElement } {
  const built = buildUnpaintedProfile();
  paintProfile(built.header);
  return built;
}

/**
 * The incident overlay: a painted fixed backdrop + card with NO `role` attribute and no
 * dialog markup anywhere â€” exactly what the old `div[role="dialog"], div[role="presentation"]`
 * guard could not see.
 */
function attachSignupModal(parent: FakeElement): { root: FakeElement; card: FakeElement } {
  const root = parent.append(
    new FakeElement({
      tag: 'div',
      box: rect(0, 0, 1280, 900),
      position: 'fixed',
      background: 'rgba(0, 0, 0, 0.65)',
    }),
  );
  const card = root.append(
    new FakeElement({
      tag: 'div',
      box: rect(440, 250, 400, 260),
      background: 'rgb(255, 255, 255)',
    }),
  );
  card.append(
    new FakeElement({
      tag: 'span',
      box: rect(460, 280, 360, 60),
      text: 'Sign up to see photos and videos from your friends.',
    }),
  );
  card.append(
    new FakeElement({
      tag: 'svg',
      box: rect(806, 258, 24, 24),
      attrs: { 'aria-label': 'Close' },
    }),
  );
  return { root, card };
}

/**
 * The paint probe is the only page function handed a `counterTokens` argument. Discriminating on
 * the ARGUMENT rather than the function name keeps these tests independent of whether a
 * transpiler preserved `name`.
 */
function isPaintProbeArg(arg: unknown): boolean {
  return typeof arg === 'object' && arg !== null && 'counterTokens' in arg;
}

/**
 * No settle/retry delays, and NO paint budget: every scenario using these is either painted
 * before the first poll (so the poll returns immediately) or is asserting that an unpainted page
 * yields nothing. Tests that exercise the poll itself pass their own budget.
 */
const FAST = {
  username: USERNAME,
  settleMs: 0,
  retryDelayMs: 0,
  maxAttempts: 3,
  paintTimeoutMs: 0,
  paintPollIntervalMs: 0,
} as const;
const NO_DISMISS = { ...FAST, maxAttempts: 0 } as const;
/** A real (but tiny) poll budget, for the tests that assert the waiting behaviour. */
const POLLING = { ...NO_DISMISS, paintTimeoutMs: 2_000, paintPollIntervalMs: 5 } as const;

// --- Tests -------------------------------------------------------------------

describe('paint readiness â€” the blank white images that shipped as proof', () => {
  it('POLLS for the paint predicate and holds the shutter until it holds', async () => {
    const { doc, header } = buildUnpaintedProfile();
    const page = new FakePage(doc);
    let polls = 0;
    let pollsAtShutter = -1;
    page.beforeEvaluate = (_source, arg): void => {
      if (!isPaintProbeArg(arg)) return;
      polls += 1;
      // The page paints partway through the poll, exactly as it does in production.
      if (polls === 4) paintProfile(header);
    };
    page.afterScreenshot = (): void => {
      pollsAtShutter = polls;
    };

    const started = Date.now();
    const shot = await captureProfileScreenshot(page.asPage(), POLLING);
    const elapsed = Date.now() - started;

    // It waited: three probes said "not painted" before the fourth found the profile.
    expect(polls).toBeGreaterThanOrEqual(4);
    expect(pollsAtShutter).toBeGreaterThanOrEqual(4);
    // ...and it WAITED between probes rather than spinning the CPU for two seconds.
    expect(elapsed).toBeGreaterThanOrEqual(20);
    // The picture that came out is the real header card.
    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
    expect(shot.width).toBe(EXPECTED_CLIP.width);
    expect(validateImage(shot.buffer).ok).toBe(true);
  });

  it('proves paint BEFORE anything touches or photographs the page', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);

    await captureProfileScreenshot(page.asPage(), NO_DISMISS);

    // The very first thing the capture does is ask whether the profile has painted.
    expect(isPaintProbeArg(page.evaluatedArgs[0])).toBe(true);
    expect(page.screenshotClips).toHaveLength(1);
  });

  it('yields NO screenshot at all for a page that never paints', async () => {
    const { doc } = buildUnpaintedProfile();
    const page = new FakePage(doc);
    let polls = 0;
    page.beforeEvaluate = (_source, arg): void => {
      if (isPaintProbeArg(arg)) polls += 1;
    };

    await expect(
      captureProfileScreenshot(page.asPage(), {
        ...NO_DISMISS,
        paintTimeoutMs: 60,
        paintPollIntervalMs: 5,
      }),
    ).rejects.toThrow(/never finished painting/i);

    // It kept trying rather than giving up after one look...
    expect(polls).toBeGreaterThan(1);
    // ...and the invariant: the shutter never fired, so no blank rectangle exists to deliver.
    expect(page.screenshotClips).toHaveLength(0);
  });

  it('never waits on a load state â€” networkidle was measured to NEVER fire on Instagram', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);

    await captureProfileScreenshot(page.asPage(), NO_DISMISS);

    // The old `waitForLoadState('networkidle', { timeout: 5000 })` could only ever time out,
    // which is precisely what fired the shutter ~5s into an unpainted page.
    expect(page.waitForLoadStateCalls).toBe(0);
  });

  it('does NOT gate on the avatar <img>, which never loaded at all for one measured account', async () => {
    const { doc, header } = buildUnpaintedProfile();
    // @trymaven's avatar image had still not loaded after 120s. Requiring it would hang every
    // capture on that account forever, so the predicate deliberately ignores it.
    header.append(new FakeElement({ tag: 'h2', box: rect(400, 100, 300, 40), text: USERNAME }));
    header.append(new FakeElement({ tag: 'ul', box: rect(400, 160, 400, 40), text: COUNTERS }));
    const page = new FakePage(doc);

    const verdict = await probeRenderReady(page.asPage(), USERNAME);
    expect(verdict.ready).toBe(true);
    expect(verdict.reason).toBe('ok');

    const shot = await captureProfileScreenshot(page.asPage(), NO_DISMISS);
    expect(shot.width).toBe(EXPECTED_CLIP.width);
  });

  it('treats an attached but unlaid-out header as not painted, not as a capture target', async () => {
    const { doc, header } = buildUnpaintedProfile();
    header.box = rect(165, 80, 950, 90); // big enough to BE the profile header, too small to have laid out
    paintProfile(header);
    const page = new FakePage(doc);

    const verdict = await probeRenderReady(page.asPage(), USERNAME);
    expect(verdict.ready).toBe(false);
    expect(verdict.reason).toBe('header-too-small');
    expect(verdict.box).toEqual({ x: 165, y: 80, width: 950, height: 90 });
  });

  it('reports no-header while the profile shell has not mounted one', async () => {
    const doc = new FakeDocument();
    doc.body.append(new FakeElement({ tag: 'main', box: rect(0, 0, 1280, 900) }));
    const page = new FakePage(doc);

    const verdict = await probeRenderReady(page.asPage(), USERNAME);
    expect(verdict.ready).toBe(false);
    expect(verdict.reason).toBe('no-header');
    expect(verdict.box).toBeNull();
  });

  it('refuses a header that does not name the account being monitored', async () => {
    const { doc, header } = buildUnpaintedProfile();
    header.append(
      new FakeElement({ tag: 'h2', box: rect(400, 100, 300, 40), text: 'someoneelse' }),
    );
    header.append(new FakeElement({ tag: 'ul', box: rect(400, 160, 400, 40), text: COUNTERS }));
    const page = new FakePage(doc);

    const verdict = await probeRenderReady(page.asPage(), USERNAME);
    expect(verdict.ready).toBe(false);
    expect(verdict.reason).toBe('identity-missing');
  });

  it('refuses a header that names the account but has not rendered the counters', async () => {
    const { doc, header } = buildUnpaintedProfile();
    header.append(new FakeElement({ tag: 'h2', box: rect(400, 100, 300, 40), text: USERNAME }));
    const page = new FakePage(doc);

    const verdict = await probeRenderReady(page.asPage(), USERNAME);
    expect(verdict.ready).toBe(false);
    expect(verdict.reason).toBe('counters-missing');
  });

  it('judges paint on RENDERED text, so markup present in an unrendered subtree proves nothing', async () => {
    const { doc, header } = buildUnpaintedProfile();
    header.append(
      new FakeElement({
        tag: 'h2',
        box: rect(400, 100, 300, 40),
        display: 'none',
        text: USERNAME,
      }),
    );
    header.append(new FakeElement({ tag: 'ul', box: rect(400, 160, 400, 40), text: COUNTERS }));
    const page = new FakePage(doc);

    // The distinction the predicate rests on: the source text HAS the username...
    expect(header.textContent).toContain(USERNAME);
    // ...but nothing has been laid out for it, which is what `innerText` reflects.
    expect(header.innerText).not.toContain(USERNAME);

    const verdict = await probeRenderReady(page.asPage(), USERNAME);
    expect(verdict.ready).toBe(false);
    expect(verdict.reason).toBe('identity-missing');
  });

  it('refuses a header whose WHOLE content is an unrendered skeleton, however complete the markup', async () => {
    // The narrow shape an earlier `innerText !== '' ? innerText : textContent` fallback left
    // open, and the only one where the two sources disagree about EVERYTHING: the header itself
    // has laid out (950x300 clears both the profile-header size gate and the painted-side gate)
    // while every piece of its content is still in a not-yet-revealed subtree. `innerText`
    // answers '' â€” correctly, "nothing is rendered here yet" â€” and an empty innerText must never
    // escalate to `textContent`, which still reads the entire skeleton.
    const { doc, header } = buildUnpaintedProfile();
    header.append(
      new FakeElement({ tag: 'h2', box: rect(400, 100, 300, 40), display: 'none', text: USERNAME }),
    );
    header.append(
      new FakeElement({
        tag: 'ul',
        box: rect(400, 160, 400, 40),
        visibility: 'hidden',
        text: COUNTERS,
      }),
    );
    const page = new FakePage(doc);

    // Markup-complete: every token the predicate looks for is in the DOM...
    expect(header.textContent).toContain(USERNAME);
    expect(header.textContent).toContain('posts');
    // ...and paint-empty, which is the whole point of judging on rendered text.
    expect(header.innerText).toBe('');

    const verdict = await probeRenderReady(page.asPage(), USERNAME);
    expect(verdict.ready).toBe(false);
    expect(verdict.reason).toBe('identity-missing');

    // End to end: the shutter never fires, so the grey skeleton card cannot reach a client.
    // Nothing downstream would have caught it â€” the occlusion probe checks geometry and never
    // re-checks identity, and solid placeholder blocks carry far more information than the
    // near-uniform blanks MIN_IMAGE_BYTES_PER_PIXEL is calibrated against.
    await expect(captureProfileScreenshot(page.asPage(), NO_DISMISS)).rejects.toThrow(
      /never finished painting \(identity-missing\)/,
    );
    expect(page.screenshotClips).toHaveLength(0);
  });
});

describe('paint readiness â€” failure paths fail CLOSED', () => {
  it('tolerates evaluate() throwing throughout, and ships nothing', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);
    page.evaluateThrows = true;
    let polls = 0;
    page.beforeEvaluate = (): void => {
      polls += 1;
    };

    const verdict = await waitForProfilePainted(page.asPage(), {
      username: USERNAME,
      timeoutMs: 40,
      pollIntervalMs: 5,
    });
    expect(verdict.ready).toBe(false);
    expect(verdict.reason).toBe('probe-failed');
    expect(polls).toBeGreaterThan(1); // a thrown probe is retried, not fatal on its own

    await expect(
      captureProfileScreenshot(page.asPage(), {
        ...NO_DISMISS,
        paintTimeoutMs: 40,
        paintPollIntervalMs: 5,
      }),
    ).rejects.toThrow(/never finished painting \(probe-failed\)/);
    expect(page.screenshotClips).toHaveLength(0);
  });

  it('costs a TRANSIENT probe failure one poll rather than the whole capture', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);
    // Two hydration hiccups, then the page answers normally â€” a capture must survive that.
    page.evaluateThrowsForNextCalls = 2;

    const shot = await captureProfileScreenshot(page.asPage(), POLLING);

    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
    expect(shot.width).toBe(EXPECTED_CLIP.width);
  });

  it('ignores a malformed readiness payload instead of trusting it', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);
    const broken = {
      ...page,
      evaluate: async (): Promise<unknown> => Promise.resolve({ painted: 'yes' }),
    } as unknown as Page;

    const verdict = await probeRenderReady(broken, USERNAME);
    expect(verdict.ready).toBe(false);
    expect(verdict.reason).toBe('probe-failed');
  });

  it('fails closed IMMEDIATELY on a blank username instead of polling for a vacuous match', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);

    const verdict = await waitForProfilePainted(page.asPage(), {
      username: '   ',
      timeoutMs: 5_000,
      pollIntervalMs: 1,
    });

    // '' is a substring of every string, so the identity half of the predicate would be
    // vacuous â€” there is nothing to prove, so nothing is proved, and no budget is burned.
    expect(verdict.ready).toBe(false);
    expect(verdict.reason).toBe('identity-missing');
    expect(page.evaluateCalls).toBe(0);
  });
});

describe('blankness backstop â€” calibrated against the production measurements', () => {
  /** The CSS-pixel size of the one CORRECT capture taken during the incident. */
  const W = 701;
  const H = 483;
  const bytesFor = (bytesPerPixel: number): number => Math.round(W * H * bytesPerPixel);

  it('rejects both blank captures that were classified ACTIVE and would have been delivered', () => {
    for (const measured of [0.016, 0.026]) {
      const density = assessImageDensity(bytesFor(measured), W, H);
      expect(density.ok).toBe(false);
    }
  });

  it('accepts a tight header crop and the full-viewport captures taken after the predicate held', () => {
    for (const measured of [0.48, 1.16, 1.42, 1.96]) {
      const density = assessImageDensity(bytesFor(measured), W, H);
      expect(density.ok).toBe(true);
    }
  });

  it('leaves real headroom on both sides rather than sitting on a single measurement', () => {
    expect(MIN_IMAGE_BYTES_PER_PIXEL).toBeGreaterThan(0.026 * 2);
    expect(MIN_IMAGE_BYTES_PER_PIXEL).toBeLessThan(0.48 / 2);
  });

  it('fails CLOSED for an image whose area cannot be reasoned about', () => {
    expect(assessImageDensity(500_000, 0, H).ok).toBe(false);
    expect(assessImageDensity(500_000, Number.NaN, H).ok).toBe(false);
    expect(assessImageDensity(500_000, -10, H).ok).toBe(false);
  });

  it('discards blank-looking BYTES even when the DOM insisted the profile had painted', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);
    // The DOM predicate holds â€” this is the one failure mode it cannot see: the compositor had
    // not produced the frame. 0.026 B/px is the DENSER of the two blanks shipped to a client.
    page.bytesPerPixel = 0.026;

    await expect(captureProfileScreenshot(page.asPage(), NO_DISMISS)).rejects.toThrow(
      /looks blank/i,
    );

    // The shutter fired, but the bytes are thrown away rather than delivered as proof.
    expect(page.screenshotClips).toHaveLength(1);
  });

  it('surfaces the blank rejection as a structured AppError so the caller degrades to text', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);
    page.bytesPerPixel = 0.016;

    const error = await captureProfileScreenshot(page.asPage(), NO_DISMISS).catch(
      (err: unknown) => err,
    );
    expect(isAppError(error)).toBe(true);
    if (isAppError(error)) expect(error.code).toBe('SCREENSHOT_INVALID');
  });

  it('delivers a capture whose density matches a real tight crop', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);
    page.bytesPerPixel = GOOD_CROP_BYTES_PER_PIXEL;

    const shot = await captureProfileScreenshot(page.asPage(), NO_DISMISS);

    expect(shot.buffer.length / (shot.width * shot.height)).toBeGreaterThan(
      MIN_IMAGE_BYTES_PER_PIXEL,
    );
    expect(validateImage(shot.buffer).ok).toBe(true);
  });
});

describe('occlusion probe â€” the signup interstitial that reached a client', () => {
  it('detects an occluding overlay that carries NO aria role, and suppresses the capture', async () => {
    const { doc } = buildProfile();
    const { root, card } = attachSignupModal(doc.body);
    const page = new FakePage(doc);

    // The blind spot, made explicit: nothing in this overlay is a dialog/presentation node.
    expect(root.getAttribute('role')).toBeNull();
    expect(card.getAttribute('role')).toBeNull();

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('occluded');
    expect(await hasBlockingOverlay(page.asPage())).toBe(true);

    await expect(captureProfileScreenshot(page.asPage(), NO_DISMISS)).rejects.toThrow(
      /No clean profile capture available \(occluded\)/,
    );
    // The invariant: nothing was photographed, so nothing misleading can be delivered.
    expect(page.screenshotClips).toHaveLength(0);
  });

  it('dismisses a modal via its real close control, then returns a clean capture', async () => {
    const { doc, header } = buildProfile();
    const { root } = attachSignupModal(doc.body);
    const page = new FakePage(doc);
    page.controls.set('svg[aria-label="Close"]', {
      visible: true,
      clicks: 0,
      onClick: () => root.parentNode?.removeChild(root),
    });

    const shot = await captureProfileScreenshot(page.asPage(), FAST);

    expect(page.controls.get('svg[aria-label="Close"]')?.clicks).toBe(1);
    expect(doc.body.descendants()).not.toContain(root);
    expect(doc.body.descendants()).toContain(header);
    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
    expect(shot.format).toBe('png');
    expect(shot.width).toBe(EXPECTED_CLIP.width);
    expect(shot.height).toBe(EXPECTED_CLIP.height);
  });

  it('removes an undismissable modal geometrically when no close control exists', async () => {
    const { doc, header } = buildProfile();
    const { root } = attachSignupModal(doc.body);
    const page = new FakePage(doc);
    // No controls registered at all: every label/ARIA heuristic misses, as it does in
    // production whenever Instagram renames things.

    const shot = await captureProfileScreenshot(page.asPage(), FAST);

    expect(doc.body.descendants()).not.toContain(root);
    expect(doc.body.descendants()).toContain(header);
    expect(page.escapePresses).toBeGreaterThan(0);
    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
    expect(shot.width).toBe(EXPECTED_CLIP.width);
  });

  it('never removes an ancestor of the header, so a nested modal cannot destroy the profile', async () => {
    const { doc, header, main } = buildProfile();
    // Modal mounted INSIDE the same subtree as the profile â€” climbing too far would delete it.
    const { root } = attachSignupModal(main);
    const page = new FakePage(doc);

    await dismissOverlays(page.asPage());

    expect(main.contains(header)).toBe(true);
    expect(doc.body.descendants()).toContain(header);
    expect(doc.body.descendants()).not.toContain(root);
    expect((await probeHeaderVisibility(page.asPage())).visible).toBe(true);
  });
});

describe('occlusion probe â€” the delivered clip is exactly the proven region', () => {
  it('rejects a login sheet that overlaps only the BOTTOM sliver of the header (below any ratio threshold)', async () => {
    const { doc } = buildProfile();
    // The verified VPS failure: Instagram's logged-out sheet whose top edge sits 25px into
    // the header (8.3% of its area). The old probe sampled no point below the 85% row and
    // its sweep ignored anything under a 10% overlap ratio, so 53px of "Log in / Sign up"
    // was baked into the delivered image while every check reported clean.
    doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(0, 355, 1280, 545),
        position: 'fixed',
        background: 'rgb(255, 255, 255)',
        text: 'Log in to see photos and videos from friends.',
      }),
    );
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('occluded');

    await expect(captureProfileScreenshot(page.asPage(), NO_DISMISS)).rejects.toThrow(
      /No clean profile capture available/,
    );
    expect(page.screenshotClips).toHaveLength(0);
  });

  it('retracts the bottom padding when a sheet sits in the band BELOW the header, and still delivers', async () => {
    const { doc } = buildProfile();
    // Sheet entirely below the header (rows 385..900) but inside the 28px padding band
    // (rows 380..408). The old code photographed it; suppressing entirely would violate
    // the other invariant. The fix: deliver the card WITHOUT the unproven band.
    doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(0, 385, 1280, 515),
        position: 'fixed',
        background: 'rgb(255, 255, 255)',
        text: 'Log in to see photos and videos from friends.',
      }),
    );
    const page = new FakePage(doc);

    const shot = await captureProfileScreenshot(page.asPage(), NO_DISMISS);

    // Bottom edge retracted to the header's own edge (y 380); nothing below it delivered.
    expect(page.screenshotClips).toEqual([{ x: 137, y: 52, width: 1006, height: 328 }]);
    expect(shot.height).toBe(328);
  });

  it('excludes a fixed banner that only crosses the TOP padding band, without suppressing the capture', async () => {
    const { doc } = buildProfile();
    // Zero overlap with the header box itself, so the old sweep never looked at it â€” yet
    // 28px of it (rows 52..80) landed inside the delivered clip.
    doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(0, 40, 1280, 40),
        position: 'fixed',
        background: 'rgb(38, 38, 38)',
        text: 'Open the app',
      }),
    );
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    // Both invariants at once: still visible (a margin banner must not kill the capture)...
    expect(probe.visible).toBe(true);

    const shot = await captureProfileScreenshot(page.asPage(), NO_DISMISS);
    // ...but the top padding is retracted to the header edge, so no banner pixel ships.
    expect(page.screenshotClips).toEqual([{ x: 137, y: 80, width: 1006, height: 328 }]);
    expect(shot.height).toBe(328);
  });

  it('keeps in-flow page content in the padding band (the posts grid is the page, not an overlay)', async () => {
    const { doc, main } = buildProfile();
    // Static content directly below the header, crossing the bottom band â€” the real page.
    main.append(
      new FakeElement({
        tag: 'div',
        box: rect(165, 381, 950, 400),
        background: 'rgb(255, 255, 255)',
        text: 'POSTS REELS TAGGED',
      }),
    );
    const page = new FakePage(doc);

    const shot = await captureProfileScreenshot(page.asPage(), NO_DISMISS);
    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
    expect(shot.height).toBe(EXPECTED_CLIP.height);
  });
});

describe('occlusion probe â€” clean pages still produce the header card', () => {
  it('returns the padded header crop, not a full-viewport shot', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(true);
    expect(probe.reason).toBe('ok');
    expect(probe.box).toEqual({ x: 165, y: 80, width: 950, height: 300 });
    expect(probe.clip).toEqual(EXPECTED_CLIP);

    const shot = await captureProfileScreenshot(page.asPage(), NO_DISMISS);

    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
    expect(shot.width).toBe(1006);
    expect(shot.height).toBe(356);
    // Not the whole page: the compact profile-header card the owner approved.
    expect(shot.height).toBeLessThan(900);
    expect(validateImage(shot.buffer).ok).toBe(true);
  });

  it('does not suppress a capture for a fixed toast that misses the header', async () => {
    const { doc } = buildProfile();
    doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(20, 780, 240, 90),
        position: 'fixed',
        background: 'rgb(255, 255, 255)',
        text: 'Saved to collection',
      }),
    );
    const page = new FakePage(doc);

    expect(await hasBlockingOverlay(page.asPage())).toBe(false);
    const shot = await captureProfileScreenshot(page.asPage(), NO_DISMISS);
    expect(shot.width).toBe(EXPECTED_CLIP.width);
  });

  it('ignores a hidden overlay that is not actually painted', async () => {
    const { doc } = buildProfile();
    doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(0, 0, 1280, 900),
        position: 'fixed',
        display: 'none',
        pointerEvents: 'none',
        background: 'rgb(255, 255, 255)',
      }),
    );
    const page = new FakePage(doc);

    expect((await probeHeaderVisibility(page.asPage())).visible).toBe(true);
  });

  it("does not flag Instagram's painted background layer that sits BEHIND all content", async () => {
    const { doc } = buildProfile();
    // Shipped on every logged-out profile page: position fixed, full viewport, painted,
    // pointer-events none, z-index -9999 â€” 100% bounding-box overlap with the header while
    // being VISUALLY behind it. The old sweep called this an occluder and downgraded a
    // perfectly clean page to a text-only alert.
    doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(0, 0, 1280, 900),
        position: 'fixed',
        pointerEvents: 'none',
        zIndex: '-9999',
        background: 'rgb(250, 250, 250)',
      }),
    );
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(true);
    expect(probe.reason).toBe('ok');

    const shot = await captureProfileScreenshot(page.asPage(), NO_DISMISS);
    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
    expect(shot.width).toBe(EXPECTED_CLIP.width);
  });

  it('does not flag a transparent, empty, hit-testable portal root ON TOP of the page', async () => {
    const { doc } = buildProfile();
    // Instagram's empty full-viewport portal containers: hit-testable and above everything,
    // but they paint nothing. The old PRIMARY check took elementFromPoint's word for it and
    // reported the header occluded by an invisible div.
    doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(0, 0, 1280, 900),
        position: 'fixed',
      }),
    );
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(true);
    expect(probe.reason).toBe('ok');

    const shot = await captureProfileScreenshot(page.asPage(), NO_DISMISS);
    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
    expect(shot.width).toBe(EXPECTED_CLIP.width);
  });
});

describe('occlusion probe â€” signals that markup checks cannot provide', () => {
  it('catches a click-through overlay that hit-testing alone would see straight past', async () => {
    const { doc, header } = buildProfile();
    const ghost = doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(0, 0, 1280, 900),
        position: 'fixed',
        pointerEvents: 'none',
        opacity: '0.9',
        background: 'rgb(255, 255, 255)',
      }),
    );
    const page = new FakePage(doc);

    // Sanity: elementFromPoint really does see past it, so only the geometric sweep can
    // catch this one. (Painted pixels land in the screenshot regardless of pointer-events.)
    const hit = doc.elementFromPoint(640, 230);
    expect(hit).not.toBe(ghost);
    expect(header.contains(hit)).toBe(true);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('occluded');
  });

  it('catches a PAINTED click-through scrim that is position:absolute, not fixed/sticky', async () => {
    const { doc } = buildProfile();
    // The adversarial finding: same class of mistake as the old role="dialog" guard, just
    // keyed on a CSS property â€” the old sweep only looked at fixed/sticky, so an absolute
    // painted scrim (invisible to hit-testing via pointer-events: none) sailed through.
    doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(0, 0, 1280, 900),
        position: 'absolute',
        pointerEvents: 'none',
        background: 'rgba(255, 255, 255, 0.92)',
      }),
    );
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('occluded');

    await expect(captureProfileScreenshot(page.asPage(), NO_DISMISS)).rejects.toThrow(
      /No clean profile capture available/,
    );
  });

  it('rejects an image when an interstitial remounts between the shutter and the check', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);
    page.afterScreenshot = (): void => {
      attachSignupModal(doc.body);
      page.afterScreenshot = null;
    };

    await expect(captureProfileScreenshot(page.asPage(), NO_DISMISS)).rejects.toThrow(
      /overlay appeared while capturing/i,
    );
    // The shutter fired, but the bytes are discarded rather than delivered.
    expect(page.screenshotClips).toHaveLength(1);
  });

  it('rejects an image when the page is REPLACED after the shutter by one with its own clean header', async () => {
    const { doc, header, main } = buildProfile();
    const page = new FakePage(doc);
    page.afterScreenshot = (): void => {
      // An interstitial that swaps the whole page and brings a LARGER header of its own:
      // the after-probe sees a perfectly visible header â€” just not the one photographed.
      // Without comparing regions, the old check declared the stale image proven.
      header.parentNode?.removeChild(header);
      const replacement = main.append(
        new FakeElement({ tag: 'header', box: rect(100, 60, 1080, 400) }),
      );
      replacement.append(new FakeElement({ tag: 'img', box: rect(120, 80, 150, 150) }));
      replacement.append(
        new FakeElement({ tag: 'h2', box: rect(300, 90, 300, 40), text: 'instagram' }),
      );
      page.afterScreenshot = null;
    };

    await expect(captureProfileScreenshot(page.asPage(), NO_DISMISS)).rejects.toThrow(
      /header region changed while capturing/i,
    );
    expect(page.screenshotClips).toHaveLength(1);
  });

  it('has no blind full-viewport fallback when the header is missing', async () => {
    const doc = new FakeDocument();
    doc.body.append(new FakeElement({ tag: 'main', box: rect(0, 0, 1280, 900) }));
    const page = new FakePage(doc);

    const probe = await ensureHeaderVisible(page.asPage(), FAST);
    expect(probe.reason).toBe('no-header');
    // No header crop, no centered-column clip, no full viewport: a ladder whose lower rungs
    // photograph the composited viewport cannot tell "no header yet" from "header here", and
    // that is exactly how both blanks were produced.
    await expect(captureProfileScreenshot(page.asPage(), FAST)).rejects.toThrow(/no-header/);
    expect(page.screenshotClips).toHaveLength(0);
  });

  it('treats a stray undersized <header> as unusable rather than cropping it', async () => {
    const doc = new FakeDocument();
    const main = doc.body.append(new FakeElement({ tag: 'main', box: rect(0, 0, 1280, 900) }));
    main.append(new FakeElement({ tag: 'header', box: rect(0, 0, 180, 40) }));
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('header-too-small');
  });

  it('refuses to clip a header that is partly off-screen', async () => {
    const { doc, header } = buildProfile();
    header.box = rect(165, 700, 950, 300); // bottom edge past the 900px viewport
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('header-off-screen');
  });
});

describe('occlusion probe â€” the DOM sweep cannot be dodged by DOM size', () => {
  it('still finds a click-through overlay portalled to the END of a heavy DOM (index > 4000)', async () => {
    const { doc } = buildProfile();
    // The old sweep silently stopped at element 4000 and reported the page clean. Modals
    // are portalled to the end of <body> â€” exactly the slice the truncation discarded.
    const filler = doc.body.append(new FakeElement({ tag: 'div', box: rect(0, 0, 0, 0) }));
    for (let i = 0; i < 4200; i += 1) {
      filler.append(new FakeElement({ tag: 'span', box: rect(0, 0, 0, 0) }));
    }
    doc.body.append(
      new FakeElement({
        tag: 'div',
        box: rect(0, 0, 1280, 900),
        position: 'fixed',
        pointerEvents: 'none',
        background: 'rgb(255, 255, 255)',
      }),
    );
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('occluded');
  });

  it('fails CLOSED (never open) when the DOM exceeds the scan cap entirely', async () => {
    const { doc } = buildProfile();
    const filler = doc.body.append(new FakeElement({ tag: 'div', box: rect(0, 0, 0, 0) }));
    for (let i = 0; i < 40_001; i += 1) {
      filler.append(new FakeElement({ tag: 'span', box: rect(0, 0, 0, 0) }));
    }
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('scan-truncated');

    await expect(captureProfileScreenshot(page.asPage(), NO_DISMISS)).rejects.toThrow(
      /scan-truncated/,
    );
    expect(page.screenshotClips).toHaveLength(0);
  });
});

describe('page functions survive the evaluate boundary', () => {
  it('ships source that references only page globals, with no bundler helpers', async () => {
    const { doc } = buildProfile();
    attachSignupModal(doc.body);
    const page = new FakePage(doc);

    await probeRenderReady(page.asPage(), USERNAME);
    await dismissOverlays(page.asPage());
    await probeHeaderVisibility(page.asPage());

    // All three page functions were exercised.
    expect(page.evaluatedSources.length).toBeGreaterThanOrEqual(3);
    for (const source of page.evaluatedSources) {
      // esbuild's keepNames (which tsx enables) rewrites nested functions to
      // `__name(fn, "fn")`. `__name` lives in module scope and does NOT exist in a page, so
      // its presence here would mean every probe throws in production while CI stays green.
      expect(source).not.toMatch(/__name\s*\(/);
      // The rule that keeps the above true: no nested function of any kind in a page function.
      const body = source.replace(/^function\s+[A-Za-z0-9_$]*\s*\(/, '');
      expect(body).not.toMatch(/=>/);
      expect(body).not.toMatch(/function\s*[A-Za-z0-9_$]*\s*\(/);
    }
  });

  it('picks the largest header, so site chrome cannot hijack the crop', async () => {
    const { doc, main } = buildProfile();
    // A full-width chrome <header> BEFORE the profile header in the document, and TALL
    // enough to clear the minimum-height gate â€” the area comparison itself must reject it.
    const chrome = new FakeElement({ tag: 'header', box: rect(0, 0, 1280, 100) });
    main.children.unshift(chrome);
    chrome.parentElement = main;
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(true);
    expect(probe.box).toEqual({ x: 165, y: 80, width: 950, height: 300 });
  });

  it('resolves the SAME header in the paint probe and the occlusion probe', async () => {
    const { doc, main } = buildProfile();
    const chrome = new FakeElement({ tag: 'header', box: rect(0, 0, 1280, 100) });
    main.children.unshift(chrome);
    chrome.parentElement = main;
    const page = new FakePage(doc);

    // If the two probes ever disagreed about WHICH header they are talking about, a painted
    // profile could be certified against site chrome (or vice versa).
    const painted = await probeRenderReady(page.asPage(), USERNAME);
    const visible = await probeHeaderVisibility(page.asPage());
    expect(painted.ready).toBe(true);
    expect(painted.box).toEqual(visible.box);
  });
});

describe('occlusion probe â€” failure paths fail CLOSED', () => {
  it('tolerates a page whose evaluate throws and reports not-visible', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);
    page.evaluateThrows = true;

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('probe-failed');
    expect(await hasBlockingOverlay(page.asPage())).toBe(true);

    await expect(captureProfileScreenshot(page.asPage(), NO_DISMISS)).rejects.toThrow(
      /probe-failed/,
    );
    expect(page.screenshotClips).toHaveLength(0);
  });

  it('tolerates elementFromPoint throwing inside the page', async () => {
    const { doc } = buildProfile();
    doc.elementFromPointThrows = true;
    const page = new FakePage(doc);

    const probe = await probeHeaderVisibility(page.asPage());
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('probe-failed');

    // The paint predicate does not hit-test at all, so it still answers â€” the capture is then
    // stopped by the occlusion proof rather than by an unpainted page.
    const painted = await probeRenderReady(page.asPage(), USERNAME);
    expect(painted.ready).toBe(true);

    // dismissOverlays must not throw either â€” it is called on every capture attempt.
    await expect(dismissOverlays(page.asPage())).resolves.toBeUndefined();
  });

  it('surfaces a structured AppError so the caller degrades to text-only', async () => {
    const { doc } = buildProfile();
    attachSignupModal(doc.body);
    const page = new FakePage(doc);

    const error = await captureProfileScreenshot(page.asPage(), NO_DISMISS).catch(
      (err: unknown) => err,
    );
    expect(isAppError(error)).toBe(true);
    if (isAppError(error)) expect(error.code).toBe('SCREENSHOT_INVALID');
  });

  it('ignores a malformed probe payload instead of trusting it', async () => {
    const { doc } = buildProfile();
    const page = new FakePage(doc);
    const broken = {
      ...page,
      evaluate: async (): Promise<unknown> => Promise.resolve({ nonsense: true }),
    } as unknown as Page;

    const probe = await probeHeaderVisibility(broken);
    expect(probe.visible).toBe(false);
    expect(probe.reason).toBe('probe-failed');
  });
});

/**
 * THE GREY CIRCLE. The one capture that DID succeed through the mobile proxy came back in 13.5s
 * with a 701x431 card whose profile picture was an empty grey circle: the text predicate held
 * long before the header's own images arrived (measured 8.1s / 16.0s / 18.0s / 70.2s after text
 * paint), and the shutter fired the instant it did.
 *
 * The fix is a wait, and the danger in a wait is that it becomes a gate. These tests pin BOTH
 * halves: it must actually hold the shutter for a pending avatar, and it must let go â€” with the
 * capture still happening â€” on every path that could otherwise hang it.
 */
describe('header-image wait â€” the avatar that was a grey circle', () => {
  /** A painted profile whose header images are still in flight. Returns the avatar element. */
  function buildProfileWithPendingImages(): {
    doc: FakeDocument;
    header: FakeElement;
    avatar: FakeElement;
    highlight: FakeElement;
  } {
    const { doc, header } = buildUnpaintedProfile();
    const avatar = header.append(
      new FakeElement({ tag: 'img', box: rect(190, 100, 150, 150), complete: false }),
    );
    header.append(new FakeElement({ tag: 'h2', box: rect(400, 100, 300, 40), text: USERNAME }));
    header.append(new FakeElement({ tag: 'ul', box: rect(400, 160, 400, 40), text: COUNTERS }));
    header.append(new FakeElement({ tag: 'div', box: rect(400, 210, 500, 60), text: BIO }));
    // A story-highlight thumbnail: inside the crop, and the second thing the wait exists for.
    const highlight = header.append(
      new FakeElement({ tag: 'img', box: rect(400, 280, 70, 70), complete: false }),
    );
    return { doc, header, avatar, highlight };
  }

  /** A real (but tiny) header-image budget, so the wait is exercised without slowing the suite. */
  const WAITING = {
    ...NO_DISMISS,
    headerImageWaitMs: 2_000,
    headerImagePollIntervalMs: 5,
  } as const;

  it('holds the shutter while the avatar is still loading, and fires once it lands', async () => {
    const { doc, avatar, highlight } = buildProfileWithPendingImages();
    const page = new FakePage(doc);

    // The images ARRIVE partway through the wait â€” the page settles on its own schedule, which
    // is the only thing that may end the wait early.
    let imageProbes = 0;
    page.beforeEvaluate = (_source, arg): void => {
      if (
        typeof arg === 'object' &&
        arg !== null &&
        'maxScan' in arg &&
        !('pad' in arg) &&
        !('maxPasses' in arg)
      ) {
        imageProbes += 1;
        if (imageProbes === 4) {
          avatar.complete = true;
          highlight.complete = true;
        }
      }
    };

    const shot = await captureProfileScreenshot(page.asPage(), WAITING);

    // It waited (more than the single opening probe)...
    expect(imageProbes).toBeGreaterThan(1);
    // ...and it did not wait a moment longer than it had to.
    expect(imageProbes).toBeLessThan(20);
    // ...and the picture is still the proven header card, unchanged by any of this.
    expect(shot.width).toBe(EXPECTED_CLIP.width);
    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
  });

  it('is BOUNDED: an avatar that never arrives still yields the card, just without it', async () => {
    // The whole trade, stated as a test. A correct card with a grey circle is proof; a capture
    // that hung waiting for an image is the client never being told at all.
    const { doc } = buildProfileWithPendingImages();
    const page = new FakePage(doc);

    const started = Date.now();
    const shot = await captureProfileScreenshot(page.asPage(), {
      ...NO_DISMISS,
      headerImageWaitMs: 60,
      headerImagePollIntervalMs: 5,
    });
    const elapsed = Date.now() - started;

    expect(shot.format).toBe('png');
    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
    // Bounded by the budget it was given, not by the image it was waiting for.
    expect(elapsed).toBeLessThan(2_000);
  });

  it('does not wait at all when no budget was granted', async () => {
    // The module default is zero on purpose: only the detector knows the caller's remaining
    // budget, so this file never spends one nobody handed it.
    const { doc } = buildProfileWithPendingImages();
    const page = new FakePage(doc);

    await captureProfileScreenshot(page.asPage(), NO_DISMISS);

    const imageProbeArgs = page.evaluatedArgs.filter(
      (arg) =>
        typeof arg === 'object' &&
        arg !== null &&
        'maxScan' in arg &&
        !('pad' in arg) &&
        !('maxPasses' in arg),
    );
    expect(imageProbeArgs).toHaveLength(0);
    expect(page.screenshotClips).toEqual([EXPECTED_CLIP]);
  });

  it('FAILS OPEN when the probe cannot run, rather than burning the whole window', async () => {
    // Every safety probe in this file fails CLOSED. This one is the exception, and it has to be:
    // it decides only how long to WAIT, so a probe error must cost nothing rather than cost the
    // client their picture.
    const { doc } = buildProfileWithPendingImages();
    const page = new FakePage(doc);
    const seen: unknown[] = [];
    const flaky = {
      ...page,
      evaluate: async (fn: (arg: unknown) => unknown, arg?: unknown): Promise<unknown> => {
        seen.push(arg);
        if (
          typeof arg === 'object' &&
          arg !== null &&
          'maxScan' in arg &&
          !('pad' in arg) &&
          !('maxPasses' in arg)
        ) {
          throw new Error('Execution context was destroyed');
        }
        return page.evaluate(fn, arg);
      },
      screenshot: page.screenshot.bind(page),
    } as unknown as Page;

    const verdict = await waitForHeaderImages(flaky, { timeoutMs: 2_000, pollIntervalMs: 5 });

    expect(verdict.ready).toBe(true);
    expect(verdict.reason).toBe('probe-failed');
    // One look, then straight through â€” not a full window of doomed retries.
    expect(seen).toHaveLength(1);
  });

  it('counts only images INSIDE the header, so the post grid can never hold the shutter', async () => {
    // The grid is cropped out of the delivered image and is exactly what the capture asset
    // budget stops fetching. If it counted here, blocking it would deadlock the wait forever.
    const { doc, header, avatar, highlight } = buildProfileWithPendingImages();
    avatar.complete = true;
    highlight.complete = true;
    const main = header.parentElement;
    expect(main).not.toBeNull();
    for (let i = 0; i < 12; i += 1) {
      main?.append(
        new FakeElement({ tag: 'img', box: rect(200 + i * 60, 500, 50, 50), complete: false }),
      );
    }
    const page = new FakePage(doc);

    const verdict = await waitForHeaderImages(page.asPage(), {
      timeoutMs: 2_000,
      pollIntervalMs: 5,
    });

    expect(verdict.total).toBe(2);
    expect(verdict.settled).toBe(2);
    expect(verdict.ready).toBe(true);
    expect(verdict.reason).toBe('ok');
  });

  it('treats a FAILED image as settled, so a blocked or 404 avatar cannot hang the wait', async () => {
    // `complete` flips to true on error as well as on success â€” which is what makes the
    // placeholder served by the capture image budget safe: it can only ever end the wait sooner.
    const { doc, avatar, highlight } = buildProfileWithPendingImages();
    avatar.complete = true; // errored: complete, but nothing was painted
    highlight.complete = true;
    const page = new FakePage(doc);

    const verdict = await waitForHeaderImages(page.asPage(), {
      timeoutMs: 2_000,
      pollIntervalMs: 5,
    });
    expect(verdict.ready).toBe(true);
  });

  it('ships source with no bundler helpers, like every other page function here', async () => {
    // Same trap as the rest: a nested function becomes `__name(...)` under esbuild's keepNames,
    // which does not exist in the page â€” and a probe that throws here silently disables the wait.
    const { doc } = buildProfileWithPendingImages();
    const page = new FakePage(doc);

    await waitForHeaderImages(page.asPage(), { timeoutMs: 0 });
    await probeHeaderImages(page.asPage());

    const source = page.evaluatedSources[page.evaluatedSources.length - 1] ?? '';
    expect(source).not.toContain('__name');
    expect(source.length).toBeGreaterThan(0);
  });
});
