import { describe, it, expect } from 'vitest';

import { DiscordNotifier } from '../../src/bot/discord/discord-notifier';
import { nullLogger } from '../../src/logging/logger';

const TOKEN = 'test-bot-token-abcdefghijklmnop';

interface FetchCall {
  url: string;
  init: RequestInit;
}

function recordingFetch(status = 200): { fn: typeof fetch; calls: FetchCall[] } {
  const calls: FetchCall[] = [];
  const fn = (async (url: string | URL | Request, init?: RequestInit): Promise<Response> => {
    calls.push({ url: String(url), init: init ?? {} });
    return new Response(null, { status });
  }) as unknown as typeof fetch;
  return { fn, calls };
}

function makeNotifier(
  fetchImpl: typeof fetch,
  channels?: Partial<{ unbans: string | null; deletions: string | null; status: string | null }>,
): DiscordNotifier {
  return new DiscordNotifier({
    botToken: TOKEN,
    channels: {
      unbans: channels?.unbans ?? null,
      deletions: channels?.deletions ?? null,
      status: channels?.status ?? null,
    },
    logger: nullLogger(),
    fetchImpl,
  });
}

describe('DiscordNotifier', () => {
  it('is a no-op when the target channel id is null', async () => {
    const { fn, calls } = recordingFetch();
    const n = makeNotifier(fn, { unbans: null });
    await n.unban('recovered!');
    expect(calls).toHaveLength(0);
  });

  it('posts text as JSON to the configured channel with a Bot auth header', async () => {
    const { fn, calls } = recordingFetch();
    const n = makeNotifier(fn, { unbans: '111' });
    await n.unban('@foo is active again');
    expect(calls).toHaveLength(1);
    const call = calls[0]!;
    expect(call.url).toBe('https://discord.com/api/v10/channels/111/messages');
    expect(call.init.method).toBe('POST');
    const headers = call.init.headers as Record<string, string>;
    expect(headers['Authorization']).toBe(`Bot ${TOKEN}`);
    expect(headers['Content-Type']).toBe('application/json');
    const body = JSON.parse(call.init.body as string) as {
      embeds: { description: string; color: number }[];
    };
    expect(body.embeds[0]!.description).toBe('@foo is active again');
    expect(body.embeds[0]!.color).toBe(0x57f287);
  });

  it('routes deletion and status to their own channels', async () => {
    const { fn, calls } = recordingFetch();
    const n = makeNotifier(fn, { deletions: '222', status: '333' });
    await n.deletion('gone');
    await n.status('degraded');
    expect(calls.map((c) => c.url)).toEqual([
      'https://discord.com/api/v10/channels/222/messages',
      'https://discord.com/api/v10/channels/333/messages',
    ]);
  });

  it('uploads an image as multipart/form-data', async () => {
    const { fn, calls } = recordingFetch();
    const n = makeNotifier(fn, { unbans: '111' });
    await n.unban('caption', { buffer: Buffer.from([1, 2, 3]), filename: 'foo.png' });
    const call = calls[0]!;
    expect(call.init.body).toBeInstanceOf(FormData);
    const form = call.init.body as FormData;
    const payload = JSON.parse(form.get('payload_json') as string) as {
      embeds: { description: string; image: { url: string } }[];
    };
    expect(payload.embeds[0]!.description).toBe('caption');
    expect(payload.embeds[0]!.image.url).toBe('attachment://foo.png');
    expect(form.get('files[0]')).toBeInstanceOf(Blob);
    // JSON Content-Type must NOT be set for multipart (fetch sets the boundary itself).
    const headers = call.init.headers as Record<string, string>;
    expect(headers['Content-Type']).toBeUndefined();
  });

  it('truncates a long embed description to the 4096-char limit', async () => {
    const { fn, calls } = recordingFetch();
    const n = makeNotifier(fn, { unbans: '111' });
    await n.unban('x'.repeat(9000));
    const body = JSON.parse(calls[0]!.init.body as string) as {
      embeds: { description: string }[];
    };
    expect(body.embeds[0]!.description.length).toBeLessThanOrEqual(4096);
    expect(body.embeds[0]!.description.endsWith('…')).toBe(true);
  });

  it('never throws when fetch rejects (best-effort)', async () => {
    const fn = (async (): Promise<Response> => {
      throw new Error('network down');
    }) as unknown as typeof fetch;
    const n = makeNotifier(fn, { unbans: '111' });
    await expect(n.unban('hi')).resolves.toBe(false);
  });

  it('never throws on a non-2xx Discord response, and reports failure', async () => {
    const { fn } = recordingFetch(429);
    const n = makeNotifier(fn, { unbans: '111' });
    await expect(n.unban('hi')).resolves.toBe(false);
  });

  it('reports success (true) on a 2xx post and false when no channel is set', async () => {
    const { fn } = recordingFetch(200);
    expect(await makeNotifier(fn, { unbans: '111' }).unban('ok')).toBe(true);
    expect(await makeNotifier(fn, { unbans: null }).unban('skip')).toBe(false);
  });
});
