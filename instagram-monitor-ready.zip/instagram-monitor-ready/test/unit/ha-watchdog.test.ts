import { spawnSync } from 'node:child_process';
import {
  existsSync,
  mkdtempSync,
  mkdirSync,
  readFileSync,
  rmSync,
  utimesSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import Database from 'better-sqlite3';
import { afterEach, describe, expect, it } from 'vitest';

const SNAPSHOT_SCRIPT = resolve(process.cwd(), 'deploy', 'ha-snapshot.mjs');
const roots: string[] = [];

function createSnapshot(
  source: string,
  incoming: string,
  seq: number,
  agentBootId = 'agent-a',
): { archive: string; manifest: string } {
  const base = `snapshot-${agentBootId}-${seq}`;
  const archive = join(incoming, `${base}.sqlite.gz.ready`);
  const manifest = join(incoming, `${base}.json.ready`);
  const child = spawnSync(
    process.execPath,
    [
      SNAPSHOT_SCRIPT,
      'create',
      '--db',
      source,
      '--archive',
      archive,
      '--manifest',
      manifest,
      '--seq',
      String(seq),
      '--agent-boot-id',
      agentBootId,
    ],
    { encoding: 'utf8' },
  );
  expect(child.status, child.stderr).toBe(0);
  return { archive, manifest };
}

afterEach(() => {
  for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true });
});

describe('VPS snapshot promotion', () => {
  it('never moves latest.json backwards when an older upload arrives after a newer one', async () => {
    const root = mkdtempSync(join(tmpdir(), 'monitor-ha-watchdog-'));
    roots.push(root);
    const data = join(root, 'data');
    const incoming = join(data, 'ha', 'incoming');
    const source = join(data, 'source.sqlite');
    mkdirSync(data, { recursive: true });
    const db = new Database(source);
    db.exec(`
      CREATE TABLE scheduler_health (
        name TEXT PRIMARY KEY,
        last_scheduler_run_utc TEXT,
        updated_at_utc TEXT
      );
      CREATE TABLE payload (value TEXT NOT NULL);
      INSERT INTO scheduler_health VALUES ('__ping__', NULL, 'proc-1');
      INSERT INTO scheduler_health VALUES ('scheduler', 'sched-1', 'row-1');
      INSERT INTO payload VALUES ('older');
    `);
    const older = createSnapshot(source, incoming, 1);
    db.prepare(
      `UPDATE scheduler_health SET updated_at_utc = 'proc-2' WHERE name = '__ping__'`,
    ).run();
    db.prepare(
      `UPDATE scheduler_health SET last_scheduler_run_utc = 'sched-2' WHERE name = 'scheduler'`,
    ).run();
    db.prepare(`UPDATE payload SET value = 'newer'`).run();
    const newer = createSnapshot(source, incoming, 2);
    db.close();

    // Model a delayed old manifest: seq 2 was fully present first; seq 1 got the later mtime.
    const nowSeconds = Date.now() / 1000;
    utimesSync(newer.manifest, nowSeconds - 20, nowSeconds - 20);
    utimesSync(older.manifest, nowSeconds - 10, nowSeconds - 10);

    const oldApp = process.env['MONITOR_HA_APP_DIR'];
    const oldData = process.env['MONITOR_HA_DATA_DIR'];
    process.env['MONITOR_HA_APP_DIR'] = root;
    process.env['MONITOR_HA_DATA_DIR'] = data;
    let promoteIncomingSnapshots: () => Promise<void>;
    try {
      // @ts-expect-error The production watchdog is intentionally a plain Node ESM deployment file.
      const module = (await import('../../deploy/vps-watchdog.mjs')) as {
        promoteIncomingSnapshots: () => Promise<void>;
      };
      promoteIncomingSnapshots = module.promoteIncomingSnapshots;
    } finally {
      if (oldApp === undefined) delete process.env['MONITOR_HA_APP_DIR'];
      else process.env['MONITOR_HA_APP_DIR'] = oldApp;
      if (oldData === undefined) delete process.env['MONITOR_HA_DATA_DIR'];
      else process.env['MONITOR_HA_DATA_DIR'] = oldData;
    }

    await promoteIncomingSnapshots();

    const latest = JSON.parse(readFileSync(join(data, 'ha', 'latest.json'), 'utf8')) as {
      seq: number;
      agentBootId: string;
      createdAtUtc: string;
      dbFile: string;
    };
    expect(latest.seq).toBe(2);
    const promoted = new Database(join(data, 'ha', 'snapshots', latest.dbFile), {
      readonly: true,
    });
    expect(promoted.prepare(`SELECT value FROM payload`).pluck().get()).toBe('newer');
    promoted.close();
    expect(existsSync(older.archive)).toBe(false);
    expect(existsSync(older.manifest)).toBe(false);

    // Losing local agent state starts a new sequence epoch. A delayed file from an older epoch
    // still must not replace the newer database merely because its agent id differs.
    const staleEpoch = createSnapshot(source, incoming, 99, 'retired-agent');
    const staleManifest = JSON.parse(readFileSync(staleEpoch.manifest, 'utf8')) as Record<
      string,
      unknown
    >;
    staleManifest['createdAtUtc'] = '2000-01-01T00:00:00.000Z';
    writeFileSync(staleEpoch.manifest, JSON.stringify(staleManifest) + '\n');
    await promoteIncomingSnapshots();
    const afterDelayedEpoch = JSON.parse(readFileSync(join(data, 'ha', 'latest.json'), 'utf8')) as {
      seq: number;
      agentBootId: string;
    };
    expect(afterDelayedEpoch).toMatchObject({ seq: 2, agentBootId: 'agent-a' });
    expect(existsSync(staleEpoch.archive)).toBe(false);
    expect(existsSync(staleEpoch.manifest)).toBe(false);
  });
});
