import { afterEach, describe, expect, it, vi } from 'vitest';
import type { BrowserContext, Page } from 'playwright';

import { ACTIVE_SIGNALS, IDENTITY_ACTIVE_SIGNALS, SIGNALS_VERSION } from '../../src/domain';
import type { AppConfig } from '../../src/config';
import type { Logger } from '../../src/logging';
import { classify, classifyHtml, extractSnapshot } from '../../src/instagram/detector';
import { PlaywrightDetector } from '../../src/instagram/detector/playwright-detector';
import { TieredDetector } from '../../src/instagram/detector/tiered-detector';
import { BrowserManager } from '../../src/instagram/browser/browser-manager';
import { BrowserLoadGovernor } from '../../src/instagram/load-governor';
import { validateImage } from '../../src/instagram/screenshot/capture';
import { readFixture } from '../fixtures/instagram';

const IG = 'https://www.instagram.com';
const profileUrl = (u: string): string => `${IG}/${u}/`;

/**
 * A fake Chromium, good enough to exercise the REAL {@link BrowserManager}: request routing,
 * per-purpose timeouts, the concurrency semaphores and the warm-context pool. There is no browser
 * in CI, but nothing under test is stubbed here — only the browser it drives.
 *
 * Built through `vi.hoisted` so the `vi.mock` factory below (which is hoisted above the imports)
 * can reach it.
 */
const pw = vi.hoisted(() => {
  interface Handled {
    resourceType: string;
    url: string;
    action: 'continue' | 'abort' | 'fulfill';
    contentType: string | null;
    bodyLength: number;
  }
  type RouteHandler = (route: unknown) => void;

  class FakePage {
    readonly handled: Handled[] = [];
    readonly gotoTimeouts: Array<number | undefined> = [];
    readonly defaultTimeouts: number[] = [];
    readonly navigationTimeouts: number[] = [];
    routeHandler: RouteHandler | null = null;
    closed = false;
    html = '<!doctype html><body></body>';
    currentUrl = 'https://www.instagram.com/testuser/';
    /** Fires while the navigation is in flight — where a real page asks for its subresources. */
    onGoto: ((page: FakePage) => void) | null = null;

    async route(_pattern: string, handler: RouteHandler): Promise<void> {
      this.routeHandler = handler;
      return Promise.resolve();
    }

    setDefaultTimeout(ms: number): void {
      this.defaultTimeouts.push(ms);
    }

    setDefaultNavigationTimeout(ms: number): void {
      this.navigationTimeouts.push(ms);
    }

    async goto(_url: string, options?: { timeout?: number }): Promise<{ status: () => number }> {
      this.gotoTimeouts.push(options?.timeout);
      this.onGoto?.(this);
      return Promise.resolve({ status: () => 200 });
    }

    async waitForSelector(): Promise<null> {
      return Promise.resolve(null);
    }

    async content(): Promise<string> {
      return Promise.resolve(this.html);
    }

    url(): string {
      return this.currentUrl;
    }

    /** Probes report nothing, so no capture is ever certified from these tests. */
    async evaluate(): Promise<unknown> {
      return Promise.resolve(null);
    }

    async close(): Promise<void> {
      this.closed = true;
      return Promise.resolve();
    }

    /** Drive the installed router exactly as Chromium would when the page wants a resource. */
    request(resourceType: string, url: string): Handled {
      const record: Handled = {
        resourceType,
        url,
        action: 'continue',
        contentType: null,
        bodyLength: 0,
      };
      const handler = this.routeHandler;
      if (handler !== null) {
        handler({
          request: () => ({ resourceType: () => resourceType, url: () => url }),
          continue: async (): Promise<void> => {
            record.action = 'continue';
            return Promise.resolve();
          },
          abort: async (): Promise<void> => {
            record.action = 'abort';
            return Promise.resolve();
          },
          fulfill: async (options: {
            contentType?: string;
            body?: unknown;
            status?: number;
          }): Promise<void> => {
            record.action = 'fulfill';
            record.contentType = options.contentType ?? null;
            record.bodyLength = Buffer.isBuffer(options.body) ? options.body.length : 0;
            return Promise.resolve();
          },
        });
      }
      this.handled.push(record);
      return record;
    }
  }

  class FakeContext {
    readonly pages: FakePage[] = [];
    private readonly closeListeners: Array<() => void> = [];
    closed = false;

    constructor(readonly options: Record<string, unknown> = {}) {}

    async newPage(): Promise<FakePage> {
      const page = new FakePage();
      this.pages.push(page);
      return Promise.resolve(page);
    }

    setDefaultTimeout(): void {
      /* recorded per-page instead */
    }

    setDefaultNavigationTimeout(): void {
      /* recorded per-page instead */
    }

    on(event: string, callback: () => void): void {
      if (event === 'close') this.closeListeners.push(callback);
    }

    async close(): Promise<void> {
      if (this.closed) return Promise.resolve();
      this.closed = true;
      for (const callback of this.closeListeners) callback();
      return Promise.resolve();
    }
  }

  class FakeBrowser {
    readonly contexts: FakeContext[] = [];
    private connected = true;

    async newContext(options: Record<string, unknown> = {}): Promise<FakeContext> {
      const context = new FakeContext(options);
      this.contexts.push(context);
      return Promise.resolve(context);
    }

    isConnected(): boolean {
      return this.connected;
    }

    async close(): Promise<void> {
      this.connected = false;
      return Promise.resolve();
    }
  }

  const state = { browsers: [] as FakeBrowser[] };
  return { state, FakePage, FakeContext, FakeBrowser };
});

vi.mock('playwright', () => ({
  chromium: {
    launch: async (): Promise<unknown> => {
      const browser = new pw.FakeBrowser();
      pw.state.browsers.push(browser);
      return Promise.resolve(browser);
    },
    connect: async (): Promise<unknown> => {
      const browser = new pw.FakeBrowser();
      pw.state.browsers.push(browser);
      return Promise.resolve(browser);
    },
  },
}));

describe('classify — Instagram detector against fixtures', () => {
  it('active profile with matching username => ACTIVE with >=2 signals incl. identity', () => {
    const result = classifyHtml(readFixture('active-profile'), {
      finalUrl: profileUrl('testuser'),
      responseStatus: 200,
      requestedUsername: 'testuser',
    });

    expect(result.classification).toBe('ACTIVE');
    expect(result.evidence.identitySignalMatched).toBe(true);
    expect(result.evidence.activeSignals.length).toBeGreaterThanOrEqual(2);
    expect(result.evidence.errorCode).toBeNull();
    expect(result.evidence.signalsVersion).toBe(SIGNALS_VERSION);

    const hasIdentitySignal = result.evidence.activeSignals.some((s) =>
      IDENTITY_ACTIVE_SIGNALS.has(s),
    );
    expect(hasIdentitySignal).toBe(true);
  });

  it('unavailable page => GONE', () => {
    const result = classifyHtml(readFixture('unavailable'), {
      finalUrl: profileUrl('testuser'),
      responseStatus: 200,
      requestedUsername: 'testuser',
    });

    expect(result.classification).toBe('GONE');
    expect(result.evidence.goneSignals).toContain('unavailable_message_present');
    expect(result.evidence.errorCode).toBeNull();
  });

  it('title-only unavailable shell => GONE', () => {
    const result = classifyHtml(
      "<!doctype html><title>Profile isn't available • Instagram</title><body></body>",
      {
        finalUrl: profileUrl('firearms'),
        responseStatus: 200,
        requestedUsername: 'firearms',
      },
    );
    expect(result.classification).toBe('GONE');
    expect(result.evidence.goneSignals).toContain('unavailable_title_present');
  });

  it('login wall at status 200 => UNKNOWN (LOGIN_WALL)', () => {
    const result = classifyHtml(readFixture('login-wall'), {
      finalUrl: profileUrl('testuser'),
      responseStatus: 200,
      requestedUsername: 'testuser',
    });

    expect(result.classification).toBe('UNKNOWN');
    expect(result.evidence.errorCode).toBe('LOGIN_WALL');
  });

  it('challenge / checkpoint page => UNKNOWN (CHALLENGE)', () => {
    const result = classifyHtml(readFixture('challenge'), {
      finalUrl: profileUrl('testuser'),
      responseStatus: 200,
      requestedUsername: 'testuser',
    });

    expect(result.classification).toBe('UNKNOWN');
    expect(result.evidence.errorCode).toBe('CHALLENGE');
  });

  it('a rejected configured login session has its own retryable error code', () => {
    const result = classifyHtml('<!doctype html><body>Confirm your account details</body>', {
      finalUrl:
        'https://www.instagram.com/accounts/update_risky_contactpoint/?challenge_context=opaque',
      responseStatus: 200,
      requestedUsername: 'testuser',
    });

    expect(result.classification).toBe('UNKNOWN');
    expect(result.evidence.errorCode).toBe('AUTH_SESSION_CHALLENGE');
  });

  it('rate limit with responseStatus 429 => UNKNOWN (HTTP_429)', () => {
    const result = classifyHtml(readFixture('rate-limit'), {
      finalUrl: profileUrl('testuser'),
      responseStatus: 429,
      requestedUsername: 'testuser',
    });

    expect(result.classification).toBe('UNKNOWN');
    expect(result.evidence.errorCode).toBe('HTTP_429');
  });

  it('unrecognized DOM => UNKNOWN', () => {
    const result = classifyHtml(readFixture('unexpected-dom'), {
      finalUrl: profileUrl('testuser'),
      responseStatus: 200,
      requestedUsername: 'testuser',
    });

    expect(result.classification).toBe('UNKNOWN');
    expect(result.evidence.errorCode).toBe('UNRECOGNIZED_DOM');
  });

  it('wrong-username page for a different requested user => NOT ACTIVE (identity mismatch)', () => {
    const result = classifyHtml(readFixture('wrong-username'), {
      finalUrl: profileUrl('testuser'),
      responseStatus: 200,
      requestedUsername: 'testuser',
    });

    expect(result.classification).not.toBe('ACTIVE');
    expect(result.evidence.identitySignalMatched).toBe(false);
  });

  it('active profile behind a login modal => still ACTIVE (identity present beneath overlay)', () => {
    const snapshot = extractSnapshot(readFixture('active-with-login-modal'), {
      finalUrl: profileUrl('testuser'),
      responseStatus: 200,
      requestedUsername: 'testuser',
    });

    // The login prompt must NOT be treated as a blocking login wall over a rendered profile.
    expect(snapshot.loginWallPresent).toBe(false);
    expect(snapshot.hasProfileStructures).toBe(true);

    const result = classify(snapshot);
    expect(result.classification).toBe('ACTIVE');
    expect(result.evidence.activeSignals).toContain(ACTIVE_SIGNALS.HEADER_USERNAME_MATCHES);
  });

  it('never ACTIVE from status 200 alone (no identity signals)', () => {
    const result = classifyHtml(readFixture('unexpected-dom'), {
      finalUrl: profileUrl('testuser'),
      responseStatus: 200,
      requestedUsername: 'testuser',
    });
    expect(result.classification).not.toBe('ACTIVE');
  });
});

describe('validateImage — magic-byte checks', () => {
  it('rejects an empty buffer', () => {
    const result = validateImage(Buffer.alloc(0));
    expect(result.ok).toBe(false);
  });

  it('accepts a PNG magic-byte buffer', () => {
    const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
    const result = validateImage(png);
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.format).toBe('png');
  });

  it('accepts a JPEG magic-byte buffer and rejects unknown bytes', () => {
    const jpeg = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10]);
    const jpegResult = validateImage(jpeg);
    expect(jpegResult.ok).toBe(true);
    if (jpegResult.ok) expect(jpegResult.format).toBe('jpeg');

    const garbage = validateImage(Buffer.from([0x00, 0x01, 0x02, 0x03]));
    expect(garbage.ok).toBe(false);
  });
});

describe('classify — identity-confirmed ACTIVE behind a login wall', () => {
  it('login-walled page whose og identity matches the username => ACTIVE (recovery detectable)', () => {
    const result = classifyHtml(
      '<!doctype html>' +
        '<meta property="og:title" content="Instagram (@instagram) • Instagram photos and videos">' +
        '<link rel="canonical" href="https://www.instagram.com/instagram/">' +
        '<title>Login • Instagram</title><body>Log in to see</body>',
      {
        finalUrl: 'https://www.instagram.com/accounts/login/?next=%2Finstagram%2F',
        responseStatus: 200,
        requestedUsername: 'instagram',
      },
    );
    expect(result.classification).toBe('ACTIVE');
    expect(result.evidence.identitySignalMatched).toBe(true);
  });

  it('still-banned "Profile isn\'t available" (no identity) stays GONE, not ACTIVE', () => {
    const result = classifyHtml(
      "<!doctype html><title>Profile isn't available • Instagram</title><body></body>",
      { finalUrl: profileUrl('firearms'), responseStatus: 200, requestedUsername: 'firearms' },
    );
    expect(result.classification).toBe('GONE');
  });

  it('generic login wall with NO matching identity is still UNKNOWN, never ACTIVE', () => {
    const result = classifyHtml(
      '<!doctype html><title>Login • Instagram</title>' +
        '<body>Phone number, username, or email<input type="password"></body>',
      {
        finalUrl: 'https://www.instagram.com/accounts/login/',
        responseStatus: 200,
        requestedUsername: 'someuser',
      },
    );
    expect(result.classification).toBe('UNKNOWN');
    expect(result.evidence.errorCode).toBe('LOGIN_WALL');
  });
});

/**
 * loadProfile's settle policy. The wait removed here was defended on the grounds that
 * classification might need the extra settle; these tests are the evidence that it does not, and
 * the guard against it being re-added.
 */
describe('BrowserManager.loadProfile — one settle wait, and it covers what classify() reads', () => {
  /** Records every wait the manager asks the page for. `goto` resolves like a real 200. */
  class SettlePage {
    readonly loadStateWaits: string[] = [];
    readonly selectorWaits: string[] = [];
    selectorFails = false;

    async goto(): Promise<{ status: () => number }> {
      return Promise.resolve({ status: () => 200 });
    }

    async waitForSelector(selector: string): Promise<null> {
      this.selectorWaits.push(selector);
      if (this.selectorFails) throw new Error('Timeout 8000ms exceeded');
      return Promise.resolve(null);
    }

    async waitForLoadState(state: string): Promise<void> {
      this.loadStateWaits.push(state);
      return Promise.resolve();
    }
  }

  const config = { scheduling: { checkTimeoutMs: 25000 } } as unknown as AppConfig;
  const logger = {
    debug: () => undefined,
    info: () => undefined,
    warn: () => undefined,
    error: () => undefined,
  } as unknown as Logger;

  async function load(page: SettlePage): Promise<number | null> {
    const manager = new BrowserManager({ config, logger });
    return manager.loadProfile(page as unknown as Page, 'https://www.instagram.com/testuser/');
  }

  it('never waits for networkidle — Instagram does not reach it, so the wait can only burn its timeout', async () => {
    // Measured: zero networkidle events in 120s across three accounts. The wait was therefore
    // 2500ms of guaranteed dead time on EVERY browser load, on the critical path of a recovery.
    const page = new SettlePage();

    expect(await load(page)).toBe(200);

    expect(page.loadStateWaits).toEqual([]);
    expect(page.selectorWaits).toHaveLength(1);
  });

  it('the single settle wait covers BOTH verdicts, so nothing was lost with it', async () => {
    // This is why removing the networkidle wait is safe rather than merely cheap: the selector
    // that runs BEFORE it already gates on the evidence classify() decides from. The ACTIVE-side
    // structures and the GONE-side copy are both in it; identity (og:url / og:title / canonical)
    // is server-rendered and present at domcontentloaded, before either wait.
    const page = new SettlePage();
    await load(page);
    const selector = page.selectorWaits[0] ?? '';

    expect(selector).toContain('header'); // profile header -> headerUsername / structures
    expect(selector).toContain('main [role="tablist"]');
    expect(selector).toContain('main img');
    expect(selector).toContain("this page isn't available"); // the GONE branch
    expect(selector).toContain('this page isn’t available'); // ...and its curly-quote twin
  });

  it('a settle that times out falls straight through — no second, padded wait behind it', async () => {
    // The one case where the removed wait could still have added time: the selector gave up.
    // A page with neither a header nor the unavailable copy after 8s is UNKNOWN either way, and
    // UNKNOWN on a baseline check simply retries in seconds.
    const page = new SettlePage();
    page.selectorFails = true;

    expect(await load(page)).toBe(200);
    expect(page.loadStateWaits).toEqual([]);
  });
});

describe('tryScreenshot — the HTML gate reads the page as SERVED, before dismissal mutates it', () => {
  const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  /** Identity-confirmed ACTIVE profile page that is login-gated in the SERVED markup. */
  const SERVED_HTML =
    '<!doctype html>' +
    '<meta property="og:title" content="Test User (@testuser) • Instagram photos and videos">' +
    '<meta property="og:type" content="profile">' +
    '<link rel="canonical" href="https://www.instagram.com/testuser/">' +
    '<title>Login • Instagram</title>' +
    '<body>Phone number, username, or email<input type="password"></body>';
  /** The same page AFTER overlay dismissal deleted the login sheet from the DOM. */
  const STRIPPED_HTML =
    '<!doctype html>' +
    '<meta property="og:title" content="Test User (@testuser) • Instagram photos and videos">' +
    '<meta property="og:type" content="profile">' +
    '<link rel="canonical" href="https://www.instagram.com/testuser/">' +
    '<title>Test User (@testuser)</title>' +
    '<body>testuser</body>';

  /**
   * A page whose `content()` reflects DOM state, the way a real page does: once overlay
   * dismissal (`clearHeaderOverlaysInPage`) has run, the login markup is GONE from the DOM,
   * so any content() read AFTER dismissal can no longer see it. The old code dismissed
   * first and then evaluated the login/consent/error gate on the stripped HTML, which let a
   * login-gated page pass as "visibly rendered" and be photographed.
   */
  class GateOrderPage {
    dismissed = false;
    screenshots = 0;
    readonly keyboard = {
      press: async (): Promise<void> => Promise.resolve(),
    };

    async content(): Promise<string> {
      return Promise.resolve(this.dismissed ? STRIPPED_HTML : SERVED_HTML);
    }

    url(): string {
      return 'https://www.instagram.com/testuser/';
    }

    private invisibleControl(): unknown {
      const handle = {
        first: (): unknown => handle,
        isVisible: async (): Promise<boolean> => Promise.resolve(false),
        click: async (): Promise<void> => Promise.resolve(),
      };
      return handle;
    }

    locator(): unknown {
      return this.invisibleControl();
    }

    getByRole(): unknown {
      return this.invisibleControl();
    }

    async waitForLoadState(): Promise<void> {
      return Promise.resolve();
    }

    /** Probes report a clean header; the geometric clear is what strips the login sheet. */
    async evaluate(fn: { name?: string }): Promise<unknown> {
      const name = fn.name ?? '';
      if (name.includes('clearHeaderOverlays')) {
        this.dismissed = true;
        return Promise.resolve(0);
      }
      if (name.includes('probeHeaderInPage')) {
        return Promise.resolve({
          visible: true,
          reason: 'ok',
          box: { x: 165, y: 80, width: 950, height: 300 },
          viewport: { width: 1280, height: 900 },
          clip: { x: 137, y: 52, width: 1006, height: 356 },
          occluder: null,
        });
      }
      return Promise.resolve(null);
    }

    async screenshot(): Promise<Buffer> {
      this.screenshots += 1;
      return Promise.resolve(PNG);
    }
  }

  const noopLogger = {
    debug: () => undefined,
    info: () => undefined,
    warn: () => undefined,
    error: () => undefined,
  } as unknown as Logger;

  it('suppresses the screenshot for a login-gated ACTIVE page even though dismissal strips the form', async () => {
    const page = new GateOrderPage();
    const browser = {
      withPage: async <T>(fn: (p: Page, ctx: BrowserContext) => Promise<T>): Promise<T> =>
        fn(page as unknown as Page, {} as BrowserContext),
      loadProfile: async (): Promise<number | null> => Promise.resolve(200),
      restart: async (): Promise<void> => Promise.resolve(),
      // The detector reads the egress generation before every load so a browser torn down by a
      // /proxy switch is not mistaken for a crash to recover from. One route, never switched.
      egressGeneration: (): number => 0,
      isCurrentEgress: (generation: number): boolean => generation === 0,
    } as unknown as BrowserManager;

    const detector = new PlaywrightDetector({
      browser,
      config: {} as AppConfig,
      logger: noopLogger,
    });

    const probe = await detector.probe('testuser', { captureScreenshot: true });

    // The recovery is still detected (identity behind the wall classifies ACTIVE)...
    expect(probe.result.classification).toBe('ACTIVE');
    // ...but the login-gated page must produce a TEXT-ONLY alert: no shutter may fire, no
    // image may ship, because the served markup said the profile is not visibly rendered.
    expect(probe.screenshot).toBeNull();
    expect(page.screenshots).toBe(0);
  });

  /**
   * A visibly-rendered profile in the SERVED markup whose header never satisfies the paint
   * predicate — the state the production measurements found for 85-96s on two of three accounts,
   * and forever on a page that simply never finishes.
   */
  class PaintStuckPage extends GateOrderPage {
    paintPolls = 0;

    override async content(): Promise<string> {
      return Promise.resolve(STRIPPED_HTML);
    }

    override async evaluate(fn: { name?: string }): Promise<unknown> {
      if ((fn.name ?? '').includes('probeRenderReadyInPage')) {
        this.paintPolls += 1;
        return Promise.resolve({ ready: false, reason: 'counters-missing', box: null });
      }
      return super.evaluate(fn);
    }
  }

  function detectorFor(page: GateOrderPage): PlaywrightDetector {
    const browser = {
      withPage: async <T>(fn: (p: Page, ctx: BrowserContext) => Promise<T>): Promise<T> =>
        fn(page as unknown as Page, {} as BrowserContext),
      loadProfile: async (): Promise<number | null> => Promise.resolve(200),
      restart: async (): Promise<void> => Promise.resolve(),
      // The detector reads the egress generation before every load so a browser torn down by a
      // /proxy switch is not mistaken for a crash to recover from. One route, never switched.
      egressGeneration: (): number => 0,
      isCurrentEgress: (generation: number): boolean => generation === 0,
    } as unknown as BrowserManager;
    return new PlaywrightDetector({ browser, config: {} as AppConfig, logger: noopLogger });
  }

  it('honours a CALLER-supplied paint budget instead of polling on its own schedule', async () => {
    // The regression: the paint poll was added to this shared path with no caller-supplied
    // bound at all, so every caller inherited the capture module's 120s ceiling — including the
    // two that run inline on the bot's strictly serial update loop.
    const page = new PaintStuckPage();

    const probe = await detectorFor(page).probe('testuser', {
      captureScreenshot: true,
      paintBudgetMs: 0,
    });

    // Still a real recovery, delivered text-only — the invariant is unchanged.
    expect(probe.result.classification).toBe('ACTIVE');
    expect(probe.screenshot).toBeNull();
    expect(page.screenshots).toBe(0);
    // A zero budget still LOOKS once; it just never sleeps.
    expect(page.paintPolls).toBe(1);
  });

  it('bounds an interactive capture rather than freezing ingress for the capture default', async () => {
    // `/check` and `/ping` reach this detector from a loop that awaits one update at a time, so
    // the wait here is the wait the whole bot serves. Measured on fake timers: it must give up
    // in tens of seconds, not the 120s the capture module waits when nobody says otherwise.
    vi.useFakeTimers();
    try {
      const page = new PaintStuckPage();
      const pending = detectorFor(page).probe('testuser', { captureScreenshot: true });
      let settled = false;
      void pending.then(() => {
        settled = true;
      });

      // It really is polling — an unbounded wait and a no-wait shortcut both look "safe" on a
      // stopwatch, and only one of them is.
      await vi.advanceTimersByTimeAsync(10_000);
      expect(settled).toBe(false);
      expect(page.paintPolls).toBeGreaterThan(1);

      // ...and it lets go well before the capture module's own 120s ceiling.
      await vi.advanceTimersByTimeAsync(35_000);
      expect(settled).toBe(true);

      const probe = await pending;
      expect(probe.result.classification).toBe('ACTIVE');
      expect(probe.screenshot).toBeNull();
      expect(page.screenshots).toBe(0);
    } finally {
      vi.useRealTimers();
    }
  });
});

/**
 * THE 45-SECOND CLIFF. On the production VPS through the mobile proxy, one `CHECK_TIMEOUT_MS`
 * governed both jobs. Measured to domcontentloaded: instagram 7.6s, trymaven 76.6s cold / 56.7s
 * warm (a single blocking resource from static.cdninstagram.com took 107s on its own). At 45s the
 * goto for @trymaven and @odpcompetitions was aborted outright, so those accounts came back
 * UNKNOWN/TIMEOUT with no image — they could not even be CLASSIFIED, which is harm rank 1.
 *
 * These run the REAL BrowserManager and PlaywrightDetector against a fake Chromium.
 */
describe('capture vs classification — separate page-load budgets', () => {
  const noopLogger = {
    debug: () => undefined,
    info: () => undefined,
    warn: () => undefined,
    error: () => undefined,
  } as unknown as Logger;

  const CAPTURE_TIMEOUT_MS = 120_000;
  const CHECK_TIMEOUT_MS = 25_000;
  const MAX_IMAGES = 32;

  function managerConfig(maxBrowserConcurrency = 4): AppConfig {
    return {
      browserWsEndpoint: null,
      igStorageState: null,
      browserProxy: null,
      scheduling: { checkTimeoutMs: CHECK_TIMEOUT_MS, maxBrowserConcurrency },
      capture: {
        timeoutMs: CAPTURE_TIMEOUT_MS,
        headerImageWaitMs: 25_000,
        maxImages: MAX_IMAGES,
      },
    } as unknown as AppConfig;
  }

  function newManager(maxBrowserConcurrency = 4): BrowserManager {
    return new BrowserManager({ config: managerConfig(maxBrowserConcurrency), logger: noopLogger });
  }

  /** Identity-confirmed, visibly-rendered ACTIVE profile markup. */
  const ACTIVE_HTML =
    '<!doctype html>' +
    '<meta property="og:title" content="Test User (@testuser) • Instagram photos and videos">' +
    '<meta property="og:type" content="profile">' +
    '<link rel="canonical" href="https://www.instagram.com/testuser/">' +
    '<title>Test User (@testuser) • Instagram photos and videos</title>' +
    '<body>testuser 12 posts 3,481 followers 210 following</body>';

  function newDetector(browser: BrowserManager): PlaywrightDetector {
    return new PlaywrightDetector({
      browser,
      config: managerConfig(),
      logger: noopLogger,
    });
  }

  /** The single FakePage a probe drove, so its recorded timeouts and routing can be read back. */
  function pagesOf(browser: BrowserManager): InstanceType<typeof pw.FakePage>[] {
    void browser;
    const out: InstanceType<typeof pw.FakePage>[] = [];
    for (const fake of pw.state.browsers) {
      for (const context of fake.contexts) out.push(...context.pages);
    }
    return out;
  }

  afterEach(() => {
    pw.state.browsers.length = 0;
  });

  it('a CAPTURE load gets the long navigation budget; a classification load does not', async () => {
    const manager = newManager();
    const detector = newDetector(manager);

    await detector.probe('testuser', { paintBudgetMs: 0 });
    const classifyPage = pagesOf(manager)[0];
    expect(classifyPage?.gotoTimeouts).toEqual([CHECK_TIMEOUT_MS]);
    expect(classifyPage?.defaultTimeouts).toEqual([CHECK_TIMEOUT_MS]);
    expect(classifyPage?.navigationTimeouts).toEqual([CHECK_TIMEOUT_MS]);

    pw.state.browsers.length = 0;
    const captureManager = newManager();
    const captureDetector = newDetector(captureManager);
    await captureDetector.probe('testuser', { captureScreenshot: true, paintBudgetMs: 0 });
    const capturePage = pagesOf(captureManager)[0];
    expect(capturePage?.gotoTimeouts).toEqual([CAPTURE_TIMEOUT_MS]);
    // The page-level defaults matter too: `page.evaluate` and the probes run under them.
    expect(capturePage?.defaultTimeouts).toEqual([CAPTURE_TIMEOUT_MS]);
    expect(capturePage?.navigationTimeouts).toEqual([CAPTURE_TIMEOUT_MS]);
  });

  it('a caller with its own deadline can LOWER the capture navigation budget', async () => {
    // Why this knob has to exist. The capture page load and the caller's total budget were
    // chosen independently of each other, and the inner one won: CAPTURE_TIMEOUT_MS is a global
    // 120s, while the re-capture sweep wrapped the same probe in a 90s `withDeadline`. 120s of
    // goto + 8s of settle nested inside 90s means the wrapper fired MID-PAGE-LOAD on every
    // profile slower than ~82s — the only profiles that sweep is ever handed, since it exists to
    // chase captures that already missed. And `withDeadline` does not cancel, so each of those
    // abandoned probes kept a Chromium page, a capture lane and a concurrency slot alive on its
    // way to a result nobody was waiting for, having already spent a page load of the single
    // residential IP's ~200/hour ceiling.
    const manager = newManager();
    await newDetector(manager).probe('testuser', {
      captureScreenshot: true,
      captureNavBudgetMs: 85_000,
      paintBudgetMs: 0,
    });
    expect(pagesOf(manager)[0]?.gotoTimeouts).toEqual([85_000]);

    // ...but never RAISE it. Clamped, not substituted: a bad option value may cost image quality,
    // it may not hold the browser on one page for longer than the operator configured.
    pw.state.browsers.length = 0;
    const greedy = newManager();
    await newDetector(greedy).probe('testuser', {
      captureScreenshot: true,
      captureNavBudgetMs: 10 * 60_000,
      paintBudgetMs: 0,
    });
    expect(pagesOf(greedy)[0]?.gotoTimeouts).toEqual([CAPTURE_TIMEOUT_MS]);

    // A classification load is untouched — it never asked for a capture budget in the first place.
    pw.state.browsers.length = 0;
    const classify = newManager();
    await newDetector(classify).probe('testuser', {
      captureNavBudgetMs: 85_000,
      paintBudgetMs: 0,
    });
    expect(pagesOf(classify)[0]?.gotoTimeouts).toEqual([CHECK_TIMEOUT_MS]);
  });

  /**
   * A visibly-rendered, PAINTED profile whose header images never finish. Everything the capture
   * path asks the page is answered truthfully except that: the shutter still fires (the image is
   * then rejected downstream for density, which is irrelevant here — the point is the WAIT).
   */
  class ImagesPendingPage {
    /** Timestamps of every header-image probe, which is what the wait is made of. */
    readonly imageProbeTimes: number[] = [];
    readonly keyboard = { press: async (): Promise<void> => Promise.resolve() };

    async content(): Promise<string> {
      return Promise.resolve(ACTIVE_HTML);
    }

    url(): string {
      return 'https://www.instagram.com/testuser/';
    }

    locator(): unknown {
      return this.control();
    }

    getByRole(): unknown {
      return this.control();
    }

    private control(): unknown {
      const handle = {
        first: (): unknown => handle,
        isVisible: async (): Promise<boolean> => Promise.resolve(false),
        click: async (): Promise<void> => Promise.resolve(),
      };
      return handle;
    }

    async evaluate(_fn: unknown, arg?: unknown): Promise<unknown> {
      const shape = (arg ?? {}) as Record<string, unknown>;
      if ('counterTokens' in shape) {
        return Promise.resolve({ ready: true, reason: 'ok', box: { x: 0, y: 0, w: 1, h: 1 } });
      }
      if ('maxScan' in shape && !('pad' in shape) && !('maxPasses' in shape)) {
        this.imageProbeTimes.push(Date.now());
        return Promise.resolve({ total: 1, settled: 0, ready: false, reason: 'pending' });
      }
      if ('pad' in shape) {
        return Promise.resolve({
          visible: true,
          reason: 'ok',
          box: { x: 165, y: 80, width: 950, height: 300 },
          viewport: { width: 1280, height: 900 },
          clip: { x: 137, y: 52, width: 1006, height: 356 },
          occluder: null,
        });
      }
      return Promise.resolve(0);
    }

    async screenshot(): Promise<Buffer> {
      return Promise.resolve(Buffer.from([0x89, 0x50, 0x4e, 0x47]));
    }

    asPage(): Page {
      return this as unknown as Page;
    }
  }

  function detectorOver(page: ImagesPendingPage): PlaywrightDetector {
    const browser = {
      withPage: async <T>(fn: (p: Page, ctx: BrowserContext) => Promise<T>): Promise<T> =>
        fn(page.asPage(), {} as BrowserContext),
      loadProfile: async (): Promise<number | null> => Promise.resolve(200),
      restart: async (): Promise<void> => Promise.resolve(),
      // The detector reads the egress generation before every load so a browser torn down by a
      // /proxy switch is not mistaken for a crash to recover from. One route, never switched.
      egressGeneration: (): number => 0,
      isCurrentEgress: (generation: number): boolean => generation === 0,
    } as unknown as BrowserManager;
    return new PlaywrightDetector({ browser, config: managerConfig(), logger: noopLogger });
  }

  it('scales the header-image wait to a QUARTER of the budget the caller was willing to spend', async () => {
    // 25s is sized for the client's proof, which runs off the monitor tick. The same code path
    // also serves `/check` on the bot's strictly SERIAL ingress loop and the inline re-capture
    // sweep, where 25s of extra waiting is charged to every other command or to the whole
    // scheduler. So it scales with whoever is paying rather than being one global number.
    const page = new ImagesPendingPage();

    // 8s of paint budget => a 2s image wait. The probe polls twice a second, so a correct
    // implementation looks ~4 times; the configured 25s ceiling would look ~50 times, and an
    // unwired one would look zero. All three are distinguishable by COUNT, without a stopwatch.
    await detectorOver(page).probe('testuser', { captureScreenshot: true, paintBudgetMs: 8_000 });

    expect(page.imageProbeTimes.length).toBeGreaterThan(1);
    expect(page.imageProbeTimes.length).toBeLessThan(12);
  });

  it('gives the header images NOTHING once the caller’s budget is already spent', async () => {
    // The third bound, and the one that keeps this out of the overall screenshot budget: whatever
    // the paint poll and the dismissal round already consumed is gone. A tiny budget is therefore
    // fully spent before the images are ever considered, and the capture proceeds immediately.
    const page = new ImagesPendingPage();

    await detectorOver(page).probe('testuser', { captureScreenshot: true, paintBudgetMs: 400 });

    expect(page.imageProbeTimes).toHaveLength(0);
  });

  it('spends NOTHING on header images when the caller granted no budget at all', async () => {
    const page = new ImagesPendingPage();

    await detectorOver(page).probe('testuser', { captureScreenshot: true, paintBudgetMs: 0 });

    expect(page.imageProbeTimes).toHaveLength(0);
  });

  it('loadProfile still defaults to the classification budget when no caller overrides it', async () => {
    const manager = newManager();
    const page = new pw.FakePage();

    await manager.loadProfile(page as unknown as Page, profileUrl('testuser'));

    expect(page.gotoTimeouts).toEqual([CHECK_TIMEOUT_MS]);
  });
});

/**
 * WHAT A CAPTURE LOAD MAY FETCH. The delivered image is a cropped HEADER CARD, yet the load used
 * to pull the entire post grid — dozens of thumbnails from `instagram.f*.fna.fbcdn.net` — and
 * throw every one of them away. Blocking by hostname is impossible: the SAME hosts serve the
 * avatar. So the discriminator is request ORDER, and these tests pin both what it drops and,
 * far more importantly, everything it must never touch.
 */
describe('capture asset budget — stop paying for pixels the crop discards', () => {
  const noopLogger = {
    debug: () => undefined,
    info: () => undefined,
    warn: () => undefined,
    error: () => undefined,
  } as unknown as Logger;

  const MAX_IMAGES = 32;
  const FBCDN = 'https://instagram.fixc1-2.fna.fbcdn.net/v/t51.82787-15/';

  function newManager(): BrowserManager {
    return new BrowserManager({
      config: {
        browserWsEndpoint: null,
        igStorageState: null,
        browserProxy: null,
        scheduling: { checkTimeoutMs: 25_000, maxBrowserConcurrency: 4 },
        capture: { timeoutMs: 120_000, headerImageWaitMs: 25_000, maxImages: MAX_IMAGES },
      } as unknown as AppConfig,
      logger: noopLogger,
    });
  }

  afterEach(() => {
    pw.state.browsers.length = 0;
  });

  /** Run `fn` against the FakePage created for one page load of the given purpose. */
  async function onPage<T>(
    purpose: 'capture' | 'classify',
    fn: (page: InstanceType<typeof pw.FakePage>) => T,
  ): Promise<T> {
    const manager = newManager();
    return manager.withPage(
      async (page) => Promise.resolve(fn(page as unknown as InstanceType<typeof pw.FakePage>)),
      purpose === 'capture' ? { purpose: 'capture' } : { blockAssets: true },
    );
  }

  it('never touches anything a verdict could depend on', async () => {
    // classify() reads serialized markup plus the main document's status. If the document, the
    // scripts that render Instagram's client-side "page isn't available" copy, or the xhr/fetch
    // those scripts make were dropped, a live account could read as GONE — the worst outcome in
    // the system. None of them may ever be intercepted.
    const actions = await onPage('capture', (page) => ({
      document: page.request('document', 'https://www.instagram.com/testuser/').action,
      script: page.request('script', 'https://static.cdninstagram.com/rsrc.php/a.js').action,
      xhr: page.request('xhr', 'https://www.instagram.com/api/v1/x/').action,
      fetch: page.request('fetch', 'https://www.instagram.com/graphql/query').action,
      stylesheet: page.request('stylesheet', 'https://static.cdninstagram.com/rsrc.php/a.css')
        .action,
      font: page.request('font', 'https://static.cdninstagram.com/rsrc.php/a.woff2').action,
      other: page.request('other', 'https://www.instagram.com/manifest.json').action,
    }));

    expect(actions).toEqual({
      document: 'continue',
      script: 'continue',
      xhr: 'continue',
      fetch: 'continue',
      stylesheet: 'continue',
      font: 'continue',
      other: 'continue',
    });
  });

  it('keeps the CSS and fonts the card is made of, and drops only media', async () => {
    // The crop is a rendered card: without CSS and fonts it is not a profile header, it is a
    // pile of unstyled text. Video is the one thing a cropped header card can never contain.
    const actions = await onPage('capture', (page) => ({
      stylesheet: page.request('stylesheet', 'https://static.cdninstagram.com/a.css').action,
      font: page.request('font', 'https://static.cdninstagram.com/a.woff2').action,
      media: page.request('media', `${FBCDN}reel.mp4`).action,
    }));

    expect(actions.stylesheet).toBe('continue');
    expect(actions.font).toBe('continue');
    expect(actions.media).toBe('abort');
  });

  it('lets the avatar through, and keeps letting images through for a whole highlight tray', async () => {
    // FAIL OPEN toward the avatar. It is the first image a profile page asks for, and the budget
    // is several times larger than an avatar plus a full story-highlight tray.
    const actions = await onPage('capture', (page) => {
      const avatar = page.request('image', `${FBCDN}avatar_s150x150.jpg`).action;
      const highlights: string[] = [];
      for (let i = 0; i < 20; i += 1) {
        highlights.push(page.request('image', `${FBCDN}highlight_${i}.jpg`).action);
      }
      return { avatar, highlights };
    });

    expect(actions.avatar).toBe('continue');
    expect(actions.highlights.every((a) => a === 'continue')).toBe(true);
  });

  it('is NOT host-based: the same fbcdn host is allowed and then withheld, purely by order', async () => {
    // This is the trap the design had to avoid. Every one of these URLs is the same host and the
    // same path prefix; only the position differs. A host rule would have blocked the avatar too.
    const actions = await onPage('capture', (page) => {
      const all: string[] = [];
      for (let i = 0; i < MAX_IMAGES + 8; i += 1) {
        all.push(page.request('image', `${FBCDN}same_host_${i}.jpg`).action);
      }
      return all;
    });

    expect(actions.slice(0, MAX_IMAGES).every((a) => a === 'continue')).toBe(true);
    expect(actions.slice(MAX_IMAGES).every((a) => a === 'fulfill')).toBe(true);
  });

  it('serves the withheld grid a real 1x1 image rather than aborting it', async () => {
    // A fulfil is a 200: no `error` event exists for Instagram's renderer to react to, `complete`
    // still flips true so the header-image wait cannot hang on it, and nothing leaves the box.
    const withheld = await onPage('capture', (page) => {
      for (let i = 0; i < MAX_IMAGES; i += 1) page.request('image', `${FBCDN}grid_${i}.jpg`);
      return page.request('image', `${FBCDN}grid_overflow.jpg`);
    });

    expect(withheld.action).toBe('fulfill');
    expect(withheld.contentType).toBe('image/gif');
    expect(withheld.bodyLength).toBeGreaterThan(0);
    expect(withheld.bodyLength).toBeLessThan(100);
  });

  it('the CLASSIFICATION load still blocks exactly the four types it always did', async () => {
    // Unchanged behaviour, asserted so the capture work cannot have quietly altered it.
    const actions = await onPage('classify', (page) => ({
      image: page.request('image', `${FBCDN}avatar.jpg`).action,
      media: page.request('media', `${FBCDN}reel.mp4`).action,
      font: page.request('font', 'https://static.cdninstagram.com/a.woff2').action,
      stylesheet: page.request('stylesheet', 'https://static.cdninstagram.com/a.css').action,
      document: page.request('document', 'https://www.instagram.com/testuser/').action,
      script: page.request('script', 'https://static.cdninstagram.com/a.js').action,
      xhr: page.request('xhr', 'https://www.instagram.com/api/v1/x/').action,
    }));

    expect(actions).toEqual({
      image: 'abort',
      media: 'abort',
      font: 'abort',
      stylesheet: 'abort',
      document: 'continue',
      script: 'continue',
      xhr: 'continue',
    });
  });

  it('a flood of withheld images cannot change the classification verdict', async () => {
    // The end-to-end version of the claim, driven through the real detector: the page asks for
    // far more images than the budget while it navigates, and the verdict is still read from the
    // served markup, untouched.
    const manager = newManager();
    const detector = new PlaywrightDetector({
      browser: manager,
      config: {
        browserWsEndpoint: null,
        igStorageState: null,
        browserProxy: null,
        scheduling: { checkTimeoutMs: 25_000, maxBrowserConcurrency: 4 },
        capture: { timeoutMs: 120_000, headerImageWaitMs: 25_000, maxImages: MAX_IMAGES },
      } as unknown as AppConfig,
      logger: noopLogger,
    });

    const activeHtml =
      '<!doctype html>' +
      '<meta property="og:title" content="Test User (@testuser) • Instagram photos and videos">' +
      '<meta property="og:type" content="profile">' +
      '<link rel="canonical" href="https://www.instagram.com/testuser/">' +
      '<title>Test User (@testuser) • Instagram photos and videos</title>' +
      '<body>testuser 12 posts 3,481 followers 210 following</body>';

    // Arm the page BEFORE the probe: the requests fire during the navigation, exactly as a real
    // page's subresources do, so nothing here is staged after the fact.
    const originalNewContext = pw.FakeContext.prototype.newPage;
    pw.FakeContext.prototype.newPage = async function armed(
      this: InstanceType<typeof pw.FakeContext>,
    ): Promise<InstanceType<typeof pw.FakePage>> {
      const page = await originalNewContext.call(this);
      page.html = activeHtml;
      page.onGoto = (p): void => {
        p.request('document', 'https://www.instagram.com/testuser/');
        p.request('script', 'https://static.cdninstagram.com/rsrc.php/a.js');
        p.request('xhr', 'https://www.instagram.com/api/v1/x/');
        for (let i = 0; i < 90; i += 1) p.request('image', `${FBCDN}img_${i}.jpg`);
      };
      return page;
    };

    try {
      const probe = await detector.probe('testuser', {
        captureScreenshot: true,
        paintBudgetMs: 0,
      });

      expect(probe.result.classification).toBe('ACTIVE');
      expect(probe.result.evidence.identitySignalMatched).toBe(true);
      expect(probe.result.evidence.errorCode).toBeNull();

      const page = pw.state.browsers[0]?.contexts[0]?.pages[0];
      const nonImages = (page?.handled ?? []).filter((h) => h.resourceType !== 'image');
      expect(nonImages.every((h) => h.action === 'continue')).toBe(true);
      // Not one image was ABORTED — the withheld ones were all answered with a valid 200.
      const images = (page?.handled ?? []).filter((h) => h.resourceType === 'image');
      expect(images).toHaveLength(90);
      expect(images.some((h) => h.action === 'abort')).toBe(false);
      expect(images.filter((h) => h.action === 'continue')).toHaveLength(MAX_IMAGES);
    } finally {
      pw.FakeContext.prototype.newPage = originalNewContext;
    }
  });
});

/**
 * GUARDING THE FLEET, and WARMING THE CONNECTIONS — the two BrowserManager changes that a capture
 * budget alone would have made dangerous.
 */
describe('BrowserManager — capture lane and warm contexts', () => {
  const noopLogger = {
    debug: () => undefined,
    info: () => undefined,
    warn: () => undefined,
    error: () => undefined,
  } as unknown as Logger;

  function configFor(
    maxBrowserConcurrency: number,
    igStorageState: string | null = null,
  ): AppConfig {
    return {
      browserWsEndpoint: null,
      igStorageState,
      browserProxy: null,
      controlUsername: 'instagram',
      scheduling: { checkTimeoutMs: 25_000, maxBrowserConcurrency },
      capture: { timeoutMs: 120_000, headerImageWaitMs: 25_000, maxImages: 32 },
    } as unknown as AppConfig;
  }

  function newManager(
    maxBrowserConcurrency: number,
    igStorageState: string | null = null,
  ): BrowserManager {
    return new BrowserManager({
      config: configFor(maxBrowserConcurrency, igStorageState),
      logger: noopLogger,
    });
  }

  const tick = (): Promise<void> => new Promise<void>((resolve) => setTimeout(resolve, 0));

  afterEach(() => {
    pw.state.browsers.length = 0;
  });

  it('captures can never occupy every slot — one is always left for routine work', async () => {
    // A capture may now legitimately run for minutes, and several can overlap (the confirmed edge
    // runs off-tick per case, the re-capture sweep runs inline, /check arrives whenever the owner
    // types it). Without a reserved slot those would hold the whole semaphore and the routine
    // checks that DETECT recoveries would simply queue behind them — harm rank 1 at fleet scale,
    // traded for one client's picture.
    const manager = newManager(4);
    const inside: string[] = [];
    let release = (): void => undefined;
    const held = new Promise<void>((resolve) => {
      release = resolve;
    });

    const captures = [0, 1, 2, 3].map((i) =>
      manager.withPage(
        async () => {
          inside.push(`capture-${i}`);
          await held;
        },
        { purpose: 'capture' },
      ),
    );
    await tick();
    await tick();

    expect(inside).toHaveLength(3);

    // The reserved slot is real: a routine check gets through while three captures are stuck.
    const routineRan = await Promise.race([
      manager.withPage(async () => 'ran').then(() => true),
      new Promise<boolean>((resolve) => setTimeout(() => resolve(false), 250)),
    ]);
    expect(routineRan).toBe(true);

    release();
    await Promise.all(captures);
    // The fourth capture is not lost, only queued — it runs once a lane frees up.
    expect(inside).toHaveLength(4);
  });

  it('a keyless load still gets a fresh isolated context, closed afterwards', async () => {
    const manager = newManager(4);

    await manager.withPage(async () => undefined);
    await manager.withPage(async () => undefined);

    const browser = pw.state.browsers[0];
    expect(browser?.contexts).toHaveLength(2);
    expect(browser?.contexts.every((c) => c.closed)).toBe(true);
  });

  it('a keyed load reuses ONE context, so per-host TLS setup is paid once, not per load', async () => {
    // The measured prize: the same avatar settled at 79.8s on a cold context and 18.5s on a
    // second load inside the same one, across a page that touches ~14 hosts.
    const manager = newManager(4);

    await manager.withPage(async () => undefined, { contextKey: 'user:testuser' });
    await manager.withPage(async () => undefined, { contextKey: 'user:testuser' });
    await manager.withPage(async () => undefined, { contextKey: 'user:testuser' });

    const browser = pw.state.browsers[0];
    expect(browser?.contexts).toHaveLength(1);
    expect(browser?.contexts[0]?.closed).toBe(false);
    // Three loads, three pages, and every page closed behind it — the CONTEXT is what survives.
    expect(browser?.contexts[0]?.pages).toHaveLength(3);
    expect(browser?.contexts[0]?.pages.every((p) => p.closed)).toBe(true);
  });

  it('different keys stay isolated from one another', async () => {
    const manager = newManager(4);

    await manager.withPage(async () => undefined, { contextKey: 'user:alice' });
    await manager.withPage(async () => undefined, { contextKey: 'user:bob' });
    await manager.withPage(async () => undefined, { contextKey: 'user:alice' });

    expect(pw.state.browsers[0]?.contexts).toHaveLength(2);
  });

  it('quarantines a challenged storage state and retries once logged-out as TWO governed loads', async () => {
    // Production incident, 2026-08-01: every /check inherited the owner-created cookie jar and
    // Instagram redirected it to accounts/update_risky_contactpoint. The account itself was never
    // inspected, so the command returned UNKNOWN/UNEXPECTED_REDIRECT. This drives the REAL
    // BrowserManager + PlaywrightDetector + TieredDetector; only Chromium/Instagram are faked.
    const originalNewPage = pw.FakeContext.prototype.newPage;
    pw.FakeContext.prototype.newPage = async function (): Promise<InstanceType<
      typeof pw.FakePage
    >> {
      const page = await originalNewPage.call(this);
      if (this.options['storageState'] !== undefined) {
        page.currentUrl =
          'https://www.instagram.com/accounts/update_risky_contactpoint/?challenge_context=opaque';
        page.html = '<!doctype html><body>Confirm your account details</body>';
      } else {
        page.currentUrl = profileUrl('testuser');
        page.html =
          '<!doctype html>' +
          '<meta property="og:title" content="Test User (@testuser) Instagram">' +
          '<link rel="canonical" href="https://www.instagram.com/testuser/">' +
          '<body>testuser 12 posts 3,481 followers 210 following</body>';
      }
      return page;
    };

    const config = configFor(4, 'package.json'); // existing file; fake Chromium never reads it
    const manager = new BrowserManager({ config, logger: noopLogger });
    const browserDetector = new PlaywrightDetector({ browser: manager, config, logger: noopLogger });
    const governor = new BrowserLoadGovernor({ capacity: 10, routineFraction: 1 });
    const detector = new TieredDetector({
      browserDetector,
      config,
      logger: noopLogger,
      governor,
      fastPath: false,
    });

    try {
      const out = await detector.probe('testuser', {
        captureScreenshot: true,
        paintBudgetMs: 0,
      });

      expect(out.result.classification).toBe('ACTIVE');
      const contexts = pw.state.browsers[0]?.contexts ?? [];
      expect(contexts).toHaveLength(2);
      expect(contexts[0]?.options['storageState']).toBe('package.json');
      expect(contexts[0]?.closed).toBe(true);
      expect(contexts[1]?.options['storageState']).toBeUndefined();
      // One challenged load + one clean retry. The retry must not hide under one admission.
      expect(governor.report().used).toBe(2);
      expect((await detector.fastTierReport()).answered.browser).toBe(2);
    } finally {
      pw.FakeContext.prototype.newPage = originalNewPage;
      await manager.close();
    }
  });

  it('reuse is BOUNDED — a warm context is retired after its load allowance', async () => {
    // A reused context is a persistent browser profile: caches and cookies accumulate in it.
    // Unbounded reuse would quietly turn "warm connections" into "one long session".
    const manager = newManager(4);

    for (let i = 0; i < 26; i += 1) {
      await manager.withPage(async () => undefined, { contextKey: 'user:testuser' });
    }

    // Exactly two: the first served its 25 loads and was retired, the 26th opened its successor.
    // (`> 1` would also pass if reuse were broken entirely and every load made its own context.)
    const contexts = pw.state.browsers[0]?.contexts ?? [];
    expect(contexts).toHaveLength(2);
    expect(contexts[0]?.closed).toBe(true);
    expect(contexts[0]?.pages).toHaveLength(25);
    expect(contexts[1]?.closed).toBe(false);
  });

  it('the CAPTURE inherits the context the preceding check already warmed', async () => {
    // This is the whole point of keying by account: the deciding confirmation check and the
    // capture that follows it seconds later are exactly the pair whose cold/warm difference was
    // measured, and the capture is the one that pays for the avatar.
    const manager = newManager(4);
    const detector = new PlaywrightDetector({
      browser: manager,
      config: {
        browserWsEndpoint: null,
        igStorageState: null,
        browserProxy: null,
        scheduling: { checkTimeoutMs: 25_000, maxBrowserConcurrency: 4 },
        capture: { timeoutMs: 120_000, headerImageWaitMs: 25_000, maxImages: 32 },
      } as unknown as AppConfig,
      logger: noopLogger,
    });

    await detector.probe('testuser', { paintBudgetMs: 0 });
    await detector.probe('testuser', { captureScreenshot: true, paintBudgetMs: 0 });

    expect(pw.state.browsers[0]?.contexts).toHaveLength(1);

    // ...and a different account never shares one.
    await detector.probe('otheruser', { paintBudgetMs: 0 });
    expect(pw.state.browsers[0]?.contexts).toHaveLength(2);
  });

  it('close() drops the warm pool as well as the contexts themselves', async () => {
    const manager = newManager(4);
    await manager.withPage(async () => undefined, { contextKey: 'user:testuser' });

    await manager.close();

    const browser = pw.state.browsers[0];
    expect(browser?.contexts.every((c) => c.closed)).toBe(true);
  });
});
