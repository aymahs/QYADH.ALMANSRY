import { describe, it, expect } from 'vitest';
import type { Classification, MonitoringCase } from '../../src/domain';
import type { TransitionParams } from '../../src/monitoring/state-machine';
import { applyCheckResult, recoverOnStartup } from '../../src/monitoring/state-machine';

const BASE_ISO = '2026-07-17T00:00:00.000Z';
const NOW = new Date(BASE_ISO);

/** Fixed, deterministic scheduling/transition params for every test. */
const params: TransitionParams = {
  baselineIntervalSeconds: 15,
  baselineJitterMaxSeconds: 2,
  confirmationIntervalSeconds: 5,
  confirmationRequiredCount: 3,
  confirmationDeadlineSeconds: 30,
  retryDelaysSeconds: [5, 10, 15, 30],
  errorBackoffMaxSeconds: 30,
  unknownBackoffBaseSeconds: 60,
  unknownBackoffMaxSeconds: 1800,
  errorBackoffInitialSeconds: 15,
  activeCount: 1,
  unknownThreshold: 3,
};

/** rand() === 0 => zero jitter, so scheduled times are exact. */
const rand = (): number => 0;

function makeCase(overrides: Partial<MonitoringCase> = {}): MonitoringCase {
  return {
    id: 'case-1',
    normalizedUsername: 'someuser',
    originalInput: 'someuser',
    startedAtUtc: BASE_ISO,
    status: 'MONITORING',
    confirmationCount: 0,
    nextCheckAtUtc: BASE_ISO,
    lastCheckedAtUtc: null,
    lastResult: null,
    consecutiveUnknownCount: 0,
    errorBackoffUntilUtc: null,
    confirmedAtUtc: null,
    clearedAtUtc: null,
    notificationClaimedAtUtc: null,
    notificationSentAtUtc: null,
    telegramMessageId: null,
    screenshotStatus: 'NONE',
    leaseOwner: null,
    leaseExpiresAtUtc: null,
    createdAtUtc: BASE_ISO,
    updatedAtUtc: BASE_ISO,
    ...overrides,
  };
}

/** Thread a sequence of classifications through the state machine. */
function run(
  start: MonitoringCase,
  classifications: Classification[],
): { states: MonitoringCase[]; confirmations: boolean[] } {
  let current = start;
  const states: MonitoringCase[] = [];
  const confirmations: boolean[] = [];
  for (const classification of classifications) {
    const out = applyCheckResult({ current, classification, now: NOW, params, rand });
    current = out.next;
    states.push(current);
    confirmations.push(out.confirmed);
  }
  return { states, confirmations };
}

const countTrue = (bools: boolean[]): number => bools.filter((b) => b).length;

describe('applyCheckResult — mandatory confirmation sequences', () => {
  it('GONE -> ACTIVE -> ACTIVE -> ACTIVE confirms exactly on the 3rd ACTIVE', () => {
    const { states, confirmations } = run(makeCase(), ['GONE', 'ACTIVE', 'ACTIVE', 'ACTIVE']);

    expect(confirmations).toEqual([false, false, false, true]);
    expect(countTrue(confirmations)).toBe(1);

    expect(states[0]?.status).toBe('MONITORING');
    expect(states[1]?.status).toBe('CONFIRMING');
    expect(states[1]?.confirmationCount).toBe(1);
    expect(states[2]?.confirmationCount).toBe(2);

    const final = states[3];
    expect(final?.status).toBe('CONFIRMED');
    expect(final?.confirmationCount).toBe(3);
    expect(final?.confirmedAtUtc).toBe(BASE_ISO);
    expect(final?.nextCheckAtUtc).toBeNull();
  });

  it('ACTIVE -> ACTIVE -> GONE never confirms and ends MONITORING with count 0', () => {
    const { states, confirmations } = run(makeCase(), ['ACTIVE', 'ACTIVE', 'GONE']);

    expect(countTrue(confirmations)).toBe(0);
    const final = states[2];
    expect(final?.status).toBe('MONITORING');
    expect(final?.confirmationCount).toBe(0);
    expect(final?.lastResult).toBe('GONE');
  });

  it('ACTIVE -> UNKNOWN -> ACTIVE -> ACTIVE never confirms (streak resets), ends CONFIRMING 2/3', () => {
    const { states, confirmations } = run(makeCase(), ['ACTIVE', 'UNKNOWN', 'ACTIVE', 'ACTIVE']);

    expect(countTrue(confirmations)).toBe(0);
    expect(states[1]?.status).toBe('MONITORING'); // UNKNOWN broke the streak
    expect(states[1]?.lastResult).toBe('UNKNOWN');

    const final = states[3];
    expect(final?.status).toBe('CONFIRMING');
    expect(final?.confirmationCount).toBe(2);
  });

  it('ACTIVE x4 confirms exactly once; the 4th check (CONFIRMED) does not re-confirm', () => {
    const { states, confirmations } = run(makeCase(), ['ACTIVE', 'ACTIVE', 'ACTIVE', 'ACTIVE']);

    expect(confirmations).toEqual([false, false, true, false]);
    expect(countTrue(confirmations)).toBe(1);

    expect(states[2]?.status).toBe('CONFIRMED');
    const final = states[3];
    expect(final?.status).toBe('CONFIRMED');
    expect(final?.confirmedAtUtc).toBe(BASE_ISO);
  });

  it('required count of 1 confirms immediately on a single ACTIVE', () => {
    const singleParams: TransitionParams = { ...params, confirmationRequiredCount: 1 };
    const out = applyCheckResult({
      current: makeCase(),
      classification: 'ACTIVE',
      now: NOW,
      params: singleParams,
      rand,
    });
    expect(out.confirmed).toBe(true);
    expect(out.next.status).toBe('CONFIRMED');
    expect(out.next.confirmedAtUtc).toBe(BASE_ISO);
    expect(out.next.nextCheckAtUtc).toBeNull();
  });
});

describe('applyCheckResult — terminal no-op', () => {
  it('a CLEARED case fed ACTIVE stays CLEARED and never confirms', () => {
    const cleared = makeCase({ status: 'CLEARED', clearedAtUtc: BASE_ISO });
    const out = applyCheckResult({
      current: cleared,
      classification: 'ACTIVE',
      now: NOW,
      params,
      rand,
    });
    expect(out.confirmed).toBe(false);
    expect(out.next.status).toBe('CLEARED');
    expect(out.next).toBe(cleared); // untouched reference
  });

  it('a NOTIFIED case fed ACTIVE stays NOTIFIED and never confirms', () => {
    const notified = makeCase({ status: 'NOTIFIED', notificationSentAtUtc: BASE_ISO });
    const out = applyCheckResult({
      current: notified,
      classification: 'ACTIVE',
      now: NOW,
      params,
      rand,
    });
    expect(out.confirmed).toBe(false);
    expect(out.next.status).toBe('NOTIFIED');
  });
});

describe('applyCheckResult — bounded backoff', () => {
  it('every routine UNKNOWN stays scheduled on the SHORT retry ladder (never a long backoff)', () => {
    const { states, confirmations } = run(makeCase(), ['UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN']);

    expect(countTrue(confirmations)).toBe(0);

    // 1st UNKNOWN -> retry in 5s (ladder[0]).
    expect(states[0]?.status).toBe('UNKNOWN_BACKOFF');
    expect(states[0]?.consecutiveUnknownCount).toBe(1);
    expect(states[0]?.nextCheckAtUtc).toBe('2026-07-17T00:00:05.000Z');
    // 2nd -> 10s.
    expect(states[1]?.nextCheckAtUtc).toBe('2026-07-17T00:00:10.000Z');
    // 3rd -> 15s.
    expect(states[2]?.nextCheckAtUtc).toBe('2026-07-17T00:00:15.000Z');
    // 4th -> 30s cap.
    expect(states[3]?.consecutiveUnknownCount).toBe(4);
    expect(states[3]?.nextCheckAtUtc).toBe('2026-07-17T00:00:30.000Z');
  });

  it('an ACTIVE result clears an accumulated unknown streak and backoff', () => {
    const backedOff = makeCase({
      status: 'UNKNOWN_BACKOFF',
      consecutiveUnknownCount: 3,
      errorBackoffUntilUtc: '2026-07-17T00:04:00.000Z',
    });
    const out = applyCheckResult({
      current: backedOff,
      classification: 'ACTIVE',
      now: NOW,
      params,
      rand,
    });
    expect(out.next.status).toBe('CONFIRMING');
    expect(out.next.confirmationCount).toBe(1);
    expect(out.next.consecutiveUnknownCount).toBe(0);
    expect(out.next.errorBackoffUntilUtc).toBeNull();
  });

  it('retryable operational UNKNOWN x3 enters ERROR_BACKOFF with the configured shorter retry', () => {
    let current = makeCase();
    for (let i = 0; i < 3; i++) {
      current = applyCheckResult({
        current,
        classification: 'UNKNOWN',
        operationalFailure: true,
        now: NOW,
        params,
        rand,
      }).next;
    }
    expect(current.status).toBe('ERROR_BACKOFF');
    // 3rd consecutive failure -> ladder[2] = 15 seconds (short, not a long backoff).
    expect(current.nextCheckAtUtc).toBe('2026-07-17T00:00:15.000Z');
  });

  it('returns to baseline monitoring after a bounded backoff cycle', () => {
    const out = applyCheckResult({
      current: makeCase({ status: 'UNKNOWN_BACKOFF', consecutiveUnknownCount: 7 }),
      classification: 'UNKNOWN',
      now: NOW,
      params,
      rand,
    });
    expect(out.next.status).toBe('MONITORING');
    expect(out.next.consecutiveUnknownCount).toBe(0);
    // Folds back to the flat baseline (15s).
    expect(out.next.nextCheckAtUtc).toBe('2026-07-17T00:00:15.000Z');
  });
});

describe('applyCheckResult — confirmation deadline', () => {
  it('a deadline-exceeded CONFIRMING case resets to MONITORING with count 0', () => {
    const confirming = makeCase({ status: 'CONFIRMING', confirmationCount: 2 });
    const out = applyCheckResult({
      current: confirming,
      classification: 'ACTIVE',
      now: NOW,
      params,
      rand,
      confirmationDeadlineExceeded: true,
    });
    expect(out.confirmed).toBe(false);
    expect(out.next.status).toBe('MONITORING');
    expect(out.next.confirmationCount).toBe(0);
  });
});

describe('applyCheckResult — immutability & timestamps', () => {
  it('returns a new object and refreshes lastCheckedAtUtc / updatedAtUtc without mutating current', () => {
    const current = makeCase();
    const out = applyCheckResult({ current, classification: 'ACTIVE', now: NOW, params, rand });
    expect(out.next).not.toBe(current);
    expect(current.status).toBe('MONITORING'); // unchanged
    expect(current.lastCheckedAtUtc).toBeNull(); // unchanged
    expect(out.next.lastCheckedAtUtc).toBe(BASE_ISO);
    expect(out.next.updatedAtUtc).toBe(BASE_ISO);
  });
});

describe('recoverOnStartup', () => {
  const START_ISO = '2026-07-17T09:00:00.000Z';
  const startNow = new Date(START_ISO);

  it('CONFIRMING(2) -> MONITORING(0) with lease released and an immediate re-check', () => {
    const confirming = makeCase({
      status: 'CONFIRMING',
      confirmationCount: 2,
      leaseOwner: 'worker-1',
      leaseExpiresAtUtc: '2026-07-17T09:02:00.000Z',
      nextCheckAtUtc: '2026-07-17T09:00:05.000Z',
    });
    const recovered = recoverOnStartup(confirming, startNow);

    expect(recovered).not.toBe(confirming);
    expect(recovered.status).toBe('MONITORING');
    expect(recovered.confirmationCount).toBe(0);
    expect(recovered.nextCheckAtUtc).toBe(START_ISO);
    expect(recovered.leaseOwner).toBeNull();
    expect(recovered.leaseExpiresAtUtc).toBeNull();
    // original untouched
    expect(confirming.status).toBe('CONFIRMING');
    expect(confirming.leaseOwner).toBe('worker-1');
  });

  it('CONFIRMED stays CONFIRMED for the outbox, with lease released', () => {
    const confirmed = makeCase({
      status: 'CONFIRMED',
      confirmationCount: 3,
      confirmedAtUtc: BASE_ISO,
      leaseOwner: 'worker-2',
      leaseExpiresAtUtc: '2026-07-17T09:02:00.000Z',
    });
    const recovered = recoverOnStartup(confirmed, startNow);

    expect(recovered.status).toBe('CONFIRMED');
    expect(recovered.confirmationCount).toBe(3);
    expect(recovered.leaseOwner).toBeNull();
    expect(recovered.leaseExpiresAtUtc).toBeNull();
  });

  it('leaves MONITORING as-is aside from releasing the lease', () => {
    const monitoring = makeCase({ leaseOwner: 'worker-3' });
    const recovered = recoverOnStartup(monitoring, startNow);
    expect(recovered.status).toBe('MONITORING');
    expect(recovered.nextCheckAtUtc).toBe(BASE_ISO); // unchanged
    expect(recovered.leaseOwner).toBeNull();
  });
});
