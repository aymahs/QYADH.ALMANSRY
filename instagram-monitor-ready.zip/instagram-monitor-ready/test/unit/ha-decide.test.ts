import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

type Action = 'HOLD' | 'STAND_BY' | 'ALREADY_ACTIVE' | 'TAKEOVER';

interface Decision {
  action: Action;
  reason: string;
  detail: string;
  installSnapshot: boolean;
  state: Record<string, unknown>;
  ages: { channelMs: number | null; procMs: number | null; schedMs: number | null };
}

interface Input {
  nowMs: number;
  thresholds: Record<string, number>;
  heartbeat: Record<string, unknown> | null;
  heartbeatMtimeMs: number | null;
  state: Record<string, unknown> | null;
  vpsRole: string | null;
  serviceActive: boolean;
  handoverLockAgeMs: number | null;
}

const SCRIPT = resolve(process.cwd(), 'deploy', 'ha-decide.mjs');
const T0 = 1_000_000;
const THRESHOLDS = {
  channelFreshMs: 2 * 60_000,
  procStaleMs: 5 * 60_000,
  schedStaleMs: 10 * 60_000,
  channelStaleMs: 12 * 60_000,
  handoverLockTtlMs: 10 * 60_000,
};

function heartbeat(
  procUtc = 'bot-proc-1',
  schedUtc = 'bot-sched-1',
  overrides: Record<string, unknown> = {},
): Record<string, unknown> {
  return {
    agentBootId: 'agent-a',
    seq: 1,
    pcRole: 'ACTIVE',
    liveness: { procUtc, schedUtc },
    ...overrides,
  };
}

function input(overrides: Partial<Input> = {}): Input {
  return {
    nowMs: T0,
    thresholds: { ...THRESHOLDS },
    heartbeat: heartbeat(),
    heartbeatMtimeMs: T0,
    state: null,
    vpsRole: 'STANDBY',
    serviceActive: false,
    handoverLockAgeMs: null,
    ...overrides,
  };
}

/** Execute the production CLI, so the test cannot drift into a second implementation. */
function decide(value: Input): Decision {
  const child = spawnSync(process.execPath, [SCRIPT], {
    input: JSON.stringify(value),
    encoding: 'utf8',
  });
  expect(child.status, child.stderr).toBe(0);
  return JSON.parse(child.stdout) as Decision;
}

describe('HA takeover decision', () => {
  it('keeps a healthy PC primary and the VPS passive', () => {
    const out = decide(input());
    expect(out.action).toBe('STAND_BY');
    expect(out.reason).toBe('pc-healthy');
    expect(out.installSnapshot).toBe(false);
  });

  it('does not start a second bot during the fresh-install grace window', () => {
    const out = decide(
      input({
        heartbeat: null,
        heartbeatMtimeMs: null,
        nowMs: T0 + THRESHOLDS.channelStaleMs - 1,
        state: { firstRunAtMs: T0 },
      }),
    );
    expect(out.action).toBe('HOLD');
    expect(out.reason).toBe('grace-window');
  });

  it('takes over after the grace window when no PC heartbeat has ever arrived', () => {
    const out = decide(
      input({
        heartbeat: null,
        heartbeatMtimeMs: null,
        nowMs: T0 + THRESHOLDS.channelStaleMs + 1,
        state: { firstRunAtMs: T0 },
      }),
    );
    expect(out.action).toBe('TAKEOVER');
    expect(out.reason).toBe('channel-stale');
    expect(out.installSnapshot).toBe(true);
  });

  it('REGRESSION: a broken channel waits 12 minutes instead of firing the 5-minute bot clock', () => {
    const first = decide(input());
    const sixMinutesLater = decide(
      input({
        nowMs: T0 + 6 * 60_000,
        heartbeat: heartbeat(),
        // The last file really is six minutes old: the transport stopped.
        heartbeatMtimeMs: T0,
        state: first.state,
      }),
    );

    // procUtc is also six minutes old, but it is OLD DATA, not positive evidence of a dead bot.
    expect(sixMinutesLater.ages.procMs).toBe(6 * 60_000);
    expect(sixMinutesLater.action).toBe('HOLD');
    expect(sixMinutesLater.reason).toBe('channel-uncertain');

    const afterTwelve = decide(
      input({
        nowMs: T0 + THRESHOLDS.channelStaleMs + 1,
        heartbeat: heartbeat(),
        heartbeatMtimeMs: T0,
        state: sixMinutesLater.state,
      }),
    );
    expect(afterTwelve.action).toBe('TAKEOVER');
    expect(afterTwelve.reason).toBe('channel-stale');
  });

  it('takes over quickly when the channel is live but the bot event loop is frozen', () => {
    const first = decide(input());
    const out = decide(
      input({
        nowMs: T0 + THRESHOLDS.procStaleMs + 1,
        heartbeat: heartbeat('bot-proc-1', 'bot-sched-1', { seq: 2 }),
        heartbeatMtimeMs: T0 + THRESHOLDS.procStaleMs + 1,
        state: first.state,
      }),
    );
    expect(out.action).toBe('TAKEOVER');
    expect(out.reason).toBe('proc-stale');
  });

  it('detects a wedged scheduler even while /healthz keeps advancing', () => {
    const first = decide(input());
    const nowMs = T0 + THRESHOLDS.schedStaleMs + 1;
    const out = decide(
      input({
        nowMs,
        heartbeat: heartbeat('bot-proc-2', 'bot-sched-1', { seq: 2 }),
        heartbeatMtimeMs: nowMs,
        state: first.state,
      }),
    );
    expect(out.ages.procMs).toBe(0);
    expect(out.action).toBe('TAKEOVER');
    expect(out.reason).toBe('sched-stale');
  });

  it('compares bot timestamps only with themselves, so host clock skew cannot age them', () => {
    const first = decide(input());
    const nowMs = T0 + THRESHOLDS.procStaleMs + 1;
    const out = decide(
      input({
        nowMs,
        heartbeat: heartbeat('2099-01-01T00:00:00Z', '1999-01-01T00:00:00Z', { seq: 2 }),
        heartbeatMtimeMs: nowMs,
        state: first.state,
      }),
    );
    expect(out.ages.procMs).toBe(0);
    expect(out.ages.schedMs).toBe(0);
    expect(out.action).toBe('STAND_BY');
  });

  it('ignores an out-of-order heartbeat from the same agent process', () => {
    const first = decide(input({ heartbeat: heartbeat('proc-new', 'sched-new', { seq: 5 }) }));
    const nowMs = T0 + THRESHOLDS.procStaleMs + 1;
    const out = decide(
      input({
        nowMs,
        heartbeat: heartbeat('proc-OLD-REPLAY', 'sched-OLD-REPLAY', { seq: 4 }),
        heartbeatMtimeMs: nowMs,
        state: first.state,
      }),
    );
    expect(out.state['lastHeartbeatSeq']).toBe(5);
    expect(out.state['lastSeenProcUtc']).toBe('proc-new');
    expect(out.action).toBe('TAKEOVER');
    expect(out.reason).toBe('proc-stale');
  });

  it('does not let the same sequence number carry different liveness values', () => {
    const first = decide(input({ heartbeat: heartbeat('proc-real', 'sched-real', { seq: 5 }) }));
    const nowMs = T0 + THRESHOLDS.procStaleMs + 1;
    const out = decide(
      input({
        nowMs,
        heartbeat: heartbeat('proc-forged-duplicate', 'sched-forged-duplicate', { seq: 5 }),
        heartbeatMtimeMs: nowMs,
        state: first.state,
      }),
    );
    expect(out.state['lastSeenProcUtc']).toBe('proc-real');
    expect(out.action).toBe('TAKEOVER');
    expect(out.reason).toBe('proc-stale');
  });

  it('reuses the last accepted role on an ordinary repeated heartbeat', () => {
    const first = decide(input({ heartbeat: heartbeat('proc-real', 'sched-real', { seq: 5 }) }));
    const repeated = decide(
      input({
        nowMs: T0 + 60_000,
        heartbeat: heartbeat('proc-real', 'sched-real', { seq: 5 }),
        heartbeatMtimeMs: T0,
        state: first.state,
      }),
    );
    expect(repeated.action).toBe('STAND_BY');
    expect(repeated.reason).toBe('pc-healthy');
  });

  it('does not let a duplicate sequence forge a PC stand-down role', () => {
    const first = decide(input({ heartbeat: heartbeat('proc-real', 'sched-real', { seq: 5 }) }));
    const forged = decide(
      input({
        nowMs: T0 + 60_000,
        heartbeat: heartbeat('proc-real', 'sched-real', { seq: 5, pcRole: 'STANDDOWN' }),
        heartbeatMtimeMs: T0 + 60_000,
        state: first.state,
      }),
    );
    expect(forged.state['lastPcRole']).toBe('ACTIVE');
    expect(forged.action).toBe('STAND_BY');
  });

  it('restarting only the helper cannot make a dead bot look alive', () => {
    const first = decide(input());
    const nowMs = T0 + THRESHOLDS.procStaleMs + 1;
    const out = decide(
      input({
        nowMs,
        heartbeat: heartbeat('bot-proc-1', 'bot-sched-1', {
          agentBootId: 'agent-b',
          seq: 0,
        }),
        heartbeatMtimeMs: nowMs,
        state: first.state,
      }),
    );
    expect(out.action).toBe('TAKEOVER');
    expect(out.reason).toBe('proc-stale');
  });

  it('honours an explicit PC stand-down immediately over a fresh channel', () => {
    const out = decide(input({ heartbeat: heartbeat('p', 's', { pcRole: 'STANDDOWN' }) }));
    expect(out.action).toBe('TAKEOVER');
    expect(out.reason).toBe('pc-stood-down');
  });

  it('keeps an already-active and running VPS on its own advanced database', () => {
    const out = decide(input({ vpsRole: 'ACTIVE', serviceActive: true }));
    expect(out.action).toBe('ALREADY_ACTIVE');
    expect(out.installSnapshot).toBe(false);
  });

  it('restarts a failed active VPS service without reinstalling the PC snapshot', () => {
    const out = decide(input({ vpsRole: 'ACTIVE', serviceActive: false }));
    expect(out.action).toBe('TAKEOVER');
    expect(out.reason).toBe('service-down');
    expect(out.installSnapshot).toBe(false);
  });

  it('a live handover lock wins over every takeover path', () => {
    const out = decide(
      input({
        vpsRole: 'ACTIVE',
        serviceActive: false,
        handoverLockAgeMs: THRESHOLDS.handoverLockTtlMs - 1,
      }),
    );
    expect(out.action).toBe('HOLD');
    expect(out.reason).toBe('takeback-in-progress');
  });

  it('clamps a future first-run clock so it cannot extend the install grace forever', () => {
    const first = decide(
      input({
        heartbeat: null,
        heartbeatMtimeMs: null,
        state: { firstRunAtMs: T0 + 24 * 60 * 60_000 },
      }),
    );
    expect(first.state['firstRunAtMs']).toBe(T0);
    const expired = decide(
      input({
        nowMs: T0 + THRESHOLDS.channelStaleMs + 1,
        heartbeat: null,
        heartbeatMtimeMs: null,
        state: first.state,
      }),
    );
    expect(expired.action).toBe('TAKEOVER');
    expect(expired.reason).toBe('channel-stale');
  });

  it('fails loudly on malformed CLI input instead of silently standing by', () => {
    const child = spawnSync(process.execPath, [SCRIPT], { input: '{bad json', encoding: 'utf8' });
    expect(child.status).toBe(2);
    expect(child.stderr).toContain('ha-decide:');
  });
});
