import { describe, it, expect } from 'vitest';

import { applyDeletionCheck } from '../../src/monitoring/deletion/state';
import type { DeletionTransitionParams } from '../../src/monitoring/deletion/state';
import { DeletionWorker } from '../../src/monitoring/deletion';
import type { DeletionMirror } from '../../src/monitoring/deletion';
import type {
  BusinessConnection,
  BusinessDeliveryStatus,
  Clock,
  DeletionClaimParams,
  DeletionWatch,
  DeletionWatchStatus,
  SendMessageParams,
  SentMessage,
  TelegramClient,
} from '../../src/domain';
import { AppError } from '../../src/domain';
import { loadConfig } from '../../src/config';
import { nullLogger } from '../../src/logging/logger';
import { MockTelegramClient } from '../../src/bot/telegram-client';
import { InMemoryRepositories, FakeDetector, makeTestConfig } from '../helpers/worker-fakes';

const ISO = '2026-07-19T12:00:00.000Z';
const OWNER_ID = 111;
const CLIENT_CHAT_ID = 999;
const CONNECTION_ID = 'bc-1';

// Message fingerprints — enough to tell the three outbound alerts apart in assertions.
const OWNER_DELETION_ALERT = 'INSTAGRAM ACCOUNT NO LONGER AVAILABLE';
const CLIENT_DELETION_ALERT = 'INSTAGRAM PROFILE NO LONGER AVAILABLE';
// The DELETION escalation, not the recovery one. This used to fingerprint 'please send them to
// the client manually' — a substring of the RECOVERY copy — which is how the ping came to tell
// the owner a just-deleted client's profile "IS ACTIVE" and to promise a screenshot that does
// not exist. Matching on deletion wording is what keeps that from coming back.
const OWNER_ACTION_PING = 'please send it to the client manually';
/** Wording that must NEVER appear in a deletion ping — it is the recovery message's. */
const RECOVERY_ONLY_PHRASES = ['IS ACTIVE', 'has recovered', 'screenshot'];

const PARAMS: DeletionTransitionParams = {
  baselineIntervalSeconds: 45,
  baselineJitterMaxSeconds: 0,
  confirmationIntervalSeconds: 5,
  confirmationRequiredCount: 3,
  confirmationDeadlineSeconds: 30,
  retryDelaysSeconds: [5, 10, 15, 30],
  unknownBackoffBaseSeconds: 60,
  unknownBackoffMaxSeconds: 1800,
  errorBackoffInitialSeconds: 15,
  errorBackoffMaxSeconds: 30,
  activeCount: 1,
};

function watch(overrides: Partial<DeletionWatch> = {}): DeletionWatch {
  return {
    id: 'w1',
    normalizedUsername: 'user',
    originalInput: 'user',
    startedAtUtc: ISO,
    status: 'WATCHING',
    confirmationCount: 0,
    consecutiveUnknownCount: 0,
    nextCheckAtUtc: ISO,
    lastCheckedAtUtc: null,
    lastResult: null,
    confirmedAtUtc: null,
    clearedAtUtc: null,
    notifiedAtUtc: null,
    telegramMessageId: null,
    leaseOwner: null,
    leaseExpiresAtUtc: null,
    createdAtUtc: ISO,
    updatedAtUtc: ISO,
    ...overrides,
  };
}

const NOW = new Date(ISO);
const rand = (): number => 0.5;

describe('applyDeletionCheck (deletion state machine)', () => {
  it('WATCHING + GONE starts the confirmation burst (1/3), not confirmed', () => {
    const { next, confirmed } = applyDeletionCheck({
      current: watch(),
      classification: 'GONE',
      now: NOW,
      params: PARAMS,
      rand,
    });
    expect(confirmed).toBe(false);
    expect(next.status).toBe('CONFIRMING');
    expect(next.confirmationCount).toBe(1);
  });

  it('CONFIRMING reaches 3 consecutive GONE -> confirmed exactly once, sealed as CONFIRMED', () => {
    const { next, confirmed } = applyDeletionCheck({
      current: watch({ status: 'CONFIRMING', confirmationCount: 2 }),
      classification: 'GONE',
      now: NOW,
      params: PARAMS,
      rand,
    });
    expect(confirmed).toBe(true);
    expect(next.confirmationCount).toBe(3);
    expect(next.confirmedAtUtc).toBe(ISO);
    expect(next.status).toBe('CONFIRMED');
    // Due now, not null: the fan-out is all that is left, and a crash before it must leave a
    // claimable row rather than a stranded one.
    expect(next.nextCheckAtUtc).toBe(ISO);
  });

  it('CONFIRMING + ACTIVE (came back) resets the burst to WATCHING', () => {
    const { next, confirmed } = applyDeletionCheck({
      current: watch({ status: 'CONFIRMING', confirmationCount: 2 }),
      classification: 'ACTIVE',
      now: NOW,
      params: PARAMS,
      rand,
    });
    expect(confirmed).toBe(false);
    expect(next.status).toBe('WATCHING');
    expect(next.confirmationCount).toBe(0);
  });

  it('CONFIRMING + UNKNOWN breaks the streak (no false deletion)', () => {
    const { next, confirmed } = applyDeletionCheck({
      current: watch({ status: 'CONFIRMING', confirmationCount: 2 }),
      classification: 'UNKNOWN',
      now: NOW,
      params: PARAMS,
      rand,
    });
    expect(confirmed).toBe(false);
    expect(next.status).toBe('WATCHING');
    expect(next.confirmationCount).toBe(0);
  });

  it('WATCHING + ACTIVE stays watching; WATCHING + UNKNOWN backs off', () => {
    const active = applyDeletionCheck({
      current: watch(),
      classification: 'ACTIVE',
      now: NOW,
      params: PARAMS,
      rand,
    });
    expect(active.confirmed).toBe(false);
    expect(active.next.status).toBe('WATCHING');

    const unknown = applyDeletionCheck({
      current: watch(),
      classification: 'UNKNOWN',
      now: NOW,
      params: PARAMS,
      rand,
    });
    expect(unknown.next.status).toBe('BACKOFF');
    expect(unknown.next.consecutiveUnknownCount).toBe(1);
  });

  it('terminal watches are frozen (a late result never revives them)', () => {
    for (const status of ['NOTIFIED', 'CLEARED'] as const) {
      const out = applyDeletionCheck({
        current: watch({ status }),
        classification: 'GONE',
        now: NOW,
        params: PARAMS,
        rand,
      });
      expect(out.confirmed).toBe(false);
      expect(out.next.status).toBe(status);
    }
  });

  it('a decided watch is frozen: even an ACTIVE result cannot retract the deletion', () => {
    for (const status of ['CONFIRMED', 'ALERTING'] as const) {
      const current = watch({ status, confirmationCount: 3, confirmedAtUtc: ISO });
      const out = applyDeletionCheck({
        current,
        classification: 'ACTIVE',
        now: NOW,
        params: PARAMS,
        rand,
      });
      expect(out.confirmed).toBe(false);
      expect(out.next.status).toBe(status);
      expect(out.next.confirmedAtUtc).toBe(ISO);
      expect(out.next.confirmationCount).toBe(3);
    }
  });
});

function mutableClock(startIso: string): { clock: Clock; advance: (ms: number) => void } {
  let ms = new Date(startIso).getTime();
  const clock: Clock = { now: () => new Date(ms), nowMs: () => ms };
  return { clock, advance: (d: number) => (ms += d) };
}

/** Records every #deletions mirror post, so duplicates are visible. */
class RecordingMirror implements DeletionMirror {
  readonly posts: string[] = [];
  async deletion(text: string): Promise<boolean> {
    this.posts.push(text);
    return true;
  }
}

/**
 * Telegram double whose OWNER deletion alert always fails, while every other send succeeds.
 * That is the exact shape of the hazard: the owner is unreachable, so the watch keeps being
 * re-armed, and anything not idempotent replays on every re-arm. Failed attempts are still
 * recorded so a test can prove the re-arms actually happened.
 */
class OwnerAlertFailsClient extends MockTelegramClient {
  /** Flip to true to end the outage and let the owner alert through. */
  ownerReachable = false;

  override async sendMessage(params: SendMessageParams): Promise<SentMessage> {
    if (!this.ownerReachable && params.text.includes(OWNER_DELETION_ALERT)) {
      this.calls.push({ method: 'sendMessage', params });
      throw new Error('telegram unreachable');
    }
    return super.sendMessage(params);
  }
}

/**
 * Telegram double whose CLIENT deletion message fails `failures` times, then goes through. The
 * owner's copy always succeeds — a transient blip on one send, not an outage.
 */
class ClientSendFailsClient extends MockTelegramClient {
  /** Every client-bound send ATTEMPTED, including the ones that threw. */
  clientAttempts = 0;
  private remaining: number;
  private readonly error: Error;

  constructor(failures: number, error?: Error) {
    super();
    this.remaining = failures;
    this.error = error ?? new AppError('TELEGRAM_ERROR', 'telegram sendMessage request failed');
  }

  override async sendMessage(params: SendMessageParams): Promise<SentMessage> {
    if (params.business_connection_id !== undefined) {
      this.clientAttempts += 1;
      if (this.remaining > 0) {
        this.remaining -= 1;
        throw this.error;
      }
    }
    return super.sendMessage(params);
  }
}

/**
 * Egress dies right after the owner's deletion alert lands: from then on every CLIENT-bound send
 * and every owner "deliver this by hand" ping fails. That correlation is the point — the
 * escalation is reached BECAUSE Telegram has been unreachable, so its ping goes out over the
 * channel that just failed repeatedly.
 */
class EgressOutageClient extends MockTelegramClient {
  /** Flip to false to end the outage. */
  down = true;
  clientAttempts = 0;
  /** Owner action-required pings ATTEMPTED, including the ones that threw. */
  ownerPingAttempts = 0;

  override async sendMessage(params: SendMessageParams): Promise<SentMessage> {
    if (params.business_connection_id !== undefined) {
      this.clientAttempts += 1;
      if (this.down) throw new AppError('TELEGRAM_ERROR', 'ECONNREFUSED');
    } else if (params.text.includes(OWNER_ACTION_PING)) {
      this.ownerPingAttempts += 1;
      if (this.down) throw new AppError('TELEGRAM_ERROR', 'ECONNREFUSED');
    }
    return super.sendMessage(params);
  }
}

/** Lets a test land an /unwatch while the CLIENT's deletion message is on the wire. */
class ClearingMidClientSend extends MockTelegramClient {
  constructor(private readonly onClientSend: () => Promise<void>) {
    super();
  }

  override async sendMessage(params: SendMessageParams): Promise<SentMessage> {
    // Only the client's copy travels over the business connection; the owner's does not.
    if (params.business_connection_id !== undefined) await this.onClientSend();
    return super.sendMessage(params);
  }
}

function countSent(client: MockTelegramClient, marker: string): number {
  return client.sentMessages.filter((m) => m.text.includes(marker)).length;
}

/** The statuses the SQLite claim query actually serves — decided watches are NOT among them. */
const PRODUCTION_CLAIMABLE_STATUSES: readonly DeletionWatchStatus[] = [
  'WATCHING',
  'CONFIRMING',
  'BACKOFF',
];

/**
 * Narrow the in-memory claim to the predicate the real driver uses. The fake re-claims anything
 * non-terminal, which is more generous than production and hid the fact that a watch parked in
 * CONFIRMED or ALERTING is never handed back to the worker by the due-check queue at all.
 */
function useProductionClaimPredicate(repos: InMemoryRepositories): void {
  const inner = repos.deletionWatches;
  const claimDue = inner.claimDue.bind(inner);
  inner.claimDue = async (params: DeletionClaimParams): Promise<DeletionWatch[]> => {
    const rows = await claimDue(params);
    for (const r of rows) {
      // Give back the lease the real query would never have taken in the first place.
      if (!PRODUCTION_CLAIMABLE_STATUSES.includes(r.status)) {
        await inner.releaseLease(r.id, params.nowUtc);
      }
    }
    return rows.filter((r) => PRODUCTION_CLAIMABLE_STATUSES.includes(r.status));
  };
}

describe('DeletionWorker', () => {
  async function seedWatch(repos: InMemoryRepositories, username: string): Promise<DeletionWatch> {
    return repos.deletionWatches.create(
      {
        normalizedUsername: username,
        originalInput: username,
        startedAtUtc: ISO,
        nextCheckAtUtc: ISO,
      },
      ISO,
    );
  }

  /** Link the watch to a client business chat, as `/ban` inside that chat would. */
  async function linkClientChat(repos: InMemoryRepositories, watchId: string): Promise<void> {
    await repos.clientLinks.create(
      {
        monitorId: watchId,
        sourceType: 'BUSINESS_CHAT',
        clientChatId: CLIENT_CHAT_ID,
        businessConnectionId: CONNECTION_ID,
        ownerTelegramUserId: OWNER_ID,
        sourceMessageId: null,
      },
      ISO,
    );
  }

  async function enableBusinessConnection(repos: InMemoryRepositories): Promise<void> {
    await repos.businessConnections.upsert({
      id: CONNECTION_ID,
      userId: OWNER_ID,
      userChatId: OWNER_ID,
      isEnabled: true,
      rights: {
        canReply: true,
        canReadMessages: true,
        canDeleteSentMessages: false,
        canDeleteAllMessages: false,
      },
      createdAtUtc: ISO,
      updatedAtUtc: ISO,
    });
  }

  function makeWorker(deps: {
    repos: InMemoryRepositories;
    detector: FakeDetector;
    client: TelegramClient;
    clock: Clock;
    discord?: DeletionMirror;
  }): DeletionWorker {
    return new DeletionWorker({
      repos: deps.repos,
      detector: deps.detector,
      client: deps.client,
      config: makeTestConfig(),
      clock: deps.clock,
      logger: nullLogger(),
      ownerChatId: () => deps.repos.owner.getOwnerTelegramId(),
      rand,
      ...(deps.discord ? { discord: deps.discord } : {}),
    });
  }

  // -------------------------------------------------------------------------------------------
  // CADENCE. A deletion watch is BROWSER-ONLY by design — an INFERRED gone is not strong enough
  // evidence to tell a client their account was deleted — so every probe it makes is a full
  // Chromium page load, not the 1-request fast probe a recovery monitor uses. Sharing the recovery
  // fleet's 15s baseline therefore cost ~225 page loads/hour PER WATCH, and two watches alone
  // exceeded the ~200/hour the single residential IP tolerates before the recovery fleet ran at
  // all. That is harm rank 3, which becomes harm rank 1 at fleet scale when the IP is burned.
  //
  // These tests use the SHIPPED defaults via loadConfig, not a hand-written interval: the number
  // under test is the one production actually runs.
  // -------------------------------------------------------------------------------------------
  describe('browser-load cadence', () => {
    const SHIPPED = loadConfig({
      TELEGRAM_BOT_TOKEN: '123456789:AAtesttokenAAAAAAAAAAAAAAAAAAAAAAAA',
      OWNER_PAIRING_SECRET: 'pair-secret-123',
    });

    /** One full tick against a watch that is still ACTIVE, returning the scheduled next check. */
    async function scheduleNextCheck(): Promise<{ watch: DeletionWatch; deltaSeconds: number }> {
      const repos = new InMemoryRepositories();
      const detector = new FakeDetector();
      const client = new MockTelegramClient();
      const { clock } = mutableClock(ISO);
      await repos.owner.claimOwner(OWNER_ID, ISO);
      await seedWatch(repos, 'still_here');
      detector.script('still_here', 'ACTIVE');

      const worker = new DeletionWorker({
        repos,
        detector,
        client,
        config: SHIPPED,
        clock,
        logger: nullLogger(),
        ownerChatId: () => repos.owner.getOwnerTelegramId(),
        rand,
      });
      await worker.runOnce();

      const watch = [...repos.deletionWatches.rows.values()][0] as DeletionWatch;
      const deltaSeconds =
        (new Date(watch.nextCheckAtUtc as string).getTime() - new Date(ISO).getTime()) / 1000;
      return { watch, deltaSeconds };
    }

    it('REGRESSION: a deletion watch does NOT share the recovery monitor cadence', async () => {
      const { deltaSeconds } = await scheduleNextCheck();

      // The defect: this was `baselineIntervalSeconds` (15s + jitter), i.e. ~225 browser loads an
      // hour for ONE watch.
      expect(deltaSeconds).toBeGreaterThan(SHIPPED.scheduling.baselineIntervalSeconds * 4);
      expect(deltaSeconds).toBeGreaterThanOrEqual(SHIPPED.scheduling.deletionIntervalSeconds);
    });

    it('the shipped deletion cadence keeps a realistic fleet inside the browser-load ceiling', () => {
      // The arithmetic the default has to satisfy, asserted rather than left in a comment.
      const loadsPerHourPerWatch = 3600 / SHIPPED.scheduling.deletionIntervalSeconds;
      const twoWatches = loadsPerHourPerWatch * 2;

      expect(loadsPerHourPerWatch).toBeLessThanOrEqual(12);
      // Two watches must be a small FRACTION of the ceiling, not a multiple of it: the recovery
      // fleet's escalations and the owner's own commands have to fit alongside them.
      expect(twoWatches).toBeLessThanOrEqual(SHIPPED.detection.browserLoadsPerHour / 4);
    });

    it('the CONFIRMATION burst is not slowed — only routine watching is', async () => {
      // A burst is three loads spent once, inside an event that has already happened. Stretching
      // it would buy nothing and delay a client-facing alert.
      const repos = new InMemoryRepositories();
      const detector = new FakeDetector();
      const client = new MockTelegramClient();
      const { clock } = mutableClock(ISO);
      await repos.owner.claimOwner(OWNER_ID, ISO);
      await seedWatch(repos, 'going_away');
      detector.script('going_away', 'GONE');

      const worker = new DeletionWorker({
        repos,
        detector,
        client,
        config: SHIPPED,
        clock,
        logger: nullLogger(),
        ownerChatId: () => repos.owner.getOwnerTelegramId(),
        rand,
      });
      await worker.runOnce();

      const watch = [...repos.deletionWatches.rows.values()][0] as DeletionWatch;
      expect(watch.status).toBe('CONFIRMING');
      const deltaSeconds =
        (new Date(watch.nextCheckAtUtc as string).getTime() - new Date(ISO).getTime()) / 1000;
      expect(deltaSeconds).toBe(SHIPPED.scheduling.confirmationIntervalSeconds);
    });

    it('routine watching is labelled ROUTINE and a confirmation burst is not', async () => {
      // The label is what the governor admits on. Getting it backwards would either starve a
      // client-facing confirmation or exempt the fleet's biggest browser-load source.
      const repos = new InMemoryRepositories();
      const detector = new FakeDetector();
      const client = new MockTelegramClient();
      const { clock, advance } = mutableClock(ISO);
      await repos.owner.claimOwner(OWNER_ID, ISO);
      await seedWatch(repos, 'watched');
      detector.script('watched', 'GONE', 'GONE');

      const worker = new DeletionWorker({
        repos,
        detector,
        client,
        config: SHIPPED,
        clock,
        logger: nullLogger(),
        ownerChatId: () => repos.owner.getOwnerTelegramId(),
        rand,
      });
      await worker.runOnce(); // WATCHING -> CONFIRMING
      advance(10_000);
      await worker.runOnce(); // CONFIRMING -> another burst check

      const priorities = detector.probes.map(
        (p) => (p.options as { loadPriority?: string } | undefined)?.loadPriority,
      );
      expect(priorities[0]).toBe('ROUTINE');
      expect(priorities[1]).toBe('CONFIRMATION');
    });
  });

  it('GONE x3 confirms once: owner is notified and the watch becomes NOTIFIED (no photo)', async () => {
    const repos = new InMemoryRepositories();
    const detector = new FakeDetector();
    const client = new MockTelegramClient();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    await seedWatch(repos, 'gone_user');
    detector.script('gone_user', 'GONE', 'GONE', 'GONE', 'GONE');

    const worker = new DeletionWorker({
      repos,
      detector,
      client,
      config: makeTestConfig(),
      clock,
      logger: nullLogger(),
      ownerChatId: () => repos.owner.getOwnerTelegramId(),
      rand,
    });

    // Three due ticks (advance past the 5s confirmation interval each time).
    for (let i = 0; i < 3; i++) {
      await worker.runOnce();
      advance(10_000);
    }

    const w = await repos.deletionWatches.findActiveByNormalizedUsername('gone_user');
    expect(w).toBeNull(); // NOTIFIED is terminal, no longer "active"
    const all = [...repos.deletionWatches.rows.values()];
    expect(all[0]?.status).toBe('NOTIFIED');
    expect(client.sentPhotos).toHaveLength(0); // deletions are text-only
    expect(client.sentMessages.some((m) => m.text.includes('NO LONGER AVAILABLE'))).toBe(true);
    expect(client.sentMessages.some((m) => m.text.includes('@gone_user'))).toBe(true);
  });

  it('an account that stays ACTIVE is never notified', async () => {
    const repos = new InMemoryRepositories();
    const detector = new FakeDetector();
    const client = new MockTelegramClient();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    await seedWatch(repos, 'alive_user');
    detector.script('alive_user', 'ACTIVE', 'ACTIVE', 'ACTIVE');

    const worker = new DeletionWorker({
      repos,
      detector,
      client,
      config: makeTestConfig(),
      clock,
      logger: nullLogger(),
      ownerChatId: () => repos.owner.getOwnerTelegramId(),
      rand,
    });
    for (let i = 0; i < 3; i++) {
      await worker.runOnce();
      advance(60_000);
    }
    expect(client.sentMessages).toHaveLength(0);
  });

  it('the Discord mirror and the owner ping each fire once across re-arms and a restart', async () => {
    const repos = new InMemoryRepositories();
    const detector = new FakeDetector();
    const client = new OwnerAlertFailsClient();
    const mirror = new RecordingMirror();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    // Linked to a client chat whose business connection is gone: delivery is impossible, so the
    // owner gets the "send it by hand" ping — the second thing that used to replay.
    await linkClientChat(repos, w.id);
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    const worker = makeWorker({ repos, detector, client, clock, discord: mirror });
    for (let i = 0; i < 5; i++) {
      await worker.runOnce();
      advance(300_000);
    }

    // Process restart: a brand-new worker over the same (durable) repositories.
    const restarted = makeWorker({ repos, detector, client, clock, discord: mirror });
    for (let i = 0; i < 3; i++) {
      await restarted.runOnce();
      advance(300_000);
    }

    expect(mirror.posts).toHaveLength(1);
    expect(countSent(client, OWNER_ACTION_PING)).toBe(1);
    // The owner alert really was retried across those passes — that is what used to drag the
    // mirror and the ping along with it.
    expect(countSent(client, OWNER_DELETION_ALERT)).toBeGreaterThanOrEqual(4);

    const stored = await repos.deletionWatches.findById(w.id);
    expect(stored?.status).toBe('ALERTING');
    expect(stored?.confirmedAtUtc).not.toBeNull();
  });

  it('a client told about a deletion is never un-told: the confirmation is never retracted', async () => {
    const repos = new InMemoryRepositories();
    const detector = new FakeDetector();
    const client = new OwnerAlertFailsClient();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    await linkClientChat(repos, w.id);
    await enableBusinessConnection(repos);
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    const worker = makeWorker({ repos, detector, client, clock });
    for (let i = 0; i < 4; i++) {
      await worker.runOnce();
      advance(300_000);
    }
    const afterConfirm = await repos.deletionWatches.findById(w.id);
    expect(afterConfirm?.confirmedAtUtc).not.toBeNull();

    const restarted = makeWorker({ repos, detector, client, clock });
    for (let i = 0; i < 3; i++) {
      await restarted.runOnce();
      advance(300_000);
    }

    // The client was told exactly once, and the bot still stands behind it: no reset of
    // confirmedAtUtc / confirmationCount, no slide back to WATCHING.
    expect(countSent(client, CLIENT_DELETION_ALERT)).toBe(1);
    expect((await repos.clientLinks.findByMonitorId(w.id))?.clientDeliveryStatus).toBe(
      'BUSINESS_DELIVERED',
    );
    const stored = await repos.deletionWatches.findById(w.id);
    expect(stored?.status).toBe('ALERTING');
    expect(stored?.confirmedAtUtc).toBe(afterConfirm?.confirmedAtUtc);
    expect(stored?.confirmationCount).toBe(3);
    // Still scheduled, so the owner alert is retried rather than lost.
    expect(stored?.nextCheckAtUtc).not.toBeNull();
  });

  it('when the owner alert finally lands the watch settles NOTIFIED, with no second mirror post', async () => {
    const repos = new InMemoryRepositories();
    const detector = new FakeDetector();
    const client = new OwnerAlertFailsClient();
    const mirror = new RecordingMirror();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    const worker = makeWorker({ repos, detector, client, clock, discord: mirror });
    for (let i = 0; i < 4; i++) {
      await worker.runOnce();
      advance(300_000);
    }
    expect((await repos.deletionWatches.findById(w.id))?.status).toBe('ALERTING');

    client.ownerReachable = true;
    await worker.runOnce();
    advance(300_000);
    await worker.runOnce();

    const stored = await repos.deletionWatches.findById(w.id);
    expect(stored?.status).toBe('NOTIFIED');
    expect(stored?.notifiedAtUtc).not.toBeNull();
    expect(stored?.nextCheckAtUtc).toBeNull();
    expect(mirror.posts).toHaveLength(1);
  });

  it('a CONFIRMED watch left behind by a killed process still alerts everyone after a restart', async () => {
    const repos = new InMemoryRepositories();
    useProductionClaimPredicate(repos);
    const detector = new FakeDetector();
    const client = new MockTelegramClient();
    const mirror = new RecordingMirror();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    await linkClientChat(repos, w.id);
    await enableBusinessConnection(repos);
    // Exactly what sealConfirmed writes, and exactly where a crash between that write and the
    // fan-out leaves the row: decided, due now, and not one alert sent. Production's claim query
    // never returns it, so only the stranded-alert sweep can finish the job.
    await repos.deletionWatches.save({
      ...w,
      status: 'CONFIRMED',
      confirmationCount: 3,
      lastResult: 'GONE',
      confirmedAtUtc: ISO,
      nextCheckAtUtc: ISO,
    });

    const restarted = makeWorker({ repos, detector, client, clock, discord: mirror });
    await restarted.runOnce();
    advance(300_000);
    await restarted.runOnce();

    expect(mirror.posts).toHaveLength(1);
    expect(countSent(client, OWNER_DELETION_ALERT)).toBe(1);
    expect(countSent(client, CLIENT_DELETION_ALERT)).toBe(1);
    const stored = await repos.deletionWatches.findById(w.id);
    expect(stored?.status).toBe('NOTIFIED');
  });

  it('a client delivery that cannot record its outcome keeps the watch retryable', async () => {
    const repos = new InMemoryRepositories();
    useProductionClaimPredicate(repos);
    const detector = new FakeDetector();
    const client = new MockTelegramClient();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    await linkClientChat(repos, w.id);
    await enableBusinessConnection(repos);
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    // SQLITE_BUSY reading the business connection: the delivery never reaches
    // updateDeliveryStatus, so the client's fate is recorded NOWHERE. Swallowing that and
    // marching the watch to NOTIFIED put the row outside listActive() — beyond claimDue AND
    // beyond the stranded-alert sweep — so the link sat at BUSINESS_DELIVERY_PENDING forever
    // and a paying client was never told their account had been deleted.
    const connections = repos.businessConnections;
    const realFindById = connections.findById.bind(connections);
    let dbBusy = true;
    connections.findById = async (id: string): Promise<BusinessConnection | null> => {
      if (dbBusy) {
        dbBusy = false;
        throw new Error('SQLITE_BUSY: database is locked');
      }
      return realFindById(id);
    };

    const worker = makeWorker({ repos, detector, client, clock });
    for (let i = 0; i < 3; i++) {
      await worker.runOnce();
      advance(10_000);
    }

    // The owner alert landed but the client half did not, so the watch is NOT terminal.
    const stranded = await repos.deletionWatches.findById(w.id);
    expect(stranded?.status).toBe('ALERTING');
    expect(stranded?.nextCheckAtUtc).not.toBeNull();
    expect(countSent(client, CLIENT_DELETION_ALERT)).toBe(0);
    expect(countSent(client, OWNER_DELETION_ALERT)).toBe(1);

    // The sweep comes back for it and the client is finally told...
    advance(300_000);
    await worker.runOnce();

    expect(countSent(client, CLIENT_DELETION_ALERT)).toBe(1);
    // ...and that retry pass does NOT send the owner a second deletion alert: the message id
    // written down on the first pass is its durable claim.
    expect(countSent(client, OWNER_DELETION_ALERT)).toBe(1);
    const settled = await repos.deletionWatches.findById(w.id);
    expect(settled?.status).toBe('NOTIFIED');
    expect(settled?.nextCheckAtUtc).toBeNull();
    expect((await repos.clientLinks.findByMonitorId(w.id))?.clientDeliveryStatus).toBe(
      'BUSINESS_DELIVERED',
    );
  });

  it('a client whose delivery could not be recorded is never told a second time', async () => {
    const repos = new InMemoryRepositories();
    useProductionClaimPredicate(repos);
    const detector = new FakeDetector();
    // The owner is unreachable, so the watch keeps being re-armed for the OWNER alert's sake —
    // and that re-arm is what re-enters the client delivery.
    const client = new OwnerAlertFailsClient();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    await linkClientChat(repos, w.id);
    await enableBusinessConnection(repos);
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    // SQLITE_BUSY on the one write that RECORDS the delivery, after the client has already been
    // told. The link stays BUSINESS_DELIVERY_PENDING, so the client channel has lost its only
    // idempotency marker and nothing but the watch itself can stop the next pass repeating
    // "your account was deleted".
    const links = repos.clientLinks;
    const realUpdate = links.updateDeliveryStatus.bind(links);
    let recordFails = true;
    links.updateDeliveryStatus = async (
      monitorId: string,
      status: BusinessDeliveryStatus,
      nowUtc: string,
    ): Promise<void> => {
      if (recordFails && status === 'BUSINESS_DELIVERED') {
        recordFails = false;
        throw new Error('SQLITE_BUSY: database is locked');
      }
      return realUpdate(monitorId, status, nowUtc);
    };

    const worker = makeWorker({ repos, detector, client, clock });
    for (let i = 0; i < 8; i++) {
      await worker.runOnce();
      advance(300_000);
    }

    expect(countSent(client, CLIENT_DELETION_ALERT)).toBe(1);
    // The owner alert really was still outstanding — the condition that keeps re-arming the row.
    expect(countSent(client, OWNER_DELETION_ALERT)).toBeGreaterThanOrEqual(1);
    // Settled rather than left retryable: with the client's marker gone, coming back here could
    // only duplicate. Losing the owner's Telegram copy (the Discord mirror already carried it) is
    // the cheaper failure.
    const stored = await repos.deletionWatches.findById(w.id);
    expect(stored?.status).toBe('NOTIFIED');
  });

  it('a transient client-send failure is retried, and the client is eventually told', async () => {
    // Same defect as the recovery outbox: EVERY exception was treated as terminal, so one 429 or
    // one network blip parked the link in OWNER_ACTION_REQUIRED and settled the watch as NOTIFIED
    // — beyond listActive(), beyond every retry path — with the paying client never told.
    const repos = new InMemoryRepositories();
    useProductionClaimPredicate(repos);
    const detector = new FakeDetector();
    const client = new ClientSendFailsClient(1);
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    await linkClientChat(repos, w.id);
    await enableBusinessConnection(repos);
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    const worker = makeWorker({ repos, detector, client, clock });
    for (let i = 0; i < 3; i++) {
      await worker.runOnce();
      advance(10_000);
    }

    // The owner has their alert; the client's copy failed and the watch is NOT settled.
    expect(client.clientAttempts).toBe(1);
    expect(countSent(client, CLIENT_DELETION_ALERT)).toBe(0);
    expect(countSent(client, OWNER_DELETION_ALERT)).toBe(1);
    const retrying = await repos.deletionWatches.findById(w.id);
    expect(retrying?.status).toBe('ALERTING');
    // A blip is not owner work.
    expect(countSent(client, OWNER_ACTION_PING)).toBe(0);

    advance(120_000);
    await worker.runOnce();

    expect(countSent(client, CLIENT_DELETION_ALERT)).toBe(1);
    // ...and the retry pass never re-alerts the owner: the message id is its durable claim.
    expect(countSent(client, OWNER_DELETION_ALERT)).toBe(1);
    expect((await repos.clientLinks.findByMonitorId(w.id))?.clientDeliveryStatus).toBe(
      'BUSINESS_DELIVERED',
    );
    const settled = await repos.deletionWatches.findById(w.id);
    expect(settled?.status).toBe('NOTIFIED');
  });

  it('client deletion retries are bounded and end in exactly one owner-action ping', async () => {
    const repos = new InMemoryRepositories();
    useProductionClaimPredicate(repos);
    const detector = new FakeDetector();
    const client = new ClientSendFailsClient(Number.MAX_SAFE_INTEGER); // never recovers
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    await linkClientChat(repos, w.id);
    await enableBusinessConnection(repos);
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    const worker = makeWorker({ repos, detector, client, clock });
    for (let i = 0; i < 30; i++) {
      await worker.runOnce();
      advance(120_000);
    }

    // Handed to a human rather than retried forever or dropped in silence.
    expect((await repos.clientLinks.findByMonitorId(w.id))?.clientDeliveryStatus).toBe(
      'OWNER_ACTION_REQUIRED',
    );
    expect(countSent(client, OWNER_ACTION_PING)).toBe(1);
    expect(countSent(client, CLIENT_DELETION_ALERT)).toBe(0);

    // The owner acts on this ping by hand-delivering it, so its WORDING is the client's message.
    // It once reused the recovery copy, which told the owner a client whose account had just been
    // deleted that it "IS ACTIVE" and "has recovered", and promised a screenshot no deletion has.
    const ping = client.sentMessages.find((m) => m.text.includes(OWNER_ACTION_PING));
    expect(ping?.text).toContain('@gone_user IS NO LONGER AVAILABLE');
    expect(ping?.text).toContain('has gone down');
    for (const phrase of RECOVERY_ONLY_PHRASES) {
      expect(ping?.text).not.toContain(phrase);
    }

    // It really did retry, and it really did stop.
    expect(client.clientAttempts).toBeGreaterThan(1);
    expect(client.clientAttempts).toBeLessThanOrEqual(10);
    expect((await repos.deletionWatches.findById(w.id))?.status).toBe('NOTIFIED');
  });

  it('REGRESSION: an owner escalation ping that never landed is retried, not thrown away', async () => {
    // Identical defect to the recovery outbox. The owner's deletion alert landed just before
    // egress died; from then on every client-bound send AND every "deliver this by hand" ping
    // fails. The escalation used to write OWNER_ACTION_REQUIRED, make ONE ping, discard its
    // failure, and report RECORDED — which settles the watch as NOTIFIED, putting the row beyond
    // listActive() and so beyond every retry path there is. Client never told, owner never told
    // they had to do it: one log line, permanent.
    const repos = new InMemoryRepositories();
    useProductionClaimPredicate(repos);
    const detector = new FakeDetector();
    const client = new EgressOutageClient();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    await linkClientChat(repos, w.id);
    await enableBusinessConnection(repos);
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    const worker = makeWorker({ repos, detector, client, clock });
    // Past the 15-minute client retry budget, well inside the ping budget.
    for (let i = 0; i < 12; i++) {
      await worker.runOnce();
      advance(120_000);
    }

    expect(client.ownerPingAttempts).toBeGreaterThan(1); // retried, not one-shot
    expect(countSent(client, OWNER_ACTION_PING)).toBe(0); // ...and none of them landed
    expect((await repos.clientLinks.findByMonitorId(w.id))?.clientDeliveryStatus).toBe(
      'BUSINESS_DELIVERY_RETRYING',
    );
    // The watch is still ALERTING — i.e. still inside listActive(), still reachable by the
    // stranded-alert sweep. Settling it here is precisely what made the loss permanent.
    expect((await repos.deletionWatches.findById(w.id))?.status).toBe('ALERTING');

    client.down = false;
    const clientAttemptsDuringOutage = client.clientAttempts;
    await worker.runOnce();

    expect(countSent(client, OWNER_ACTION_PING)).toBe(1);
    expect((await repos.clientLinks.findByMonitorId(w.id))?.clientDeliveryStatus).toBe(
      'OWNER_ACTION_REQUIRED',
    );
    expect((await repos.deletionWatches.findById(w.id))?.status).toBe('NOTIFIED');
    // Never a second "your account was deleted": a parked link only ever escalates.
    expect(client.clientAttempts).toBe(clientAttemptsDuringOutage);
    expect(countSent(client, CLIENT_DELETION_ALERT)).toBe(0);
  });

  it('a client deletion send whose outcome is unknowable is never repeated', async () => {
    const repos = new InMemoryRepositories();
    useProductionClaimPredicate(repos);
    const detector = new FakeDetector();
    const client = new ClientSendFailsClient(
      Number.MAX_SAFE_INTEGER,
      new AppError('TELEGRAM_AMBIGUOUS', 'socket closed mid-send'),
    );
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    await linkClientChat(repos, w.id);
    await enableBusinessConnection(repos);
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    const worker = makeWorker({ repos, detector, client, clock });
    for (let i = 0; i < 8; i++) {
      await worker.runOnce();
      advance(120_000);
    }

    // The message MAY already be in their chat, so it is escalated, never repeated.
    expect(client.clientAttempts).toBe(1);
    expect((await repos.clientLinks.findByMonitorId(w.id))?.clientDeliveryStatus).toBe(
      'OWNER_ACTION_REQUIRED',
    );
    expect(countSent(client, OWNER_ACTION_PING)).toBe(1);
  });

  it('an /unwatch landing while the client send is in flight is never resurrected', async () => {
    const repos = new InMemoryRepositories();
    useProductionClaimPredicate(repos);
    const detector = new FakeDetector();
    const { clock, advance } = mutableClock(ISO);
    const client = new ClearingMidClientSend(async () => {
      await repos.deletionWatches.clearByNormalizedUsername('gone_user', clock.now().toISOString());
    });
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    await linkClientChat(repos, w.id);
    await enableBusinessConnection(repos);
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    const worker = makeWorker({ repos, detector, client, clock });
    for (let i = 0; i < 4; i++) {
      await worker.runOnce();
      advance(300_000);
    }

    // The /unwatch wins. Writing the stale in-memory watch back over it resurrected a row the
    // owner had explicitly cleared — NOTIFIED with clearedAtUtc null, still holding the
    // username's active slot and so blocking a fresh /ban on it.
    const stored = await repos.deletionWatches.findById(w.id);
    expect(stored?.status).toBe('CLEARED');
    expect(stored?.clearedAtUtc).not.toBeNull();
  });

  it('an ALERTING watch keeps retrying the owner alert even though claimDue never returns it', async () => {
    const repos = new InMemoryRepositories();
    useProductionClaimPredicate(repos);
    const detector = new FakeDetector();
    const client = new OwnerAlertFailsClient();
    const mirror = new RecordingMirror();
    const { clock, advance } = mutableClock(ISO);
    await repos.owner.claimOwner(OWNER_ID, ISO);
    const w = await seedWatch(repos, 'gone_user');
    detector.script('gone_user', 'GONE', 'GONE', 'GONE');

    const worker = makeWorker({ repos, detector, client, clock, discord: mirror });
    for (let i = 0; i < 6; i++) {
      await worker.runOnce();
      advance(300_000);
    }

    // Three ticks confirm and make the first (failing) owner attempt; every attempt after that
    // could only have come from a pass that re-reached the parked ALERTING row.
    expect((await repos.deletionWatches.findById(w.id))?.status).toBe('ALERTING');
    expect(countSent(client, OWNER_DELETION_ALERT)).toBeGreaterThanOrEqual(3);
    expect(mirror.posts).toHaveLength(1);

    client.ownerReachable = true;
    await worker.runOnce();

    const stored = await repos.deletionWatches.findById(w.id);
    expect(stored?.status).toBe('NOTIFIED');
    expect(stored?.nextCheckAtUtc).toBeNull();
    expect(mirror.posts).toHaveLength(1);
  });
});
