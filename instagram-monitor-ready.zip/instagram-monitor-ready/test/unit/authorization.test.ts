import { describe, it, expect } from 'vitest';

// Pairing throttle: while the bot is unclaimed, anyone who finds it can guess /start <secret>,
// and a correct guess hands over full owner access including client identities.
describe('OwnerAuthorizer pairing throttle', () => {
  it('locks a user out after repeated wrong secrets, then recovers after the window', async () => {
    const { OwnerAuthorizer } = await import('../../src/bot/authorization/owner-auth');
    const { makeFakeDb } = await import('../helpers/fake-repos');
    const { nullLogger } = await import('../../src/logging/logger');
    const { repos } = makeFakeDb();
    let t = 0;
    const auth = new OwnerAuthorizer({
      owner: repos.owner,
      pairingSecret: 'the-real-secret',
      logger: nullLogger(),
      now: () => t,
    });

    for (let i = 0; i < 5; i += 1) {
      expect(await auth.tryPair(42, 'wrong', new Date(0).toISOString())).toBe('invalid');
    }
    // Sixth attempt is refused WITHOUT comparing, so a lockout leaks nothing about the secret.
    expect(await auth.tryPair(42, 'wrong', new Date(0).toISOString())).toBe('throttled');
    // Even the CORRECT secret is refused while locked out.
    expect(await auth.tryPair(42, 'the-real-secret', new Date(0).toISOString())).toBe('throttled');

    // The window expires, so a legitimate owner who fat-fingers the code is only delayed.
    t += 16 * 60 * 1000;
    expect(await auth.tryPair(42, 'the-real-secret', new Date(0).toISOString())).toBe('paired');
  });

  it('once the global budget is spent, every caller is spaced — rotating accounts get no free run', async () => {
    const { OwnerAuthorizer } = await import('../../src/bot/authorization/owner-auth');
    const { makeFakeDb } = await import('../helpers/fake-repos');
    const { nullLogger } = await import('../../src/logging/logger');
    const { repos } = makeFakeDb();
    const auth = new OwnerAuthorizer({
      owner: repos.owner,
      pairingSecret: 'the-real-secret',
      logger: nullLogger(),
      now: () => 0,
    });
    // 20 failures spread across 20 distinct users (1 each, under the per-user cap of 5).
    for (let user = 1; user <= 20; user += 1) {
      await auth.tryPair(user, 'wrong', new Date(0).toISOString());
    }
    // A fresh account still gets its first guess — that is what keeps the owner's route open —
    // but it is then metered, instead of the five rapid guesses the per-user cap alone allows.
    expect(await auth.tryPair(999, 'wrong', new Date(0).toISOString())).toBe('invalid');
    expect(await auth.tryPair(999, 'wrong', new Date(0).toISOString())).toBe('throttled');
    expect(await auth.tryPair(999, 'wrong', new Date(0).toISOString())).toBe('throttled');
  });

  // DEFECT D(a). Telegram sends a bare /start AUTOMATICALLY when anyone opens the bot, so
  // counting it as a failed guess let ordinary curiosity traffic spend the brute-force budget
  // and lock the real owner out of pairing.
  it('a bare /start consumes no throttle budget, so the owner can still pair', async () => {
    const { OwnerAuthorizer } = await import('../../src/bot/authorization/owner-auth');
    const { makeFakeDb } = await import('../helpers/fake-repos');
    const { nullLogger } = await import('../../src/logging/logger');
    const { repos } = makeFakeDb();
    const auth = new OwnerAuthorizer({
      owner: repos.owner,
      pairingSecret: 'the-real-secret',
      logger: nullLogger(),
      now: () => 0,
    });

    // Far more bare /starts than either budget would tolerate, from many distinct users.
    for (let user = 1; user <= 40; user += 1) {
      expect(await auth.tryPair(user, '', new Date(0).toISOString())).toBe('no_secret');
    }
    // The owner's very first real attempt still gets compared, and pairs.
    expect(await auth.tryPair(7, 'the-real-secret', new Date(0).toISOString())).toBe('paired');
  });

  // DEFECT D(b). A hard global deny is a trivial denial of service: 20 messages per window from
  // throwaway accounts would keep the real owner permanently unable to pair. So is a SHARED
  // reserve admission — whoever polls fastest takes it, for free, forever.
  it('the global budget never refuses a caller who has not guessed recently', async () => {
    const { OwnerAuthorizer } = await import('../../src/bot/authorization/owner-auth');
    const { makeFakeDb } = await import('../helpers/fake-repos');
    const { nullLogger } = await import('../../src/logging/logger');
    const { repos } = makeFakeDb();
    const auth = new OwnerAuthorizer({
      owner: repos.owner,
      pairingSecret: 'the-real-secret',
      logger: nullLogger(),
      now: () => 1_000_000,
    });

    for (let user = 1; user <= 20; user += 1) {
      await auth.tryPair(user, 'wrong', new Date(0).toISOString());
    }
    // The owner has spent none of their OWN budget, so their attempt is compared straight away.
    expect(await auth.tryPair(777, 'the-real-secret', new Date(0).toISOString())).toBe('paired');
  });

  it('the reserve lane meters each caller separately, not one shared admission', async () => {
    const { OwnerAuthorizer } = await import('../../src/bot/authorization/owner-auth');
    const { makeFakeDb } = await import('../helpers/fake-repos');
    const { nullLogger } = await import('../../src/logging/logger');
    const { repos } = makeFakeDb();
    let t = 1_000_000;
    const auth = new OwnerAuthorizer({
      owner: repos.owner,
      pairingSecret: 'the-real-secret',
      logger: nullLogger(),
      now: () => t,
    });
    for (let user = 1; user <= 20; user += 1) {
      await auth.tryPair(user, 'wrong', new Date(0).toISOString());
    }
    // 501's own guess is what delays 501 — and only 501.
    expect(await auth.tryPair(501, 'wrong', new Date(0).toISOString())).toBe('invalid');
    expect(await auth.tryPair(501, 'wrong', new Date(0).toISOString())).toBe('throttled');
    t += 61_000;
    expect(await auth.tryPair(501, 'wrong', new Date(0).toISOString())).toBe('invalid');
  });

  // DEFECT D(b), the surviving half. A single shared admission is first-come-first-served and a
  // refused poll costs nothing, so a script polling every second took EVERY admission and the
  // owner — holding the correct secret — was told "pairing failed" indefinitely. The bot could
  // then never be claimed, and every client's recovery alert is missed for the duration.
  it('a fast-polling attacker cannot consume the route back that the owner needs', async () => {
    const { OwnerAuthorizer } = await import('../../src/bot/authorization/owner-auth');
    const { makeFakeDb } = await import('../helpers/fake-repos');
    const { nullLogger } = await import('../../src/logging/logger');
    const { repos } = makeFakeDb();
    let t = 1_000_000;
    const auth = new OwnerAuthorizer({
      owner: repos.owner,
      pairingSecret: 'the-real-secret',
      logger: nullLogger(),
      now: () => t,
    });
    for (let user = 1; user <= 20; user += 1) {
      await auth.tryPair(user, 'wrong', new Date(0).toISOString());
    }
    // An hour of guesses at 1/second from four rotating throwaway accounts.
    for (let second = 0; second < 3600; second += 1) {
      t += 1000;
      await auth.tryPair(9000 + (second % 4), 'wrong', new Date(0).toISOString());
    }
    // The owner arrives in the middle of the flood — the worst moment, with a shared admission
    // just consumed — and still pairs on their first attempt.
    expect(await auth.tryPair(777, 'the-real-secret', new Date(0).toISOString())).toBe('paired');
  });

  // DEFECT D(c). Unbounded growth: every distinct Telegram id that ever guesses stays in the map.
  it('evicts attempt records once their window has passed', async () => {
    const { OwnerAuthorizer } = await import('../../src/bot/authorization/owner-auth');
    const { makeFakeDb } = await import('../helpers/fake-repos');
    const { nullLogger } = await import('../../src/logging/logger');
    const { repos } = makeFakeDb();
    let t = 0;
    const auth = new OwnerAuthorizer({
      owner: repos.owner,
      pairingSecret: 'the-real-secret',
      logger: nullLogger(),
      now: () => t,
    });
    for (let user = 1; user <= 20; user += 1) {
      await auth.tryPair(user, 'wrong', new Date(0).toISOString());
    }
    const tracked = (auth as unknown as { attempts: Map<number, unknown> }).attempts;
    expect(tracked.size).toBe(20);

    t += 16 * 60 * 1000;
    await auth.tryPair(1, 'wrong', new Date(0).toISOString());
    // Everything aged out; only the attempt just made is still held.
    expect(tracked.size).toBe(1);
  });
});

import { OwnerAuthorizer } from '../../src/bot/authorization';
import { nullLogger } from '../../src/logging/logger';
import { makeFakeDb } from '../helpers/fake-repos';

const SECRET = 'correct-horse-battery';
const NOW_ISO = '2026-07-17T12:00:00.000Z';

function makeAuth(): { auth: OwnerAuthorizer } {
  const { repos } = makeFakeDb();
  const auth = new OwnerAuthorizer({
    owner: repos.owner,
    pairingSecret: SECRET,
    logger: nullLogger(),
  });
  return { auth };
}

describe('OwnerAuthorizer', () => {
  it('pairs the first user presenting the correct secret', async () => {
    const { auth } = makeAuth();
    await expect(auth.tryPair(111, SECRET, NOW_ISO)).resolves.toBe('paired');
    await expect(auth.isOwner(111)).resolves.toBe(true);
  });

  it('rejects a wrong secret and pairs nobody', async () => {
    const { auth } = makeAuth();
    await expect(auth.tryPair(111, 'wrong-secret-here', NOW_ISO)).resolves.toBe('invalid');
    await expect(auth.isOwner(111)).resolves.toBe(false);
  });

  it('treats an empty secret as "no secret", not a failed guess', async () => {
    const { auth } = makeAuth();
    await expect(auth.tryPair(111, '', NOW_ISO)).resolves.toBe('no_secret');
    await expect(auth.isOwner(111)).resolves.toBe(false);
  });

  it('never pairs a second user after an owner exists — even with the correct secret', async () => {
    const { auth } = makeAuth();
    await expect(auth.tryPair(111, SECRET, NOW_ISO)).resolves.toBe('paired');

    await expect(auth.tryPair(222, SECRET, NOW_ISO)).resolves.toBe('already_paired');
    await expect(auth.tryPair(222, 'wrong-secret-here', NOW_ISO)).resolves.toBe('already_paired');
    await expect(auth.isOwner(222)).resolves.toBe(false);
    await expect(auth.isOwner(111)).resolves.toBe(true);
  });

  it('returns already_paired when the existing owner presents the secret again', async () => {
    const { auth } = makeAuth();
    await expect(auth.tryPair(111, SECRET, NOW_ISO)).resolves.toBe('paired');
    await expect(auth.tryPair(111, SECRET, NOW_ISO)).resolves.toBe('already_paired');
    await expect(auth.isOwner(111)).resolves.toBe(true);
  });

  it('isOwner is false for everyone while unpaired', async () => {
    const { auth } = makeAuth();
    await expect(auth.isOwner(111)).resolves.toBe(false);
  });
});
