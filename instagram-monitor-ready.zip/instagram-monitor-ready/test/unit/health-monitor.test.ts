import { beforeEach, describe, expect, it } from 'vitest';
import type { SchedulerHealth, SendMessageParams, SentMessage } from '../../src/domain';
import { FixedClock } from '../../src/domain';
import { nullLogger } from '../../src/logging';
import { MockTelegramClient } from '../../src/bot/telegram-client/mock-client';
import { monitoringRestored, monitoringWarning } from '../../src/notifications/formatter';
import { HealthMonitor } from '../../src/health';
import { FakeDetector, InMemoryRepositories, makeTestConfig } from '../helpers/worker-fakes';

const BASE_ISO = '2026-07-17T00:00:00.000Z';
const CONTROL = 'instagram'; // makeTestConfig().controlUsername
const OWNER_CHAT_ID = 777;
const FIVE_MINUTES_MS = 5 * 60 * 1000;
const TEN_MINUTES_MS = 10 * 60 * 1000;

/**
 * A Telegram client whose sends always fail, counting ATTEMPTS.
 *
 * `MockTelegramClient` only records a call after a successful send, which is the right behaviour
 * for "what did the owner receive" but cannot see a retry storm of failed sends — the exact bug
 * the regression test below locks down.
 */
class UnreachableTelegramClient extends MockTelegramClient {
  sendAttempts = 0;
  override sendMessage(_params: SendMessageParams): Promise<SentMessage> {
    this.sendAttempts += 1;
    return Promise.reject(new Error('telegram unreachable'));
  }
}

describe('HealthMonitor', () => {
  let clock: FixedClock;
  let repos: InMemoryRepositories;
  let detector: FakeDetector;
  let client: MockTelegramClient;
  let monitor: HealthMonitor;

  function build(withClient: MockTelegramClient): HealthMonitor {
    return new HealthMonitor({
      repos,
      detector,
      client: withClient,
      ownerChatId: async (): Promise<number | null> => OWNER_CHAT_ID,
      config: makeTestConfig(),
      clock,
      logger: nullLogger(),
    });
  }

  beforeEach(() => {
    clock = new FixedClock(new Date(BASE_ISO));
    repos = new InMemoryRepositories();
    detector = new FakeDetector();
    client = new MockTelegramClient();
    monitor = build(client);
  });

  async function seedHealth(overrides: Partial<SchedulerHealth> = {}): Promise<void> {
    await repos.health.upsert({
      name: 'scheduler',
      lastSchedulerRunUtc: BASE_ISO,
      lastSuccessfulCheckUtc: null,
      lastControlOkUtc: null,
      recentUnknownRate: 0.9,
      browserRestarts: 0,
      detectorUnhealthy: false,
      lastWarningSentUtc: null,
      updatedAtUtc: BASE_ISO,
      ...overrides,
    });
  }

  async function seedActiveCases(count: number): Promise<string[]> {
    const ids: string[] = [];
    for (let i = 0; i < count; i++) {
      const c = await repos.cases.create(
        {
          normalizedUsername: `user${i}`,
          originalInput: `user${i}`,
          startedAtUtc: BASE_ISO,
          nextCheckAtUtc: BASE_ISO,
        },
        BASE_ISO,
      );
      ids.push(c.id);
    }
    return ids;
  }

  /** Run `count` evaluations at the production-like 5-minute cadence. */
  async function evaluateTimes(count: number, target: HealthMonitor = monitor): Promise<void> {
    for (let i = 0; i < count; i++) {
      await target.evaluate();
      clock.advanceMs(FIVE_MINUTES_MS);
    }
  }

  /**
   * `count` evaluations, each by a BRAND NEW HealthMonitor over the same repos — i.e. a process
   * that dies and is relaunched between every evaluation. Only the health row survives.
   */
  async function evaluateAcrossRestarts(
    count: number,
    withClient: MockTelegramClient = client,
  ): Promise<void> {
    for (let i = 0; i < count; i++) {
      await build(withClient).evaluate();
      clock.advanceMs(FIVE_MINUTES_MS);
    }
  }

  // REGRESSION, 2026-08-04: the control probe must let a FAST-tier ACTIVE verdict stand.
  //
  // Without `allowFastActive`, an ACTIVE control account always escalates to a full Chromium load,
  // so the entire health verdict rested on the most fragile operation in the system. On the VPS
  // that produced "MONITORING WARNING" every 30 minutes for five hours while the fleet was logging
  // ~650 clean checks an hour with zero errors. A false alarm is not harmless: it teaches the owner
  // to ignore the one message that must never be ignored.
  it('probes the control account WITHOUT forcing a browser load', async () => {
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE'); // force the probe path to run
    await monitor.evaluate();

    const controlProbes = detector.probes.filter((p) => p.username === CONTROL);
    expect(controlProbes.length).toBeGreaterThan(0);
    for (const p of controlProbes) {
      expect((p.options as { allowFastActive?: boolean } | undefined)?.allowFastActive).toBe(true);
    }
  });

  // REGRESSION, 2026-08-04 (second incident of the same day): a warning may only be built from
  // evaluations where the FLEET is degraded. The control account failing while the recorded
  // unknown rate was 4e-155 produced "MONITORING WARNING" every 30 minutes about a fleet doing
  // ~650 clean checks an hour — and the incident could never close, because closing required the
  // control probe to succeed twice.
  it('an open incident over a HEALTHY fleet closes with RESTORED and never re-warns', async () => {
    await seedHealth({
      detectorUnhealthy: true,
      lastWarningSentUtc: BASE_ISO, // the owner heard the original warning
      recentUnknownRate: 0, // ...but the fleet is demonstrably fine
    });
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE'); // control probe stays red throughout (sticky)

    await evaluateTimes(4);

    const texts = client.sentMessages.map((m) => m.text);
    expect(texts.filter((t) => t === monitoringWarning().text)).toHaveLength(0);
    expect(texts.filter((t) => t === monitoringRestored().text)).toHaveLength(1);
    const health = await repos.health.get('scheduler');
    expect(health?.detectorUnhealthy).toBe(false);
    expect(health?.lastWarningSentUtc).toBeNull();
  });

  it('a silent incident over a healthy fleet closes with NO message at all', async () => {
    // Incident open but never announced: closing it must not manufacture a lone RESTORED.
    await seedHealth({ detectorUnhealthy: true, lastWarningSentUtc: null, recentUnknownRate: 0 });
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE');

    await evaluateTimes(4);

    expect(client.sentMessages).toHaveLength(0);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(false);
  });

  // NOTE: this test previously asserted that the FIRST failed control probe warns and the FIRST
  // success restores. That is the behaviour being deliberately changed — it turned every transient
  // blip into a WARNING+RESTORED pair (eight pairs in one night in production). It now asserts the
  // streak contract: 3 consecutive failures to warn, 2 consecutive successes to restore.
  it('warns once after 3 consecutive failures, then suppresses repeats for 30 minutes', async () => {
    await seedHealth();
    const ids = await seedActiveCases(2);
    detector.script(CONTROL, 'GONE'); // control probe fails (sticky repeats)

    // First two failures are silent: nothing is sent, but the incident is open so probing goes on.
    await monitor.evaluate();
    expect(client.sentMessages).toHaveLength(0);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(true);

    await monitor.evaluate();
    expect(client.sentMessages).toHaveLength(0);

    // Third consecutive failure: exactly one warning.
    await monitor.evaluate();
    expect(client.sentMessages).toHaveLength(1);
    expect(client.sentMessages[0]?.text).toBe(monitoringWarning().text);
    expect(client.sentMessages[0]?.chat_id).toBe(OWNER_CHAT_ID);

    let health = await repos.health.get('scheduler');
    expect(health?.detectorUnhealthy).toBe(true);
    expect(health?.lastWarningSentUtc).toBe(BASE_ISO);

    // Another evaluate 10 minutes later, still failing: NO second warning.
    clock.advanceMs(TEN_MINUTES_MS);
    await monitor.evaluate();
    expect(client.sentMessages).toHaveLength(1);

    // Control recovers. The FIRST success must not restore anything.
    detector.script(CONTROL, 'ACTIVE');
    clock.advanceMs(TEN_MINUTES_MS);
    await monitor.evaluate();
    expect(client.sentMessages).toHaveLength(1);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(true);

    // The second consecutive success restores, exactly once, and clears the flag.
    clock.advanceMs(TEN_MINUTES_MS);
    await monitor.evaluate();
    expect(client.sentMessages).toHaveLength(2);
    expect(client.sentMessages[1]?.text).toBe(monitoringRestored().text);
    health = await repos.health.get('scheduler');
    expect(health?.detectorUnhealthy).toBe(false);
    expect(health?.lastControlOkUtc).toBe(clock.now().toISOString());

    // Healthy again: further evaluates send nothing more.
    clock.advanceMs(TEN_MINUTES_MS);
    await monitor.evaluate();
    expect(client.sentMessages).toHaveLength(2);

    // Case statuses were never touched by any evaluation.
    for (const id of ids) {
      const stored = await repos.cases.findById(id);
      expect(stored?.status).toBe('MONITORING');
      expect(stored?.confirmationCount).toBe(0);
    }
  });

  it('a single failed control probe produces NO messages at all', async () => {
    await seedHealth();
    await seedActiveCases(2);
    // One blip, then the control answers normally forever after.
    detector.script(CONTROL, 'GONE', 'ACTIVE');

    await evaluateTimes(4);

    expect(client.sentMessages).toHaveLength(0);
    // It kept probing throughout, and closed the incident on its own.
    expect(detector.probes).toHaveLength(4);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(false);
  });

  it('two failures (one short of the threshold) never emit a lone RESTORED', async () => {
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE', 'GONE', 'ACTIVE');

    await evaluateTimes(5);

    // The incident opened (detectorUnhealthy was set so probing continued) but was never
    // ANNOUNCED, so the recovery must be silent too.
    expect(client.sentMessages).toHaveLength(0);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(false);
  });

  it('a sustained outage still warns exactly once', async () => {
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE');

    // 6 evaluations = 30 minutes of continuous failure at the 5-minute cadence.
    await evaluateTimes(6);

    expect(client.sentMessages).toHaveLength(1);
    expect(client.sentMessages[0]?.text).toBe(monitoringWarning().text);
    expect(detector.probes).toHaveLength(6);
  });

  it('re-warns after the 30-minute suppression window passes while still unhealthy', async () => {
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE');

    await monitor.evaluate();
    await monitor.evaluate();
    await monitor.evaluate();
    expect(client.sentMessages).toHaveLength(1);

    clock.advanceMs(31 * 60 * 1000);
    await monitor.evaluate();
    expect(client.sentMessages).toHaveLength(2);
    expect(client.sentMessages[1]?.text).toBe(monitoringWarning().text);
  });

  it('a single good probe mid-incident neither restores nor stops the probe loop', async () => {
    await seedHealth();
    await seedActiveCases(2);
    // Warn, then flap: one good probe, back to failing, then a real two-probe recovery.
    detector.script(CONTROL, 'GONE', 'GONE', 'GONE', 'ACTIVE', 'GONE', 'ACTIVE', 'ACTIVE');

    await evaluateTimes(3);
    expect(client.sentMessages).toHaveLength(1); // the warning

    await evaluateTimes(1); // one ACTIVE — not a recovery
    expect(client.sentMessages).toHaveLength(1);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(true);

    await evaluateTimes(1); // back to GONE
    expect(client.sentMessages).toHaveLength(1);

    await evaluateTimes(2); // two consecutive ACTIVE — a real recovery
    expect(client.sentMessages).toHaveLength(2);
    expect(client.sentMessages[1]?.text).toBe(monitoringRestored().text);
    expect(detector.probes).toHaveLength(7);
  });

  it('a warning whose delivery FAILS is attempted once, not on every evaluation', async () => {
    // Regression: suppression used to be derived from the persisted `lastWarningSentUtc`, which is
    // only written when the send succeeds. A failed send left it null, and the `null` case re-opened
    // the warn gate every cycle — an alert storm during exactly the Telegram outage that caused it.
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE');
    const unreachable = new UnreachableTelegramClient();

    // 6 evaluations = 30 minutes, all inside the suppression window after the 3rd.
    await evaluateTimes(6, build(unreachable));

    expect(unreachable.sendAttempts).toBe(1);
    // Nothing was delivered, so nothing may claim the owner was told.
    expect((await repos.health.get('scheduler'))?.lastWarningSentUtc).toBeNull();
  });

  it('an undelivered warning does not authorise a later RESTORED', async () => {
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE', 'GONE', 'GONE', 'ACTIVE');
    const unreachable = new UnreachableTelegramClient();
    const m = build(unreachable);

    await evaluateTimes(3, m); // warning attempted and lost
    expect(unreachable.sendAttempts).toBe(1);

    await evaluateTimes(2, m); // two consecutive successes

    // The owner never heard the warning, so a "restored" would be the only message of the incident
    // and would make no sense. Only the one lost warning was ever attempted.
    expect(unreachable.sendAttempts).toBe(1);
    expect(unreachable.sentMessages).toHaveLength(0);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(false);
  });

  // -----------------------------------------------------------------------------------------
  // Restart survival. An incident routinely outlives the process (crash loop, OOM, the Windows
  // scheduled-task relaunch, home-PC sleep/wake), and every one of these used to fail because the
  // whole incident lived in fields of a HealthMonitor instance.
  // -----------------------------------------------------------------------------------------

  it('still sends RESTORED when the process restarts mid-incident', async () => {
    // Regression: "was a warning announced" was an in-memory flag. A restart zeroed it while the
    // persisted `detectorUnhealthy` kept the incident open, so the recovery closed the incident
    // SILENTLY — and since closing it is irreversible, the owner's last word on a fully healthy
    // fleet stayed "monitoring degraded" forever.
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE');

    await evaluateTimes(3);
    expect(client.sentMessages).toHaveLength(1);
    expect(client.sentMessages[0]?.text).toBe(monitoringWarning().text);

    // The process dies here. Everything except the health row is lost.
    detector.script(CONTROL, 'ACTIVE');
    await evaluateTimes(2, build(client));

    expect(client.sentMessages).toHaveLength(2);
    expect(client.sentMessages[1]?.text).toBe(monitoringRestored().text);
    const health = await repos.health.get('scheduler');
    expect(health?.detectorUnhealthy).toBe(false);
    // Cleared with the incident, so the NEXT blip cannot inherit it and emit a lone RESTORED.
    expect(health?.lastWarningSentUtc).toBeNull();
  });

  it('a closed incident does not let a later blip inherit a stale RESTORED', async () => {
    // Guards the clearing above: warn+restore one incident, then open a second that never reaches
    // the warn threshold. The second recovery must stay silent even across a restart.
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE', 'GONE', 'GONE', 'ACTIVE', 'ACTIVE');

    await evaluateTimes(5);
    expect(client.sentMessages).toHaveLength(2); // warning + restored

    // Second incident: a single failure, then a restart, then recovery.
    detector.script(CONTROL, 'GONE', 'ACTIVE', 'ACTIVE');
    await evaluateTimes(1);
    await evaluateTimes(2, build(client));

    expect(client.sentMessages).toHaveLength(2);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(false);
  });

  it('warns during a sustained outage even when the process restarts every evaluation', async () => {
    // Regression: the failure streak was in memory and needs 3 evaluations (~15 min of unbroken
    // uptime). A host restarting faster than that reset it to 0 every boot, so a real, sustained
    // outage was NEVER reported — the worst failure this monitor has.
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE');

    await evaluateAcrossRestarts(4);

    // Exactly one: the outage is reported, and the restart loop does not turn into a warning per
    // boot (the durable send time suppresses the 3rd and 4th).
    expect(client.sentMessages).toHaveLength(1);
    expect(client.sentMessages[0]?.text).toBe(monitoringWarning().text);
    expect(detector.probes).toHaveLength(4);
  });

  it('the durable suppression still expires, so a restart loop re-warns after 30 minutes', async () => {
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE');

    await evaluateAcrossRestarts(2); // boot 1 opens the incident, boot 2 warns
    expect(client.sentMessages).toHaveLength(1);

    clock.advanceMs(31 * 60 * 1000);
    await evaluateAcrossRestarts(1);
    expect(client.sentMessages).toHaveLength(2);
    expect(client.sentMessages[1]?.text).toBe(monitoringWarning().text);
  });

  it('a restart with no open incident starts a fresh streak rather than a seeded one', async () => {
    // The resume seed must be conditional on the persisted flag: a process that boots healthy and
    // then sees ONE bad probe must stay silent, exactly as an uninterrupted process would.
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'ACTIVE', 'GONE', 'ACTIVE');

    await evaluateAcrossRestarts(3);

    expect(client.sentMessages).toHaveLength(0);
  });

  it('keeps probing on the persisted flag alone after the unknown rate falls', async () => {
    // Coverage gap, not a regression: every other test pins recentUnknownRate at 0.9, so
    // `degraded` is true on every evaluation and the probe-loop assertions pass on that term
    // alone. Here the rate drops back to normal mid-incident, leaving `detectorUnhealthy` as the
    // only thing keeping the loop alive — and the recovery streak can only be built by probing.
    await seedHealth();
    await seedActiveCases(2);
    detector.script(CONTROL, 'GONE', 'GONE', 'GONE', 'ACTIVE');

    await evaluateTimes(3);
    expect(client.sentMessages).toHaveLength(1);
    expect(detector.probes).toHaveLength(3);

    const mid = await repos.health.get('scheduler');
    expect(mid).not.toBeNull();
    if (mid !== null) await repos.health.upsert({ ...mid, recentUnknownRate: 0.1 });

    await evaluateTimes(2);

    expect(detector.probes).toHaveLength(5);
    expect(client.sentMessages).toHaveLength(2);
    expect(client.sentMessages[1]?.text).toBe(monitoringRestored().text);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(false);

    // Incident closed AND the rate is normal: now it must stop probing entirely. Without this the
    // assertions above would still hold if `degraded` had been doing the work all along.
    await evaluateTimes(1);
    expect(detector.probes).toHaveLength(5);
  });

  it('does not probe the control or warn with fewer than 2 active cases', async () => {
    await seedHealth();
    await seedActiveCases(1);
    detector.script(CONTROL, 'GONE');

    await monitor.evaluate();

    expect(detector.probes).toHaveLength(0);
    expect(client.sentMessages).toHaveLength(0);
    expect((await repos.health.get('scheduler'))?.detectorUnhealthy).toBe(false);
  });

  it('does not probe the control or warn when the unknown rate is low', async () => {
    await seedHealth({ recentUnknownRate: 0.3 });
    await seedActiveCases(3);
    detector.script(CONTROL, 'GONE');

    await monitor.evaluate();

    expect(detector.probes).toHaveLength(0);
    expect(client.sentMessages).toHaveLength(0);
  });
});
