/**
 * Wallet tracker tests. Fixtures are shaped from the REAL API responses captured in the
 * 2026-08-04 probe of the owner's actual wallets — including the scam-airdrop rows
 * ("Duhash.games") that make the allowlist a measured necessity, not a hypothetical.
 *
 * Discipline per CLAUDE.md: no test writes the row it then asserts on. The watcher must produce
 * `wallet_txs` itself from fixture-fed fake fetches; the store is only ever READ by assertions.
 */

import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';

import type { Logger } from '../../src/logging';
import { EtherscanClient } from '../../src/wallets/chains/etherscan';
import { TronGridClient, TRON_USDT_CONTRACT } from '../../src/wallets/chains/trongrid';
import { loadWalletsConfig, parseWallets } from '../../src/wallets/config';
import type { WalletsConfig } from '../../src/wallets/config';
import { formatAlert, formatBalances } from '../../src/wallets/formatter';
import { WalletBot } from '../../src/wallets/bot';
import { WalletStore } from '../../src/wallets/persistence';
import { WalletWatcher } from '../../src/wallets/watcher';

const noopLogger = {
  debug: () => undefined,
  info: () => undefined,
  warn: () => undefined,
  error: () => undefined,
} as unknown as Logger;

const ENV = {
  WALLETS:
    'tron|TWKczMnoQDg3Bh84pnn7fK3xJ6mJ2ozStW|Binance TRC;eth|0x3f2680c939c2db53ff28920aff40cbe5e722735c|Binance ERC',
  WALLET_BOT_TOKEN: '123456:test-token',
  WALLET_PAIRING_SECRET: 'test-secret-123',
  ETHERSCAN_API_KEY: 'test-key',
} as NodeJS.ProcessEnv;

const ETH_WALLET = '0x3f2680c939c2db53ff28920aff40cbe5e722735c';
const TRON_WALLET = 'TWKczMnoQDg3Bh84pnn7fK3xJ6mJ2ozStW';
const USDT_ETH = '0xdac17f958d2ee523a2206206994597c13d831ec7';
/** The scam token contract observed on the owner's real wallets on 2026-08-01. */
const SCAM_CONTRACT = '0x00000000000000000000000000000000000scam1';

// --------------------------------------------------------------------------------------- helpers

const tempDirs: string[] = [];
const openStores: WalletStore[] = [];
function newStore(): WalletStore {
  const dir = mkdtempSync(join(tmpdir(), 'wallet-test-'));
  tempDirs.push(dir);
  const store = new WalletStore(join(dir, 'test.sqlite'));
  openStores.push(store);
  return store;
}
afterEach(() => {
  // Close before delete: Windows holds the file lock for as long as the connection lives, and
  // rmSync on a locked SQLite file is EBUSY.
  for (const store of openStores.splice(0)) {
    try {
      store.close();
    } catch {
      // already closed by the test
    }
  }
  for (const dir of tempDirs.splice(0)) rmSync(dir, { recursive: true, force: true });
});

function jsonResponse(body: unknown): Response {
  return new Response(JSON.stringify(body), { status: 200 });
}

/** Etherscan tokentx row, shaped exactly like the captured probe responses. */
function tokenTxRow(over: Partial<Record<string, string>>): Record<string, string> {
  return {
    hash: '0xabc1',
    from: '0x000000000000000000000000000000000000dead',
    to: ETH_WALLET,
    contractAddress: USDT_ETH,
    value: '699600000',
    tokenSymbol: 'USDT',
    tokenDecimal: '6',
    confirmations: '2383',
    timeStamp: '1785758820',
    gasPrice: '1000000000',
    gasUsed: '60000',
    blockNumber: '21000000',
    transactionIndex: '5',
    isError: '0',
    ...over,
  };
}

interface EthFixture {
  tokentx: Record<string, string>[];
  txlist: Record<string, string>[];
  tipBlock: number;
}

/** A fetch that answers like Etherscan V2, from fixtures. */
function etherscanFetch(fx: EthFixture): typeof fetch {
  return (async (input: string | URL | Request): Promise<Response> => {
    const url = String(input);
    if (url.includes('action=tokentx'))
      return jsonResponse({ status: '1', message: 'OK', result: fx.tokentx });
    if (url.includes('action=txlist'))
      return jsonResponse({ status: '1', message: 'OK', result: fx.txlist });
    if (url.includes('action=eth_blockNumber'))
      return jsonResponse({ result: '0x' + fx.tipBlock.toString(16) });
    if (url.includes('action=balance'))
      return jsonResponse({ status: '1', message: 'OK', result: '13477000000000000' });
    if (url.includes('action=tokenbalance'))
      return jsonResponse({ status: '1', message: 'OK', result: '0' });
    throw new Error('unexpected etherscan url: ' + url);
  }) as typeof fetch;
}

interface TronFixture {
  trc20: Array<Record<string, unknown>>;
}

function trongridFetch(fx: TronFixture): typeof fetch {
  return (async (input: string | URL | Request): Promise<Response> => {
    const url = String(input);
    if (url.includes('/transactions/trc20')) return jsonResponse({ success: true, data: fx.trc20 });
    if (url.includes('/v1/accounts/')) {
      return jsonResponse({
        success: true,
        data: [{ balance: 18000000, trc20: [{ [TRON_USDT_CONTRACT]: '500000000' }] }],
      });
    }
    if (url.includes('gettransactioninfobyid')) return jsonResponse({ fee: 27300000 });
    throw new Error('unexpected trongrid url: ' + url);
  }) as typeof fetch;
}

function trc20Row(over: Partial<Record<string, unknown>>): Record<string, unknown> {
  return {
    transaction_id: 'trontx1',
    from: 'TSenderSenderSenderSenderSenderSen',
    to: TRON_WALLET,
    value: '500000000',
    block_timestamp: 1785845000000,
    token_info: { symbol: 'USDT', decimals: 6, address: TRON_USDT_CONTRACT },
    ...over,
  };
}

interface Harness {
  watcher: WalletWatcher;
  store: WalletStore;
  sent: string[];
  sendFailure: { fail: boolean };
}

function harness(
  eth: EthFixture,
  tron: TronFixture,
  configOver: Partial<WalletsConfig> = {},
): Harness {
  const config = loadWalletsConfig(ENV);
  if (config === null) throw new Error('fixture env did not configure the feature');
  const store = newStore();
  const sent: string[] = [];
  const sendFailure = { fail: false };
  const watcher = new WalletWatcher({
    config: { ...config, ...configOver },
    store,
    etherscan: new EtherscanClient({ apiKey: 'k', fetchImpl: etherscanFetch(eth) }),
    trongrid: new TronGridClient({ apiKey: null, fetchImpl: trongridFetch(tron) }),
    logger: noopLogger,
    sendAlert: (html) => {
      if (sendFailure.fail) return Promise.reject(new Error('telegram down'));
      sent.push(html);
      return Promise.resolve();
    },
  });
  return { watcher, store, sent, sendFailure };
}

// ---------------------------------------------------------------------------------------- config

describe('wallet config', () => {
  it('parses the owner-supplied WALLETS format exactly', () => {
    const wallets = parseWallets(
      'tron|TWKczMnoQDg3Bh84pnn7fK3xJ6mJ2ozStW|Binance TRC;eth|0x3f2680c939c2db53ff28920aff40cbe5e722735c|Binance ERC',
    );
    expect(wallets).toHaveLength(2);
    expect(wallets[0]).toEqual({
      chain: 'tron',
      address: 'TWKczMnoQDg3Bh84pnn7fK3xJ6mJ2ozStW',
      label: 'Binance TRC',
    });
  });

  it('REFUSES malformed entries rather than silently dropping a wallet', () => {
    expect(() => parseWallets('eth|0xnothex|Bad')).toThrow(/malformed eth address/);
    expect(() => parseWallets('sol|abc|Sol')).toThrow(/unknown chain/);
    expect(() => parseWallets('eth|0x3f2680c939c2db53ff28920aff40cbe5e722735c|')).toThrow(
      /empty label/,
    );
  });

  it('returns null (feature off) when unconfigured, throws when half-configured', () => {
    expect(loadWalletsConfig({} as NodeJS.ProcessEnv)).toBeNull();
    expect(() => loadWalletsConfig({ ...ENV, ETHERSCAN_API_KEY: '' } as NodeJS.ProcessEnv)).toThrow(
      /ETHERSCAN_API_KEY/,
    );
  });

  it('REFUSES to run on the monitor bot token — two loops on one token steal updates', () => {
    expect(() =>
      loadWalletsConfig({
        ...ENV,
        TELEGRAM_BOT_TOKEN: ENV['WALLET_BOT_TOKEN'],
      } as NodeJS.ProcessEnv),
    ).toThrow(/DIFFERENT bot/);
    // Different tokens: loads normally.
    expect(
      loadWalletsConfig({ ...ENV, TELEGRAM_BOT_TOKEN: '999:other' } as NodeJS.ProcessEnv),
    ).not.toBeNull();
  });
});

// --------------------------------------------------------------------------------------- watcher

describe('wallet watcher', () => {
  it('first sight seeds the cursor and alerts NOTHING — no alert storm on install', async () => {
    const h = harness(
      { tokentx: [tokenTxRow({})], txlist: [], tipBlock: 21_100_000 },
      { trc20: [trc20Row({})] },
    );
    await h.watcher.tick();
    expect(h.sent).toHaveLength(0);
    expect(h.store.getCursor(ETH_WALLET)).not.toBeNull();
    expect(h.store.getCursor(TRON_WALLET)).not.toBeNull();
  });

  it('alerts a confirmed incoming USDT transfer on the tick after seeding', async () => {
    const h = harness(
      { tokentx: [tokenTxRow({})], txlist: [], tipBlock: 21_100_000 },
      { trc20: [] },
    );
    await h.watcher.tick(); // seed
    await h.watcher.tick(); // observe
    expect(h.sent).toHaveLength(1);
    expect(h.sent[0]).toContain('RECEIVED — Binance ERC');
    expect(h.sent[0]).toContain('699.60 USDT');
    // Incoming: the fee is the sender's, never shown as ours.
    expect(h.sent[0]).not.toContain('Fee:');
  });

  it('NEVER alerts a scam airdrop, even when its symbol claims to be USDT', async () => {
    // The measured attack: token contract nobody trusts, symbol spoofed to look legitimate.
    const scam = tokenTxRow({
      hash: '0xscam',
      contractAddress: SCAM_CONTRACT,
      tokenSymbol: 'USDT',
      value: '7016510000',
    });
    const h = harness({ tokentx: [scam], txlist: [], tipBlock: 21_100_000 }, { trc20: [] });
    await h.watcher.tick();
    await h.watcher.tick();
    expect(h.sent).toHaveLength(0);
    // ...but it IS recorded for the ledger: withheld from alerts, not erased.
    const row = h.store.getTx(1);
    expect(row).not.toBeNull();
    expect(row?.token_contract).toBe(SCAM_CONTRACT);
    expect(row?.alerted).toBe(0);
  });

  it('holds an under-confirmed ETH transfer for a later tick instead of alerting early', async () => {
    const young = tokenTxRow({ confirmations: '3' });
    const h = harness({ tokentx: [young], txlist: [], tipBlock: 21_100_000 }, { trc20: [] });
    await h.watcher.tick(); // seed
    await h.watcher.tick(); // sees it, too young
    expect(h.sent).toHaveLength(0);

    // The same transfer matures; the SAME rows are served again (cursor did not advance past it).
    young['confirmations'] = '48';
    await h.watcher.tick();
    expect(h.sent).toHaveLength(1);
  });

  it('dedupes across re-polls: the same transfer served twice alerts once', async () => {
    const h = harness(
      { tokentx: [tokenTxRow({})], txlist: [], tipBlock: 21_100_000 },
      { trc20: [] },
    );
    await h.watcher.tick();
    await h.watcher.tick();
    await h.watcher.tick();
    await h.watcher.tick();
    expect(h.sent).toHaveLength(1);
  });

  it('alerts an outgoing TRON USDT transfer with the fee fetched lazily', async () => {
    const out = trc20Row({
      from: TRON_WALLET,
      to: 'TReceiverReceiverReceiverReceiverR',
      value: '4003890000',
    });
    const h = harness({ tokentx: [], txlist: [], tipBlock: 21_100_000 }, { trc20: [out] });
    await h.watcher.tick(); // seed
    await h.watcher.tick();
    expect(h.sent).toHaveLength(1);
    expect(h.sent[0]).toContain('SENT — Binance TRC');
    expect(h.sent[0]).toContain('4,003.89 USDT');
    expect(h.sent[0]).toContain('Fee: 27.30 TRX');
  });

  it('a failed send is retried on the next tick and NEVER duplicated after success', async () => {
    const h = harness(
      { tokentx: [tokenTxRow({})], txlist: [], tipBlock: 21_100_000 },
      { trc20: [] },
    );
    await h.watcher.tick(); // seed
    h.sendFailure.fail = true;
    await h.watcher.tick(); // discover; send fails -> released to PENDING
    expect(h.sent).toHaveLength(0);
    h.sendFailure.fail = false;
    await h.watcher.tick(); // retry succeeds
    await h.watcher.tick(); // and never again
    expect(h.sent).toHaveLength(1);
  });

  it('records dust below the alert floor without alerting it', async () => {
    const dust = tokenTxRow({ value: '500000' }); // 0.50 USDT
    const h = harness({ tokentx: [dust], txlist: [], tipBlock: 21_100_000 }, { trc20: [] });
    await h.watcher.tick();
    await h.watcher.tick();
    expect(h.sent).toHaveLength(0);
    expect(h.store.getTx(1)).not.toBeNull();
  });

  it('one chain failing backs off THAT chain while the other keeps alerting', async () => {
    const failingEth = (async (): Promise<Response> => {
      throw new Error('etherscan 502');
    }) as typeof fetch;
    const config = loadWalletsConfig(ENV);
    if (config === null) throw new Error('unreachable');
    const store = newStore();
    const sent: string[] = [];
    const watcher = new WalletWatcher({
      config,
      store,
      etherscan: new EtherscanClient({ apiKey: 'k', fetchImpl: failingEth }),
      trongrid: new TronGridClient({
        apiKey: null,
        fetchImpl: trongridFetch({ trc20: [trc20Row({})] }),
      }),
      logger: noopLogger,
      sendAlert: (html) => {
        sent.push(html);
        return Promise.resolve();
      },
    });
    await watcher.tick(); // tron seeds; eth fails
    await watcher.tick(); // tron observes and alerts; eth in backoff
    expect(sent).toHaveLength(1);
    expect(watcher.failureSnapshot().eth).toBeGreaterThan(0);
  });
});

// ----------------------------------------------------------------------------- store invariants

describe('wallet store', () => {
  it('claim-then-send: a claimed alert is invisible to a second claimant', () => {
    const store = newStore();
    const id = store.insertTx({
      wallet_address: ETH_WALLET,
      chain: 'eth',
      txid: '0x1',
      log_index: 0,
      direction: 'IN',
      token_contract: USDT_ETH,
      symbol: 'USDT',
      amount: 10,
      fee_native: null,
      counterparty: '0xdead',
      block_time_utc: '2026-08-04T00:00:00Z',
      seen_at_utc: '2026-08-04T00:00:00Z',
    });
    expect(id).not.toBeNull();
    store.enqueueAlert(id as number, '2026-08-04T00:00:01Z');
    const first = store.claimNextAlert('2026-08-04T00:00:02Z');
    expect(first).not.toBeNull();
    expect(store.claimNextAlert('2026-08-04T00:00:03Z')).toBeNull();
  });

  it('stale claims from a dead process are recovered to PENDING at startup', () => {
    const store = newStore();
    const id = store.insertTx({
      wallet_address: ETH_WALLET,
      chain: 'eth',
      txid: '0x2',
      log_index: 0,
      direction: 'IN',
      token_contract: USDT_ETH,
      symbol: 'USDT',
      amount: 10,
      fee_native: null,
      counterparty: '0xdead',
      block_time_utc: '2026-08-04T00:00:00Z',
      seen_at_utc: '2026-08-04T00:00:00Z',
    }) as number;
    store.enqueueAlert(id, '2026-08-04T00:00:01Z');
    store.claimNextAlert('2026-08-04T00:00:02Z'); // process "dies" here
    expect(store.recoverStaleClaims('2026-08-04T00:00:10Z')).toBe(1);
    expect(store.claimNextAlert('2026-08-04T00:00:11Z')).not.toBeNull();
  });

  it('gives up on an alert after the attempt cap instead of retrying forever', () => {
    const store = newStore();
    const id = store.insertTx({
      wallet_address: ETH_WALLET,
      chain: 'eth',
      txid: '0x3',
      log_index: 0,
      direction: 'IN',
      token_contract: USDT_ETH,
      symbol: 'USDT',
      amount: 10,
      fee_native: null,
      counterparty: '0xdead',
      block_time_utc: '2026-08-04T00:00:00Z',
      seen_at_utc: '2026-08-04T00:00:00Z',
    }) as number;
    store.enqueueAlert(id, 't0');
    for (let i = 0; i < 5; i += 1) {
      const claimed = store.claimNextAlert('t1');
      expect(claimed).not.toBeNull();
      store.releaseAlert((claimed as { id: number }).id, 'boom', 5, 't2');
    }
    expect(store.claimNextAlert('t3')).toBeNull(); // FAILED, not PENDING
  });
});

// ------------------------------------------------------------------------- owner recognition

describe('wallet bot owner recognition', () => {
  /** The main app's owner table — ITS artifact, fixtured here as external state. */
  function seedMainOwner(store: WalletStore, userId: number): void {
    const raw = (store as unknown as { db: import('better-sqlite3').Database }).db;
    raw.exec(
      'CREATE TABLE IF NOT EXISTS owner (id INTEGER PRIMARY KEY, telegram_user_id INTEGER NOT NULL, paired_at_utc TEXT NOT NULL)',
    );
    raw
      .prepare('INSERT INTO owner (id, telegram_user_id, paired_at_utc) VALUES (1, ?, ?)')
      .run(userId, '2026-07-01T00:00:00Z');
  }

  interface FakeTelegram {
    client: import('../../src/domain').TelegramClient;
    sent: Array<{ chat_id: number; text: string }>;
    queue: Array<{ update_id: number; text: string; chatId: number }>;
    /** Wired to bot.stop() before run(), so an empty queue ends the loop. */
    stopRef: { stop: () => void };
  }

  /** Serves queued batches; when the queue is empty, stops the bot so run() returns. */
  function fakeTelegram(): FakeTelegram {
    const sent: FakeTelegram['sent'] = [];
    const queue: FakeTelegram['queue'] = [];
    const stopRef = { stop: (): void => undefined };
    const client = {
      setMyCommands: () => Promise.resolve(true),
      sendMessage: (p: { chat_id: number; text: string }) => {
        sent.push({ chat_id: p.chat_id, text: p.text });
        return Promise.resolve({ message_id: sent.length });
      },
      getUpdates: () => {
        if (queue.length === 0) {
          stopRef.stop();
          return Promise.resolve([]);
        }
        return Promise.resolve(
          queue.splice(0).map((q) => ({
            update_id: q.update_id,
            message: { chat: { id: q.chatId, type: 'private' }, text: q.text },
          })),
        );
      },
    } as unknown as import('../../src/domain').TelegramClient;
    return { client, sent, queue, stopRef };
  }

  function makeBot(store: WalletStore, tg: FakeTelegram): WalletBot {
    const config = loadWalletsConfig(ENV);
    if (config === null) throw new Error('unreachable');
    return new WalletBot({
      config,
      store,
      telegram: tg.client,
      etherscan: new EtherscanClient({
        apiKey: 'k',
        fetchImpl: etherscanFetch({ tokentx: [], txlist: [], tipBlock: 1 }),
      }),
      trongrid: new TronGridClient({ apiKey: null, fetchImpl: trongridFetch({ trc20: [] }) }),
      watcher: { failureSnapshot: () => ({ eth: 0, tron: 0 }) } as unknown as WalletWatcher,
      logger: noopLogger,
    });
  }

  async function runBot(store: WalletStore, tg: FakeTelegram): Promise<WalletBot> {
    const bot = makeBot(store, tg);
    tg.stopRef.stop = () => bot.stop();
    await bot.run();
    return bot;
  }

  it('store reads the main owner; null when the table is absent', () => {
    const bare = newStore();
    expect(bare.mainOwnerChatId()).toBeNull();
    const seeded = newStore();
    seedMainOwner(seeded, 777001);
    expect(seeded.mainOwnerChatId()).toBe(777001);
  });

  it('auto-pairs the MAIN BOT OWNER on a bare /start — no secret ceremony', async () => {
    const store = newStore();
    seedMainOwner(store, 777001);
    const tg = fakeTelegram();
    tg.queue.push({ update_id: 1, text: '/start', chatId: 777001 });
    await runBot(store, tg);
    expect(store.pairedChatId()).toBe(777001);
    expect(tg.sent).toHaveLength(1);
    expect(tg.sent[0]?.text).toContain('Wallet bot paired');
  });

  it('stays SILENT to strangers: wrong secret and /wallets both draw no reply', async () => {
    const store = newStore();
    seedMainOwner(store, 777001);
    const tg = fakeTelegram();
    tg.queue.push({ update_id: 1, text: '/start wrong-secret', chatId: 666000 });
    tg.queue.push({ update_id: 2, text: '/wallets', chatId: 666000 });
    await runBot(store, tg);
    expect(tg.sent).toHaveLength(0);
    expect(store.pairedChatId()).toBeNull();
  });

  it('sendAlert reaches the main owner even before any explicit pairing exists', async () => {
    const store = newStore();
    seedMainOwner(store, 777001);
    const tg = fakeTelegram();
    const bot = makeBot(store, tg);
    await bot.sendAlert('<b>test</b>');
    expect(tg.sent.some((s) => s.chat_id === 777001 && s.text === '<b>test</b>')).toBe(true);
  });
});

// ------------------------------------------------------------------------------------ formatter

describe('wallet formatter', () => {
  it('escapes HTML in attacker-controllable fields', () => {
    const html = formatAlert(
      {
        id: 1,
        wallet_address: ETH_WALLET,
        chain: 'eth',
        txid: '0xabc',
        log_index: 0,
        direction: 'IN',
        token_contract: SCAM_CONTRACT,
        symbol: '<script>alert(1)</script>',
        amount: 5,
        fee_native: null,
        counterparty: '0xdead',
        block_time_utc: '2026-08-03T13:47:00Z',
        seen_at_utc: '2026-08-03T13:47:10Z',
        alerted: 0,
      },
      'Ledger ERC',
      null,
    );
    expect(html).not.toContain('<script>');
    expect(html).toContain('&lt;script&gt;');
  });

  it('renders balances with IST timestamp and grouped amounts', () => {
    const text = formatBalances(
      [
        { label: 'Binance TRC', chain: 'tron', address: TRON_WALLET, native: 18, usdt: 0 },
        { label: 'Ledger ERC', chain: 'eth', address: ETH_WALLET, native: 0.000628, usdt: 699.6 },
      ],
      '2026-08-03T16:37:00Z',
    );
    expect(text).toContain('WALLET BALANCES');
    expect(text).toContain('699.60 USDT');
    expect(text).toContain('IST');
  });
});
