import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import Database from 'better-sqlite3';
import { afterEach, describe, expect, it } from 'vitest';

const SCRIPT = resolve(process.cwd(), 'deploy', 'ha-snapshot.mjs');
const roots: string[] = [];

function run(...args: string[]): { status: number | null; stdout: string; stderr: string } {
  const child = spawnSync(process.execPath, [SCRIPT, ...args], { encoding: 'utf8' });
  return { status: child.status, stdout: child.stdout, stderr: child.stderr };
}

afterEach(() => {
  for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true });
});

describe('HA SQLite snapshots', () => {
  it('backs up committed WAL pages, verifies them, and restores one standalone database', () => {
    const root = mkdtempSync(join(tmpdir(), 'monitor-ha-snapshot-'));
    roots.push(root);
    const source = join(root, 'monitor.sqlite');
    const archive = join(root, 'snapshot-7.sqlite.gz');
    const manifest = join(root, 'snapshot-7.json');
    const restored = join(root, 'restored.sqlite');

    const db = new Database(source);
    try {
      db.pragma('journal_mode = WAL');
      db.pragma('wal_autocheckpoint = 0');
      db.exec(`
        CREATE TABLE scheduler_health (
          name TEXT PRIMARY KEY,
          last_scheduler_run_utc TEXT,
          updated_at_utc TEXT
        );
        CREATE TABLE payload (id INTEGER PRIMARY KEY, value TEXT NOT NULL);
      `);
      // Put the schema in the main DB, then deliberately leave the facts only in the WAL. A plain
      // file copy of monitor.sqlite at this point is exactly the unsafe production failure shape.
      db.pragma('wal_checkpoint(TRUNCATE)');
      db.prepare(
        `INSERT INTO scheduler_health (name, last_scheduler_run_utc, updated_at_utc)
         VALUES ('__ping__', NULL, 'proc-1'), ('scheduler', 'sched-1', 'row-update')`,
      ).run();
      db.prepare(`INSERT INTO payload (value) VALUES (?)`).run('committed-in-wal');
      expect(existsSync(`${source}-wal`)).toBe(true);

      const inspect = run('inspect', '--db', source);
      expect(inspect.status, inspect.stderr).toBe(0);
      expect(JSON.parse(inspect.stdout).liveness).toEqual({
        procUtc: 'proc-1',
        schedUtc: 'sched-1',
      });

      const create = run(
        'create',
        '--db',
        source,
        '--archive',
        archive,
        '--manifest',
        manifest,
        '--seq',
        '7',
        '--agent-boot-id',
        'test-agent',
      );
      expect(create.status, create.stderr).toBe(0);
      expect(existsSync(archive)).toBe(true);
      expect(existsSync(manifest)).toBe(true);

      const restore = run(
        'restore',
        '--archive',
        archive,
        '--manifest',
        manifest,
        '--out',
        restored,
      );
      expect(restore.status, restore.stderr).toBe(0);
      const copy = new Database(restored, { readonly: true });
      try {
        expect(copy.prepare(`SELECT value FROM payload`).pluck().get()).toBe('committed-in-wal');
        expect(copy.pragma('integrity_check', { simple: true })).toBe('ok');
      } finally {
        copy.close();
      }
    } finally {
      db.close();
    }
  });

  it('rejects a partial/corrupted transfer and never creates the restore target', () => {
    const root = mkdtempSync(join(tmpdir(), 'monitor-ha-corrupt-'));
    roots.push(root);
    const source = join(root, 'monitor.sqlite');
    const archive = join(root, 'snapshot.sqlite.gz');
    const manifest = join(root, 'snapshot.json');
    const restored = join(root, 'must-not-exist.sqlite');

    const db = new Database(source);
    db.exec(
      `CREATE TABLE scheduler_health (name TEXT PRIMARY KEY, last_scheduler_run_utc TEXT, updated_at_utc TEXT)`,
    );
    db.close();
    expect(
      run(
        'create',
        '--db',
        source,
        '--archive',
        archive,
        '--manifest',
        manifest,
        '--seq',
        '1',
        '--agent-boot-id',
        'test-agent',
      ).status,
    ).toBe(0);

    const bytes = readFileSync(archive);
    bytes[Math.max(0, bytes.length - 2)] = (bytes[Math.max(0, bytes.length - 2)] ?? 0) ^ 0xff;
    writeFileSync(archive, bytes);

    const attempt = run('restore', '--archive', archive, '--manifest', manifest, '--out', restored);
    expect(attempt.status).toBe(2);
    expect(attempt.stderr).toContain('sha256 mismatch');
    expect(existsSync(restored)).toBe(false);
  });
});
