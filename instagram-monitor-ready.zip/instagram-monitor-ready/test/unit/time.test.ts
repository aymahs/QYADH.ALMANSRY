import { describe, it, expect } from 'vitest';
import { parseBackdatedTimestamp, formatIstDateTime, formatIstTime } from '../../src/core';

const IST = 'Asia/Kolkata';
const NOW = new Date('2026-07-17T00:00:00.000Z');

describe('parseBackdatedTimestamp', () => {
  it('interprets a wall-clock time in Asia/Kolkata as UTC', () => {
    const r = parseBackdatedTimestamp('2026-07-15 18:30', IST, NOW);
    expect('iso' in r).toBe(true);
    if ('iso' in r) expect(r.iso).toBe('2026-07-15T13:00:00.000Z');
  });

  it('accepts optional seconds', () => {
    const r = parseBackdatedTimestamp('2026-07-15 18:30:45', IST, NOW);
    expect('iso' in r && r.iso).toBe('2026-07-15T13:00:45.000Z');
  });

  it('honors an explicit Z offset regardless of tz', () => {
    const r = parseBackdatedTimestamp('2026-07-15 13:00:00Z', IST, NOW);
    expect('iso' in r && r.iso).toBe('2026-07-15T13:00:00.000Z');
  });

  it('honors an explicit numeric offset', () => {
    const r = parseBackdatedTimestamp('2026-07-15 18:30+05:30', IST, NOW);
    expect('iso' in r && r.iso).toBe('2026-07-15T13:00:00.000Z');
  });

  it('rejects future timestamps', () => {
    const r = parseBackdatedTimestamp('2030-01-01 00:00', IST, NOW);
    expect('error' in r).toBe(true);
  });

  it('rejects unparseable input', () => {
    expect('error' in parseBackdatedTimestamp('not a date', IST, NOW)).toBe(true);
    expect('error' in parseBackdatedTimestamp('2026-13-40 99:99', IST, NOW)).toBe(true);
    expect('error' in parseBackdatedTimestamp('2026-02-30 10:00', IST, NOW)).toBe(true);
  });
});

describe('formatIstDateTime', () => {
  it('formats a UTC instant as day, month, year, 12-hour time, and IST label', () => {
    // 17:00:15Z + 05:30 = 22:30:15 IST
    expect(formatIstDateTime('2026-07-17T17:00:15.000Z', IST)).toBe(
      '17 July 2026, 10:30:15 PM IST',
    );
  });
});

describe('formatIstTime', () => {
  it('formats a UTC instant as time only', () => {
    // 17:01:00Z + 05:30 = 22:31:00 IST
    expect(formatIstTime('2026-07-17T17:01:00.000Z', IST)).toBe('10:31:00 PM IST');
  });
});
