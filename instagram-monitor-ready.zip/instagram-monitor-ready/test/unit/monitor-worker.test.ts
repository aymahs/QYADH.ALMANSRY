import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type {
  DetectorErrorCode,
  MonitoringCase,
  ProbeOptions,
  ProbeResult,
  Screenshot,
} from '../../src/domain';
import { FixedClock, SIGNALS_VERSION } from '../../src/domain';
import type { BreakerState } from '../../src/instagram/circuit-breaker';
import type {
  FastTierReport,
  TieredProbeOptions,
} from '../../src/instagram/detector/tiered-detector';
import { nullLogger } from '../../src/logging';
import { MockTelegramClient } from '../../src/bot/telegram-client';
import { MonitorWorker } from '../../src/monitoring/scheduler';
import { OutboxWorker } from '../../src/notifications/outbox';
import {
  FAKE_PNG,
  FakeDetector,
  InMemoryRepositories,
  instantSleep,
  makeTestConfig,
} from '../helpers/worker-fakes';

/**
 * A detector whose fleet-wide breaker is OPEN. The real {@link TieredDetector} then refuses every
 * probe instantly without sending a packet, so a sweep can learn nothing — the sweep must not pay
 * for one either.
 */
class BreakerOpenDetector extends FakeDetector {
  breakerSnapshot(): { state: BreakerState; consecutive: number; retryAfterMs: number } {
    return { state: 'OPEN', consecutive: 5, retryAfterMs: 600_000 };
  }

  fastTierReport(): Promise<FastTierReport> {
    throw new Error('fastTierReport is never called by the re-capture sweep');
  }
}

/**
 * A detector whose capture never comes back — a page whose header never satisfies the paint
 * predicate, or a renderer wedged inside `page.evaluate` (which `setDefaultTimeout` does not
 * cover). The scheduler must not be hostage to it.
 */
class HangingDetector extends FakeDetector {
  calls = 0;

  override probe(): Promise<ProbeResult> {
    this.calls += 1;
    return new Promise<ProbeResult>(() => undefined);
  }
}

/** The settle-selector wait every browser load pays after domcontentloaded (BrowserManager). */
const SETTLE_MS = 8_000;

/** The `Screenshot` the browser path hands back, wrapping the shared fake PNG bytes. */
const FAKE_SCREENSHOT: Screenshot = { buffer: FAKE_PNG, format: 'png', width: 701, height: 431 };

const delayMs = (ms: number): Promise<void> =>
  new Promise((resolve) => {
    setTimeout(resolve, ms);
  });

/** The two shapes the browser path returns when it ran but could not produce a picture. */
function withoutPicture(
  classification: 'ACTIVE' | 'UNKNOWN',
  errorCode: DetectorErrorCode | null,
): ProbeResult {
  return {
    result: {
      classification,
      evidence: {
        signalsVersion: SIGNALS_VERSION,
        activeSignals: [],
        goneSignals: [],
        identitySignalMatched: false,
        finalUrl: null,
        responseStatus: null,
        errorCode,
      },
      durationMs: 0,
    },
    screenshot: null,
  };
}

/**
 * A detector that takes the time a REAL slow profile takes, and fails the way the browser fails.
 *
 * Modelled on @trymaven through the production mobile proxy: `navMs` to domcontentloaded, then
 * the settle wait, then `paintMs` more before the header satisfies the paint predicate. It obeys
 * both budgets the caller hands it, exactly as the browser path does — a page load longer than
 * `captureNavBudgetMs` is aborted by `page.goto` (UNKNOWN/TIMEOUT, no picture) and a paint slower
 * than `paintBudgetMs` gives up on the picture (ACTIVE, no picture). It never invents a screenshot
 * for a probe that was not given the room to take one, which is the only reason an assertion about
 * the delivered file means anything.
 *
 * Classification probes are answered immediately: they run on their own, much tighter budget and
 * are not what any of this is about.
 */
class SlowProfileDetector extends FakeDetector {
  constructor(
    private readonly navMs: number,
    private readonly paintMs: number,
  ) {
    super();
  }

  override async probe(username: string, options?: ProbeOptions): Promise<ProbeResult> {
    if (options?.captureScreenshot !== true) return super.probe(username, options);

    this.probes.push({ username, options });
    const navBudgetMs = options.captureNavBudgetMs ?? Number.POSITIVE_INFINITY;
    if (this.navMs > navBudgetMs) {
      await delayMs(navBudgetMs);
      return withoutPicture('UNKNOWN', 'TIMEOUT');
    }
    await delayMs(this.navMs + SETTLE_MS);

    const paintBudgetMs = options.paintBudgetMs ?? 0;
    if (this.paintMs > paintBudgetMs) {
      await delayMs(paintBudgetMs);
      return withoutPicture('ACTIVE', null);
    }
    await delayMs(this.paintMs);
    return { result: withoutPicture('ACTIVE', null).result, screenshot: FAKE_SCREENSHOT };
  }
}

const BASE_ISO = '2026-07-17T00:00:00.000Z';
const USER = 'someuser';
const OTHER_USER = 'otheruser';
/** rand() === 0 => zero jitter, so scheduled times are exact. */
const rand = (): number => 0;

const BASELINE_MS = 60_000;
const CONFIRM_MS = 5_000;

describe('MonitorWorker', () => {
  let clock: FixedClock;
  let repos: InMemoryRepositories;
  let detector: FakeDetector;
  let dir: string;

  beforeEach(async () => {
    clock = new FixedClock(new Date(BASE_ISO));
    repos = new InMemoryRepositories();
    detector = new FakeDetector();
    dir = await mkdtemp(join(tmpdir(), 'monitor-worker-'));
  });

  afterEach(async () => {
    await rm(dir, { recursive: true, force: true });
  });

  function makeWorker(workerId = 'w1'): MonitorWorker {
    return new MonitorWorker({
      repos,
      detector,
      config: makeTestConfig(),
      clock,
      logger: nullLogger(),
      rand,
      workerId,
      screenshotDir: dir,
      sleep: instantSleep,
    });
  }

  async function seedCase(overrides: Partial<MonitoringCase> = {}): Promise<MonitoringCase> {
    const created = await repos.cases.create(
      {
        normalizedUsername: USER,
        originalInput: USER,
        startedAtUtc: BASE_ISO,
        nextCheckAtUtc: BASE_ISO,
      },
      BASE_ISO,
    );
    if (Object.keys(overrides).length === 0) return created;
    const next: MonitoringCase = { ...created, ...overrides };
    await repos.cases.save(next);
    return next;
  }

  async function tick(worker: MonitorWorker, advanceMs: number): Promise<void> {
    clock.advanceMs(advanceMs);
    await worker.runOnce();
  }

  // -------------------------------------------------------------------------------------------
  // BROWSER-LOAD PRIORITY AND CADENCE. The governor can only protect recoveries if the worker
  // labels its traffic honestly, and can only slow the fleet if the worker reads the pressure.
  // -------------------------------------------------------------------------------------------
  describe('browser-load budget integration', () => {
    /** A detector that also reports a browser-load budget, exactly as TieredDetector does. */
    class BudgetedDetector extends FakeDetector {
      budget: NonNullable<FastTierReport['browserBudget']> = {
        capacity: 120,
        routineAllowance: 90,
        windowMs: 3_600_000,
        used: 0,
        routineUsed: 0,
        deferred: 0,
        intervalMultiplier: 1,
        escalationStreak: 0,
        storm: false,
        throttling: false,
        overCapacity: false,
        reason: 'no throttling',
      };

      breakerSnapshot(): { state: BreakerState; consecutive: number; retryAfterMs: number } {
        return { state: 'CLOSED', consecutive: 0, retryAfterMs: 0 };
      }

      browserBudget(): FastTierReport['browserBudget'] {
        return this.budget;
      }

      fastTierReport(): Promise<FastTierReport> {
        throw new Error('the monitor worker must never pay for a fast-tier report on the hot path');
      }
    }

    function budgetedWorker(d: FakeDetector): MonitorWorker {
      return new MonitorWorker({
        repos,
        detector: d,
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        rand,
        workerId: 'w1',
        screenshotDir: dir,
        sleep: instantSleep,
      });
    }

    it('labels routine polling ROUTINE and a confirmation burst CONFIRMATION', async () => {
      // The label decides what the governor may refuse. Labelling a burst ROUTINE would let
      // routine polling starve a recovery that has already happened (harm rank 1); labelling
      // baseline polling CONFIRMATION would exempt the fleet's whole volume from the budget.
      await seedCase();
      const d = new BudgetedDetector();
      d.script(USER, 'ACTIVE', 'ACTIVE');
      const worker = budgetedWorker(d);

      await tick(worker, 0); // MONITORING -> CONFIRMING
      await tick(worker, CONFIRM_MS); // CONFIRMING -> next burst check

      const priorities = d.probes.map(
        (p) => (p.options as TieredProbeOptions | undefined)?.loadPriority,
      );
      expect(priorities[0]).toBe('ROUTINE');
      expect(priorities[1]).toBe('CONFIRMATION');
    });

    it('REGRESSION: baseline polling slows when the fleet is over its browser-load budget', async () => {
      // Nothing used to connect load to cadence at all: the ESCALATION_STORM signal only printed
      // a /ping line, and the circuit breaker is structurally blind to escalations because they
      // SUCCEED. The fleet ran at 20-50x normal load with no brake of any kind.
      const c = await seedCase();
      const d = new BudgetedDetector();
      d.script(USER, 'GONE', 'GONE');
      const worker = budgetedWorker(d);

      await tick(worker, 0);
      const relaxed = await repos.cases.findById(c.id);
      const relaxedGap =
        new Date(relaxed?.nextCheckAtUtc ?? BASE_ISO).getTime() - clock.now().getTime();

      d.budget = { ...d.budget, intervalMultiplier: 4, throttling: true, reason: 'storm' };
      await tick(worker, relaxedGap);
      const throttled = await repos.cases.findById(c.id);
      const throttledGap =
        new Date(throttled?.nextCheckAtUtc ?? BASE_ISO).getTime() - clock.now().getTime();

      // 4x the interval is 1/4 the page loads per hour — the only lever that reduces VOLUME
      // without refusing anything.
      expect(throttledGap).toBeGreaterThan(relaxedGap * 3);
    });

    it('a detector with no governor to report on schedules exactly as before', async () => {
      // The governor is optional (tests, and any detector without one). Its absence must not
      // change a single scheduling decision.
      const c = await seedCase();
      detector.script(USER, 'GONE');
      const worker = makeWorker();
      await tick(worker, 0);
      const stored = await repos.cases.findById(c.id);
      const gap = new Date(stored?.nextCheckAtUtc ?? BASE_ISO).getTime() - clock.now().getTime();
      expect(gap).toBe(BASELINE_MS);
    });
  });

  it('GONE -> ACTIVE x3 confirms once: one RECOVERY_PHOTO item, NOTIFYING, screenshot written', async () => {
    const c = await seedCase();
    detector.script(
      USER,
      'GONE',
      'ACTIVE',
      'ACTIVE',
      'ACTIVE',
      { classification: 'ACTIVE', screenshot: FAKE_PNG }, // capture probe
    );
    const worker = makeWorker();

    await tick(worker, 0); // GONE -> baseline re-armed
    await tick(worker, BASELINE_MS); // ACTIVE -> CONFIRMING 1/3
    await tick(worker, CONFIRM_MS); // ACTIVE -> CONFIRMING 2/3
    await tick(worker, CONFIRM_MS); // ACTIVE -> CONFIRMED -> capture -> NOTIFYING

    const items = repos.outbox.all();
    expect(items).toHaveLength(1);
    expect(items[0]?.kind).toBe('RECOVERY_PHOTO');
    expect(items[0]?.status).toBe('PENDING');

    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('NOTIFYING');
    expect(stored?.screenshotStatus).toBe('CAPTURED');
    expect(stored?.confirmedAtUtc).not.toBeNull();

    const file = await readFile(join(dir, `${c.id}.png`));
    expect(file.equals(FAKE_PNG)).toBe(true);
  });

  it('ACTIVE -> ACTIVE -> GONE never notifies; case back to MONITORING with count 0', async () => {
    const c = await seedCase();
    detector.script(USER, 'ACTIVE', 'ACTIVE', 'GONE');
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, CONFIRM_MS);
    await tick(worker, CONFIRM_MS);

    expect(repos.outbox.all()).toHaveLength(0);
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('MONITORING');
    expect(stored?.confirmationCount).toBe(0);
  });

  it('ACTIVE -> UNKNOWN -> ACTIVE -> ACTIVE never notifies (streak reset); ends CONFIRMING 2/3', async () => {
    const c = await seedCase();
    detector.script(USER, 'ACTIVE', 'UNKNOWN', 'ACTIVE', 'ACTIVE');
    const worker = makeWorker();

    await tick(worker, 0); // CONFIRMING 1/3
    await tick(worker, CONFIRM_MS); // UNKNOWN -> MONITORING, baseline
    await tick(worker, BASELINE_MS); // CONFIRMING 1/3
    await tick(worker, CONFIRM_MS); // CONFIRMING 2/3

    expect(repos.outbox.all()).toHaveLength(0);
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('CONFIRMING');
    expect(stored?.confirmationCount).toBe(2);
  });

  it('ACTIVE x4 produces exactly one outbox item in total', async () => {
    await seedCase();
    detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', {
      classification: 'ACTIVE',
      screenshot: FAKE_PNG,
    });
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, CONFIRM_MS);
    await tick(worker, CONFIRM_MS); // confirmed here; capture + NOTIFYING
    await tick(worker, CONFIRM_MS); // NOTIFYING is not claimable — no-op tick

    const items = repos.outbox.all();
    expect(items).toHaveLength(1);
    expect(items[0]?.kind).toBe('RECOVERY_PHOTO');
  });

  it('/clear landing between claim and save drops the transition; zero outbox', async () => {
    // CONFIRMING 2/3: the next ACTIVE would confirm and notify.
    const c = await seedCase({
      status: 'CONFIRMING',
      confirmationCount: 2,
      lastCheckedAtUtc: BASE_ISO,
      nextCheckAtUtc: new Date(new Date(BASE_ISO).getTime() + CONFIRM_MS).toISOString(),
    });
    detector.script(USER, {
      classification: 'ACTIVE',
      screenshot: FAKE_PNG,
      onProbe: async (): Promise<void> => {
        // /clear wins the race while the browser check is in flight.
        await repos.cases.clearByNormalizedUsername(USER, clock.now().toISOString());
      },
    });
    const worker = makeWorker();

    await tick(worker, CONFIRM_MS);

    expect(repos.outbox.all()).toHaveLength(0);
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('CLEARED');
    expect(stored?.clearedAtUtc).not.toBeNull();
    expect(stored?.confirmationCount).toBe(2); // transition was dropped, not saved
  });

  it('GONE at capture time cancels the notification and reverts to MONITORING', async () => {
    const c = await seedCase();
    detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', 'GONE'); // capture probe sees GONE
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, CONFIRM_MS);
    await tick(worker, CONFIRM_MS);

    expect(repos.outbox.all()).toHaveLength(0);
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('MONITORING');
    expect(stored?.confirmationCount).toBe(0);
    expect(stored?.confirmedAtUtc).toBeNull();
    expect(stored?.screenshotStatus).toBe('NONE');
    expect(stored?.nextCheckAtUtc).not.toBeNull();
  });

  it('an INCONCLUSIVE capture probe keeps the confirmation (only GONE cancels it)', async () => {
    // UNKNOWN at capture time means we could not SEE the page — a throttled egress or a browser
    // hiccup. That is no evidence about the account, so it must not discard three already-verified
    // consecutive ACTIVE checks. Previously it cancelled, restarting the whole cycle and (on a
    // flaky proxy) postponing a real recovery indefinitely.
    const c = await seedCase();
    detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN');
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, CONFIRM_MS);
    await tick(worker, CONFIRM_MS);

    // The recovery still goes out (text-only, since no screenshot was obtainable)...
    const items = repos.outbox.all();
    expect(items).toHaveLength(1);
    expect(items[0]?.kind).toBe('RECOVERY_TEXT');
    // ...and the case was NOT reverted to MONITORING.
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('NOTIFYING');
  });

  it('a GONE capture probe DOES cancel the confirmation (a real contradiction)', async () => {
    const c = await seedCase();
    detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', 'GONE');
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, CONFIRM_MS);
    await tick(worker, CONFIRM_MS);

    expect(repos.outbox.all()).toHaveLength(0); // no alert for an account that went away
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('MONITORING');
    expect(stored?.confirmationCount).toBe(0);
  });

  it('technical screenshot failure x3 falls back to RECOVERY_TEXT with screenshotStatus FAILED', async () => {
    const c = await seedCase();
    // Confirmation ACTIVEs, then three capture attempts: ACTIVE but no screenshot.
    detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', { classification: 'ACTIVE' });
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, CONFIRM_MS);
    await tick(worker, CONFIRM_MS);

    const items = repos.outbox.all();
    expect(items).toHaveLength(1);
    expect(items[0]?.kind).toBe('RECOVERY_TEXT');

    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('NOTIFYING');
    expect(stored?.screenshotStatus).toBe('FAILED');
    // 3 confirmation probes + 3 capture attempts. The attempts share ONE overall time budget
    // (SCREENSHOT_BUDGET_MS) so they cannot delay the alert indefinitely on a slow egress, while
    // still giving a genuinely failing capture several chances before it is handed off to the
    // slower re-capture sweep.
    expect(detector.probes).toHaveLength(6);
    expect(detector.probes[3]?.options?.captureScreenshot).toBe(true);
    expect(detector.probes[5]?.options?.captureScreenshot).toBe(true);
  });

  it('a capture the egress refused does not burn the retry attempts', async () => {
    // While the fleet-wide circuit breaker is OPEN, TieredDetector answers UNKNOWN/HTTP_429
    // instantly WITHOUT touching the network. Treating that like an ordinary capture miss meant
    // all three attempts and the whole 30s budget were spent in ~1.5s of sleeps, producing
    // nothing — and a throttled IP is exactly when a capture is most likely to be refused.
    const c = await seedCase();
    detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', {
      classification: 'UNKNOWN',
      errorCode: 'HTTP_429',
    });
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, CONFIRM_MS);
    await tick(worker, CONFIRM_MS);

    // 3 confirmation probes + exactly ONE capture attempt: repeating a request that never left
    // the process cannot produce a different answer.
    expect(detector.probes).toHaveLength(4);

    // The alert still goes out promptly — the client is not made to wait for an image.
    const items = repos.outbox.all();
    expect(items).toHaveLength(1);
    expect(items[0]?.kind).toBe('RECOVERY_TEXT');
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('NOTIFYING');
    // FAILED is what hands the picture to the re-capture sweep.
    expect(stored?.screenshotStatus).toBe('FAILED');
  });

  describe('screenshot re-capture sweep', () => {
    /** A recovery already delivered text-only: the client is still owed the proof image. */
    function owedScreenshot(): Partial<MonitoringCase> {
      return {
        status: 'NOTIFIED',
        screenshotStatus: 'FAILED',
        confirmedAtUtc: BASE_ISO,
        notificationSentAtUtc: BASE_ISO,
        telegramMessageId: 1000,
        nextCheckAtUtc: null,
        updatedAtUtc: BASE_ISO,
      };
    }

    it('re-takes the picture and queues the follow-up', async () => {
      const c = await seedCase(owedScreenshot());
      detector.script(USER, { classification: 'ACTIVE', screenshot: FAKE_PNG });
      const worker = makeWorker();

      await tick(worker, 6 * 60_000); // past the per-case spacing

      // PRODUCTION code wrote this file. Nothing in this test creates one — that was the whole
      // defect: SCREENSHOT_FOLLOWUP only ever READ a file, and the one-shot `confirmed` edge was
      // the only writer that had ever existed, so a missed capture stayed missed forever.
      const file = await readFile(join(dir, `${c.id}.png`));
      expect(file.equals(FAKE_PNG)).toBe(true);
      expect(detector.probes).toHaveLength(1);
      expect(detector.probes[0]?.options?.captureScreenshot).toBe(true);
      // The sweep runs INLINE in `runOnce`, and a run in flight skips every tick, so it must
      // hand the detector a bounded paint budget rather than let it inherit the capture
      // module's 120s ceiling. Bounding only the outer deadline would not do: `withDeadline`
      // does not cancel, so an abandoned poll keeps a browser page and a concurrency slot.
      const budget = detector.probes[0]?.options?.paintBudgetMs;
      expect(budget).toBeGreaterThan(0);
      expect(budget).toBeLessThan(60_000);

      expect((await repos.cases.findById(c.id))?.screenshotStatus).toBe('CAPTURED');
      const items = repos.outbox.all();
      expect(items).toHaveLength(1);
      expect(items[0]?.kind).toBe('SCREENSHOT_FOLLOWUP');
      expect(items[0]?.status).toBe('PENDING');
    });

    it('spaces attempts and abandons them after the window, so it cannot burn the IP', async () => {
      await seedCase(owedScreenshot());
      detector.script(USER, { classification: 'UNKNOWN', errorCode: 'HTTP_429' });
      const worker = makeWorker();

      await tick(worker, 6 * 60_000); // 1st attempt: still throttled, nothing captured
      expect(detector.probes).toHaveLength(1);

      await tick(worker, 60_000); // sweep not due yet
      expect(detector.probes).toHaveLength(1);

      await tick(worker, 5 * 60_000); // sweep due, and the case is past its spacing
      expect(detector.probes).toHaveLength(2);

      // Two hours after the alert the proof is no longer chased at all.
      await tick(worker, 2 * 60 * 60 * 1000);
      expect(detector.probes).toHaveLength(2);
      expect(repos.outbox.all()).toHaveLength(0);
    });

    /**
     * A detector that reports a browser-load budget AND honours it exactly as {@link TieredDetector}
     * does: a ROUTINE probe once total consumption has reached the routine allowance is DEFERRED —
     * `admit` refuses, no Chromium load is issued, and the caller gets UNKNOWN/HTTP_429 with
     * `screenshot: null`. Reproducing the collaborator faithfully is the point; the code under test
     * is the sweep's pre-flight guard.
     */
    class GovernedDetector extends FakeDetector {
      budget: NonNullable<FastTierReport['browserBudget']> = {
        capacity: 120,
        routineAllowance: 90,
        windowMs: 3_600_000,
        used: 0,
        routineUsed: 0,
        deferred: 0,
        intervalMultiplier: 1,
        escalationStreak: 0,
        storm: false,
        throttling: false,
        overCapacity: false,
        reason: 'no throttling',
      };

      breakerSnapshot(): { state: BreakerState; consecutive: number; retryAfterMs: number } {
        return { state: 'CLOSED', consecutive: 0, retryAfterMs: 0 };
      }

      browserBudget(): FastTierReport['browserBudget'] {
        return this.budget;
      }

      fastTierReport(): Promise<FastTierReport> {
        throw new Error('the re-capture sweep must never pay for a fast-tier report');
      }

      override async probe(username: string, options?: ProbeOptions): Promise<ProbeResult> {
        const priority = (options as TieredProbeOptions | undefined)?.loadPriority;
        if (priority === 'ROUTINE' && this.budget.used >= this.budget.routineAllowance) {
          this.probes.push({ username, options });
          return {
            result: {
              classification: 'UNKNOWN',
              evidence: {
                signalsVersion: SIGNALS_VERSION,
                activeSignals: [],
                goneSignals: [],
                identitySignalMatched: false,
                finalUrl: null,
                responseStatus: null,
                errorCode: 'HTTP_429',
              },
              durationMs: 0,
            },
            screenshot: null,
          };
        }
        return super.probe(username, options);
      }
    }

    it('REGRESSION: a spent routine browser-load allowance does not burn the case attempt', async () => {
      // The breaker guard above this exists so a probe the fleet will REFUSE cannot spend a case's
      // durable spacer — but it was never extended to the browser-load GOVERNOR, which refuses this
      // sweep's ROUTINE probe once the routine allowance is gone. The two conditions are POSITIVELY
      // correlated: a degraded egress both causes the capture miss that puts a case here and drains
      // the routine allowance, because every fast negative then escalates to a browser load. So the
      // sweep wrote `updatedAtUtc = now`, got `screenshot: null` back having issued ZERO page loads,
      // logged "came back empty", and repeated that until all ~24 attempts inside
      // RECAPTURE_WINDOW_MS were gone — the paying client's proof lost for good without the
      // residential IP ever being touched, and with the priority reserve still untouched too.
      const c = await seedCase(owedScreenshot());
      const starved = new GovernedDetector();
      starved.script(USER, { classification: 'ACTIVE', screenshot: FAKE_PNG });
      starved.budget = { ...starved.budget, used: 90 }; // routine allowance fully consumed
      const worker = new MonitorWorker({
        repos,
        detector: starved,
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        rand,
        screenshotDir: dir,
        sleep: instantSleep,
      });

      await tick(worker, 6 * 60_000); // past the per-case spacing: the sweep would take the slot

      // Nothing was probed, and — the part that matters — the case's DURABLE spacer is untouched,
      // so none of its bounded attempts was spent on an attempt that could never have happened.
      expect(starved.probes).toHaveLength(0);
      expect((await repos.cases.findById(c.id))?.updatedAtUtc).toBe(BASE_ISO);
      expect((await repos.cases.findById(c.id))?.screenshotStatus).toBe('FAILED');

      // The rolling window frees up; the very next sweep still has its attempt and gets the proof.
      starved.budget = { ...starved.budget, used: 10 };
      await tick(worker, 5 * 60_000);

      expect(starved.probes).toHaveLength(1);
      expect((await repos.cases.findById(c.id))?.screenshotStatus).toBe('CAPTURED');
      expect(repos.outbox.all()[0]?.kind).toBe('SCREENSHOT_FOLLOWUP');
    });

    it('gives up on a capture that never returns, but only ABOVE what its own budgets allow', async () => {
      // The backstop exists for a capture that is genuinely wedged — `page.evaluate` is not
      // covered by `setDefaultTimeout`, so a stuck renderer can outlive the paint poll. It must
      // sit clear of every budget the probe was actually handed (85s goto + 8s settle + 45s paint
      // + dismissal + a 5s paint re-check + an 11.25s header-image wait = 159.25s), because
      // `withDeadline` does not cancel: firing early does not save the page load, it only throws
      // away one the residential IP has already been charged for and leaves the abandoned probe
      // holding a capture lane. The previous 90s could not clear even the page load.
      await seedCase(owedScreenshot());
      const hanging = new HangingDetector();
      const worker = new MonitorWorker({
        repos,
        detector: hanging,
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        rand,
        screenshotDir: dir,
        sleep: instantSleep,
      });

      vi.useFakeTimers();
      try {
        clock.advanceMs(6 * 60_000); // past the per-case spacing, so the sweep takes the slot
        const run = worker.runOnce();
        let finished = false;
        void run.then(() => {
          finished = true;
        });

        // The capture is genuinely under way. Past 155s — beyond the sum of every inner budget —
        // so the backstop is provably not cutting off a capture that was still making progress.
        await vi.advanceTimersByTimeAsync(155_000);
        expect(hanging.calls).toBe(1);
        expect(finished).toBe(false);

        // ...and it does eventually let go, so a wedged renderer cannot leak a sweep forever.
        await vi.advanceTimersByTimeAsync(15_000);
        expect(finished).toBe(true);
        await run;
      } finally {
        vi.useRealTimers();
      }
    });

    it('re-captures a profile as slow as the production one, instead of cutting it off mid-load', async () => {
      // @trymaven on the production VPS through the mobile proxy, cold: 76.6s to
      // domcontentloaded, text paint 30.1s after the settle wait that follows it. That is not an
      // exotic profile — it is the ONLY kind this sweep is ever handed, because a fast profile
      // never misses its capture on the confirmed edge in the first place.
      //
      // The sweep used to wrap the probe in a 90s deadline while the probe's own page load was
      // allowed 120s + 8s. The deadline therefore fired MID-`goto`, every time, for the whole
      // 2-hour window: ~24 real Chromium page loads charged against the single residential IP,
      // ~24 durable spacers spent, and the paying client never received the proof that is the
      // product.
      const c = await seedCase(owedScreenshot());
      const slow = new SlowProfileDetector(76_600, 30_100);
      const worker = new MonitorWorker({
        repos,
        detector: slow,
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        rand,
        screenshotDir: dir,
        sleep: instantSleep,
      });

      clock.advanceMs(6 * 60_000); // past the per-case spacing, so the sweep takes the slot
      vi.useFakeTimers();
      const run = worker.runOnce();
      try {
        await vi.advanceTimersByTimeAsync(160_000);
      } finally {
        vi.useRealTimers();
      }
      await run;

      // The navigation ceiling the sweep hands the probe has to be one its OWN deadline can
      // outlive. Asserting the delivered file alone would not pin that down: this is the term
      // that was taken from a global constant instead of from the sweep's budget.
      const options = slow.probes[0]?.options;
      expect(options?.captureScreenshot).toBe(true);
      expect(options?.captureNavBudgetMs).toBeGreaterThan(76_600);

      // PRODUCTION code wrote this file — nothing in this test creates one.
      const file = await readFile(join(dir, `${c.id}.png`));
      expect(file.equals(FAKE_PNG)).toBe(true);
      expect((await repos.cases.findById(c.id))?.screenshotStatus).toBe('CAPTURED');
      const items = repos.outbox.all();
      expect(items).toHaveLength(1);
      expect(items[0]?.kind).toBe('SCREENSHOT_FOLLOWUP');
    });

    it('keeps claiming and checking other cases while a slow re-capture is in flight', async () => {
      // The sweep re-loads a profile ALREADY KNOWN to be slow, and it used to be awaited inside
      // the scheduling pass — before `claimDueCases`, with `start()` skipping every tick while a
      // pass is in flight. So one client's picture bought a fleet-wide detection blackout for the
      // length of the capture, once every 5 minutes for 2 hours. Any OTHER account that recovered
      // during it was not looked at: harm rank 1, at scale, to chase one image.
      await seedCase(owedScreenshot());
      await repos.cases.create(
        {
          normalizedUsername: OTHER_USER,
          originalInput: OTHER_USER,
          startedAtUtc: BASE_ISO,
          nextCheckAtUtc: BASE_ISO,
        },
        BASE_ISO,
      );
      const slow = new SlowProfileDetector(76_600, 30_100);
      slow.script(OTHER_USER, 'GONE');
      const worker = new MonitorWorker({
        repos,
        detector: slow,
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        rand,
        screenshotDir: dir,
        sleep: instantSleep,
      });

      clock.advanceMs(6 * 60_000);
      vi.useFakeTimers();
      try {
        worker.start(1000);
        // A few ticks: nowhere near enough for a 114.7s capture to have finished.
        await vi.advanceTimersByTimeAsync(5_000);

        const captures = slow.probes.filter((p) => p.options?.captureScreenshot === true);
        const routine = slow.probes.filter((p) => p.username === OTHER_USER);
        expect(captures).toHaveLength(1); // the re-capture really is under way...
        expect(routine.length).toBeGreaterThan(0); // ...and the fleet is still being checked

        // Let the abandoned-timer state unwind cleanly rather than leaving work mid-flight.
        await vi.advanceTimersByTimeAsync(200_000);
        await worker.stop();
      } finally {
        vi.useRealTimers();
      }
    });

    it('spends no attempt while the egress breaker is open', async () => {
      // A breaker-refused probe never leaves the process, so it can neither take the picture nor
      // teach us anything — but bumping `updatedAtUtc` for it charged the case a 5-minute slot out
      // of its bounded 2-hour window. The breaker being open is precisely the condition that made
      // the proof go missing in the first place, so that spent the whole window on nothing.
      const blocked = new BreakerOpenDetector();
      const c = await seedCase(owedScreenshot());
      blocked.script(USER, { classification: 'ACTIVE', screenshot: FAKE_PNG });
      const worker = new MonitorWorker({
        repos,
        detector: blocked,
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        rand,
        screenshotDir: dir,
        sleep: instantSleep,
      });

      await tick(worker, 6 * 60_000);

      expect(blocked.probes).toHaveLength(0);
      // The slot is intact, so the first sweep after the breaker closes can still take the picture.
      expect((await repos.cases.findById(c.id))?.updatedAtUtc).toBe(BASE_ISO);
    });

    it('hands the slot round, so an uncapturable case never starves the others', async () => {
      // Two clients downgraded to text-only by the SAME fleet-wide throttle — the normal shape
      // here, since a throttle is fleet-wide. Nothing below manufactures the "owed proof" state:
      // the monitor confirms both recoveries and the outbox delivers both alerts, as in production.
      const older = await repos.cases.create(
        {
          normalizedUsername: 'olduser',
          originalInput: 'olduser',
          startedAtUtc: BASE_ISO,
          nextCheckAtUtc: BASE_ISO,
        },
        BASE_ISO,
      );
      const newer = await repos.cases.create(
        {
          normalizedUsername: 'newuser',
          originalInput: 'newuser',
          startedAtUtc: BASE_ISO,
          nextCheckAtUtc: BASE_ISO,
        },
        BASE_ISO,
      );
      for (const username of ['olduser', 'newuser']) {
        detector.script(username, 'ACTIVE', 'ACTIVE', 'ACTIVE', {
          classification: 'UNKNOWN',
          errorCode: 'HTTP_429',
        });
      }
      const monitor = new MonitorWorker({
        repos,
        detector,
        config: makeTestConfig({ maxBrowserConcurrency: 2 }),
        clock,
        logger: nullLogger(),
        rand,
        screenshotDir: dir,
        sleep: instantSleep,
      });
      const outbox = new OutboxWorker({
        repos,
        client: new MockTelegramClient(),
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        ownerChatId: async (): Promise<number | null> => 777,
        screenshotDir: dir,
      });

      for (let i = 0; i < 3; i++) await tick(monitor, CONFIRM_MS);
      await outbox.runOnce(); // older case: text-only recovery
      clock.advanceMs(1000);
      await outbox.runOnce(); // newer case: text-only recovery

      // The older profile is behind a login wall: ACTIVE by identity, but nothing renders, so its
      // capture can never succeed. It used to win the sweep on every single pass — the per-case
      // spacer expires exactly as often as the sweep runs — for the whole 2-hour window.
      detector.script('olduser', { classification: 'ACTIVE' });
      detector.script('newuser', { classification: 'ACTIVE', screenshot: FAKE_PNG });

      await tick(monitor, 6 * 60_000); // sweep 1 -> the older case
      await tick(monitor, 5 * 60_000 + 1000); // sweep 2 -> the newer case

      const file = await readFile(join(dir, `${newer.id}.png`));
      expect(file.equals(FAKE_PNG)).toBe(true);
      expect((await repos.cases.findById(newer.id))?.screenshotStatus).toBe('CAPTURED');
      expect(
        repos.outbox
          .all()
          .filter((i) => i.kind === 'SCREENSHOT_FOLLOWUP')
          .map((i) => i.caseId),
      ).toEqual([newer.id]);
      // The older case was tried first and is still owed — it simply no longer hogs every slot.
      expect((await repos.cases.findById(older.id))?.screenshotStatus).toBe('FAILED');
    });

    it('never chases a restricted profile — there is nothing viewable to capture', async () => {
      await seedCase({ ...owedScreenshot(), screenshotStatus: 'RESTRICTED' });
      const worker = makeWorker();

      await tick(worker, 6 * 60_000);

      expect(detector.probes).toHaveLength(0);
      expect(repos.outbox.all()).toHaveLength(0);
    });
  });

  // --- browser loads per recovery -----------------------------------------------------------
  // Three consecutive ACTIVE checks each bought their own Chromium page load (20-50 requests,
  // ~8s) to re-read evidence the cheap tier had already read correctly. Only the check that can
  // CONFIRM needs that verdict — and it still gets one, plus a second on the capture probe.

  /** What the worker told the detector about check `i`. */
  function allowedFastActive(i: number): boolean | undefined {
    return (detector.probes[i]?.options as TieredProbeOptions | undefined)?.allowFastActive;
  }

  it('only the DECIDING confirmation asks for a browser verdict', async () => {
    await seedCase();
    detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', {
      classification: 'ACTIVE',
      screenshot: FAKE_PNG,
    });
    const worker = makeWorker();

    await tick(worker, 0); // confirmation 1/3
    await tick(worker, CONFIRM_MS); // confirmation 2/3
    await tick(worker, CONFIRM_MS); // confirmation 3/3 -> CONFIRMED

    expect(allowedFastActive(0)).toBe(true);
    expect(allowedFastActive(1)).toBe(true);
    // The one that confirms must NOT be allowed to stand on the cheap tier...
    expect(allowedFastActive(2)).toBeUndefined();
    // ...and the capture probe on top of it is a second browser verdict.
    expect(detector.probes[3]?.options?.captureScreenshot).toBe(true);
  });

  it('with a single required confirmation the FIRST check is the deciding one', async () => {
    // The edge that would silently let an alert rest on fast-tier evidence alone: with
    // CONFIRMATION_REQUIRED_COUNT=1 the baseline check confirms outright.
    await seedCase();
    detector.script(USER, { classification: 'ACTIVE', screenshot: FAKE_PNG });
    const worker = new MonitorWorker({
      repos,
      detector,
      config: makeTestConfig({ confirmationRequiredCount: 1 }),
      clock,
      logger: nullLogger(),
      rand,
      screenshotDir: dir,
      sleep: instantSleep,
    });

    await tick(worker, 0);

    expect(allowedFastActive(0)).toBeUndefined();
    expect(repos.outbox.all()).toHaveLength(1);
  });

  // --- confirmation deadline: burst-scoped, not gap-scoped ------------------------------------

  it('a slow confirmation leg no longer discards its OWN ACTIVE result', async () => {
    // THE PRODUCTION BUG. The deadline compared post-probe `now` against the PREVIOUS check's
    // timestamp, so the gap included this check's own duration. A browser confirmation leg
    // measured 85-96s through the mobile proxy against a 30s deadline, so on that route a
    // genuine recovery was thrown away and the case re-armed at a fresh baseline — forever.
    const c = await seedCase({
      status: 'CONFIRMING',
      confirmationCount: 1,
      lastCheckedAtUtc: BASE_ISO,
      nextCheckAtUtc: new Date(new Date(BASE_ISO).getTime() + CONFIRM_MS).toISOString(),
    });
    detector.script(USER, {
      classification: 'ACTIVE',
      onProbe: (): void => {
        clock.advanceMs(90_000); // the slow browser leg, inside the probe
      },
    });
    const worker = makeWorker(); // confirmationDeadlineSeconds: 30

    await tick(worker, CONFIRM_MS);

    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('CONFIRMING');
    expect(stored?.confirmationCount).toBe(2);
  });

  it('the deadline bounds the WHOLE burst, so a stuck one still terminates', async () => {
    // The other half: burst-scoping must not become an unbounded confirmation. Two gaps that are
    // each comfortably inside the deadline still exhaust it together, and the case is handed back
    // to baseline monitoring rather than left confirming forever.
    await seedCase();
    detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', 'ACTIVE', 'ACTIVE');
    const worker = new MonitorWorker({
      repos,
      detector,
      // 5 required so the burst cannot simply finish; 30s deadline as today.
      config: makeTestConfig({ confirmationRequiredCount: 5, confirmationDeadlineSeconds: 30 }),
      clock,
      logger: nullLogger(),
      rand,
      screenshotDir: dir,
      sleep: instantSleep,
    });

    await tick(worker, 0); // burst begins: 1/5
    await tick(worker, 20_000); // 20s in — under the deadline: 2/5
    await tick(worker, 20_000); // 40s in — the BURST is over budget

    const all = await repos.cases.listByStatuses(['MONITORING']);
    expect(all).toHaveLength(1);
    expect(all[0]?.confirmationCount).toBe(0);
    expect(all[0]?.nextCheckAtUtc).not.toBeNull(); // re-armed, not wedged
    expect(repos.outbox.all()).toHaveLength(0);
  });

  it('a fresh burst gets a full deadline, never the spent one from the burst before it', async () => {
    // The leak the burst clock could introduce: if the window survived the burst that opened it,
    // the NEXT recovery attempt for the same case would be abandoned on its first check.
    const c = await seedCase();
    detector.script(
      USER,
      'ACTIVE', // burst 1 starts
      'GONE', // ...and is reset back to baseline
      'ACTIVE', // burst 2 starts, long after burst 1's window would have expired
      'ACTIVE',
      { classification: 'ACTIVE', screenshot: FAKE_PNG },
    );
    const worker = makeWorker(); // 30s deadline

    await tick(worker, 0);
    await tick(worker, CONFIRM_MS);
    await tick(worker, BASELINE_MS); // 65s after burst 1 opened
    await tick(worker, CONFIRM_MS);
    await tick(worker, CONFIRM_MS);

    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('NOTIFYING');
    expect(repos.outbox.all()).toHaveLength(1);
  });

  // --- the confirmed-edge capture must not hold the tick -----------------------------------------

  /**
   * Drive a case to its DECIDING confirmation check and then wedge the capture that follows.
   * `onProbe` never resolving is the real shape: a profile whose header does not satisfy the paint
   * predicate (measured at 96.4s on `trymaven`) inside a capture budget of 150s.
   */
  async function seedWedgedCapture(): Promise<MonitoringCase> {
    const recovering = await seedCase({ status: 'CONFIRMING', confirmationCount: 2 });
    detector.script(
      USER,
      'ACTIVE', // the deciding check: confirms the recovery
      {
        classification: 'ACTIVE',
        screenshot: FAKE_PNG,
        onProbe: (): Promise<void> => new Promise<void>(() => undefined), // the capture wedges
      },
    );
    return recovering;
  }

  it('a wedged confirmed capture no longer freezes the checks of every other client', async () => {
    // SCREENSHOT_BUDGET_MS is 150s so a slow-painting profile still yields the proof the client
    // pays for. Awaited inside the tick that decides the confirmation — and `start()` skips every
    // tick while one is in flight — that ceiling was charged to the WHOLE fleet: for up to 2.5
    // minutes no case was claimed and no Instagram check performed, so an account that recovered
    // during the window was not even looked at. One client's picture must not blind the others.
    await seedWedgedCapture();
    const other = await repos.cases.create(
      {
        normalizedUsername: 'otheruser',
        originalInput: 'otheruser',
        startedAtUtc: BASE_ISO,
        nextCheckAtUtc: BASE_ISO,
      },
      BASE_ISO,
    );
    detector.script('otheruser', 'GONE');
    const worker = makeWorker(); // maxBrowserConcurrency 1: one claimed case per tick

    vi.useFakeTimers();
    try {
      worker.start(1000);
      // Tick 1 claims the CONFIRMING case (claimDueCases orders those first), confirms it, and
      // starts the capture that never returns.
      await vi.advanceTimersByTimeAsync(1000);
      expect(await repos.checks.countByCase(other.id)).toBe(0);

      // Several further ticks while the capture is still wedged.
      await vi.advanceTimersByTimeAsync(4000);

      expect(detector.probes.some((p) => p.username === 'otheruser')).toBe(true);
      expect(await repos.checks.countByCase(other.id)).toBeGreaterThan(0);
    } finally {
      vi.useRealTimers(); // discards the fake interval; the wedged capture never settles
    }
  });

  it('the stranded sweep never double-alerts a case whose capture is still running', async () => {
    // The hazard that moving the capture off the tick introduces, and the reason the in-flight map
    // exists. The 60s stranded sweep looks for CONFIRMED cases with no outbox row — which is
    // exactly what a case mid-capture looks like. Enqueuing RECOVERY_TEXT there would sit BESIDE
    // the RECOVERY_PHOTO the capture is about to enqueue: different kinds, so the outbox's
    // (case_id, kind) uniqueness does not collapse them and the client is told twice.
    const recovering = await seedWedgedCapture();
    const worker = makeWorker();

    vi.useFakeTimers();
    try {
      worker.start(1000);
      await vi.advanceTimersByTimeAsync(1000); // confirm; capture starts and wedges
      expect((await repos.cases.findById(recovering.id))?.status).toBe('CONFIRMED');

      clock.advanceMs(60_000); // the stranded sweep is now due on the next tick
      await vi.advanceTimersByTimeAsync(2000);

      expect(repos.outbox.all()).toHaveLength(0);
      expect((await repos.cases.findById(recovering.id))?.status).toBe('CONFIRMED');
    } finally {
      vi.useRealTimers();
    }
  });

  it('an off-tick capture never writes its expired lease back onto the case', async () => {
    // Ordering trap created by moving the capture off the tick. `runSchedulingPass` releases the
    // lease in its `finally` — which NOW runs BEFORE the capture's own save, not after it. The
    // capture writes a snapshot taken while the lease was still held, so a naive detach resurrects
    // a lease owned by nobody. On the cancellation path that snapshot goes back to MONITORING
    // carrying it, and `claimDueCases` skips any row whose lease has not expired: the case would
    // be invisible to the scheduler for the remainder of the lease even though its next check is
    // due sooner. A recovery delayed by a bookkeeping artefact is the one outcome that matters.
    const c = await seedCase({ status: 'CONFIRMING', confirmationCount: 2 });
    detector.script(USER, 'ACTIVE', { classification: 'ACTIVE', screenshot: FAKE_PNG });
    const worker = makeWorker();

    await tick(worker, 0);

    const notifying = await repos.cases.findById(c.id);
    expect(notifying?.status).toBe('NOTIFYING');
    expect(notifying?.leaseOwner).toBeNull();
    expect(notifying?.leaseExpiresAtUtc).toBeNull();
  });

  it('a cancelled off-tick capture hands the case back with no lease holding it down', async () => {
    // Same trap, on the path that matters more: GONE at capture time reverts to MONITORING, and a
    // resurrected lease there would suppress the next scheduled check outright.
    const c = await seedCase({ status: 'CONFIRMING', confirmationCount: 2 });
    detector.script(USER, 'ACTIVE', 'GONE'); // deciding check confirms; the capture contradicts it
    const worker = makeWorker();

    await tick(worker, 0);

    const reverted = await repos.cases.findById(c.id);
    expect(reverted?.status).toBe('MONITORING');
    expect(reverted?.leaseOwner).toBeNull();
    expect(reverted?.leaseExpiresAtUtc).toBeNull();
    expect(repos.outbox.all()).toHaveLength(0);
  });

  it('two workers running simultaneously process the same due case exactly once', async () => {
    const c = await seedCase();
    detector.script(USER, 'ACTIVE');
    const w1 = makeWorker('w1');
    const w2 = makeWorker('w2');

    await Promise.all([w1.runOnce(), w2.runOnce()]);

    expect(detector.probes).toHaveLength(1); // lease blocked the second worker
    expect(await repos.checks.countByCase(c.id)).toBe(1);
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('CONFIRMING');
    expect(stored?.confirmationCount).toBe(1);
  });

  it('routine UNKNOWN x3 lands in UNKNOWN_BACKOFF with a future retry and no outbox', async () => {
    const c = await seedCase();
    detector.script(USER, 'UNKNOWN', 'UNKNOWN', 'UNKNOWN');
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, BASELINE_MS);
    await tick(worker, BASELINE_MS);

    expect(repos.outbox.all()).toHaveLength(0);
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('UNKNOWN_BACKOFF');
    expect(stored?.consecutiveUnknownCount).toBe(3);
    expect(stored?.errorBackoffUntilUtc).not.toBeNull();
    expect(new Date(stored?.errorBackoffUntilUtc ?? 0).getTime()).toBeGreaterThan(clock.nowMs());

    // Health EMA rolled toward 1 across three UNKNOWN checks: 0.2, 0.36, 0.488.
    const health = await repos.health.get('scheduler');
    expect(health?.recentUnknownRate).toBeCloseTo(0.488, 5);
    expect(health?.lastSchedulerRunUtc).toBe(clock.now().toISOString());
  });

  // REGRESSION 2026-08-05: a check the fleet DECLINED to make must move nothing in the health
  // rate. Breaker-open and governor-deferred probes come back UNKNOWN/HTTP_429 without touching
  // the network; counting them inverted the meaning of the rate — the harder the fleet protected
  // the IP, the more "degraded" it declared itself — producing WARNING/RESTORED cycles all night
  // over a fleet whose real checks were clean, with browser loads sitting at 16/160 precisely
  // BECAUSE nothing was being loaded.
  it('breaker-blocked / deferred checks do NOT move the unknown-rate EMA', async () => {
    await seedCase();
    detector.script(
      USER,
      { classification: 'UNKNOWN', errorCode: 'HTTP_429', notObserved: true },
      { classification: 'UNKNOWN', errorCode: 'HTTP_429', notObserved: true },
      { classification: 'UNKNOWN', errorCode: 'HTTP_429', notObserved: true },
    );
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, BASELINE_MS);
    await tick(worker, BASELINE_MS);

    const health = await repos.health.get('scheduler');
    // Untouched — NOT rolled to 0.488 the way three real UNKNOWNs would.
    expect(health?.recentUnknownRate ?? 0).toBe(0);
  });

  it('a REAL unknown still moves the rate, so genuine outages are never masked', async () => {
    await seedCase();
    detector.script(
      USER,
      { classification: 'UNKNOWN', errorCode: 'HTTP_429', notObserved: true }, // declined
      'UNKNOWN', // genuinely observed and unreadable
    );
    const worker = makeWorker();

    await tick(worker, 0);
    await tick(worker, BASELINE_MS);

    const health = await repos.health.get('scheduler');
    expect(health?.recentUnknownRate).toBeCloseTo(0.2, 5); // exactly one real UNKNOWN counted
  });

  it('retryable browser timeout x3 lands in ERROR_BACKOFF with a finite retry time', async () => {
    const worker = makeWorker();
    const c = await seedCase();
    detector.script(
      USER,
      { classification: 'UNKNOWN', errorCode: 'TIMEOUT' },
      { classification: 'UNKNOWN', errorCode: 'TIMEOUT' },
      { classification: 'UNKNOWN', errorCode: 'TIMEOUT' },
    );

    await worker.runOnce();
    clock.advanceMs(60_000);
    await worker.runOnce();
    clock.advanceMs(60_000);
    await worker.runOnce();

    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('ERROR_BACKOFF');
    expect(stored?.nextCheckAtUtc).not.toBeNull();
    expect(new Date(stored?.nextCheckAtUtc ?? 0).getTime()).toBeGreaterThan(clock.nowMs());
  });

  describe('stranded-notification sweep', () => {
    /** A case parked mid-notification: never checked again, and no alert delivered yet. */
    function strandedCase(): Partial<MonitoringCase> {
      return {
        status: 'NOTIFYING',
        screenshotStatus: 'CAPTURED',
        confirmedAtUtc: BASE_ISO,
        nextCheckAtUtc: null,
      };
    }

    function sweepingWorker(): { worker: MonitorWorker; rescues: number } {
      const state = { rescues: 0 };
      const logger = {
        ...nullLogger(),
        warn: (msg: string): void => {
          if (msg.includes('stranded notification')) state.rescues += 1;
        },
      };
      const worker = new MonitorWorker({
        repos,
        detector,
        config: makeTestConfig(),
        clock,
        logger,
        rand,
        screenshotDir: dir,
        sleep: instantSleep,
      });
      return {
        worker,
        get rescues(): number {
          return state.rescues;
        },
      };
    }

    it('revives an outbox row that exhausted its attempts', async () => {
      const c = await seedCase(strandedCase());
      const item = await repos.outbox.enqueue({
        caseId: c.id,
        kind: 'RECOVERY_PHOTO',
        createdAtUtc: BASE_ISO,
      });
      await repos.outbox.markFailed(item.id, 'telegram_error:TELEGRAM_ERROR', BASE_ISO);
      const swept = sweepingWorker();

      clock.advanceMs(60_000); // so a refreshed created_at is distinguishable
      await swept.worker.runOnce();

      // `enqueue` alone could never do this: it is ON CONFLICT DO NOTHING, so the exhausted row
      // stayed FAILED while the sweep logged a rescue that never happened, every 60 seconds.
      const revived = repos.outbox.all()[0];
      expect(revived?.status).toBe('PENDING');
      expect(revived?.attempts).toBe(0);
      expect(revived?.lastError).toBeNull();
      expect(revived?.createdAtUtc).toBe(clock.now().toISOString());
      expect(swept.rescues).toBe(1);
    });

    it('enqueues a fresh row for a case that never got one', async () => {
      const c = await seedCase({ ...strandedCase(), screenshotStatus: 'FAILED' });
      const swept = sweepingWorker();

      await swept.worker.runOnce();

      const items = repos.outbox.all();
      expect(items).toHaveLength(1);
      expect(items[0]?.kind).toBe('RECOVERY_TEXT');
      expect(items[0]?.status).toBe('PENDING');
      expect(items[0]?.caseId).toBe(c.id);
    });

    it('never re-sends an alert that already went out, and claims no false rescue', async () => {
      // A crash between `markSent` and the case close-out: the owner HAS the alert.
      const c = await seedCase(strandedCase());
      const item = await repos.outbox.enqueue({
        caseId: c.id,
        kind: 'RECOVERY_PHOTO',
        createdAtUtc: BASE_ISO,
      });
      await repos.outbox.markSent(item.id, BASE_ISO, 4242);
      const swept = sweepingWorker();

      await swept.worker.runOnce();
      clock.advanceMs(60_000);
      await swept.worker.runOnce();

      expect(repos.outbox.all()[0]?.status).toBe('SENT');
      expect(swept.rescues).toBe(0);
    });

    it('repairs a case whose alert went out but whose close-out never ran', async () => {
      // Same crash window as above. Silently skipping it left the case parked in NOTIFYING
      // forever: invisible to /list, never checked again, and still holding the username's
      // active-monitor slot.
      const c = await seedCase(strandedCase());
      const item = await repos.outbox.enqueue({
        caseId: c.id,
        kind: 'RECOVERY_PHOTO',
        createdAtUtc: BASE_ISO,
      });
      await repos.outbox.markSent(item.id, BASE_ISO, 4242);

      await sweepingWorker().worker.runOnce();

      const stored = await repos.cases.findById(c.id);
      expect(stored?.status).toBe('NOTIFIED');
      expect(stored?.notificationSentAtUtc).toBe(BASE_ISO);
      expect(stored?.telegramMessageId).toBe(4242);
      expect(stored?.screenshotStatus).toBe('SENT');
      // A repair, not a re-send: the delivered row is untouched.
      expect(repos.outbox.all()[0]?.status).toBe('SENT');
    });

    it('leaves an in-flight row alone and claims no rescue', async () => {
      const c = await seedCase(strandedCase());
      await repos.outbox.enqueue({
        caseId: c.id,
        kind: 'RECOVERY_PHOTO',
        createdAtUtc: BASE_ISO,
      });
      const swept = sweepingWorker();

      await swept.worker.runOnce();

      expect(repos.outbox.all()[0]?.status).toBe('PENDING');
      expect(swept.rescues).toBe(0);
    });

    it('never resurrects a cleared case', async () => {
      // Both shapes: a fully cleared case, and a torn one still labelled NOTIFYING.
      const cleared = await seedCase({
        ...strandedCase(),
        status: 'CLEARED',
        clearedAtUtc: BASE_ISO,
      });
      const torn = await seedCase({ ...strandedCase(), clearedAtUtc: BASE_ISO });
      for (const c of [cleared, torn]) {
        const item = await repos.outbox.enqueue({
          caseId: c.id,
          kind: 'RECOVERY_PHOTO',
          createdAtUtc: BASE_ISO,
        });
        await repos.outbox.markFailed(item.id, 'case_cleared', BASE_ISO);
      }
      const swept = sweepingWorker();

      await swept.worker.runOnce();

      expect(repos.outbox.all().every((i) => i.status === 'FAILED')).toBe(true);
      expect(swept.rescues).toBe(0);
    });
  });
});
