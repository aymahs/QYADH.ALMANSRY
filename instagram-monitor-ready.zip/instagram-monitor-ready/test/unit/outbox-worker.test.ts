import { existsSync } from 'node:fs';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type {
  BusinessDeliveryStatus,
  MonitoringCase,
  OutboxKind,
  SendMessageParams,
  SendPhotoParams,
  SentMessage,
  TelegramClient,
} from '../../src/domain';
import { AppError, FixedClock } from '../../src/domain';
import type { DiscordNotifier } from '../../src/bot/discord/discord-notifier';
import { nullLogger } from '../../src/logging';
import { HttpTelegramClient } from '../../src/bot/telegram-client/http-client';
import { MockTelegramClient } from '../../src/bot/telegram-client/mock-client';
import { SqliteDatabase } from '../../src/persistence/sqlite-database';
import { MonitorWorker } from '../../src/monitoring/scheduler';
import { recoveryCaption, recoveryTextFallback } from '../../src/notifications/formatter';
import { OutboxWorker } from '../../src/notifications/outbox';
import {
  FAKE_PNG,
  FakeDetector,
  InMemoryRepositories,
  instantSleep,
  makeTestConfig,
} from '../helpers/worker-fakes';

const BASE_ISO = '2026-07-17T00:00:00.000Z';
const CONFIRMED_ISO = '2026-07-17T01:00:00.000Z';
const USER = 'someuser';
const OWNER_CHAT_ID = 777;
const TZ = 'Asia/Kolkata';
const ELEVEN_MINUTES_MS = 11 * 60 * 1000;
/** One client-rescue sweep interval, plus a beat. */
const SWEEP_MS = 61 * 1000;
/** Distinctive line of the "deliver this by hand" alert, so it cannot be confused with a recovery. */
const OWNER_ACTION_PING = 'please send them to the client manually';

/**
 * Rejects only the OWNER's captionless reply-photo — exactly what Telegram answers once the
 * message being replied to is gone (owner deleted it, or the bot was re-paired to another chat).
 * Every other send, including the client's proof, succeeds.
 */
class OwnerFollowupFailsClient extends MockTelegramClient {
  override async sendPhoto(params: SendPhotoParams): Promise<SentMessage> {
    if (params.business_connection_id === undefined && params.reply_to_message_id !== undefined) {
      throw new AppError('TELEGRAM_ERROR', 'Bad Request: message to be replied not found');
    }
    return super.sendPhoto(params);
  }
}

/** Lets a test land a /clear in the window between the owner send and the case close-out. */
class ClearingMidSendClient extends MockTelegramClient {
  constructor(private readonly onSend: () => Promise<void>) {
    super();
  }

  override async sendPhoto(params: SendPhotoParams): Promise<SentMessage> {
    await this.onSend();
    return super.sendPhoto(params);
  }
}

describe('OutboxWorker', () => {
  let clock: FixedClock;
  let repos: InMemoryRepositories;
  let client: MockTelegramClient;
  let dir: string;

  beforeEach(async () => {
    clock = new FixedClock(new Date(CONFIRMED_ISO));
    repos = new InMemoryRepositories();
    client = new MockTelegramClient();
    dir = await mkdtemp(join(tmpdir(), 'outbox-worker-'));
  });

  afterEach(async () => {
    await rm(dir, { recursive: true, force: true });
  });

  function makeWorker(telegram: TelegramClient = client): OutboxWorker {
    return new OutboxWorker({
      repos,
      client: telegram,
      config: makeTestConfig(),
      clock,
      logger: nullLogger(),
      ownerChatId: async (): Promise<number | null> => OWNER_CHAT_ID,
      screenshotDir: dir,
      maxAttempts: 3,
    });
  }

  async function seedNotifyingCase(
    overrides: Partial<MonitoringCase> = {},
  ): Promise<MonitoringCase> {
    const created = await repos.cases.create(
      {
        normalizedUsername: USER,
        originalInput: USER,
        startedAtUtc: BASE_ISO,
        nextCheckAtUtc: BASE_ISO,
      },
      BASE_ISO,
    );
    const next: MonitoringCase = {
      ...created,
      status: 'NOTIFYING',
      confirmationCount: 3,
      confirmedAtUtc: CONFIRMED_ISO,
      nextCheckAtUtc: null,
      screenshotStatus: 'CAPTURED',
      ...overrides,
    };
    await repos.cases.save(next);
    return next;
  }

  async function enqueue(caseId: string, kind: OutboxKind): Promise<void> {
    await repos.outbox.enqueue({ caseId, kind, createdAtUtc: clock.now().toISOString() });
  }

  it('happy path RECOVERY_PHOTO: exact caption + button, case NOTIFIED, file deleted, no resend', async () => {
    const c = await seedNotifyingCase();
    const filePath = join(dir, `${c.id}.png`);
    await writeFile(filePath, FAKE_PNG);
    await enqueue(c.id, 'RECOVERY_PHOTO');
    const worker = makeWorker();

    await worker.runOnce();

    expect(client.sentPhotos).toHaveLength(1);
    const photo = client.sentPhotos[0];
    expect(photo?.chat_id).toBe(OWNER_CHAT_ID);
    expect(photo?.photo.equals(FAKE_PNG)).toBe(true);
    expect(photo?.caption).toBe(recoveryCaption(USER, BASE_ISO, CONFIRMED_ISO, TZ));
    expect(photo?.reply_markup?.inline_keyboard[0]?.[0]?.url).toBe(
      'https://www.instagram.com/someuser/',
    );

    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('NOTIFIED');
    expect(stored?.telegramMessageId).toBe(1000);
    expect(stored?.notificationSentAtUtc).not.toBeNull();
    expect(stored?.screenshotStatus).toBe('SENT');

    const items = repos.outbox.all();
    expect(items).toHaveLength(1);
    expect(items[0]?.status).toBe('SENT');
    expect(items[0]?.telegramMessageId).toBe(1000);
    expect(existsSync(filePath)).toBe(false);

    // A second tick has nothing pending and sends nothing.
    await worker.runOnce();
    expect(client.sentPhotos).toHaveLength(1);
    expect(client.sentMessages).toHaveLength(0);
  });

  it('cleared case in the queue never notifies: item failed, nothing sent', async () => {
    const c = await seedNotifyingCase({ status: 'CLEARED', clearedAtUtc: CONFIRMED_ISO });
    await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
    await enqueue(c.id, 'RECOVERY_PHOTO');
    const worker = makeWorker();

    await worker.runOnce();

    expect(client.sentPhotos).toHaveLength(0);
    expect(client.sentMessages).toHaveLength(0);
    const items = repos.outbox.all();
    expect(items[0]?.status).toBe('FAILED');
    expect(items[0]?.lastError).toBe('case_cleared');
  });

  it('already-notified case never notifies again', async () => {
    const c = await seedNotifyingCase({
      notificationClaimedAtUtc: CONFIRMED_ISO,
      notificationSentAtUtc: CONFIRMED_ISO,
      telegramMessageId: 999,
    });
    await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
    await enqueue(c.id, 'RECOVERY_PHOTO');
    const worker = makeWorker();

    await worker.runOnce();

    expect(client.sentPhotos).toHaveLength(0);
    const items = repos.outbox.all();
    expect(items[0]?.status).toBe('FAILED');
    expect(items[0]?.lastError).toBe('already_notified');
  });

  it('claimNotification single-winner: a live pre-claim defers, a stale one is taken over', async () => {
    const c = await seedNotifyingCase({
      notificationClaimedAtUtc: clock.now().toISOString(), // fresh claim by another worker
    });
    const filePath = join(dir, `${c.id}.png`);
    await writeFile(filePath, FAKE_PNG);
    await enqueue(c.id, 'RECOVERY_PHOTO');
    const worker = makeWorker();

    // Live claimant elsewhere: no send, item deferred (left CLAIMED).
    await worker.runOnce();
    expect(client.sentPhotos).toHaveLength(0);
    expect(repos.outbox.all()[0]?.status).toBe('CLAIMED');

    // The claimant crashed: after the stale window this worker takes over — once.
    clock.advanceMs(ELEVEN_MINUTES_MS);
    await worker.runOnce();
    expect(client.sentPhotos).toHaveLength(1);
    expect((await repos.cases.findById(c.id))?.status).toBe('NOTIFIED');
  });

  it('pre-claim with notificationSentAt set sends nothing', async () => {
    const c = await seedNotifyingCase({
      notificationClaimedAtUtc: BASE_ISO,
      notificationSentAtUtc: BASE_ISO,
    });
    await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
    await enqueue(c.id, 'RECOVERY_PHOTO');

    await makeWorker().runOnce();

    expect(client.sentPhotos).toHaveLength(0);
    expect(client.sentMessages).toHaveLength(0);
    expect(repos.outbox.all()[0]?.lastError).toBe('already_notified');
  });

  it('an ambiguous owner send is closed out unretried, with no message id recorded', async () => {
    const c = await seedNotifyingCase();
    const filePath = join(dir, `${c.id}.png`);
    await writeFile(filePath, FAKE_PNG);
    await enqueue(c.id, 'RECOVERY_PHOTO');
    client.failMethod('sendPhoto', new AppError('TELEGRAM_AMBIGUOUS', 'socket closed mid-send'));
    const worker = makeWorker();

    // Telegram MAY already have delivered it. Leaving the item CLAIMED was not enough:
    // requeueStale resets a stale claim to PENDING, so ~10 minutes later it went out AGAIN — a
    // duplicate "ACCOUNT UNBANNED" to the owner and, on a linked monitor, to the client.
    await worker.runOnce();
    const closed = repos.outbox.all()[0];
    expect(closed?.status).toBe('SENT');
    // A null id is the honest record of "possibly delivered, never confirmed".
    expect(closed?.telegramMessageId).toBeNull();

    const afterAmbiguous = await repos.cases.findById(c.id);
    expect(afterAmbiguous?.status).toBe('NOTIFIED');
    expect(afterAmbiguous?.notificationSentAtUtc).not.toBeNull();
    expect(afterAmbiguous?.telegramMessageId).toBeNull();

    // Even after the stale window, the owner alert is NEVER sent again.
    clock.advanceMs(ELEVEN_MINUTES_MS);
    await worker.runOnce();
    clock.advanceMs(ELEVEN_MINUTES_MS);
    await worker.runOnce();
    expect(client.sentPhotos).toHaveLength(0);
    // The photo already went out with the alert, so nothing is owed a follow-up.
    expect(repos.outbox.all().map((i) => i.kind)).toEqual(['RECOVERY_PHOTO']);
  });

  it('an ordinary (definitely-not-delivered) failure is retried rather than closed out', async () => {
    const c = await seedNotifyingCase();
    await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
    await enqueue(c.id, 'RECOVERY_PHOTO');
    // What a DNS / ECONNREFUSED failure now maps to. Nothing was delivered, so the alert MUST
    // still go out — the old over-broad AMBIGUOUS classification suppressed exactly this retry.
    client.failNextSendWith(new AppError('TELEGRAM_ERROR', 'telegram sendPhoto request failed'));
    const worker = makeWorker();

    await worker.runOnce();
    expect(client.sentPhotos).toHaveLength(0);
    expect(repos.outbox.all()[0]?.status).toBe('CLAIMED');
    expect((await repos.cases.findById(c.id))?.status).toBe('NOTIFYING');

    // The stale claim is requeued and the retry delivers for real.
    clock.advanceMs(ELEVEN_MINUTES_MS);
    await worker.runOnce();

    expect(client.sentPhotos).toHaveLength(1);
    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('NOTIFIED');
    expect(stored?.telegramMessageId).toBe(1000);
  });

  it('RECOVERY_TEXT sends the fallback and queues NO follow-up: no file exists to send yet', async () => {
    const c = await seedNotifyingCase({ screenshotStatus: 'FAILED' });
    await enqueue(c.id, 'RECOVERY_TEXT');
    const worker = makeWorker();

    await worker.runOnce();

    expect(client.sentMessages).toHaveLength(1);
    const msg = client.sentMessages[0];
    expect(msg?.text).toBe(recoveryTextFallback(USER, BASE_ISO, CONFIRMED_ISO, TZ));
    expect(msg?.text).toContain('Screenshot capture failed');
    expect(msg?.reply_markup?.inline_keyboard[0]?.[0]?.url).toBe(
      'https://www.instagram.com/someuser/',
    );

    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('NOTIFIED');
    expect(stored?.telegramMessageId).toBe(1000);
    // FAILED is the durable "still owed a picture" marker the monitor's re-capture sweep reads.
    expect(stored?.screenshotStatus).toBe('FAILED');

    // A follow-up queued HERE could only claim, find no file, and be failed — this handler has
    // no screenshot and cannot make one. It is enqueued by the monitor worker once a re-capture
    // has actually produced a file. Repeated ticks must not conjure one either.
    clock.advanceMs(ELEVEN_MINUTES_MS);
    await worker.runOnce();
    clock.advanceMs(ELEVEN_MINUTES_MS);
    await worker.runOnce();
    expect(repos.outbox.all().map((i) => `${i.kind}:${i.status}`)).toEqual(['RECOVERY_TEXT:SENT']);
    expect(client.sentPhotos).toHaveLength(0);
  });

  it('RECOVERY_PHOTO with a missing file downgrades to RECOVERY_TEXT, in the SAME tick', async () => {
    const c = await seedNotifyingCase();
    await enqueue(c.id, 'RECOVERY_PHOTO');
    const worker = makeWorker();

    await worker.runOnce();

    expect(client.sentPhotos).toHaveLength(0);
    const photoItem = repos.outbox.all().find((i) => i.kind === 'RECOVERY_PHOTO');
    expect(photoItem?.status).toBe('FAILED');
    expect(photoItem?.lastError).toBe('screenshot_missing');
    // The downgrade used to wait a whole tick to go out, purely because a tick drained exactly
    // one item — the client sat there while a queue with work in it deliberately idled.
    expect(client.sentMessages).toHaveLength(1);
    const textItem = repos.outbox.all().find((i) => i.kind === 'RECOVERY_TEXT');
    expect(textItem?.status).toBe('SENT');

    const stored = await repos.cases.findById(c.id);
    expect(stored?.status).toBe('NOTIFIED');
    // The case entered this path labelled CAPTURED; closing out still labelled CAPTURED left the
    // re-capture sweep blind to it, so a downgraded recovery was silently proof-less forever.
    expect(stored?.screenshotStatus).toBe('FAILED');
  });

  // --- tick cadence and drain ----------------------------------------------------------------
  // Time between a confirmed recovery and the client being told, spent doing nothing.

  it('drains a burst within one tick, bounded, instead of one item per tick', async () => {
    // Six queued recoveries used to take six ticks (nine seconds at the old cadence) even though
    // the queue was sitting right there. Draining cannot multiply Telegram calls: every pass is
    // the same single-winner claim, so it sends exactly what the queue holds.
    for (let i = 0; i < 6; i += 1) {
      const created = await repos.cases.create(
        {
          normalizedUsername: `user${i}`,
          originalInput: `user${i}`,
          startedAtUtc: BASE_ISO,
          nextCheckAtUtc: BASE_ISO,
        },
        BASE_ISO,
      );
      await repos.cases.save({
        ...created,
        status: 'NOTIFYING',
        confirmedAtUtc: CONFIRMED_ISO,
        nextCheckAtUtc: null,
        screenshotStatus: 'FAILED',
      });
      await enqueue(created.id, 'RECOVERY_TEXT');
    }
    const worker = makeWorker();

    await worker.runOnce();
    // Bounded: one tick must not monopolise the loop while a backlog is worked off.
    expect(client.sentMessages).toHaveLength(5);

    await worker.runOnce();
    expect(client.sentMessages).toHaveLength(6);

    // ...and an empty queue costs one claim query and no sends at all.
    await worker.runOnce();
    expect(client.sentMessages).toHaveLength(6);
  });

  it('start() polls in hundreds of milliseconds, not seconds', async () => {
    // The default cadence IS the dead time in front of every recovery alert. An idle tick is one
    // indexed claim query and zero Telegram calls, so a fast cadence costs nothing.
    const spy = vi.spyOn(globalThis, 'setInterval');
    const worker = makeWorker();
    try {
      worker.start();
      expect(spy).toHaveBeenCalled();
      expect(spy.mock.calls[0]?.[1]).toBeLessThanOrEqual(500);
    } finally {
      await worker.stop();
      spy.mockRestore();
    }
  });

  describe('business client delivery', () => {
    function enableConnection(canReply: boolean): Promise<void> {
      return repos.businessConnections.upsert({
        id: 'bc1',
        userId: 42,
        userChatId: null,
        isEnabled: true,
        rights: {
          canReply,
          canReadMessages: true,
          canDeleteSentMessages: false,
          canDeleteAllMessages: false,
        },
        createdAtUtc: BASE_ISO,
        updatedAtUtc: BASE_ISO,
      });
    }
    async function linkClient(monitorId: string): Promise<void> {
      await repos.clientLinks.create(
        {
          monitorId,
          sourceType: 'BUSINESS_CHAT',
          clientChatId: 5555,
          businessConnectionId: 'bc1',
          ownerTelegramUserId: 42,
          sourceMessageId: 1,
        },
        BASE_ISO,
      );
      await repos.clientLinks.updateDeliveryStatus(
        monitorId,
        'BUSINESS_DELIVERY_PENDING',
        BASE_ISO,
      );
    }

    /** Records the order in which the three deliveries actually happen. */
    class OrderRecordingClient extends MockTelegramClient {
      constructor(private readonly log: string[]) {
        super();
      }

      override async sendPhoto(params: SendPhotoParams): Promise<SentMessage> {
        this.log.push(params.business_connection_id === undefined ? 'owner' : 'client');
        return super.sendPhoto(params);
      }
    }

    /** A Discord mirror that records when it ran, and optionally fails. */
    function discordStub(log: string[], fail = false): DiscordNotifier {
      return {
        unban: async (): Promise<boolean> => {
          log.push('discord');
          if (fail) throw new Error('discord 503');
          return true;
        },
      } as unknown as DiscordNotifier;
    }

    function workerWithDiscord(telegram: TelegramClient, discord: DiscordNotifier): OutboxWorker {
      return new OutboxWorker({
        repos,
        client: telegram,
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        ownerChatId: async (): Promise<number | null> => OWNER_CHAT_ID,
        screenshotDir: dir,
        maxAttempts: 3,
        discord,
      });
    }

    it('the PAYING CLIENT is served before our own Discord mirror', async () => {
      // The mirror is internal bookkeeping. Uploading a photo to Discord's API before sending the
      // client's message put ~0.9s of our own convenience in front of the message they pay for.
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      const log: string[] = [];
      const telegram = new OrderRecordingClient(log);

      await workerWithDiscord(telegram, discordStub(log)).runOnce();

      expect(log).toEqual(['owner', 'client', 'discord']);
    });

    it('a Discord failure still cannot touch client delivery or the delivered record', async () => {
      // The guarantee that had to survive the reordering. The mirror now runs last, so a failure
      // cannot delay the client — but it must also not escape into the tick's error handling and
      // re-drive (or un-record) an alert that already went out.
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      const log: string[] = [];
      const telegram = new OrderRecordingClient(log);

      await workerWithDiscord(telegram, discordStub(log, true)).runOnce();

      expect(log).toEqual(['owner', 'client', 'discord']);
      expect(await repos.clientLinks.findByMonitorId(c.id)).toMatchObject({
        clientDeliveryStatus: 'BUSINESS_DELIVERED',
      });
      const stored = await repos.cases.findById(c.id);
      expect(stored?.status).toBe('NOTIFIED');
      // Left SENT: a row demoted to FAILED here is one the stranded-notification sweep would
      // re-open, sending the client a second "YOUR ACCOUNT IS BACK".
      expect(repos.outbox.all()[0]?.status).toBe('SENT');
    });

    it('also delivers the recovery into the linked client chat via business_connection_id', async () => {
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');

      await makeWorker().runOnce();

      // Owner photo + client photo.
      expect(client.sentPhotos).toHaveLength(2);
      const clientPhoto = client.sentPhotos.find((p) => p.business_connection_id === 'bc1');
      expect(clientPhoto?.chat_id).toBe(5555);
      expect(clientPhoto?.caption).toContain('YOUR INSTAGRAM PROFILE IS ACTIVE AGAIN');
      const link = await repos.clientLinks.findByMonitorId(c.id);
      expect(link?.clientDeliveryStatus).toBe('BUSINESS_DELIVERED');
    });

    it('an AMBIGUOUS owner send still delivers to the client, exactly once', async () => {
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      // Only the OWNER send is ambiguous; the client send that follows succeeds.
      client.failNextSendWith(new AppError('TELEGRAM_AMBIGUOUS', 'socket closed mid-send'));
      const worker = makeWorker();

      await worker.runOnce();

      // The owner's photo never confirmed, but the client's did — the two are independent.
      const clientPhotos = client.sentPhotos.filter((p) => p.business_connection_id === 'bc1');
      expect(clientPhotos).toHaveLength(1);
      expect(clientPhotos[0]?.chat_id).toBe(5555);
      expect(await repos.clientLinks.findByMonitorId(c.id)).toMatchObject({
        clientDeliveryStatus: 'BUSINESS_DELIVERED',
      });

      // Further ticks never duplicate either half.
      clock.advanceMs(ELEVEN_MINUTES_MS);
      await worker.runOnce();
      expect(client.sentPhotos.filter((p) => p.business_connection_id === 'bc1')).toHaveLength(1);
    });

    it('an AMBIGUOUS owner send whose client delivery fails pings the owner for action', async () => {
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(false); // no can_reply -> business delivery impossible
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      client.failNextSendWith(new AppError('TELEGRAM_AMBIGUOUS', 'socket closed mid-send'));

      await makeWorker().runOnce();

      // The client's fate is recorded explicitly and escalated, never left silently pending.
      expect(await repos.clientLinks.findByMonitorId(c.id)).toMatchObject({
        clientDeliveryStatus: 'BUSINESS_PERMISSION_MISSING',
      });
      expect(client.sentMessages.some((m) => m.text.includes('IS ACTIVE'))).toBe(true);
    });

    it('a /clear landing mid-send never resurrects the case as NOTIFIED', async () => {
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      // The owner clears the monitor while the owner send is on the wire.
      const racing = new ClearingMidSendClient(async () => {
        await repos.cases.clearByNormalizedUsername(USER, CONFIRMED_ISO);
      });

      await makeWorker(racing).runOnce();

      const stored = await repos.cases.findById(c.id);
      expect(stored?.status).toBe('CLEARED');
      expect(stored?.notificationSentAtUtc).toBeNull();
      expect(racing.sentPhotos.some((p) => p.business_connection_id === 'bc1')).toBe(false);
    });

    it('rescues a client delivery stranded by a crash after the owner alert was marked SENT', async () => {
      // markSent commits BEFORE the case close-out and before the client delivery. A container
      // restart in that window used to strand the paying client forever: the outbox never claims
      // a SENT row again, and the scheduler sweep refuses to revive one.
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      const item = await repos.outbox.enqueue({
        caseId: c.id,
        kind: 'RECOVERY_PHOTO',
        createdAtUtc: BASE_ISO,
      });
      await repos.outbox.markSent(item.id, CONFIRMED_ISO, 1000);
      const worker = makeWorker();

      await worker.runOnce();

      const clientPhotos = client.sentPhotos.filter((p) => p.business_connection_id === 'bc1');
      expect(clientPhotos).toHaveLength(1);
      expect(clientPhotos[0]?.chat_id).toBe(5555);
      expect(clientPhotos[0]?.caption).toContain('YOUR INSTAGRAM PROFILE IS ACTIVE AGAIN');
      expect(await repos.clientLinks.findByMonitorId(c.id)).toMatchObject({
        clientDeliveryStatus: 'BUSINESS_DELIVERED',
      });
      // The owner alert already went out; the rescue must never re-send it.
      expect(client.sentPhotos.filter((p) => p.business_connection_id === undefined)).toHaveLength(
        0,
      );

      // And the sweep is idempotent: the client is never told twice.
      clock.advanceMs(ELEVEN_MINUTES_MS);
      await worker.runOnce();
      expect(client.sentPhotos.filter((p) => p.business_connection_id === 'bc1')).toHaveLength(1);
    });

    it('a recovery confirmed while the egress is throttled still gets its proof to the client', async () => {
      // The two defects compounded here. The circuit breaker answers UNKNOWN instantly without
      // touching the network, so every capture attempt "failed" in milliseconds and the alert
      // went out text-only; and SCREENSHOT_FOLLOWUP only ever READ a file that nothing re-wrote,
      // so the picture never arrived. A throttle window is exactly when both fire at once.
      //
      // NOTHING in this test writes a screenshot file. If production does not re-capture one,
      // there is no proof to deliver and this fails.
      const detector = new FakeDetector();
      const monitor = new MonitorWorker({
        repos,
        detector,
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        rand: () => 0,
        screenshotDir: dir,
        sleep: instantSleep,
      });
      const outbox = makeWorker();
      await enableConnection(true);
      const c = await repos.cases.create(
        {
          normalizedUsername: USER,
          originalInput: USER,
          startedAtUtc: BASE_ISO,
          nextCheckAtUtc: BASE_ISO,
        },
        BASE_ISO,
      );
      await linkClient(c.id);
      // Three confirmations, then a capture the OPEN breaker refuses to let through.
      detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', {
        classification: 'UNKNOWN',
        errorCode: 'HTTP_429',
      });

      for (let i = 0; i < 3; i++) {
        clock.advanceMs(5_000);
        await monitor.runOnce();
      }
      expect((await repos.cases.findById(c.id))?.screenshotStatus).toBe('FAILED');
      expect(repos.outbox.all().map((i) => i.kind)).toEqual(['RECOVERY_TEXT']);

      // The alert is prompt — the client is told at once, not made to wait for a picture.
      await outbox.runOnce();
      expect(client.sentMessages.some((m) => m.business_connection_id === 'bc1')).toBe(true);
      expect(await repos.clientLinks.findByMonitorId(c.id)).toMatchObject({
        clientDeliveryStatus: 'BUSINESS_DELIVERED',
      });
      expect(repos.outbox.all().map((i) => i.kind)).toEqual(['RECOVERY_TEXT']);

      // The throttle lifts. The monitor's re-capture sweep is what actually re-takes the picture.
      detector.script(USER, { classification: 'ACTIVE', screenshot: FAKE_PNG });
      clock.advanceMs(6 * 60 * 1000);
      await monitor.runOnce();
      expect((await repos.cases.findById(c.id))?.screenshotStatus).toBe('CAPTURED');
      expect(repos.outbox.all().find((i) => i.kind === 'SCREENSHOT_FOLLOWUP')?.status).toBe(
        'PENDING',
      );

      // ...and the outbox delivers it: a captionless reply to the owner, and the client's proof.
      await outbox.runOnce();

      const clientPhotos = client.sentPhotos.filter((p) => p.business_connection_id === 'bc1');
      expect(clientPhotos).toHaveLength(1);
      expect(clientPhotos[0]?.chat_id).toBe(5555);
      expect(clientPhotos[0]?.photo.equals(FAKE_PNG)).toBe(true);
      const ownerPhoto = client.sentPhotos.find((p) => p.business_connection_id === undefined);
      expect(ownerPhoto?.reply_to_message_id).toBe(1000);
      expect((await repos.cases.findById(c.id))?.screenshotStatus).toBe('SENT');

      // Exactly once: later ticks of either worker never repeat it.
      clock.advanceMs(ELEVEN_MINUTES_MS);
      await outbox.runOnce();
      await monitor.runOnce();
      expect(client.sentPhotos.filter((p) => p.business_connection_id === 'bc1')).toHaveLength(1);
    });

    it('a rejected owner follow-up still gets the proof to the client', async () => {
      // Replying to a message the owner has deleted is an ordinary TELEGRAM_ERROR, and up to
      // RECAPTURE_WINDOW_MS separates the recovery alert from its follow-up, so it is routine.
      // Letting it escape aborted the item before the CLIENT's proof was ever attempted; every
      // retry hit the same permanent rejection, and once the row was FAILED nothing could revive
      // it — the case is screenshotStatus CAPTURED, which the re-capture sweep skips. The paying
      // client silently never received the picture the text-only alert had promised.
      const failing = new OwnerFollowupFailsClient();
      const detector = new FakeDetector();
      const monitor = new MonitorWorker({
        repos,
        detector,
        config: makeTestConfig(),
        clock,
        logger: nullLogger(),
        rand: () => 0,
        screenshotDir: dir,
        sleep: instantSleep,
      });
      const outbox = makeWorker(failing);
      await enableConnection(true);
      const c = await repos.cases.create(
        {
          normalizedUsername: USER,
          originalInput: USER,
          startedAtUtc: BASE_ISO,
          nextCheckAtUtc: BASE_ISO,
        },
        BASE_ISO,
      );
      await linkClient(c.id);
      detector.script(USER, 'ACTIVE', 'ACTIVE', 'ACTIVE', {
        classification: 'UNKNOWN',
        errorCode: 'HTTP_429',
      });

      for (let i = 0; i < 3; i++) {
        clock.advanceMs(5_000);
        await monitor.runOnce();
      }
      await outbox.runOnce(); // text-only recovery, to the owner and the client

      // Production re-captures the picture; nothing in this test writes the file.
      detector.script(USER, { classification: 'ACTIVE', screenshot: FAKE_PNG });
      clock.advanceMs(6 * 60 * 1000);
      await monitor.runOnce();
      expect(repos.outbox.all().find((i) => i.kind === 'SCREENSHOT_FOLLOWUP')?.status).toBe(
        'PENDING',
      );

      await outbox.runOnce(); // Telegram rejects the owner's reply-photo

      const clientPhotos = failing.sentPhotos.filter((p) => p.business_connection_id === 'bc1');
      expect(clientPhotos).toHaveLength(1);
      expect(clientPhotos[0]?.photo.equals(FAKE_PNG)).toBe(true);
      // Only the owner's copy was lost, and the item is settled rather than retried forever.
      expect(failing.sentPhotos.some((p) => p.business_connection_id === undefined)).toBe(false);
      expect(repos.outbox.all().find((i) => i.kind === 'SCREENSHOT_FOLLOWUP')?.status).toBe('SENT');
      expect(existsSync(join(dir, `${c.id}.png`))).toBe(false);

      // ...and never a second copy on a later tick.
      clock.advanceMs(ELEVEN_MINUTES_MS);
      await outbox.runOnce();
      expect(failing.sentPhotos.filter((p) => p.business_connection_id === 'bc1')).toHaveLength(1);
    });

    // --- transient client-delivery failures ---------------------------------------------------
    // Harm rank 1: a client is never told about a recovery. Every test below starts from a
    // recovery that IS real and IS confirmed, and asks what happens to the paying client when
    // something between us and Telegram misbehaves for a moment.

    /**
     * Fails the CLIENT's business-connection send `failures` times, then lets it through. The
     * owner's copy always succeeds: this is a transient blip on one send, not an outage.
     */
    class ClientSendFailsClient extends MockTelegramClient {
      /** Every client-bound send ATTEMPTED, including the ones that threw. */
      clientAttempts = 0;
      private remaining: number;
      private readonly error: Error;

      constructor(failures: number, error?: Error) {
        super();
        this.remaining = failures;
        this.error = error ?? new AppError('TELEGRAM_ERROR', 'telegram sendPhoto request failed');
      }

      private failIfClientBound(businessConnectionId: string | undefined): void {
        if (businessConnectionId === undefined) return;
        this.clientAttempts += 1;
        if (this.remaining > 0) {
          this.remaining -= 1;
          throw this.error;
        }
      }

      override async sendPhoto(params: SendPhotoParams): Promise<SentMessage> {
        this.failIfClientBound(params.business_connection_id);
        return super.sendPhoto(params);
      }

      override async sendMessage(params: SendMessageParams): Promise<SentMessage> {
        this.failIfClientBound(params.business_connection_id);
        return super.sendMessage(params);
      }
    }

    /**
     * How many messages the CLIENT actually received, photo or text. Counting only photos hides a
     * duplicate that arrived as the text fallback, which is exactly the shape a re-send takes once
     * the screenshot has been cleaned up.
     */
    function clientSends(telegram: MockTelegramClient): number {
      return (
        telegram.sentPhotos.filter((p) => p.business_connection_id === 'bc1').length +
        telegram.sentMessages.filter((m) => m.business_connection_id === 'bc1').length
      );
    }

    function ownerActionPings(telegram: MockTelegramClient): number {
      return telegram.sentMessages.filter((m) => m.text.includes(OWNER_ACTION_PING)).length;
    }

    it('a transient client-send failure is retried, and the client is eventually told', async () => {
      // The whole point of the product. One 429 / network blip used to write the client off
      // permanently: the catch treated EVERY exception as terminal, parked the link in
      // OWNER_ACTION_REQUIRED, and the rescue sweep deliberately refuses to touch that status.
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      const telegram = new ClientSendFailsClient(1);
      const worker = makeWorker(telegram);

      await worker.runOnce();

      // The owner has their alert; the client's copy did not land and was NOT written off.
      expect(telegram.clientAttempts).toBe(1);
      expect(clientSends(telegram)).toBe(0);
      expect((await repos.clientLinks.findByMonitorId(c.id))?.clientDeliveryStatus).toBe(
        'BUSINESS_DELIVERY_PENDING',
      );
      // A blip is not owner work: nothing has been escalated yet.
      expect(ownerActionPings(telegram)).toBe(0);

      clock.advanceMs(SWEEP_MS);
      await worker.runOnce();

      // ...and it is still the PHOTO, not a downgraded text: the proof is held on disk while the
      // client is owed a retry.
      const clientPhotos = telegram.sentPhotos.filter((p) => p.business_connection_id === 'bc1');
      expect(clientPhotos).toHaveLength(1);
      expect(clientPhotos[0]?.photo.equals(FAKE_PNG)).toBe(true);
      expect(clientPhotos[0]?.caption).toContain('YOUR INSTAGRAM PROFILE IS ACTIVE AGAIN');
      expect((await repos.clientLinks.findByMonitorId(c.id))?.clientDeliveryStatus).toBe(
        'BUSINESS_DELIVERED',
      );

      // Exactly once, ever.
      clock.advanceMs(SWEEP_MS);
      await worker.runOnce();
      expect(clientSends(telegram)).toBe(1);
      expect(existsSync(join(dir, `${c.id}.png`))).toBe(false);
    });

    it('a bookkeeping failure after a SUCCESSFUL client send never sends a second message', async () => {
      // Harm rank 2. The send and the "delivered" write used to share one try block, so a database
      // failure AFTER the client had been told was indistinguishable from the client never being
      // told. The escalation write failed too — it is the same sick database — so the whole thing
      // threw, the caller swallowed it, the link stayed owed, and the sweep sent the client a
      // second "YOUR ACCOUNT IS BACK".
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');

      const links = repos.clientLinks;
      const realUpdate = links.updateDeliveryStatus.bind(links);
      let dbSick = true;
      links.updateDeliveryStatus = async (
        monitorId: string,
        status: BusinessDeliveryStatus,
        nowUtc: string,
      ): Promise<void> => {
        // Every write that RECORDS an outcome fails; the pre-send claim is not one of those.
        if (dbSick && (status === 'BUSINESS_DELIVERED' || status === 'OWNER_ACTION_REQUIRED')) {
          throw new Error('SQLITE_BUSY: database is locked');
        }
        return realUpdate(monitorId, status, nowUtc);
      };
      const worker = makeWorker();

      await worker.runOnce();
      expect(clientSends(client)).toBe(1); // they WERE told

      // The database recovers. Nothing may conclude from a lost record that the client is owed
      // another message.
      dbSick = false;
      for (let i = 0; i < 3; i += 1) {
        clock.advanceMs(SWEEP_MS);
        await worker.runOnce();
      }

      expect(clientSends(client)).toBe(1);
      // Resolved toward the owner rather than toward a duplicate — and pinged exactly once.
      expect((await repos.clientLinks.findByMonitorId(c.id))?.clientDeliveryStatus).toBe(
        'OWNER_ACTION_REQUIRED',
      );
      expect(ownerActionPings(client)).toBe(1);
    });

    it('a client send whose outcome is unknowable is never repeated, only escalated', async () => {
      // TELEGRAM_AMBIGUOUS means the message MAY be sitting in the client's chat already. A retry
      // would be a second "YOUR ACCOUNT IS BACK"; the owner ping costs nothing by comparison.
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      const telegram = new ClientSendFailsClient(
        Number.MAX_SAFE_INTEGER,
        new AppError('TELEGRAM_AMBIGUOUS', 'socket closed mid-send'),
      );
      const worker = makeWorker(telegram);

      await worker.runOnce();
      for (let i = 0; i < 3; i += 1) {
        clock.advanceMs(SWEEP_MS);
        await worker.runOnce();
      }

      expect(telegram.clientAttempts).toBe(1);
      expect((await repos.clientLinks.findByMonitorId(c.id))?.clientDeliveryStatus).toBe(
        'OWNER_ACTION_REQUIRED',
      );
      expect(ownerActionPings(telegram)).toBe(1);
    });

    it('client retries are bounded and end in exactly one owner-action ping', async () => {
      // The counterweight to retrying at all: a client whose chat we simply cannot reach must not
      // keep us trying forever, nor die quietly — a human has to be told to finish the job.
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      const telegram = new ClientSendFailsClient(Number.MAX_SAFE_INTEGER); // never recovers
      const worker = makeWorker(telegram);

      for (let i = 0; i < 40; i += 1) {
        await worker.runOnce();
        clock.advanceMs(SWEEP_MS);
      }

      expect((await repos.clientLinks.findByMonitorId(c.id))?.clientDeliveryStatus).toBe(
        'OWNER_ACTION_REQUIRED',
      );
      expect(ownerActionPings(telegram)).toBe(1);
      // It really did retry, and it really did stop: roughly one attempt a minute across the
      // 15-minute budget, not 40.
      expect(telegram.clientAttempts).toBeGreaterThan(1);
      expect(telegram.clientAttempts).toBeLessThanOrEqual(16);
    });

    /**
     * The real shape of an escalation: the owner's recovery alert landed just before egress died,
     * and from then on EVERY client-bound send and EVERY owner "deliver this by hand" ping fails.
     * That correlation is the whole point — the escalation is reached BECAUSE Telegram has been
     * unreachable for the full 15-minute retry window, so the ping goes out over the channel that
     * just failed ~15 consecutive times.
     */
    class EgressOutageClient extends MockTelegramClient {
      /** Flip to false to end the outage. */
      down = true;
      clientAttempts = 0;
      /** Owner action-required pings ATTEMPTED, including the ones that threw. */
      ownerPingAttempts = 0;

      override async sendPhoto(params: SendPhotoParams): Promise<SentMessage> {
        if (params.business_connection_id !== undefined) {
          this.clientAttempts += 1;
          if (this.down) throw new AppError('TELEGRAM_ERROR', 'ECONNREFUSED');
        }
        return super.sendPhoto(params);
      }

      override async sendMessage(params: SendMessageParams): Promise<SentMessage> {
        if (params.business_connection_id !== undefined) {
          this.clientAttempts += 1;
          if (this.down) throw new AppError('TELEGRAM_ERROR', 'ECONNREFUSED');
        } else if (params.text.includes(OWNER_ACTION_PING)) {
          this.ownerPingAttempts += 1;
          if (this.down) throw new AppError('TELEGRAM_ERROR', 'ECONNREFUSED');
        }
        return super.sendMessage(params);
      }
    }

    it('REGRESSION: an owner escalation ping that never landed is retried, not thrown away', async () => {
      // The bounded client retry used to END in a single unretried ping whose failure was
      // discarded by `.catch(() => undefined)` — and the status it accompanied (OWNER_ACTION_REQUIRED)
      // is one the rescue sweep deliberately skips forever, `/ping` never reads and `/clients`
      // never shows. So a ping lost to the very outage that caused the escalation left the paying
      // client permanently untold AND the owner permanently unaware they had to finish it by hand.
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      const telegram = new EgressOutageClient();
      const worker = makeWorker(telegram);

      // ~20 minutes of outage: the 15-minute client retry budget runs out, the escalation fires,
      // and its ping dies on the same dead egress.
      for (let i = 0; i < 20; i += 1) {
        await worker.runOnce();
        clock.advanceMs(SWEEP_MS);
      }

      expect(telegram.ownerPingAttempts).toBeGreaterThan(1); // retried, not one-shot
      expect(ownerActionPings(telegram)).toBe(0); // ...and not one of them landed
      // Parked in the durable "never send this client anything again" state, NOT in the terminal
      // status that every sweep refuses to touch.
      expect((await repos.clientLinks.findByMonitorId(c.id))?.clientDeliveryStatus).toBe(
        'BUSINESS_DELIVERY_RETRYING',
      );

      // Egress comes back (a residential-proxy flap, routine for this deployment).
      const clientAttemptsDuringOutage = telegram.clientAttempts;
      telegram.down = false;
      await worker.runOnce();

      // The owner is finally told, and only now is the escalation committed.
      expect(ownerActionPings(telegram)).toBe(1);
      expect((await repos.clientLinks.findByMonitorId(c.id))?.clientDeliveryStatus).toBe(
        'OWNER_ACTION_REQUIRED',
      );
      // Harm rank 2 held throughout: a parked link only ever escalates, so the client was never
      // sent a second copy while the ping was being retried.
      expect(telegram.clientAttempts).toBe(clientAttemptsDuringOutage);
      expect(clientSends(telegram)).toBe(0);

      // ...and it really is terminal now: exactly one ping, ever.
      clock.advanceMs(SWEEP_MS);
      await worker.runOnce();
      expect(ownerActionPings(telegram)).toBe(1);
    });

    it('the escalation ping retry is BOUNDED: an unreachable owner settles, it does not loop', async () => {
      // The counterweight. Retrying a ping forever would hammer Telegram with the bot's own token
      // — which is the same token the client sends go out on — so an owner who genuinely cannot be
      // reached (blocked bot, deleted chat) has to settle, loudly, and stop.
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      const telegram = new EgressOutageClient(); // never comes back
      const worker = makeWorker(telegram);

      for (let i = 0; i < 70; i += 1) {
        await worker.runOnce();
        clock.advanceMs(SWEEP_MS);
      }

      expect((await repos.clientLinks.findByMonitorId(c.id))?.clientDeliveryStatus).toBe(
        'OWNER_ACTION_REQUIRED',
      );
      const attemptsAtSettle = telegram.ownerPingAttempts;
      expect(attemptsAtSettle).toBeGreaterThan(1);

      for (let i = 0; i < 10; i += 1) {
        await worker.runOnce();
        clock.advanceMs(SWEEP_MS);
      }
      expect(telegram.ownerPingAttempts).toBe(attemptsAtSettle);
    });

    it('a restart mid-retry does not lose the client delivery', async () => {
      // The retry state has to be durable, not a counter in the worker's head: this bot is
      // redeployed, OOM-killed and restarted routinely.
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(true);
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');
      const telegram = new ClientSendFailsClient(1);

      await makeWorker(telegram).runOnce();
      expect(clientSends(telegram)).toBe(0);

      // A brand-new worker with no in-memory state at all, over the same durable repositories.
      const restarted = makeWorker(telegram);
      clock.advanceMs(SWEEP_MS);
      await restarted.runOnce();

      expect(clientSends(telegram)).toBe(1);
      expect((await repos.clientLinks.findByMonitorId(c.id))?.clientDeliveryStatus).toBe(
        'BUSINESS_DELIVERED',
      );
    });

    it('when the bot cannot reply, does not fake client delivery and alerts the owner', async () => {
      const c = await seedNotifyingCase();
      await writeFile(join(dir, `${c.id}.png`), FAKE_PNG);
      await enableConnection(false); // no can_reply
      await linkClient(c.id);
      await enqueue(c.id, 'RECOVERY_PHOTO');

      await makeWorker().runOnce();

      // Owner still got their photo; NO client photo was sent through the business connection.
      expect(client.sentPhotos).toHaveLength(1);
      expect(client.sentPhotos.some((p) => p.business_connection_id === 'bc1')).toBe(false);
      const link = await repos.clientLinks.findByMonitorId(c.id);
      expect(link?.clientDeliveryStatus).toBe('BUSINESS_PERMISSION_MISSING');
      // Owner received an action-required alert.
      expect(client.sentMessages.some((m) => m.text.includes('IS ACTIVE'))).toBe(true);
    });
  });
});

/**
 * The persistence-level half of the "never re-send a delivered alert" guarantee. The sweep in
 * MonitorWorker treats a SENT row as proof the owner already has the alert; that only holds if
 * nothing can rewrite SENT afterwards.
 */
describe('outbox markFailed never demotes a delivered row', () => {
  it('leaves a SENT row SENT when a post-send step fails into markFailed', async () => {
    const db = new SqliteDatabase(':memory:');
    await db.migrate();
    const repos = db.repositories();
    const c = await repos.cases.create(
      {
        normalizedUsername: USER,
        originalInput: USER,
        startedAtUtc: BASE_ISO,
        nextCheckAtUtc: BASE_ISO,
      },
      BASE_ISO,
    );
    const item = await repos.outbox.enqueue({
      caseId: c.id,
      kind: 'RECOVERY_PHOTO',
      createdAtUtc: BASE_ISO,
    });
    await repos.outbox.markSent(item.id, CONFIRMED_ISO, 4242);

    // The close-out throws (SQLITE_BUSY / dropped pool) after a successful send and the item has
    // spent its attempts, so handleSendError lands here. Without the status guard the row flipped
    // SENT -> FAILED, the sweep re-opened it, and the owner got a second recovery alert.
    await repos.outbox.markFailed(item.id, 'telegram_error:DB_ERROR', CONFIRMED_ISO);

    const stored = (await repos.outbox.findByCase(c.id))[0];
    expect(stored?.status).toBe('SENT');
    expect(stored?.telegramMessageId).toBe(4242);
    // Still unreachable by the rescue path that would duplicate the alert.
    expect(await repos.outbox.reopenFailed(c.id, 'RECOVERY_PHOTO', CONFIRMED_ISO)).toBe(false);
    await db.close();
  });
});

/**
 * The transport-level half of the same defect, kept next to the outbox behaviour it feeds:
 * a send is only AMBIGUOUS when the outcome is genuinely unknowable. Classifying failures that
 * definitively never left the process as ambiguous suppressed the retry of an alert that had
 * NOT been delivered.
 */
describe('HttpTelegramClient send-failure classification', () => {
  function clientWith(fetchImpl: typeof fetch): HttpTelegramClient {
    return new HttpTelegramClient({
      token: 'test-token',
      logger: nullLogger(),
      fetchImpl,
      apiBase: 'https://api.telegram.org',
    });
  }

  /** How `fetch` surfaces a transport errno: a TypeError wrapping the real cause. */
  function transportFailure(code: string): TypeError {
    const cause = Object.assign(new Error(`${code} while connecting`), { code });
    return Object.assign(new TypeError('fetch failed'), { cause });
  }

  async function sendCode(fetchImpl: typeof fetch): Promise<string> {
    try {
      await clientWith(fetchImpl).sendMessage({ chat_id: 1, text: 'x' });
    } catch (err) {
      return err instanceof AppError ? err.code : 'not-an-AppError';
    }
    return 'resolved';
  }

  it.each(['ENOTFOUND', 'EAI_AGAIN', 'ECONNREFUSED', 'CERT_HAS_EXPIRED'])(
    'treats %s as a retryable TELEGRAM_ERROR, not ambiguous',
    async (code) => {
      expect(await sendCode(() => Promise.reject(transportFailure(code)))).toBe('TELEGRAM_ERROR');
    },
  );

  it('treats a socket reset mid-send as ambiguous — it may already have been delivered', async () => {
    expect(await sendCode(() => Promise.reject(transportFailure('ECONNRESET')))).toBe(
      'TELEGRAM_AMBIGUOUS',
    );
  });

  it('treats our own timeout abort as ambiguous', async () => {
    const abort = Object.assign(new Error('This operation was aborted'), { name: 'AbortError' });
    expect(await sendCode(() => Promise.reject(abort))).toBe('TELEGRAM_AMBIGUOUS');
  });

  it('treats a non-JSON 502 gateway page as a retryable error — it never reached the API', async () => {
    const page = (): Promise<Response> =>
      Promise.resolve(new Response('<html>502 Bad Gateway</html>', { status: 502 }));
    expect(await sendCode(page)).toBe('TELEGRAM_ERROR');
  });

  /** A 200 whose body stream errors part-way through, as a reset egress produces. */
  function truncated200(bodyError: unknown): () => Promise<Response> {
    return () => {
      const body = new ReadableStream<Uint8Array>({
        start(controller) {
          controller.enqueue(new TextEncoder().encode('{"ok":true,"result":{"message_'));
          controller.error(bodyError);
        },
      });
      return Promise.resolve(new Response(body, { status: 200 }));
    };
  }

  it('treats a socket reset while reading a 200 body as ambiguous — the send already landed', async () => {
    // The 200 status line only exists because Telegram accepted and posted the message. Calling
    // this "definitely not delivered" made the outbox re-send an alert the owner already had.
    expect(await sendCode(truncated200(transportFailure('UND_ERR_SOCKET')))).toBe(
      'TELEGRAM_AMBIGUOUS',
    );
  });

  it('treats our own timeout aborting the 200 body read as ambiguous', async () => {
    const abort = Object.assign(new Error('This operation was aborted'), { name: 'AbortError' });
    expect(await sendCode(truncated200(abort))).toBe('TELEGRAM_AMBIGUOUS');
  });

  it('keeps a fully-received non-JSON 200 body retryable — a proxy page, not the API', async () => {
    // The counterweight: a false AMBIGUOUS closes the owner alert out unretried, which is a
    // MISSED notification. Only a body that never finished arriving may be called unknowable.
    const portal = (): Promise<Response> =>
      Promise.resolve(new Response('<html>captive portal</html>', { status: 200 }));
    expect(await sendCode(portal)).toBe('TELEGRAM_ERROR');
  });

  it('keeps a non-JSON 504 ambiguous — the backend may have processed the send', async () => {
    const page = (): Promise<Response> =>
      Promise.resolve(new Response('<html>504 Gateway Timeout</html>', { status: 504 }));
    expect(await sendCode(page)).toBe('TELEGRAM_AMBIGUOUS');
  });
});
