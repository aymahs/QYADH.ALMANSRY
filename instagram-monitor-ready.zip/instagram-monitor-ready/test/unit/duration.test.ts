import { describe, it, expect } from 'vitest';
import { formatDuration, durationBetween, durationMsBetween } from '../../src/core';

const SEC = 1_000;
const MIN = 60 * SEC;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

describe('formatDuration', () => {
  it('formats zero', () => {
    expect(formatDuration(0)).toBe('0 days 00 hours 00 minutes 00 seconds');
  });

  it('clamps negatives to zero', () => {
    expect(formatDuration(-5000)).toBe('0 days 00 hours 00 minutes 00 seconds');
  });

  it('floors sub-second remainders', () => {
    expect(formatDuration(2_999)).toBe('0 days 00 hours 00 minutes 02 seconds');
  });

  it('zero-pads seconds', () => {
    expect(formatDuration(9 * SEC)).toBe('0 days 00 hours 00 minutes 09 seconds');
  });

  it('formats minutes and seconds', () => {
    expect(formatDuration(2 * MIN + 9 * SEC)).toBe('0 days 00 hours 02 minutes 09 seconds');
  });

  it('formats hours with zero-padding', () => {
    expect(formatDuration(1 * HOUR + 5 * MIN + 3 * SEC)).toBe(
      '0 days 01 hours 05 minutes 03 seconds',
    );
  });

  it('formats the 12-day example with unpadded days', () => {
    expect(formatDuration(12 * DAY + 7 * HOUR + 4 * MIN + 51 * SEC)).toBe(
      '12 days 07 hours 04 minutes 51 seconds',
    );
  });
});

describe('durationBetween / durationMsBetween', () => {
  it('computes ms between two ISO strings', () => {
    expect(durationMsBetween('2026-07-01T00:00:00.000Z', '2026-07-01T00:02:09.000Z')).toBe(129_000);
  });

  it('formats the duration between two ISO strings', () => {
    expect(durationBetween('2026-07-01T00:00:00.000Z', '2026-07-01T00:02:09.000Z')).toBe(
      '0 days 00 hours 02 minutes 09 seconds',
    );
  });
});
