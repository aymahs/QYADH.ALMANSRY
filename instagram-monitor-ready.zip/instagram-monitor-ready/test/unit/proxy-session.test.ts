/**
 * Sticky-proxy-session self-healing.
 *
 * The failure being guarded against is not "a probe errored" — it is an ALL-NIGHT SILENT OUTAGE.
 * A Decodo session expires (which the provider considers routine), the gateway then refuses every
 * CONNECT with 502, and every probe in the fleet fails at the transport. Nothing about that says
 * anything about Instagram, yet before this change it looked exactly like ordinary flakiness, so
 * the fleet went dark and stayed dark until the owner noticed by hand: harm rank 1.
 *
 * These tests therefore pin the four properties that make the cure safe rather than merely
 * present — it must FIRE on the real error shape, must NOT fire on an Instagram-origin 502, must
 * NOT open the fleet-wide circuit breaker, and must NOT leak the session token into a log.
 */

import { describe, expect, it, vi } from 'vitest';

import type { AppConfig } from '../../src/config';
import type { Logger } from '../../src/logging';
import {
  ProxySessionHealer,
  hasRotatableSession,
  isProxySessionFailure,
  rotateSessionToken,
} from '../../src/instagram/proxy-session';
import { ProxySwitch } from '../../src/instagram/proxy-switch';
import { CircuitBreaker } from '../../src/instagram/circuit-breaker';
import {
  TieredDetector,
  type TieredProbeOptions,
} from '../../src/instagram/detector/tiered-detector';
import { httpProbe, type HttpProbeOutcome } from '../../src/instagram/detector/http-probe';
import { SIGNALS_VERSION, type Detector, type DetectorResult } from '../../src/domain';

/** The real production username shape: a session token followed by another `-key-value-` pair. */
const USERNAME = 'user-account123-session-abcdefghij-sessionduration-30';

const noopLogger = {
  debug: () => undefined,
  info: () => undefined,
  warn: () => undefined,
  error: () => undefined,
} as unknown as Logger;

function configWithProxy(): AppConfig {
  return {
    controlUsername: 'nasa',
    proxyMode: 'proxy',
    browserProxy: {
      server: 'http://gate.example.com:10004',
      username: USERNAME,
      password: 'secret-password',
    },
    scheduling: { checkTimeoutMs: 15_000 },
  } as unknown as AppConfig;
}

// ---------------------------------------------------------------------------------------------
// Token rotation
// ---------------------------------------------------------------------------------------------

describe('rotateSessionToken', () => {
  it('replaces ONLY the session token, preserving every neighbouring field', () => {
    const rotated = rotateSessionToken(USERNAME);

    expect(rotated).not.toBeNull();
    const next = rotated as string;
    expect(next).not.toBe(USERNAME);
    // The account prefix and the trailing sessionduration pair must survive byte-for-byte: an
    // index-based edit would silently corrupt them the first time the plan added a field.
    expect(next.startsWith('user-account123-session-')).toBe(true);
    expect(next.endsWith('-sessionduration-30')).toBe(true);
    expect(next).not.toContain('abcdefghij');
  });

  it('handles a session token at the very end of the username', () => {
    const rotated = rotateSessionToken('user-acct-session-tail');
    expect(rotated).not.toBeNull();
    expect((rotated as string).startsWith('user-acct-session-')).toBe(true);
    expect(rotated).not.toBe('user-acct-session-tail');
  });

  it('returns null when there is no session segment, so callers can tell "nothing to do"', () => {
    expect(rotateSessionToken('plain-username')).toBeNull();
    expect(hasRotatableSession('plain-username')).toBe(false);
    expect(hasRotatableSession(null)).toBe(false);
    expect(hasRotatableSession(USERNAME)).toBe(true);
  });

  it('never returns the token it replaced, even when the minter keeps producing it', () => {
    // A rotation that "succeeded" but produced the SAME token would reconnect to the same dead
    // session and burn the caller's single retry — a silent no-op wearing a success label.
    const stubborn = (): string => 'abcdefghij';
    const rotated = rotateSessionToken(USERNAME, stubborn);
    expect(rotated).not.toBeNull();
    expect(rotated).not.toBe(USERNAME);
  });
});

// ---------------------------------------------------------------------------------------------
// Detection — the discriminator that decides whether we rotate at all
// ---------------------------------------------------------------------------------------------

describe('isProxySessionFailure', () => {
  it('sees through the `TypeError: fetch failed` wrapper Node actually throws', () => {
    // THE test. Node's fetch reports every transport fault as this bare wrapper and hides the real
    // error in `.cause`, so a matcher reading only `err.message` finds nothing — and the healing
    // would never fire in production while every unit test that built a flat error still passed.
    const real = new TypeError('fetch failed', {
      cause: new Error('Proxy response (502) !== 200 when HTTP Tunneling'),
    });
    expect(isProxySessionFailure(real)).toBe(true);
  });

  it('matches Chromium’s tunnel error from the browser tier', () => {
    const err = new Error('page.goto: net::ERR_TUNNEL_CONNECTION_FAILED at https://instagram.com/');
    expect(isProxySessionFailure(err)).toBe(true);
  });

  it('does NOT fire once a response was received — an Instagram 502 is not a gateway 502', () => {
    // Both mention 502 and they mean opposite things. Rotating on an origin error would throw away
    // a working session because Instagram hiccuped.
    const err = new Error('Proxy response (502) !== 200 when HTTP Tunneling');
    expect(isProxySessionFailure(err, true)).toBe(false);
  });

  it('does NOT fire on 407, which a new session token cannot fix', () => {
    const err = new TypeError('fetch failed', {
      cause: new Error('Proxy response (407) !== 200 when HTTP Tunneling'),
    });
    expect(isProxySessionFailure(err)).toBe(false);
  });

  it('does NOT fire on ordinary timeouts or DNS failures', () => {
    expect(isProxySessionFailure(new Error('The operation was aborted'))).toBe(false);
    expect(
      isProxySessionFailure(
        new TypeError('fetch failed', { cause: new Error('getaddrinfo ENOTFOUND') }),
      ),
    ).toBe(false);
  });
});

// ---------------------------------------------------------------------------------------------
// The transport boundary: what httpProbe reports for each shape
// ---------------------------------------------------------------------------------------------

describe('httpProbe transport classification', () => {
  it('reports PROXY_TUNNEL for a refused tunnel, not a generic NAVIGATION error', async () => {
    const fetchImpl = (): Promise<Response> =>
      Promise.reject(
        new TypeError('fetch failed', {
          cause: new Error('Proxy response (502) !== 200 when HTTP Tunneling'),
        }),
      );

    const out = await httpProbe(
      'someaccount',
      { config: {} as AppConfig, fetchImpl: fetchImpl as unknown as typeof fetch },
      1000,
    );

    expect(out.transportFailed).toBe(true);
    expect(out.result.evidence.errorCode).toBe('PROXY_TUNNEL');
  });

  it('reports a REAL Instagram 502 as a response, never as a tunnel failure', async () => {
    // The structural discriminator: this one RESOLVED, so it carries a status. It must never be
    // eligible for rotation.
    const fetchImpl = (): Promise<Response> =>
      Promise.resolve(new Response('<html><head></head><body>oops</body></html>', { status: 502 }));

    const out = await httpProbe(
      'someaccount',
      { config: {} as AppConfig, fetchImpl: fetchImpl as unknown as typeof fetch },
      1000,
    );

    expect(out.transportFailed).toBe(false);
    expect(out.result.evidence.responseStatus).toBe(502);
    expect(out.result.evidence.errorCode).not.toBe('PROXY_TUNNEL');
  });
});

// ---------------------------------------------------------------------------------------------
// The bounds
// ---------------------------------------------------------------------------------------------

describe('ProxySessionHealer bounds', () => {
  it('rate-limits a burst so concurrent failures cannot discard each other’s new session', () => {
    let now = 1_000_000;
    const healer = new ProxySessionHealer({ minIntervalMs: 30_000, now: () => now });

    expect(healer.attempt(() => true)).toBe('rotated');
    // The rest of the fleet fails at the same instant. Only the first may rotate.
    expect(healer.attempt(() => true)).toBe('rate-limited');
    expect(healer.attempt(() => true)).toBe('rate-limited');

    now += 30_000;
    expect(healer.attempt(() => true)).toBe('rotated');
  });

  it('gives up after repeated futile rotations instead of storming', () => {
    let now = 0;
    const healer = new ProxySessionHealer({ maxConsecutive: 3, minIntervalMs: 0, now: () => now });

    for (let i = 0; i < 3; i += 1) {
      now += 1;
      expect(healer.attempt(() => true)).toBe('rotated');
    }
    now += 1_000_000;
    // If three fresh sessions all failed, the session is not what is broken.
    expect(healer.attempt(() => true)).toBe('exhausted');
    expect(healer.snapshot().exhausted).toBe(true);
  });

  it('clears the give-up counter once the route works, so a later expiry still heals', () => {
    let now = 0;
    const healer = new ProxySessionHealer({ maxConsecutive: 2, minIntervalMs: 0, now: () => now });

    now += 1;
    healer.attempt(() => true);
    now += 1;
    healer.attempt(() => true);
    expect(healer.attempt(() => true)).toBe('exhausted');

    healer.noteHealthy();
    now += 1;
    // Without this, a bot that healed twice over its lifetime would refuse to heal ever again.
    expect(healer.attempt(() => true)).toBe('rotated');
  });

  it('reports "unavailable" rather than consuming a slot when there is nothing to rotate', () => {
    const healer = new ProxySessionHealer({ minIntervalMs: 0 });
    expect(healer.attempt(() => false)).toBe('unavailable');
    expect(healer.snapshot().consecutive).toBe(0);
  });
});

describe('ProxySwitch.rotateSession', () => {
  it('rotates the token and bumps the generation so cached connections rebuild', () => {
    const proxySwitch = new ProxySwitch(configWithProxy(), 'proxy');
    const before = proxySwitch.gen();

    expect(proxySwitch.canRotateSession()).toBe(true);
    expect(proxySwitch.rotateSession()).toBe(true);
    expect(proxySwitch.gen()).toBe(before + 1);
    expect(proxySwitch.state().active?.username).not.toBe(USERNAME);
    // The password and server are untouched — only the session token moves.
    expect(proxySwitch.state().active?.password).toBe('secret-password');
  });

  it('refuses — and does NOT bump the generation — on the home route', () => {
    const proxySwitch = new ProxySwitch(configWithProxy(), 'direct');
    const before = proxySwitch.gen();

    expect(proxySwitch.canRotateSession()).toBe(false);
    expect(proxySwitch.rotateSession()).toBe(false);
    // A needless bump would tear down and rebuild a perfectly good browser for nothing.
    expect(proxySwitch.gen()).toBe(before);
  });

  it('never exposes the session token through describe()', () => {
    const proxySwitch = new ProxySwitch(configWithProxy(), 'proxy');
    const described = proxySwitch.describe();
    expect(described).toContain('gate.example.com');
    expect(described).not.toContain('abcdefghij');
    expect(described).not.toContain('secret-password');
  });
});

// ---------------------------------------------------------------------------------------------
// End to end through the detector — the properties that actually protect clients
// ---------------------------------------------------------------------------------------------

/** A fast-probe outcome shaped exactly like the real one, for the given error code. */
function fastOutcome(errorCode: 'PROXY_TUNNEL' | null, identity: boolean): HttpProbeOutcome {
  const result: DetectorResult = {
    classification: identity ? 'ACTIVE' : 'UNKNOWN',
    evidence: {
      signalsVersion: SIGNALS_VERSION,
      activeSignals: [],
      goneSignals: [],
      identitySignalMatched: identity,
      finalUrl: null,
      responseStatus: identity ? 200 : null,
      errorCode,
    },
    durationMs: 1,
  };
  return { result, transportFailed: errorCode !== null, bodyTruncated: false };
}

const neverCalledBrowser: Detector = {
  probe: () => {
    throw new Error('the browser must not be reached in this test');
  },
};

describe('TieredDetector session healing', () => {
  it('rotates and retries on the fast tier instead of escalating to a doomed browser load', async () => {
    const config = configWithProxy();
    const proxySwitch = new ProxySwitch(config, 'proxy');
    const usernamesUsed: Array<string | null> = [];

    // The probe reports what the CURRENT route is at call time, so the retry provably goes out
    // over the rotated session rather than the dead one.
    const httpProbeImpl = vi.fn(async (): Promise<HttpProbeOutcome> => {
      usernamesUsed.push(proxySwitch.current()?.username ?? null);
      return usernamesUsed.length === 1
        ? fastOutcome('PROXY_TUNNEL', false)
        : fastOutcome(null, true);
    });

    const detector = new TieredDetector({
      browserDetector: neverCalledBrowser,
      config,
      logger: noopLogger,
      proxySwitch,
      httpProbeImpl: httpProbeImpl as unknown as typeof httpProbe,
    });

    // Tier-aware option: lets the cheap ACTIVE verdict stand so this test exercises the ROTATION,
    // not the (separately tested) escalation to a browser that is not wired up here.
    const options: TieredProbeOptions = { allowFastActive: true };
    const out = await detector.probe('someclient', options);

    expect(httpProbeImpl).toHaveBeenCalledTimes(2);
    expect(usernamesUsed[0]).toBe(USERNAME);
    expect(usernamesUsed[1]).not.toBe(USERNAME);
    expect(out.result.classification).toBe('ACTIVE');
  });

  it('NEVER opens the fleet-wide breaker on a dead session', async () => {
    // The property that matters most. A dead session is a transport fault; treating it as
    // throttling would blind every monitored client for the whole cooldown over something a
    // rotation fixes in a second — manufacturing harm rank 1 from a provider-side routine event.
    const config = configWithProxy();
    const proxySwitch = new ProxySwitch(config, 'proxy');
    const breaker = new CircuitBreaker({ threshold: 2 });

    const httpProbeImpl = vi.fn(async (): Promise<HttpProbeOutcome> =>
      fastOutcome('PROXY_TUNNEL', false),
    );

    // The browser sees the same dead tunnel, exactly as it would in production.
    const browserDetector: Detector = {
      probe: () =>
        Promise.resolve({ result: fastOutcome('PROXY_TUNNEL', false).result, screenshot: null }),
    };

    const detector = new TieredDetector({
      browserDetector,
      config,
      logger: noopLogger,
      proxySwitch,
      breaker,
      httpProbeImpl: httpProbeImpl as unknown as typeof httpProbe,
    });

    for (let i = 0; i < 6; i += 1) await detector.probe(`client${String(i)}`);

    expect(breaker.snapshot().state).toBe('CLOSED');
    expect(breaker.snapshot().consecutive).toBe(0);
  });

  it('stops rotating once rotation has stopped helping', async () => {
    const config = configWithProxy();
    const proxySwitch = new ProxySwitch(config, 'proxy');
    const healer = new ProxySessionHealer({ maxConsecutive: 2, minIntervalMs: 0 });

    const httpProbeImpl = vi.fn(async (): Promise<HttpProbeOutcome> =>
      fastOutcome('PROXY_TUNNEL', false),
    );
    const browserDetector: Detector = {
      probe: () =>
        Promise.resolve({ result: fastOutcome('PROXY_TUNNEL', false).result, screenshot: null }),
    };

    const detector = new TieredDetector({
      browserDetector,
      config,
      logger: noopLogger,
      proxySwitch,
      sessionHealer: healer,
      httpProbeImpl: httpProbeImpl as unknown as typeof httpProbe,
    });

    const genBefore = proxySwitch.gen();
    for (let i = 0; i < 8; i += 1) await detector.probe(`client${String(i)}`);

    // Bounded: a handful of rotations, not one per probe per tier across the whole fleet.
    expect(proxySwitch.gen() - genBefore).toBeLessThanOrEqual(2);
    expect(healer.snapshot().exhausted).toBe(true);
  });

  it('never writes the session token or the password into a log line', async () => {
    const config = configWithProxy();
    const proxySwitch = new ProxySwitch(config, 'proxy');
    const lines: string[] = [];
    const capturing = {
      debug: (m: string, c?: unknown) => lines.push(m + JSON.stringify(c ?? {})),
      info: (m: string, c?: unknown) => lines.push(m + JSON.stringify(c ?? {})),
      warn: (m: string, c?: unknown) => lines.push(m + JSON.stringify(c ?? {})),
      error: (m: string, c?: unknown) => lines.push(m + JSON.stringify(c ?? {})),
    } as unknown as Logger;

    const httpProbeImpl = vi.fn(async (): Promise<HttpProbeOutcome> =>
      fastOutcome('PROXY_TUNNEL', false),
    );
    const browserDetector: Detector = {
      probe: () =>
        Promise.resolve({ result: fastOutcome('PROXY_TUNNEL', false).result, screenshot: null }),
    };

    const detector = new TieredDetector({
      browserDetector,
      config,
      logger: capturing,
      proxySwitch,
      httpProbeImpl: httpProbeImpl as unknown as typeof httpProbe,
    });

    for (let i = 0; i < 4; i += 1) await detector.probe(`client${String(i)}`);

    expect(lines.length).toBeGreaterThan(0);
    const all = lines.join('\n');
    // The username IS a credential — it carries the session token and the account name.
    expect(all).not.toContain('abcdefghij');
    expect(all).not.toContain('secret-password');
    expect(all).not.toContain('user-account123');
  });
});
