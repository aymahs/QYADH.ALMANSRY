import { describe, it, expect } from 'vitest';
import { NetworkCorrectedClock } from '../../src/core/network-clock';

/** Build a fake fetch returning a fixed Date header. */
function fakeFetch(dateHeader: string | null): typeof fetch {
  return (async () => {
    const headers = new Headers();
    if (dateHeader !== null) headers.set('date', dateHeader);
    return new Response(null, { status: 200, headers });
  }) as unknown as typeof fetch;
}

describe('NetworkCorrectedClock', () => {
  it('corrects a real multi-hour host-clock skew (observed: dev box 4.5h fast)', async () => {
    // Trusted server time is ~4.5h behind the local machine -> a genuinely wrong host clock
    // (a cached Date is only seconds/minutes stale), so the offset MUST be applied.
    const serverMs = Date.now() - 4.5 * 3600 * 1000;
    const clock = new NetworkCorrectedClock(fakeFetch(new Date(serverMs).toUTCString()));
    const res = await clock.sync('https://example.test');
    expect(res.ok).toBe(true);
    expect(res.offsetMs).toBeLessThan(-4.4 * 3600 * 1000);
    expect(res.offsetMs).toBeGreaterThan(-4.6 * 3600 * 1000);
    expect(clock.now().getTime()).toBeLessThan(Date.now() - 4 * 3600 * 1000);
  });

  it('rejects an absurd (>24h) delta as a broken source, not real skew', async () => {
    const serverMs = Date.now() - 30 * 3600 * 1000;
    const clock = new NetworkCorrectedClock(fakeFetch(new Date(serverMs).toUTCString()));
    const res = await clock.sync('https://example.test');
    expect(res.ok).toBe(false);
    expect(res.offsetMs).toBe(0);
  });

  it('ignores sub-30s skew (trusts a well-synced host)', async () => {
    const clock = new NetworkCorrectedClock(fakeFetch(new Date().toUTCString()));
    const res = await clock.sync('https://example.test');
    expect(res.ok).toBe(true);
    expect(res.offsetMs).toBe(0);
    expect(clock.appliedOffsetMs).toBe(0);
  });

  it('keeps the previous offset and reports failure on a missing/invalid header', async () => {
    const clock = new NetworkCorrectedClock(fakeFetch(null));
    const res = await clock.sync('https://example.test');
    expect(res.ok).toBe(false);
    expect(res.offsetMs).toBe(0);
  });

  it('swallows fetch errors without throwing', async () => {
    const throwing = (async () => {
      throw new Error('network down');
    }) as unknown as typeof fetch;
    const clock = new NetworkCorrectedClock(throwing);
    const res = await clock.sync('https://example.test');
    expect(res.ok).toBe(false);
  });
});
