import { describe, it, expect } from 'vitest';

import { CommandRouter, parseCommand } from '../../src/bot/commands';
import { OwnerAuthorizer } from '../../src/bot/authorization';
import { MockTelegramClient } from '../../src/bot/telegram-client';
import { loadConfig } from '../../src/config';
import { ACTIVE_SIGNALS, FixedClock, LISTED_STATUSES } from '../../src/domain';
import type { Repositories, TelegramChatType, TelegramUpdate } from '../../src/domain';
import { nullLogger } from '../../src/logging/logger';
import type { AppConfig } from '../../src/config';
import type { BulkPrecheckLimits } from '../../src/bot/commands/router';
import type { FastTierReport } from '../../src/instagram/detector/tiered-detector';
import { ProxySwitch } from '../../src/instagram/proxy-switch';
import type { ProxyMode } from '../../src/instagram/proxy-switch';
import { FakeDetector } from '../helpers/fake-detector';
import { FakeDatabase, makeFakeDb } from '../helpers/fake-repos';

const NOW = new Date('2026-07-17T12:00:00.000Z');
const OWNER_ID = 111;
const STRANGER_ID = 999;
const PAIRING_SECRET = 'pair-secret-123';

const TEST_ENV = {
  TELEGRAM_BOT_TOKEN: '123456789:AAtesttokenAAAAAAAAAAAAAAAAAAAAAAAA',
  OWNER_PAIRING_SECRET: PAIRING_SECRET,
};

interface Harness {
  router: CommandRouter;
  client: MockTelegramClient;
  repos: Repositories;
  db: FakeDatabase;
  detector: FakeDetector;
  clock: FixedClock;
}

/**
 * A detector that also implements the fast-tier diagnostics surface, so /ping can be driven
 * through the reporting path a real {@link TieredDetector} exposes.
 */
class DiagnosticFakeDetector extends FakeDetector {
  fastTier: FastTierReport = {
    state: 'ok',
    detail: 'the control account resolves over the current egress route',
    canaryHealthy: true,
    breakerState: 'CLOSED',
    breakerRetryAfterMs: 0,
    answered: { fast: 0, browser: 0, blocked: 0, deferred: 0 },
    consecutiveEscalations: 0,
    browserBudget: null,
  };
  /** Counts calls, so a test can prove /ping does NOT pay for a second browser load. */
  reports = 0;

  breakerSnapshot(): {
    state: 'CLOSED' | 'OPEN' | 'HALF_OPEN';
    consecutive: number;
    retryAfterMs: number;
  } {
    return {
      state: this.fastTier.breakerState,
      consecutive: 0,
      retryAfterMs: this.fastTier.breakerRetryAfterMs,
    };
  }

  browserBudget(): FastTierReport['browserBudget'] {
    return this.fastTier.browserBudget;
  }

  fastTierReport(): Promise<FastTierReport> {
    this.reports += 1;
    return Promise.resolve(this.fastTier);
  }
}

/**
 * A detector whose fast-tier report follows the route the shared ProxySwitch is ACTUALLY on when
 * it is asked — which is how Instagram behaves (per IP), and the whole reason `/proxy` has to
 * measure rather than report from a boolean.
 *
 * The test never states the verdict for a given reply. It states which routes the network serves;
 * the verdict follows from the route the handler selected, so a handler that verified the WRONG
 * route (or never switched at all) fails.
 */
class RouteAwareDetector extends FakeDetector {
  /** The route in force for each fast-tier report, in order. */
  readonly seen: ProxyMode[] = [];

  constructor(
    private readonly proxySwitch: ProxySwitch,
    private readonly serving: readonly ProxyMode[],
  ) {
    super();
  }

  breakerSnapshot(): {
    state: 'CLOSED' | 'OPEN' | 'HALF_OPEN';
    consecutive: number;
    retryAfterMs: number;
  } {
    return { state: 'CLOSED', consecutive: 0, retryAfterMs: 0 };
  }

  browserBudget(): FastTierReport['browserBudget'] {
    return null;
  }

  fastTierReport(): Promise<FastTierReport> {
    const route = this.proxySwitch.state().mode;
    this.seen.push(route);
    const healthy = this.serving.includes(route);
    return Promise.resolve({
      state: healthy ? 'ok' : 'degraded',
      detail: healthy
        ? 'the control account resolves over the current egress route'
        : 'the control account did not resolve over the current egress route (HTTP_429)',
      canaryHealthy: healthy,
      breakerState: 'CLOSED',
      breakerRetryAfterMs: 0,
      answered: { fast: 0, browser: 0, blocked: 0, deferred: 0 },
      consecutiveEscalations: 0,
      browserBudget: null,
    });
  }
}

async function setup(options?: {
  pairOwner?: boolean;
  detector?: FakeDetector;
  config?: AppConfig;
  proxySwitch?: ProxySwitch;
  bulkPrecheckLimits?: Partial<BulkPrecheckLimits>;
}): Promise<Harness> {
  const clock = new FixedClock(NOW);
  const { db, repos } = makeFakeDb();
  const client = new MockTelegramClient();
  const detector = options?.detector ?? new FakeDetector();
  const config = options?.config ?? loadConfig(TEST_ENV);
  const auth = new OwnerAuthorizer({
    owner: repos.owner,
    pairingSecret: config.ownerPairingSecret,
    logger: nullLogger(),
  });
  if (options?.pairOwner !== false) {
    await repos.owner.claimOwner(OWNER_ID, NOW.toISOString());
  }
  const router = new CommandRouter({
    client,
    repos,
    db,
    detector,
    auth,
    config,
    clock,
    logger: nullLogger(),
    ...(options?.proxySwitch !== undefined ? { proxySwitch: options.proxySwitch } : {}),
    // Pacing exists to protect a real residential IP; in tests it would only add wall time.
    bulkPrecheckLimits: options?.bulkPrecheckLimits ?? { spacingMs: 0 },
  });
  return { router, client, repos, db, detector, clock };
}

let updateIdCounter = 1;

function update(
  text: string,
  opts?: { userId?: number; chatType?: TelegramChatType; updateId?: number },
): TelegramUpdate {
  const userId = opts?.userId ?? OWNER_ID;
  return {
    update_id: opts?.updateId ?? updateIdCounter++,
    message: {
      message_id: 1,
      from: { id: userId, is_bot: false, first_name: 'Tester' },
      chat: { id: userId, type: opts?.chatType ?? 'private' },
      date: Math.floor(NOW.getTime() / 1000),
      text,
    },
  };
}

function lastReply(client: MockTelegramClient): string {
  const last = client.sentMessages[client.sentMessages.length - 1];
  return last?.text ?? '';
}

/** Seed a fresh scheduler health row so /ping does not flag the scheduler. */
async function seedFreshSchedulerHealth(repos: Repositories, lastRunIso: string): Promise<void> {
  await repos.health.upsert({
    name: 'scheduler',
    lastSchedulerRunUtc: lastRunIso,
    lastSuccessfulCheckUtc: lastRunIso,
    lastControlOkUtc: lastRunIso,
    recentUnknownRate: 0,
    browserRestarts: 0,
    detectorUnhealthy: false,
    lastWarningSentUtc: null,
    updatedAtUtc: lastRunIso,
  });
}

describe('parseCommand', () => {
  it('parses /cmd, /cmd@BotName, and trims args', () => {
    expect(parseCommand('/unban natgeo')).toEqual({ command: 'unban', args: 'natgeo' });
    expect(parseCommand('/unban@MyMonitorBot  natgeo ')).toEqual({
      command: 'unban',
      args: 'natgeo',
    });
    expect(parseCommand('/PING')).toEqual({ command: 'ping', args: '' });
  });

  it('returns null for non-commands', () => {
    expect(parseCommand('hello there')).toBeNull();
    expect(parseCommand('')).toBeNull();
    expect(parseCommand('unban natgeo')).toBeNull();
  });
});

describe('CommandRouter', () => {
  it('deduplicates by update_id: the same update twice yields one reply', async () => {
    const { router, client } = await setup();
    const u = update('/list', { updateId: 42 });
    await router.handleUpdate(u);
    await router.handleUpdate(u);
    expect(client.sentMessages).toHaveLength(1);
  });

  it('ignores group chat messages entirely', async () => {
    const { router, client } = await setup();
    await router.handleUpdate(update('/list', { chatType: 'group' }));
    await router.handleUpdate(update('/unban natgeo', { chatType: 'supergroup' }));
    expect(client.sentMessages).toHaveLength(0);
  });

  it('ignores edited messages and bot senders', async () => {
    const { router, client } = await setup();
    const edited: TelegramUpdate = {
      update_id: updateIdCounter++,
      edited_message: {
        message_id: 2,
        from: { id: OWNER_ID, is_bot: false },
        chat: { id: OWNER_ID, type: 'private' },
        date: Math.floor(NOW.getTime() / 1000),
        text: '/list',
      },
    };
    await router.handleUpdate(edited);
    const fromBot = update('/list');
    if (fromBot.message?.from) fromBot.message.from.is_bot = true;
    await router.handleUpdate(fromBot);
    expect(client.sentMessages).toHaveLength(0);
  });

  it('replies notAuthorized to a stranger and creates no case', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(update('/unban natgeo', { userId: STRANGER_ID }));
    expect(lastReply(client)).toContain('Not authorized');
    await expect(repos.cases.findActiveByNormalizedUsername('natgeo')).resolves.toBeNull();
  });

  it('/start with the correct secret pairs and replies with the guide', async () => {
    const { router, client } = await setup({ pairOwner: false });
    await router.handleUpdate(update(`/start ${PAIRING_SECRET}`, { userId: OWNER_ID }));
    const texts = client.sentMessages.map((m) => m.text).join('\n---\n');
    expect(texts).toContain('Paired');
    expect(texts).toContain('مرحباً بك في نظام مراقبة الحسابات.');
    expect(texts).toContain('@r.nmc');
  });

  it('/start with a wrong secret replies pairing failed', async () => {
    const { router, client } = await setup({ pairOwner: false });
    await router.handleUpdate(update('/start not-the-secret', { userId: STRANGER_ID }));
    expect(lastReply(client)).toContain('Pairing failed');
  });

  // DEFECT D(a). Telegram sends a bare /start automatically when anyone opens the bot, so
  // counting it as a guess let ordinary traffic burn the brute-force budget. Answering it with
  // "this bot has no owner yet" fixed that but volunteered the one fact worth hiding — that the
  // pairing endpoint is real and still claimable — to every casual visitor, for free.
  it('a bare /start spends no brute-force budget and never says the bot is unclaimed', async () => {
    const { router, client } = await setup({ pairOwner: false });
    for (let i = 0; i < 30; i += 1) {
      await router.handleUpdate(update('/start', { userId: STRANGER_ID + i }));
    }
    const texts = client.sentMessages.map((m) => m.text).join('\n');
    expect(texts).not.toContain('no owner yet');
    expect(texts).not.toContain('pairing secret');
    // Same wording a wrong code gets: ambiguous between "invalid" and "already paired".
    expect(lastReply(client)).toContain('Pairing failed');

    // The owner can still pair afterwards: none of that traffic was counted.
    await router.handleUpdate(update(`/start ${PAIRING_SECRET}`, { userId: OWNER_ID }));
    expect(client.sentMessages.map((m) => m.text).join('\n')).toContain('Paired');
  });

  it.each(['natgeo', 'NatGeo', '@natgeo', 'https://www.instagram.com/NatGeo/?hl=en'])(
    '/unban %s creates one case with normalized lowercase username',
    async (input) => {
      const { router, client, repos, detector } = await setup();
      // A CONCLUSIVE pre-check, so this exercises the verified reply. Without one the account is
      // still enrolled, but reported as "not pre-checked" — a different message on purpose.
      detector.queue('natgeo', 'GONE');
      await router.handleUpdate(update(`/unban ${input}`));

      expect(lastReply(client)).toContain('Monitoring Started');
      expect(lastReply(client)).toContain('@natgeo');
      const active = await repos.cases.findActiveByNormalizedUsername('natgeo');
      expect(active).not.toBeNull();
      expect(active?.normalizedUsername).toBe('natgeo');
      const all = await repos.cases.listByStatuses(LISTED_STATUSES);
      expect(all).toHaveLength(1);
      // Immediate initial check is queued for the scheduler, not run inline.
      expect(active?.nextCheckAtUtc).toBe(NOW.toISOString());
    },
  );

  it('duplicate /unban replies Already Monitoring and keeps exactly one case', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(update('/unban natgeo'));
    await router.handleUpdate(update('/unban @NATGEO'));

    expect(lastReply(client)).toContain('Already Monitoring');
    const all = await repos.cases.listByStatuses(LISTED_STATUSES);
    expect(all).toHaveLength(1);
  });

  it('/bulkunban acknowledges immediately, then posts exactly ONE summary', async () => {
    const { router, client, repos, detector } = await setup();
    // A conclusive pre-check on every name, so this exercises the VERIFIED reporting path.
    for (const name of ['natgeo', 'nasa', 'spacex', 'bmw']) detector.queue(name, 'GONE');
    await router.handleUpdate(update('/bulkunban natgeo, nasa\nspacex bmw'));
    // The handler returns as soon as it has acknowledged: the polling loop awaits handlers one
    // at a time, so a batch of live probes inline would freeze ALL Telegram ingress.
    expect(client.sentMessages).toHaveLength(1);
    expect(lastReply(client)).toContain('Checking 4 accounts');
    expect(await repos.cases.listByStatuses(LISTED_STATUSES)).toHaveLength(0);

    await router.whenIdle();
    expect(client.sentMessages).toHaveLength(2); // ack + one consolidated summary
    expect(lastReply(client)).toContain('Bulk Monitoring Started');
    expect(lastReply(client)).toContain('Now monitoring 4 new accounts');
    expect(lastReply(client)).not.toContain('NOT pre-checked');
    expect(await repos.cases.listByStatuses(LISTED_STATUSES)).toHaveLength(4);
  });

  // DEFECT E, surviving half. Every non-ACTIVE probe was collapsed into "not currently public",
  // so an UNKNOWN — a login wall, a challenge, a navigation timeout, an off-network breaker
  // result; none of which throw — was enrolled and reported under "CONFIRMED not currently
  // public by a live pre-check". If such an account was in fact already public, the scheduler
  // confirms it ACTIVE within a minute and fires a false "ACCOUNT UNBANNED" at the client.
  it('/bulkunban never reports an inconclusive probe as pre-checked', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('natgeo', 'GONE'); // conclusive
    detector.queue('nasa', 'UNKNOWN'); // a failed observation, NOT evidence of being banned

    await router.handleUpdate(update('/bulkunban natgeo nasa'));
    await router.whenIdle();

    const text = lastReply(client);
    expect(text).toContain('❓ Monitoring, but NOT pre-checked (1)');
    expect(text).toContain('@nasa');
    // Both are still enrolled — a missed recovery is worse than a false one — and the probe did
    // happen, so this is about how it is REPORTED, not about refusing to monitor.
    expect(detector.probes).toHaveLength(2);
    expect(await repos.cases.listByStatuses(LISTED_STATUSES)).toHaveLength(2);
  });

  it('/bulkunban de-dupes, skips already-monitored and invalid, still one summary', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(update('/unban natgeo')); // pre-existing
    await router.whenIdle();
    const before = client.sentMessages.length;
    await router.handleUpdate(update('/bulkunban natgeo natgeo nasa bad__name!!'));
    await router.whenIdle();
    expect(client.sentMessages.length).toBe(before + 2); // ack + exactly one summary
    expect(lastReply(client)).toContain('Already monitoring');
    expect(lastReply(client)).toContain('Skipped');
    expect(await repos.cases.findActiveByNormalizedUsername('nasa')).not.toBeNull();
    // natgeo (already) + nasa (new); dupe natgeo ignored; invalid skipped.
    expect(await repos.cases.listByStatuses(LISTED_STATUSES)).toHaveLength(2);
  });

  // DEFECT E. The pre-check SELF-CANCELLED at scale: the burst tripped the shared breaker, every
  // remaining probe came back UNKNOWN without touching the network, and the tail of the batch was
  // enrolled with no pre-check at all — silently reported as if it had been checked.
  it('/bulkunban reports "not pre-checked" separately when the breaker is open', async () => {
    const detector = new DiagnosticFakeDetector();
    detector.fastTier = { ...detector.fastTier, breakerState: 'OPEN' };
    const { router, client, repos } = await setup({ detector });

    await router.handleUpdate(update('/bulkunban natgeo nasa'));
    await router.whenIdle();

    const text = lastReply(client);
    expect(text).toContain('❓ Monitoring, but NOT pre-checked (2)');
    expect(text).toContain('fleet-wide back-off');
    // Not probed at all: an open breaker means "leave the network alone", not "probe anyway".
    expect(detector.probes).toHaveLength(0);
    // Still enrolled — a missed recovery is worse than a false one — but never called verified.
    expect(await repos.cases.listByStatuses(LISTED_STATUSES)).toHaveLength(2);
    expect(text).not.toContain('Already active, not monitored');
  });

  it('/bulkunban buckets an already-public account away from the verified ones', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('nasa', 'ACTIVE');
    detector.queue('natgeo', 'GONE');

    await router.handleUpdate(update('/bulkunban natgeo nasa'));
    await router.whenIdle();

    const text = lastReply(client);
    expect(text).toContain('Already active, not monitored');
    expect(text).toContain('@nasa');
    expect(text).not.toContain('NOT pre-checked');
    expect(await repos.cases.findActiveByNormalizedUsername('nasa')).toBeNull();
    expect(await repos.cases.findActiveByNormalizedUsername('natgeo')).not.toBeNull();
  });

  it('/bulkunban never runs more than the configured number of probes at once', async () => {
    const { router, detector } = await setup({
      bulkPrecheckLimits: { spacingMs: 0, concurrency: 2 },
    });
    let inFlight = 0;
    let peak = 0;
    const realProbe = detector.probe.bind(detector);
    detector.probe = async (username, options): Promise<Awaited<ReturnType<typeof realProbe>>> => {
      inFlight += 1;
      peak = Math.max(peak, inFlight);
      await new Promise((resolve) => setTimeout(resolve, 1));
      inFlight -= 1;
      return realProbe(username, options);
    };

    const names = Array.from({ length: 12 }, (_, i) => `acct${i}`).join(' ');
    await router.handleUpdate(update(`/bulkunban ${names}`));
    await router.whenIdle();

    expect(peak).toBeLessThanOrEqual(2);
    expect(detector.probes).toHaveLength(12);
  });

  it('/bulkunban stops at its deadline and reports the remainder as unverified', async () => {
    const { router, client, repos, detector } = await setup({
      bulkPrecheckLimits: { spacingMs: 0, concurrency: 1, deadlineMs: 0 },
    });
    await router.handleUpdate(update('/bulkunban natgeo nasa'));
    await router.whenIdle();

    const text = lastReply(client);
    expect(text).toContain('NOT pre-checked');
    expect(text).toContain('time limit');
    expect(detector.probes).toHaveLength(0);
    // Enrolled regardless: refusing on a transient failure would lose the recovery entirely.
    expect(await repos.cases.listByStatuses(LISTED_STATUSES)).toHaveLength(2);
  });

  it('/bulkunban with no args shows usage', async () => {
    const { router, client } = await setup();
    await router.handleUpdate(update('/bulkunban'));
    expect(lastReply(client)).toContain('Usage: /bulkunban');
  });

  it('/unban with a backdate stores the IST wall clock as the right UTC instant', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('natgeo', 'GONE'); // conclusive pre-check -> the ordinary acceptance reply
    await router.handleUpdate(update('/unban natgeo 2026-07-15 18:30'));

    expect(lastReply(client)).toContain('Monitoring Started');
    const active = await repos.cases.findActiveByNormalizedUsername('natgeo');
    expect(active?.startedAtUtc).toBe('2026-07-15T13:00:00.000Z');
  });

  it('/unban with a future backdate is rejected', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(update('/unban natgeo 2026-07-18 10:00'));
    expect(lastReply(client)).toContain('future');
    await expect(repos.cases.findActiveByNormalizedUsername('natgeo')).resolves.toBeNull();
  });

  it('/unban of the control username is refused and creates no case', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(update('/unban instagram'));
    expect(lastReply(client)).toContain('control account');
    await expect(repos.cases.findActiveByNormalizedUsername('instagram')).resolves.toBeNull();
  });

  it('/unban with an invalid username replies the validation error', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(update('/unban bad..name'));
    expect(lastReply(client)).toContain('valid Instagram username');
    const all = await repos.cases.listByStatuses(LISTED_STATUSES);
    expect(all).toHaveLength(0);
  });

  it('/clear removes the case (CLEARED, next check null); second /clear says Not Found', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(update('/unban natgeo'));
    const created = await repos.cases.findActiveByNormalizedUsername('natgeo');

    await router.handleUpdate(update('/clear natgeo'));
    expect(lastReply(client)).toContain('Monitoring Removed');
    const cleared = created ? await repos.cases.findById(created.id) : null;
    expect(cleared?.status).toBe('CLEARED');
    expect(cleared?.nextCheckAtUtc).toBeNull();

    await router.handleUpdate(update('/clear natgeo'));
    expect(lastReply(client)).toContain('Not Found');
  });

  it('/list replies the empty message when nothing is monitored', async () => {
    const { router, client } = await setup();
    await router.handleUpdate(update('/list'));
    expect(lastReply(client)).toContain('No Instagram accounts are currently being monitored');
  });

  it('/list shows both cases with their statuses, including Confirming 2/3', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(update('/unban first_user'));
    await router.handleUpdate(update('/unban second_user'));

    const second = await repos.cases.findActiveByNormalizedUsername('second_user');
    expect(second).not.toBeNull();
    if (second) {
      await repos.cases.save({ ...second, status: 'CONFIRMING', confirmationCount: 2 });
    }

    await router.handleUpdate(update('/list'));
    const text = lastReply(client);
    // Compact one-line-per-account format, grouped by status (the Discord shape).
    expect(text).toContain('@first_user');
    expect(text).toContain('@second_user · 2/3');
    expect(text).toContain('🟢 Monitoring: 1');
    expect(text).toContain('🟡 Confirming: 1');
    expect(text).not.toContain('Page ');
  });

  it('/ping healthy: ACTIVE control probe with screenshot and fresh scheduler', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('instagram', 'ACTIVE');
    await seedFreshSchedulerHealth(repos, NOW.toISOString());

    await router.handleUpdate(update('/ping'));

    expect(lastReply(client)).toContain('Monitoring System Healthy');
    // DEFECT C: exactly ONE browser page load. The fast tier is asked about itself, not probed
    // through — the second probe used to always escalate (the control account is live), so /ping
    // cost two Chromium loads and two breaker outcomes against a ~200 loads/hour budget.
    expect(detector.probes).toHaveLength(1);
    expect(detector.probes[0]?.username).toBe('instagram');
    expect(detector.probes[0]?.options?.captureScreenshot).toBe(true);
    // Never creates a monitoring case for the control account.
    await expect(repos.cases.findActiveByNormalizedUsername('instagram')).resolves.toBeNull();
  });

  // DEFECT C. `fastOk` was derived from the classification of whichever tier answered, and the
  // tiered detector returns the BROWSER's ACTIVE verdict on every fast-tier failure — so a
  // completely dead fast tier printed "Fast probe: Working".
  it('/ping reports the fast tier as DEGRADED when it fails but the browser succeeds', async () => {
    const detector = new DiagnosticFakeDetector();
    detector.fastTier = {
      ...detector.fastTier,
      state: 'degraded',
      detail: 'the control account did not resolve over the current egress route (LOGIN_WALL)',
      canaryHealthy: false,
    };
    const { router, client, repos } = await setup({ detector });
    detector.queue('instagram', 'ACTIVE'); // the BROWSER still resolves it perfectly
    await seedFreshSchedulerHealth(repos, NOW.toISOString());

    await router.handleUpdate(update('/ping'));

    const text = lastReply(client);
    expect(text).toContain('Monitoring System Unhealthy');
    expect(text).toContain('Fast probe: DEGRADED');
    expect(text).toContain('LOGIN_WALL');
    expect(text).not.toContain('Fast probe: Working');
    // Still only one browser load, even on the unhealthy path.
    expect(detector.probes).toHaveLength(1);
    expect(detector.reports).toBe(1);
  });

  it('/ping surfaces the canary state on the healthy path', async () => {
    const detector = new DiagnosticFakeDetector();
    const { router, client, repos } = await setup({ detector });
    detector.queue('instagram', 'ACTIVE');
    await seedFreshSchedulerHealth(repos, NOW.toISOString());

    await router.handleUpdate(update('/ping'));

    const text = lastReply(client);
    expect(text).toContain('Fast probe: Working');
    expect(text).toContain('Egress canary: Serving live profiles');
  });

  // DEFECT C, surviving half. The per-tier counters were computed, returned, documented as
  // "Reported by /ping" — and then read by nobody, so the one number that exposes a fast tier
  // escalating everything to Chromium never reached the owner.
  it('/ping prints which tier is actually carrying the checks', async () => {
    const detector = new DiagnosticFakeDetector();
    detector.fastTier = {
      ...detector.fastTier,
      answered: { fast: 900, browser: 12, blocked: 0, deferred: 0 },
    };
    const { router, client, repos } = await setup({ detector });
    detector.queue('instagram', 'ACTIVE');
    await seedFreshSchedulerHealth(repos, NOW.toISOString());

    await router.handleUpdate(update('/ping'));

    expect(lastReply(client)).toContain('Fast probe: Working — answered 900 of 912 checks');
  });

  it('/ping names fleet back-off plainly instead of probing through an open breaker', async () => {
    const detector = new DiagnosticFakeDetector();
    detector.fastTier = {
      ...detector.fastTier,
      state: 'blocked',
      detail: 'fleet-wide back-off engaged (circuit breaker OPEN)',
      breakerState: 'OPEN',
      breakerRetryAfterMs: 300_000,
    };
    const { router, client, repos } = await setup({ detector });
    detector.queue('instagram', 'ACTIVE');
    await seedFreshSchedulerHealth(repos, NOW.toISOString());

    await router.handleUpdate(update('/ping'));

    const text = lastReply(client);
    expect(text).toContain('Monitoring System Unhealthy');
    expect(text).toContain('Egress back-off');
    expect(text).toContain('retrying in 300s');
  });

  it('/ping healthy: login-gated ACTIVE control (no screenshot, not rendered) stays healthy, notes "Limited"', async () => {
    const { router, client, repos, detector } = await setup();
    // Instagram serves the control profile as a login redirect that still carries its identity
    // metadata: classifies ACTIVE, but there is no visible profile so no screenshot is captured.
    detector.queue('instagram', {
      classification: 'ACTIVE',
      screenshot: null,
      activeSignals: [ACTIVE_SIGNALS.URL_ON_USERNAME_PATH, ACTIVE_SIGNALS.CANONICAL_MATCHES],
    });
    await seedFreshSchedulerHealth(repos, NOW.toISOString());

    await router.handleUpdate(update('/ping'));

    const text = lastReply(client);
    expect(text).toContain('Monitoring System Healthy');
    expect(text).toContain('Screenshot capture: Limited');
  });

  it('/ping unhealthy: a visibly-rendered ACTIVE control with no screenshot flags Screenshot capture', async () => {
    const { router, client, repos, detector } = await setup();
    // The page actually rendered (profile structures + not redirected) but capture produced
    // nothing — that is a genuine screenshot-subsystem fault and must fail the health check.
    detector.queue('instagram', {
      classification: 'ACTIVE',
      screenshot: null,
      activeSignals: [
        ACTIVE_SIGNALS.PROFILE_STRUCTURES_RENDERED,
        ACTIVE_SIGNALS.NOT_REDIRECTED_AWAY,
      ],
    });
    await seedFreshSchedulerHealth(repos, NOW.toISOString());

    await router.handleUpdate(update('/ping'));

    const text = lastReply(client);
    expect(text).toContain('Monitoring System Unhealthy');
    expect(text).toContain('Screenshot capture');
  });

  it('/ping unhealthy: UNKNOWN detector result names the detector', async () => {
    const { router, client, repos } = await setup();
    // Detector defaults to UNKNOWN when nothing is queued.
    await seedFreshSchedulerHealth(repos, NOW.toISOString());

    await router.handleUpdate(update('/ping'));

    const text = lastReply(client);
    expect(text).toContain('Monitoring System Unhealthy');
    expect(text).toContain('Instagram detector: UNKNOWN');
    await expect(repos.cases.findActiveByNormalizedUsername('instagram')).resolves.toBeNull();
  });

  it('/ping unhealthy: a stale scheduler timestamp names the Scheduler', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('instagram', 'ACTIVE');
    // Threshold is 2 * 60s + 60s = 180s; 200s ago is stale.
    const stale = new Date(NOW.getTime() - 200_000).toISOString();
    await seedFreshSchedulerHealth(repos, stale);

    await router.handleUpdate(update('/ping'));

    const text = lastReply(client);
    expect(text).toContain('Monitoring System Unhealthy');
    expect(text).toContain('Scheduler');
    expect(text).not.toContain('Instagram detector');
  });

  it('/ping unhealthy: a failing database ping names the Database', async () => {
    const { router, client, repos, db, detector } = await setup();
    detector.queue('instagram', 'ACTIVE');
    await seedFreshSchedulerHealth(repos, NOW.toISOString());
    db.pingResult = false;

    await router.handleUpdate(update('/ping'));

    const text = lastReply(client);
    expect(text).toContain('Monitoring System Unhealthy');
    expect(text).toContain('Database');
  });

  it('unknown commands get a brief help reply for the owner only', async () => {
    const { router, client } = await setup();
    await router.handleUpdate(update('/bogus'));
    expect(lastReply(client)).toContain('Unknown command');

    const before = client.sentMessages.length;
    await router.handleUpdate(update('/bogus', { userId: STRANGER_ID }));
    expect(client.sentMessages).toHaveLength(before);
  });

  it('never throws when a repository fails; owner gets a generic error reply', async () => {
    const { router, client, repos } = await setup();
    const failing = repos.cases;
    failing.listByStatuses = async () => {
      throw new Error('boom');
    };
    await expect(router.handleUpdate(update('/list'))).resolves.toBeUndefined();
    expect(lastReply(client)).toContain('Something went wrong');
  });
});

describe('/check', () => {
  it('active profile: returns diagnostic evidence and does not send a recovery notification', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('rahil05_', 'ACTIVE');

    await router.handleUpdate(update('/check rahil05_'));

    // Acknowledgement first, then a diagnostic result.
    expect(client.sentMessages.some((m) => m.text.includes('Checking @rahil05_'))).toBe(true);
    // A /check on an ACTIVE profile now sends the captured screenshot as visual proof — this
    // is a live-check image, NOT a recovery notification (no monitoring case is created).
    expect(client.sentPhotos).toHaveLength(1);
    expect(lastReply(client)).toContain('Result: ACTIVE');
    expect(lastReply(client)).toContain('Screenshot capture: Working');
    expect(detector.probes[0]?.options?.captureScreenshot).toBe(true);
    // One-off check: never creates a monitoring case.
    await expect(repos.cases.findActiveByNormalizedUsername('rahil05_')).resolves.toBeNull();
  });

  it('gone profile: returns diagnostic evidence, no photo, no case', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('gone_user', 'GONE');

    await router.handleUpdate(update('/check gone_user'));

    expect(client.sentPhotos).toHaveLength(0);
    expect(lastReply(client)).toContain('Result: GONE');
    expect(lastReply(client)).toContain('Unavailable message: Yes');
    await expect(repos.cases.findActiveByNormalizedUsername('gone_user')).resolves.toBeNull();
  });

  it('unknown result: returns an honest diagnostic, no photo', async () => {
    const { router, client, detector } = await setup();
    // FakeDetector defaults to UNKNOWN when nothing is queued.
    void detector;

    await router.handleUpdate(update('/check someuser'));

    expect(client.sentPhotos).toHaveLength(0);
    expect(lastReply(client)).toContain('Result: UNKNOWN');
    expect(lastReply(client)).toContain('UNKNOWN_ERROR');
  });

  it('accepts @username and URL forms, requires an argument, rejects non-owners', async () => {
    const { router, client, detector } = await setup();
    detector.queue('natgeo', 'ACTIVE');
    await router.handleUpdate(update('/check https://www.instagram.com/natgeo/'));
    expect(client.sentPhotos).toHaveLength(1); // ACTIVE check sends the screenshot as proof
    expect(lastReply(client)).toContain('Result: ACTIVE');

    await router.handleUpdate(update('/check'));
    expect(lastReply(client)).toContain('Usage: /check');

    const photosBefore = client.sentPhotos.length;
    const msgsBefore = client.sentMessages.length;
    await router.handleUpdate(update('/check natgeo', { userId: STRANGER_ID }));
    expect(client.sentPhotos).toHaveLength(photosBefore);
    expect(client.sentMessages[client.sentMessages.length - 1]?.text).toContain('Not authorized');
    expect(client.sentMessages.length).toBe(msgsBefore + 1);
  });
});

describe('/ban, /banlist, /unwatch (deletion watches — separate from /unban)', () => {
  it('/ban on a currently-ACTIVE account starts a watch', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('natgeo', 'ACTIVE'); // must be live now to watch for deletion
    await router.handleUpdate(update('/ban natgeo'));
    expect(lastReply(client)).toContain('DELETION WATCH STARTED');
    expect(lastReply(client)).toContain('@natgeo');
    expect(await repos.deletionWatches.findActiveByNormalizedUsername('natgeo')).not.toBeNull();
  });

  it('/ban on an already-GONE account is rejected and creates no watch', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('firearms', 'GONE');
    await router.handleUpdate(update('/ban firearms'));
    expect(lastReply(client)).toContain('already inactive');
    expect(await repos.deletionWatches.findActiveByNormalizedUsername('firearms')).toBeNull();
  });

  it('/ban when the account cannot be confirmed active (UNKNOWN) is rejected', async () => {
    const { router, client, repos } = await setup();
    // FakeDetector defaults to UNKNOWN when nothing is queued.
    await router.handleUpdate(update('/ban someuser'));
    expect(lastReply(client)).toContain("Couldn't confirm");
    expect(await repos.deletionWatches.findActiveByNormalizedUsername('someuser')).toBeNull();
  });

  it('duplicate /ban replies Already watching and keeps exactly one watch', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('natgeo', 'ACTIVE');
    await router.handleUpdate(update('/ban natgeo'));
    await router.handleUpdate(update('/ban @NATGEO')); // already watching -> no probe needed
    expect(lastReply(client)).toContain('Already watching');
    expect(await repos.deletionWatches.listActive()).toHaveLength(1);
  });

  it('/banlist shows active watches; /unwatch clears one', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('natgeo', 'ACTIVE');
    await router.handleUpdate(update('/ban natgeo'));
    await router.handleUpdate(update('/banlist'));
    expect(lastReply(client)).toContain('Deletion Watches');
    expect(lastReply(client)).toContain('@natgeo');

    await router.handleUpdate(update('/unwatch natgeo'));
    expect(lastReply(client)).toContain('Stopped watching');
    expect(await repos.deletionWatches.findActiveByNormalizedUsername('natgeo')).toBeNull();
  });

  it('/banlist empty state', async () => {
    const { router, client } = await setup();
    await router.handleUpdate(update('/banlist'));
    expect(lastReply(client)).toContain('No accounts are being watched');
  });

  it('deletion and recovery watches are fully independent for the same username', async () => {
    const { router, repos, detector } = await setup();
    // Both commands now probe first, and each consumes one queued result:
    //   /unban refuses an already-ACTIVE account, so it needs a GONE precheck;
    //   /ban requires a live account, so it needs an ACTIVE one.
    detector.queue('natgeo', 'GONE');
    detector.queue('natgeo', 'ACTIVE');
    await router.handleUpdate(update('/unban natgeo')); // recovery watch (monitoring_cases)
    await router.handleUpdate(update('/ban natgeo')); // deletion watch (deletion_watches)
    expect(await repos.cases.findActiveByNormalizedUsername('natgeo')).not.toBeNull();
    expect(await repos.deletionWatches.findActiveByNormalizedUsername('natgeo')).not.toBeNull();
  });

  it('/unban REFUSES an account that is already active (no false recovery alert)', async () => {
    // Monitoring a live account would confirm ACTIVE 3x within a minute and fire an
    // "ACCOUNT UNBANNED" alert for an account that was never banned.
    const { router, repos, detector, client } = await setup();
    detector.queue('natgeo', 'ACTIVE');
    await router.handleUpdate(update('/unban natgeo'));
    expect(await repos.cases.findActiveByNormalizedUsername('natgeo')).toBeNull();
    expect(lastReply(client)).toContain('ALREADY ACTIVE');
  });

  it('/unban still starts monitoring when the account is gone', async () => {
    const { router, repos, detector } = await setup();
    detector.queue('bannedone', 'GONE');
    await router.handleUpdate(update('/unban bannedone'));
    expect(await repos.cases.findActiveByNormalizedUsername('bannedone')).not.toBeNull();
  });

  it('/unban still starts monitoring on an inconclusive check (never refuse on a blip)', async () => {
    const { router, repos, detector } = await setup();
    detector.queue('maybe', 'UNKNOWN');
    await router.handleUpdate(update('/unban maybe'));
    expect(await repos.cases.findActiveByNormalizedUsername('maybe')).not.toBeNull();
  });

  // H5. UNKNOWN is a FAILED OBSERVATION, not "the page is down": a login wall, a challenge or a
  // navigation timeout all land there without throwing. Enrolling anyway is right — a missed
  // recovery is the worst failure this system has — but reporting it under the ordinary
  // "👀 Monitoring Started" left the owner unable to tell a verified-down page from one nothing
  // ever looked at. An already-public page then confirms ACTIVE within a minute and a client is
  // told their profile recovered when nothing happened.
  it('/unban REPORTS that an inconclusive pre-check never verified anything', async () => {
    const { router, client, repos, detector } = await setup();
    detector.queue('maybe', 'UNKNOWN');

    await router.handleUpdate(update('/unban maybe'));

    const text = lastReply(client);
    expect(text).toContain('NOT pre-checked');
    expect(text).not.toContain('👀 Monitoring Started');
    expect(text).toContain('/check maybe'); // and how to settle it
    // Enrolment is UNCHANGED: the probe was attempted and the monitor exists either way.
    expect(detector.probes.map((p) => p.username)).toEqual(['maybe']);
    expect(await repos.cases.findActiveByNormalizedUsername('maybe')).not.toBeNull();
  });

  // The breaker case is the nastiest one: it answers UNKNOWN without touching the network at all,
  // so /unban used to print "Monitoring Started" for a page nothing had even tried to look at.
  it('/unban with the breaker OPEN monitors, never probes, and names the back-off', async () => {
    const detector = new DiagnosticFakeDetector();
    detector.fastTier = { ...detector.fastTier, breakerState: 'OPEN' };
    const { router, client, repos } = await setup({ detector });

    await router.handleUpdate(update('/unban maybe'));

    const text = lastReply(client);
    expect(text).toContain('NOT pre-checked');
    expect(text).toContain('fleet-wide back-off');
    expect(detector.probes).toHaveLength(0);
    expect(await repos.cases.findActiveByNormalizedUsername('maybe')).not.toBeNull();
  });

  // HALF_OPEN is NOT open. CircuitBreaker.allowRequest admits exactly one trial prober in that
  // state, and rehydrate() sets it deterministically at boot whenever a stored cooldown has
  // already elapsed — so treating it as "no live check was possible" skipped the pre-check in a
  // state where the check was available, and enrolled precisely the already-public accounts the
  // pre-check exists to refuse. Three ACTIVE confirmations later a client is told their profile
  // recovered when nothing ever happened.
  it('/unban with the breaker HALF_OPEN still pre-checks, and still refuses an already-active page', async () => {
    const detector = new DiagnosticFakeDetector();
    detector.fastTier = { ...detector.fastTier, breakerState: 'HALF_OPEN' };
    detector.queue('livepage', 'ACTIVE');
    const { router, client, repos } = await setup({ detector });

    await router.handleUpdate(update('/unban livepage'));

    expect(detector.probes.map((p) => p.username)).toEqual(['livepage']);
    expect(lastReply(client)).toContain('ALREADY ACTIVE');
    expect(await repos.cases.findActiveByNormalizedUsername('livepage')).toBeNull();
  });
});

describe('/clients', () => {
  async function seedMonitor(
    repos: Repositories,
    username: string,
    nowIso: string,
  ): Promise<string> {
    const c = await repos.cases.create(
      {
        normalizedUsername: username,
        originalInput: username,
        startedAtUtc: nowIso,
        nextCheckAtUtc: nowIso,
      },
      nowIso,
    );
    return c.id;
  }
  async function link(
    repos: Repositories,
    monitorId: string,
    clientChatId: number,
    nowIso: string,
  ): Promise<void> {
    await repos.clientLinks.create(
      {
        monitorId,
        sourceType: 'BUSINESS_CHAT',
        clientChatId,
        businessConnectionId: 'bc1',
        ownerTelegramUserId: OWNER_ID,
        sourceMessageId: 1,
      },
      nowIso,
    );
  }

  it('groups pages by client (stored + getChat backfill) with a Direct group for DM monitors', async () => {
    const { router, client, repos, clock } = await setup();
    const nowIso = clock.now().toISOString();
    // Client A (stored identity): 2 pages.
    await link(repos, await seedMonitor(repos, 'pagea1', nowIso), 5001, nowIso);
    await link(repos, await seedMonitor(repos, 'pagea2', nowIso), 5001, nowIso);
    await repos.clients.upsert(
      {
        clientChatId: 5001,
        businessConnectionId: 'bc1',
        username: 'johnc',
        firstName: 'John',
        lastName: null,
      },
      nowIso,
    );
    // Client B (no stored identity -> getChat backfill): 1 page.
    await link(repos, await seedMonitor(repos, 'pageb1', nowIso), 5002, nowIso);
    client.seedChat(5002, { id: 5002, username: 'sarah_b', first_name: 'Sarah' });
    // Direct (owner DM, no link).
    await seedMonitor(repos, 'directpage', nowIso);

    await router.handleUpdate(update('/clients'));
    const text = lastReply(client);
    expect(text).toContain('👥 Clients — 2');
    expect(text).toContain('@johnc (John)');
    expect(text).toContain('@pagea1');
    expect(text).toContain('@pagea2');
    expect(text).toContain('@sarah_b (Sarah)'); // resolved via getChat
    expect(text).toContain('Direct (your DM)');
    expect(text).toContain('@directpage');
    // Backfill was persisted.
    expect(await repos.clients.findByChatId(5002)).not.toBeNull();
  });

  it('falls back to "Client #id" when identity is unknown and getChat returns null', async () => {
    const { router, client, repos, clock } = await setup();
    const nowIso = clock.now().toISOString();
    await link(repos, await seedMonitor(repos, 'mystery', nowIso), 5999, nowIso);
    await router.handleUpdate(update('/clients')); // no seedChat -> getChat null
    const text = lastReply(client);
    expect(text).toContain('Client #5999');
    expect(text).toContain('@mystery');
  });

  it('empty state', async () => {
    const { router, client } = await setup();
    await router.handleUpdate(update('/clients'));
    expect(lastReply(client)).toContain('No monitored accounts yet');
  });

  it('captures client identity from a business /unban and shows it in /clients', async () => {
    const { router, client, repos, clock } = await setup();
    const nowIso = clock.now().toISOString();
    await repos.businessConnections.upsert({
      id: 'bc1',
      userId: OWNER_ID,
      userChatId: OWNER_ID,
      isEnabled: true,
      rights: {
        canReply: true,
        canReadMessages: true,
        canDeleteSentMessages: false,
        canDeleteAllMessages: false,
      },
      createdAtUtc: nowIso,
      updatedAtUtc: nowIso,
    });
    await router.handleUpdate({
      update_id: updateIdCounter++,
      business_message: {
        message_id: 7,
        from: { id: OWNER_ID, is_bot: false },
        chat: {
          id: 7777,
          type: 'private',
          username: 'clientx',
          first_name: 'Client',
          last_name: 'X',
        },
        date: Math.floor(NOW.getTime() / 1000),
        text: '/unban clientpage',
        business_connection_id: 'bc1',
      },
    });
    const identity = await repos.clients.findByChatId(7777);
    expect(identity?.username).toBe('clientx');

    await router.handleUpdate(update('/clients'));
    const text = lastReply(client);
    expect(text).toContain('@clientx (Client X)');
    expect(text).toContain('@clientpage');
  });
});

// ---------------------------------------------------------------------------
// /proxy — the reply must describe what was MEASURED, not what was requested.
//
// The two routes are not equally valid, and which one works depends on the HOST: on the owner's
// home PC 'direct' is a residential IP Instagram serves normally; on the VPS it is a datacenter
// IP Instagram refuses outright, so a fleet switched there detects no recoveries at all. Both are
// legitimate — the command must refuse neither and must tell the truth about both.
// ---------------------------------------------------------------------------
describe('/proxy', () => {
  const PROXY_ENV = {
    ...TEST_ENV,
    BROWSER_PROXY_SERVER: 'http://gate.example.com:7000',
    BROWSER_PROXY_USERNAME: 'proxy-user-secret',
    BROWSER_PROXY_PASSWORD: 'proxy-pass-secret',
  };

  /** A router wired to a REAL ProxySwitch over a network that serves only `serving`. */
  async function proxyHarness(options: {
    startOn: ProxyMode;
    serving: readonly ProxyMode[];
    configured?: boolean;
  }): Promise<Harness & { proxySwitch: ProxySwitch; detector: RouteAwareDetector }> {
    const config = loadConfig(
      options.configured === false
        ? { ...TEST_ENV, PROXY_MODE: options.startOn }
        : { ...PROXY_ENV, PROXY_MODE: options.startOn },
    );
    const proxySwitch = new ProxySwitch(config);
    const detector = new RouteAwareDetector(proxySwitch, options.serving);
    const harness = await setup({ config, detector, proxySwitch });
    return { ...harness, proxySwitch, detector };
  }

  it('confirms a switch only after the NEW route is verified against the control account', async () => {
    const { router, client, proxySwitch, detector } = await proxyHarness({
      startOn: 'direct',
      serving: ['direct', 'proxy'],
    });

    await router.handleUpdate(update('/proxy mobile'));

    const text = lastReply(client);
    expect(text).toContain('VERIFIED');
    expect(text).toContain('gate.example.com:7000');
    expect(text).toContain('@instagram');
    // The switch really moved, and the measurement was taken ON the new route.
    expect(proxySwitch.state().mode).toBe('proxy');
    expect(detector.seen).toEqual(['proxy']);
  });

  it('REVERTS a switch to a route that cannot see Instagram, and says so loudly', async () => {
    // The VPS case: '/proxy direct' selects a datacenter IP. Reporting success here is how the
    // whole fleet goes blind without anyone noticing.
    const { router, client, proxySwitch } = await proxyHarness({
      startOn: 'proxy',
      serving: ['proxy'],
    });

    await router.handleUpdate(update('/proxy direct'));

    const text = lastReply(client);
    expect(text).toContain('EGRESS NOT SWITCHED');
    expect(text).toContain('BLIND');
    expect(text).not.toContain('✅');
    // The fleet is back where it was, not left unable to detect anything.
    expect(proxySwitch.state().mode).toBe('proxy');
  });

  it('honours a deliberate repeat, and warns that the fleet is now blind', async () => {
    const { router, client, proxySwitch } = await proxyHarness({
      startOn: 'proxy',
      serving: ['proxy'],
    });

    await router.handleUpdate(update('/proxy direct'));
    await router.handleUpdate(update('/proxy direct'));

    const text = lastReply(client);
    expect(text).toContain('THE FLEET IS NOW BLIND');
    expect(text).toContain('NO RECOVERY WILL BE DETECTED');
    // The escape hatch must be a command that actually parses. The owner-facing words are
    // 'home' and 'vps'; 'direct'/'mobile' remain accepted but are no longer what we suggest.
    expect(text).toContain('/proxy vps');
    expect(proxySwitch.state().mode).toBe('direct');
  });

  it('does not claim a switch happened when already on that route', async () => {
    const { router, client, proxySwitch } = await proxyHarness({
      startOn: 'proxy',
      serving: ['direct', 'proxy'],
    });
    const before = proxySwitch.gen();

    await router.handleUpdate(update('/proxy mobile'));

    const text = lastReply(client);
    expect(text).toContain('Already on that route');
    expect(text).not.toContain('Egress switched');
    // No generation bump: a no-op must not force a needless browser relaunch either.
    expect(proxySwitch.gen()).toBe(before);
  });

  it('says mobile is unavailable when no proxy is configured, and changes nothing', async () => {
    const { router, client, proxySwitch, detector } = await proxyHarness({
      startOn: 'direct',
      serving: ['direct'],
      configured: false,
    });

    await router.handleUpdate(update('/proxy mobile'));

    expect(lastReply(client)).toContain('unavailable');
    expect(proxySwitch.state().mode).toBe('direct');
    // Nothing was measured, because nothing was selected.
    expect(detector.seen).toHaveLength(0);
  });

  it('keeps the "home" alias working', async () => {
    const { router, client, proxySwitch } = await proxyHarness({
      startOn: 'proxy',
      serving: ['direct', 'proxy'],
    });

    await router.handleUpdate(update('/proxy home'));

    expect(lastReply(client)).toContain('VERIFIED');
    expect(proxySwitch.state().mode).toBe('direct');
  });

  it('never puts a proxy credential in any reply', async () => {
    const { router, client } = await proxyHarness({ startOn: 'proxy', serving: ['proxy'] });

    await router.handleUpdate(update('/proxy'));
    await router.handleUpdate(update('/proxy direct')); // reverted
    await router.handleUpdate(update('/proxy direct')); // kept, blind
    await router.handleUpdate(update('/proxy mobile')); // switched back, verified
    await router.handleUpdate(update('/proxy mobile')); // no-op
    await router.handleUpdate(update('/proxy nonsense')); // usage

    expect(client.sentMessages.length).toBeGreaterThanOrEqual(6);
    for (const message of client.sentMessages) {
      expect(message.text).not.toContain('proxy-user-secret');
      expect(message.text).not.toContain('proxy-pass-secret');
    }
    // host:port IS shown — it is what tells the owner which route they are on.
    expect(client.sentMessages.some((m) => m.text.includes('gate.example.com:7000'))).toBe(true);
  });
});
