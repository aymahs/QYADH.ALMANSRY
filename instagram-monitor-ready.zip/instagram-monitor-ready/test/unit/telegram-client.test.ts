import { describe, it, expect } from 'vitest';

import {
  HttpTelegramClient,
  MockTelegramClient,
  configureCommands,
} from '../../src/bot/telegram-client';
import { AppError, isAppError } from '../../src/domain/errors';
import { VISIBLE_COMMANDS } from '../../src/domain/telegram';
import type {
  SendMessageParams,
  SendPhotoParams,
  SetWebhookParams,
} from '../../src/domain/telegram';
import { createLogger, nullLogger } from '../../src/logging/logger';

const TOKEN = '123456:AAaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqR';
const API_BASE = 'https://api.telegram.org';

interface RecordedRequest {
  url: string;
  method: string | undefined;
  headers: unknown;
  body: unknown;
}

/** A fetch-compatible fake that records requests and returns whatever `responder` yields. */
function makeFakeFetch(responder: (req: RecordedRequest) => Response | Promise<Response>): {
  fetchImpl: typeof fetch;
  requests: RecordedRequest[];
} {
  const requests: RecordedRequest[] = [];
  const fetchImpl: typeof fetch = async (input, init) => {
    const req: RecordedRequest = {
      url: String(input),
      method: init?.method,
      headers: init?.headers,
      body: init?.body,
    };
    requests.push(req);
    return responder(req);
  };
  return { fetchImpl, requests };
}

function okResponse(result: unknown): Response {
  return new Response(JSON.stringify({ ok: true, result }), { status: 200 });
}

function client(fetchImpl: typeof fetch): HttpTelegramClient {
  return new HttpTelegramClient({
    token: TOKEN,
    logger: nullLogger(),
    fetchImpl,
    apiBase: API_BASE,
  });
}

describe('HttpTelegramClient', () => {
  it('sendMessage posts JSON to the sendMessage URL and returns the message_id', async () => {
    const { fetchImpl, requests } = makeFakeFetch(() => okResponse({ message_id: 555 }));
    const params: SendMessageParams = {
      chat_id: 12345,
      text: 'hello',
      reply_markup: { inline_keyboard: [[{ text: 'open', url: 'https://example.com' }]] },
    };

    const result = await client(fetchImpl).sendMessage(params);

    expect(result.message_id).toBe(555);
    expect(requests).toHaveLength(1);
    const req = requests[0]!;
    expect(req.url).toBe(`${API_BASE}/bot${TOKEN}/sendMessage`);
    expect(req.method).toBe('POST');
    expect(typeof req.body).toBe('string');
    const body = JSON.parse(req.body as string);
    expect(body.chat_id).toBe(12345);
    expect(body.text).toBe('hello');
    expect(body.reply_markup).toEqual(params.reply_markup);
  });

  it('setWebhook posts url + secret_token', async () => {
    const { fetchImpl, requests } = makeFakeFetch(() => okResponse(true));
    const params: SetWebhookParams = {
      url: 'https://hook.example.com/tg',
      secret_token: 's3cr3t-token-value',
      allowed_updates: ['message'],
    };

    const ok = await client(fetchImpl).setWebhook(params);

    expect(ok).toBe(true);
    const body = JSON.parse(requests[0]!.body as string);
    expect(body.url).toBe(params.url);
    expect(body.secret_token).toBe(params.secret_token);
    expect(body.allowed_updates).toEqual(['message']);
  });

  it('setMyCommands posts the visible commands', async () => {
    const { fetchImpl, requests } = makeFakeFetch(() => okResponse(true));

    const ok = await client(fetchImpl).setMyCommands([...VISIBLE_COMMANDS]);

    expect(ok).toBe(true);
    expect(requests[0]!.url).toBe(`${API_BASE}/bot${TOKEN}/setMyCommands`);
    const body = JSON.parse(requests[0]!.body as string);
    expect(body.commands).toHaveLength(VISIBLE_COMMANDS.length);
    expect(body.commands).toEqual([...VISIBLE_COMMANDS]);
  });

  it('sendPhoto sends multipart FormData with photo + caption + reply_markup', async () => {
    let capturedBody: unknown;
    const { fetchImpl } = makeFakeFetch((req) => {
      capturedBody = req.body;
      return okResponse({ message_id: 777 });
    });
    const params: SendPhotoParams = {
      chat_id: 9,
      photo: Buffer.from([1, 2, 3, 4]),
      caption: 'a screenshot',
      reply_markup: { inline_keyboard: [[{ text: 'view', url: 'https://x.test' }]] },
    };

    const result = await client(fetchImpl).sendPhoto(params);

    expect(result.message_id).toBe(777);
    expect(capturedBody).toBeInstanceOf(FormData);
    const form = capturedBody as FormData;
    expect(form.get('chat_id')).toBe('9');
    expect(form.get('caption')).toBe('a screenshot');
    expect(form.get('reply_markup')).toBe(JSON.stringify(params.reply_markup));
    const photo = form.get('photo');
    expect(photo).toBeInstanceOf(Blob);
    expect((photo as Blob).size).toBe(4);
  });

  it('throws AppError TELEGRAM_ERROR with the description when ok:false', async () => {
    const { fetchImpl } = makeFakeFetch(
      () =>
        new Response(JSON.stringify({ ok: false, description: 'Bad Request: chat not found' }), {
          status: 400,
        }),
    );

    await expect(client(fetchImpl).sendMessage({ chat_id: 1, text: 'x' })).rejects.toMatchObject({
      code: 'TELEGRAM_ERROR',
      message: 'Bad Request: chat not found',
    });
  });

  it('throws AppError TELEGRAM_AMBIGUOUS when the network aborts during sendPhoto', async () => {
    const abortError = new Error('The operation was aborted');
    abortError.name = 'AbortError';
    const { fetchImpl } = makeFakeFetch(() => Promise.reject(abortError));

    let caught: unknown;
    try {
      await client(fetchImpl).sendPhoto({ chat_id: 1, photo: Buffer.from([9]) });
    } catch (err) {
      caught = err;
    }

    expect(isAppError(caught)).toBe(true);
    expect((caught as AppError).code).toBe('TELEGRAM_AMBIGUOUS');
  });

  it('surfaces TELEGRAM_ERROR (not ambiguous) for read-only getUpdates network failures', async () => {
    const { fetchImpl } = makeFakeFetch(() => Promise.reject(new TypeError('fetch failed')));

    await expect(client(fetchImpl).getUpdates(0, 5)).rejects.toMatchObject({
      code: 'TELEGRAM_ERROR',
    });
  });

  it('never writes the bot token into logs', async () => {
    const lines: string[] = [];
    const logger = createLogger({
      level: 'debug',
      secrets: [TOKEN],
      write: (line) => lines.push(line),
    });
    // One success (debug log) and one failure (warn log) to exercise both log paths.
    const okFetch = makeFakeFetch(() => okResponse({ message_id: 1 })).fetchImpl;
    await new HttpTelegramClient({
      token: TOKEN,
      logger,
      fetchImpl: okFetch,
      apiBase: API_BASE,
    }).sendMessage({
      chat_id: 1,
      text: 'hi',
    });
    const failFetch = makeFakeFetch(() => Promise.reject(new TypeError('boom'))).fetchImpl;
    await expect(
      new HttpTelegramClient({
        token: TOKEN,
        logger,
        fetchImpl: failFetch,
        apiBase: API_BASE,
      }).getUpdates(0, 1),
    ).rejects.toBeInstanceOf(AppError);

    expect(lines.length).toBeGreaterThan(0);
    for (const line of lines) {
      expect(line).not.toContain(TOKEN);
    }
  });
});

describe('MockTelegramClient', () => {
  it('returns incrementing message ids from 1000 and records calls', async () => {
    const mock = new MockTelegramClient();

    const first = await mock.sendMessage({ chat_id: 1, text: 'a' });
    const second = await mock.sendPhoto({ chat_id: 1, photo: Buffer.from([1]) });

    expect(first.message_id).toBe(1000);
    expect(second.message_id).toBe(1001);
    expect(mock.sentMessages).toHaveLength(1);
    expect(mock.sentPhotos).toHaveLength(1);
    expect(mock.calls.map((c) => c.method)).toEqual(['sendMessage', 'sendPhoto']);
  });

  it('getMe / webhook / commands return canned values', async () => {
    const mock = new MockTelegramClient();

    expect(await mock.getMe()).toEqual({ id: 42, username: 'test_bot' });
    expect(await mock.setWebhook({ url: 'u', secret_token: 's' })).toBe(true);
    expect(await mock.deleteWebhook(true)).toBe(true);
    expect(mock.webhookCalls).toHaveLength(1);
  });

  it('drains enqueued update batches then returns empty', async () => {
    const mock = new MockTelegramClient();
    mock.enqueueUpdates([{ update_id: 1 }]);

    expect(await mock.getUpdates(0, 30)).toEqual([{ update_id: 1 }]);
    expect(await mock.getUpdates(1, 30)).toEqual([]);
  });

  it('failNextSendWith rejects only the next send', async () => {
    const mock = new MockTelegramClient();
    mock.failNextSendWith(new AppError('TELEGRAM_AMBIGUOUS', 'network outcome uncertain'));

    await expect(mock.sendMessage({ chat_id: 1, text: 'x' })).rejects.toMatchObject({
      code: 'TELEGRAM_AMBIGUOUS',
    });
    // Next send succeeds.
    await expect(mock.sendMessage({ chat_id: 1, text: 'y' })).resolves.toMatchObject({
      message_id: 1000,
    });
  });

  it('failMethod rejects every call to that method', async () => {
    const mock = new MockTelegramClient();
    mock.failMethod('getUpdates', new AppError('TELEGRAM_ERROR', 'down'));

    await expect(mock.getUpdates(0, 30)).rejects.toMatchObject({ code: 'TELEGRAM_ERROR' });
    await expect(mock.getUpdates(0, 30)).rejects.toMatchObject({ code: 'TELEGRAM_ERROR' });
  });
});

describe('configureCommands', () => {
  it('registers the visible commands via setMyCommands', async () => {
    const mock = new MockTelegramClient();

    await configureCommands(mock);

    expect(mock.commandCalls).toHaveLength(1);
    expect(mock.commandCalls[0]).toEqual([...VISIBLE_COMMANDS]);
  });
});
