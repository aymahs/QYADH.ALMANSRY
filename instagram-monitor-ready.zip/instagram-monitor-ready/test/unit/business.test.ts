import { describe, it, expect, beforeEach } from 'vitest';
import type { TelegramUpdate } from '../../src/domain';
import { FixedClock } from '../../src/domain';
import { loadConfig } from '../../src/config';
import { nullLogger } from '../../src/logging';
import { MockTelegramClient } from '../../src/bot/telegram-client';
import { OwnerAuthorizer } from '../../src/bot/authorization';
import { CommandRouter } from '../../src/bot/commands';
import { makeFakeDb } from '../helpers/fake-repos';
import { FakeDetector } from '../helpers/fake-detector';

const NOW = new Date('2026-07-17T09:00:00.000Z');
const OWNER_ID = 7672755630;
const CLIENT_ID = 111222333;
const CLIENT_CHAT = 111222333;
/** A SECOND paying client's business chat, used for the link-stealing regression. */
const OTHER_CLIENT_CHAT = 444555666;
const BCID = 'biz-conn-1';
const TEST_ENV = {
  TELEGRAM_BOT_TOKEN: '123456789:AAtesttokenAAAAAAAAAAAAAAAAAAAAAAAA',
  OWNER_PAIRING_SECRET: 'pairing-secret-value',
  CONTROL_USERNAME: 'instagram',
};

async function setup(seedDetector?: (d: FakeDetector) => void): Promise<{
  router: CommandRouter;
  client: MockTelegramClient;
  repos: ReturnType<typeof makeFakeDb>['repos'];
}> {
  const clock = new FixedClock(NOW);
  const { db, repos } = makeFakeDb();
  const client = new MockTelegramClient();
  const config = loadConfig(TEST_ENV);
  const auth = new OwnerAuthorizer({
    owner: repos.owner,
    pairingSecret: config.ownerPairingSecret,
    logger: nullLogger(),
  });
  await repos.owner.claimOwner(OWNER_ID, NOW.toISOString());
  const detector = new FakeDetector();
  seedDetector?.(detector);
  const router = new CommandRouter({
    client,
    repos,
    db,
    detector,
    auth,
    config,
    clock,
    logger: nullLogger(),
  });
  return { router, client, repos };
}

let uid = 1;
function connectionUpdate(enabled = true, canReply = true): TelegramUpdate {
  return {
    update_id: uid++,
    business_connection: {
      id: BCID,
      user: { id: OWNER_ID, is_bot: false },
      date: 0,
      is_enabled: enabled,
      rights: { can_reply: canReply, can_read_messages: true },
    },
  };
}
function businessUnban(
  text: string,
  fromId: number,
  chatId: number = CLIENT_CHAT,
  bcid: string = BCID,
): TelegramUpdate {
  return {
    update_id: uid++,
    business_message: {
      message_id: 500 + uid,
      from: { id: fromId, is_bot: false },
      chat: { id: chatId, type: 'private' },
      date: 0,
      text,
      business_connection_id: bcid,
    },
  };
}

describe('Telegram Business chat monitoring', () => {
  beforeEach(() => {
    uid = 1;
  });

  it('stores a business connection from the business_connection update', async () => {
    const { router, repos } = await setup();
    await router.handleUpdate(connectionUpdate());
    const conn = await repos.businessConnections.findById(BCID);
    expect(conn?.isEnabled).toBe(true);
    expect(conn?.rights.canReply).toBe(true);
    expect(conn?.userId).toBe(OWNER_ID);
  });

  it('owner /unban inside a client chat creates a monitor linked to that chat and replies via the business connection', async () => {
    // A CONCLUSIVE pre-check: the page really is down, which is the whole use case. Without one
    // the monitor still starts, but the owner is additionally DM'd that nothing verified it.
    const { router, client, repos } = await setup((d) => d.queue('queenbuenrostro', 'GONE'));
    await router.handleUpdate(connectionUpdate());
    await router.handleUpdate(businessUnban('/unban queenbuenrostro', OWNER_ID));

    const monitor = await repos.cases.findActiveByNormalizedUsername('queenbuenrostro');
    expect(monitor).not.toBeNull();
    const link = await repos.clientLinks.findByMonitorId(monitor!.id);
    expect(link?.clientChatId).toBe(CLIENT_CHAT);
    expect(link?.businessConnectionId).toBe(BCID);
    expect(link?.sourceType).toBe('BUSINESS_CHAT');
    expect(link?.clientDeliveryStatus).toBe('BUSINESS_DELIVERY_PENDING');

    const reply = client.sentMessages[client.sentMessages.length - 1];
    expect(reply?.business_connection_id).toBe(BCID);
    expect(reply?.chat_id).toBe(CLIENT_CHAT);
    expect(reply?.text).toContain('RECOVERY MONITORING STARTED');
    expect(reply?.text).toContain('@queenbuenrostro');
  });

  it('owner /ban inside a client chat starts a deletion watch linked to that chat', async () => {
    const { router, client, repos } = await setup(
      // /ban requires the account to be live right now, so seed an ACTIVE probe.
      (d) => d.queue('liveaccount', 'ACTIVE'),
    );
    await router.handleUpdate(connectionUpdate());
    await router.handleUpdate(businessUnban('/ban liveaccount', OWNER_ID));

    const watch = await repos.deletionWatches.findActiveByNormalizedUsername('liveaccount');
    expect(watch).not.toBeNull();

    // The link is keyed by the WATCH id, which is what routes the later alert to this chat.
    const link = await repos.clientLinks.findByMonitorId(watch!.id);
    expect(link?.clientChatId).toBe(CLIENT_CHAT);
    expect(link?.businessConnectionId).toBe(BCID);
    expect(link?.clientDeliveryStatus).toBe('BUSINESS_DELIVERY_PENDING');

    const reply = client.sentMessages[client.sentMessages.length - 1];
    expect(reply?.business_connection_id).toBe(BCID);
    expect(reply?.chat_id).toBe(CLIENT_CHAT);
    expect(reply?.text).toContain('DELETION MONITORING STARTED');
    expect(reply?.text).toContain('@liveaccount');
  });

  it('owner /ban in a client chat is refused when the account is already gone', async () => {
    const { router, client, repos } = await setup((d) => d.queue('deadaccount', 'GONE'));
    await router.handleUpdate(connectionUpdate());
    await router.handleUpdate(businessUnban('/ban deadaccount', OWNER_ID));

    expect(await repos.deletionWatches.findActiveByNormalizedUsername('deadaccount')).toBeNull();
    const reply = client.sentMessages[client.sentMessages.length - 1];
    expect(reply?.text).toContain('already unavailable');
  });

  it('a CLIENT-sent /ban is ignored — no watch, no reply', async () => {
    const { router, client, repos } = await setup((d) => d.queue('liveaccount', 'ACTIVE'));
    await router.handleUpdate(connectionUpdate());
    const before = client.sentMessages.length;
    await router.handleUpdate(businessUnban('/ban liveaccount', CLIENT_ID));
    expect(await repos.deletionWatches.findActiveByNormalizedUsername('liveaccount')).toBeNull();
    expect(client.sentMessages.length).toBe(before);
  });

  it('a CLIENT-sent /unban is ignored — no monitor, no reply', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(connectionUpdate());
    const before = client.sentMessages.length;
    await router.handleUpdate(businessUnban('/unban someoneelse', CLIENT_ID));
    expect(await repos.cases.findActiveByNormalizedUsername('someoneelse')).toBeNull();
    expect(client.sentMessages.length).toBe(before);
  });

  it('accepts @username and URL forms and normalizes; a second /unban does not duplicate the monitor', async () => {
    const { router, repos } = await setup();
    await router.handleUpdate(connectionUpdate());
    await router.handleUpdate(
      businessUnban('/unban https://www.instagram.com/try.maven/', OWNER_ID),
    );
    await router.handleUpdate(businessUnban('/unban @try.maven', OWNER_ID));
    const all = await repos.cases.listByStatuses([
      'MONITORING',
      'CONFIRMING',
      'ERROR_BACKOFF',
      'UNKNOWN_BACKOFF',
    ]);
    expect(all.filter((c) => c.normalizedUsername === 'try.maven')).toHaveLength(1);
  });

  it('a second /unban from ANOTHER client chat does not steal the first client’s link', async () => {
    // Conclusive pre-check on the first enrolment, so the ONLY owner DM in this test is the
    // conflict one being asserted below.
    const { router, client, repos } = await setup((d) => d.queue('brandpage', 'GONE'));
    await router.handleUpdate(connectionUpdate());
    await router.handleUpdate(businessUnban('/unban brandpage', OWNER_ID));
    const monitor = await repos.cases.findActiveByNormalizedUsername('brandpage');
    expect(monitor).not.toBeNull();

    // The owner types the same command inside a DIFFERENT client's chat. One active case per
    // username means this reuses the SAME monitor, so the link is what decides who gets told.
    await router.handleUpdate(businessUnban('/unban brandpage', OWNER_ID, OTHER_CLIENT_CHAT));

    // 1. The first client still owns the link — the recovery will still reach them.
    const link = await repos.clientLinks.findByMonitorId(monitor!.id);
    expect(link?.clientChatId).toBe(CLIENT_CHAT);
    expect(link?.businessConnectionId).toBe(BCID);
    expect(link?.clientDeliveryStatus).toBe('BUSINESS_DELIVERY_PENDING');

    // 2. The second chat is NOT promised an alert it will never receive.
    const toOther = client.sentMessages.filter((m) => m.chat_id === OTHER_CLIENT_CHAT);
    expect(toOther).toHaveLength(1);
    expect(toOther[0]?.text).toContain('NOT STARTED');
    expect(toOther[0]?.text).not.toContain('MONITORING STARTED');
    // It must not disclose the other customer to this one.
    expect(toOther[0]?.text).not.toContain(String(CLIENT_CHAT));

    // 3. The owner is told privately, and told WHICH chat already owns it, so they can act.
    const toOwner = client.sentMessages.filter(
      (m) => m.chat_id === OWNER_ID && m.business_connection_id === undefined,
    );
    expect(toOwner).toHaveLength(1);
    expect(toOwner[0]?.text).toContain('CLIENT LINK CONFLICT');
    expect(toOwner[0]?.text).toContain('@brandpage');
    expect(toOwner[0]?.text).toContain(String(CLIENT_CHAT));
  });

  it('re-running /unban in the SAME client chat stays harmless (idempotent)', async () => {
    const { router, client, repos } = await setup((d) => d.queue('brandpage', 'GONE'));
    await router.handleUpdate(connectionUpdate());
    await router.handleUpdate(businessUnban('/unban brandpage', OWNER_ID));
    const monitor = await repos.cases.findActiveByNormalizedUsername('brandpage');

    await router.handleUpdate(businessUnban('/unban brandpage', OWNER_ID));

    const link = await repos.clientLinks.findByMonitorId(monitor!.id);
    expect(link?.clientChatId).toBe(CLIENT_CHAT);
    expect(link?.clientDeliveryStatus).toBe('BUSINESS_DELIVERY_PENDING');
    // Confirmed again in-chat, and nothing was escalated to the owner.
    const reply = client.sentMessages[client.sentMessages.length - 1];
    expect(reply?.chat_id).toBe(CLIENT_CHAT);
    expect(reply?.text).toContain('RECOVERY MONITORING STARTED');
    expect(client.sentMessages.some((m) => m.text.includes('CLIENT LINK CONFLICT'))).toBe(false);
  });

  // H5. The client chat is where an unchecked enrolment costs the most: the pre-check answers
  // UNKNOWN for a login wall, a timeout or an open breaker without throwing, the client is told
  // "RECOVERY MONITORING STARTED" all the same, and if that page was in fact already public the
  // scheduler confirms it ACTIVE within a minute and the CLIENT is told their profile recovered.
  // Enrolling is still right; letting the owner believe it was checked is not.
  it('an inconclusive pre-check still monitors, still tells the client — and warns the owner', async () => {
    const { router, client, repos } = await setup((d) => d.queue('clientpage', 'UNKNOWN'));
    await router.handleUpdate(connectionUpdate());

    await router.handleUpdate(businessUnban('/unban clientpage', OWNER_ID));

    // 1. Enrolment is UNCHANGED — monitor created and linked, so the recovery still routes here.
    const monitor = await repos.cases.findActiveByNormalizedUsername('clientpage');
    expect(monitor).not.toBeNull();
    expect((await repos.clientLinks.findByMonitorId(monitor!.id))?.clientChatId).toBe(CLIENT_CHAT);

    // 2. The client gets the same clean confirmation as always — no internal diagnostics.
    const toClient = client.sentMessages.filter((m) => m.chat_id === CLIENT_CHAT);
    expect(toClient[toClient.length - 1]?.text).toContain('RECOVERY MONITORING STARTED');
    expect(toClient.some((m) => m.text.includes('pre-check'))).toBe(false);

    // 3. The owner is told privately that nothing verified the page is down, and what to do.
    const toOwner = client.sentMessages.filter(
      (m) => m.chat_id === OWNER_ID && m.business_connection_id === undefined,
    );
    expect(toOwner).toHaveLength(1);
    expect(toOwner[0]?.text).toContain('WITHOUT A PRE-CHECK');
    expect(toOwner[0]?.text).toContain('@clientpage');
    expect(toOwner[0]?.text).toContain(String(CLIENT_CHAT));
    expect(toOwner[0]?.text).toContain('/clear clientpage');
  });

  // --- unknown business connection id -------------------------------------------------------
  //
  // Telegram sends `business_connection` only on connect / change / disconnect, never on startup,
  // so the stored row can be missing (fresh volume, reset database, bot down when the owner
  // connected) while the connection itself is perfectly live. Every one of these updates used to
  // be discarded without a reply, a log line or an owner ping.

  it('an owner command on an UNKNOWN connection id, with nothing to fall back on, tells the owner instead of vanishing', async () => {
    const { router, client, repos } = await setup();
    // Deliberately NO connectionUpdate(): business_connections is empty, exactly as it is after a
    // database reset. The test never writes the row it is checking for.
    await router.handleUpdate(businessUnban('/unban queenbuenrostro', OWNER_ID, CLIENT_CHAT));

    // The command genuinely could not run…
    expect(await repos.cases.findActiveByNormalizedUsername('queenbuenrostro')).toBeNull();
    // …but the owner is told so, in their own DM, with the fix — never silence.
    const toOwner = client.sentMessages.filter(
      (m) => m.chat_id === OWNER_ID && m.business_connection_id === undefined,
    );
    expect(toOwner).toHaveLength(1);
    expect(toOwner[0]?.text).toContain('BUSINESS CONNECTION NOT RECOGNISED');
    expect(toOwner[0]?.text).toContain('/unban');
    expect(toOwner[0]?.text).toContain(String(CLIENT_CHAT));
    // Nothing was posted into the client's conversation.
    expect(client.sentMessages.some((m) => m.chat_id === CLIENT_CHAT)).toBe(false);
  });

  it('an owner command on a NEW connection id adopts the surviving connection and runs normally', async () => {
    const { router, client, repos } = await setup((d) => d.queue('queenbuenrostro', 'GONE'));
    // The bot holds an enabled connection, but the owner reconnected while it was down, so the
    // live connection now carries a different id.
    await router.handleUpdate(connectionUpdate());
    const NEW_BCID = 'biz-conn-2';

    await router.handleUpdate(
      businessUnban('/unban queenbuenrostro', OWNER_ID, CLIENT_CHAT, NEW_BCID),
    );

    const monitor = await repos.cases.findActiveByNormalizedUsername('queenbuenrostro');
    expect(monitor).not.toBeNull();
    // The link must carry the id the message ACTUALLY arrived on — that is what the outbox
    // worker looks up when it delivers the recovery to this client.
    const link = await repos.clientLinks.findByMonitorId(monitor!.id);
    expect(link?.clientChatId).toBe(CLIENT_CHAT);
    expect(link?.businessConnectionId).toBe(NEW_BCID);
    expect(link?.clientDeliveryStatus).toBe('BUSINESS_DELIVERY_PENDING');
    // …and that id is now stored, so the delivery path can find it.
    const adopted = await repos.businessConnections.findById(NEW_BCID);
    expect(adopted?.userId).toBe(OWNER_ID);
    expect(adopted?.isEnabled).toBe(true);
    expect(adopted?.rights.canReply).toBe(true);

    const reply = client.sentMessages[client.sentMessages.length - 1];
    expect(reply?.business_connection_id).toBe(NEW_BCID);
    expect(reply?.chat_id).toBe(CLIENT_CHAT);
    expect(reply?.text).toContain('RECOVERY MONITORING STARTED');
  });

  it('a CLIENT-sent command on an unknown connection id is still ignored — and cannot make the bot DM the owner', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(connectionUpdate());
    const before = client.sentMessages.length;

    await router.handleUpdate(
      businessUnban('/unban someoneelse', CLIENT_ID, CLIENT_CHAT, 'biz-conn-forged'),
    );

    expect(await repos.cases.findActiveByNormalizedUsername('someoneelse')).toBeNull();
    // The fallback must not widen who can drive the bot, nor become an owner-spam channel.
    expect(client.sentMessages.length).toBe(before);
    expect(await repos.businessConnections.findById('biz-conn-forged')).toBeNull();
  });

  // --- a business handler that THROWS ---------------------------------------------------------
  //
  // The business branch of handleUpdate returns before `message` is assigned, so the outer
  // catch's bestEffortErrorReply had nothing to answer: every failure inside a client chat was
  // completely silent. The owner saw "🔎 Checking @x…" and then nothing, and assumed it worked.

  it('a half-created enrolment (case written, client link write failed) pings the owner instead of vanishing', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(connectionUpdate());
    // Fault injection ONLY. Nothing here writes the monitor, the missing link, or the owner ping
    // that the assertions below check — those all come from the production path.
    repos.clientLinks.create = (): Promise<never> =>
      Promise.reject(new Error('SQLITE_BUSY: database is locked'));

    await router.handleUpdate(businessUnban('/unban queenbuenrostro', OWNER_ID));

    // The exact half-created state: a monitor exists with no route back to the client, so the
    // recovery delivery would treat it as owner-only and the client would never be told.
    const monitor = await repos.cases.findActiveByNormalizedUsername('queenbuenrostro');
    expect(monitor).not.toBeNull();
    expect(await repos.clientLinks.findByMonitorId(monitor!.id)).toBeNull();

    // …and the owner is told exactly that, naming the page, the chat and the repair.
    const toOwner = client.sentMessages.filter(
      (m) => m.chat_id === OWNER_ID && m.business_connection_id === undefined,
    );
    expect(toOwner).toHaveLength(1);
    expect(toOwner[0]?.text).toContain('CLIENT NOT LINKED');
    expect(toOwner[0]?.text).toContain('@queenbuenrostro');
    expect(toOwner[0]?.text).toContain(String(CLIENT_CHAT));
    // The client must never be told monitoring started — no alert can reach them.
    expect(
      client.sentMessages.some(
        (m) => m.chat_id === CLIENT_CHAT && m.text.includes('MONITORING STARTED'),
      ),
    ).toBe(false);
  });

  // The /ban mirror of the case above, and the one the generic copy got provably WRONG. /ban has
  // the identical two-write enrolment (deletion_watches, then the same client_chat_links row), so
  // a failed link write strands a live watch — and DeletionWorker.deliverToClient treats a missing
  // link as an owner-only watch, so the paying client is never told about the deletion they paid
  // to be watched for. The generic advice ("It may have set up nothing at all … re-run /ban")
  // was wrong in both directions: something WAS set up, and re-running /ban stops at "already
  // being watched" BEFORE the link write, so it can never close the gap.
  it('a half-created /ban (watch written, client link write failed) names the watch and prescribes a repair that works', async () => {
    const { router, client, repos } = await setup((d) => d.queue('liveaccount', 'ACTIVE'));
    await router.handleUpdate(connectionUpdate());
    // Fault injection ONLY, on the SECOND write. Nothing here creates the watch, the missing
    // link, or the owner ping — those are all produced by the production path.
    repos.clientLinks.create = (): Promise<never> =>
      Promise.reject(new Error('SQLITE_BUSY: database is locked'));

    await router.handleUpdate(businessUnban('/ban liveaccount', OWNER_ID));

    // The exact half-created state: a live watch with no route back to the client.
    const watch = await repos.deletionWatches.findActiveByNormalizedUsername('liveaccount');
    expect(watch).not.toBeNull();
    expect(await repos.clientLinks.findByMonitorId(watch!.id)).toBeNull();

    const toOwner = client.sentMessages.filter(
      (m) => m.chat_id === OWNER_ID && m.business_connection_id === undefined,
    );
    expect(toOwner).toHaveLength(1);
    const text = toOwner[0]?.text ?? '';
    expect(text).toContain('CLIENT NOT LINKED');
    expect(text).toContain('@liveaccount');
    expect(text).toContain(String(CLIENT_CHAT));
    // The repair must clear the watch first; re-running /ban on its own cannot add the link.
    expect(text).toContain('/unwatch liveaccount');
    // …and must NOT be the generic copy, which claims nothing was set up.
    expect(text).not.toContain('It may have set up nothing at all');
  });

  // The half-created lookup reads the very tables whose failure caused the throw, and on the
  // Postgres driver every deletionWatches method throws by design. If that escaped it would take
  // the owner's ping with it — the failure would be silent again, which is the whole point of the
  // reporter.
  it('the owner is still pinged when the half-created lookup itself throws', async () => {
    const { router, client, repos } = await setup((d) => d.queue('liveaccount', 'ACTIVE'));
    await router.handleUpdate(connectionUpdate());
    repos.deletionWatches.findActiveByNormalizedUsername = (): Promise<never> =>
      Promise.reject(new Error('DB_ERROR: deletion watches require the SQLite driver'));

    await router.handleUpdate(businessUnban('/ban liveaccount', OWNER_ID));

    const toOwner = client.sentMessages.filter(
      (m) => m.chat_id === OWNER_ID && m.business_connection_id === undefined,
    );
    expect(toOwner).toHaveLength(1);
    expect(toOwner[0]?.text).toContain('COMMAND FAILED IN A CLIENT CHAT');
  });

  it('any other business handler failure is reported too — /ban whose watch write throws', async () => {
    const { router, client, repos } = await setup((d) => d.queue('liveaccount', 'ACTIVE'));
    await router.handleUpdate(connectionUpdate());
    repos.deletionWatches.create = (): Promise<never> =>
      Promise.reject(new Error('SQLITE_BUSY: database is locked'));

    await router.handleUpdate(businessUnban('/ban liveaccount', OWNER_ID));

    const toOwner = client.sentMessages.filter(
      (m) => m.chat_id === OWNER_ID && m.business_connection_id === undefined,
    );
    expect(toOwner).toHaveLength(1);
    expect(toOwner[0]?.text).toContain('COMMAND FAILED IN A CLIENT CHAT');
    expect(toOwner[0]?.text).toContain('/ban');
    expect(toOwner[0]?.text).toContain(String(CLIENT_CHAT));
  });

  it('a failure while handling a CLIENT-sent command never DMs the owner', async () => {
    const { router, client, repos } = await setup();
    await router.handleUpdate(connectionUpdate());
    const before = client.sentMessages.length;
    // Throws before the sender is even checked, so the reporter is what has to hold the line:
    // the ping must not become a channel a client can make the bot fire at the owner, and
    // "your command failed" would be untrue for a command the owner never typed.
    repos.businessConnections.findById = (): Promise<never> =>
      Promise.reject(new Error('SQLITE_BUSY: database is locked'));

    await router.handleUpdate(businessUnban('/unban someoneelse', CLIENT_ID));

    expect(client.sentMessages.length).toBe(before);
  });

  it('a command sent while the connection is disabled is ignored', async () => {
    const { router, repos } = await setup();
    await router.handleUpdate(connectionUpdate(false));
    await router.handleUpdate(businessUnban('/unban queenbuenrostro', OWNER_ID));
    expect(await repos.cases.findActiveByNormalizedUsername('queenbuenrostro')).toBeNull();
  });
});
