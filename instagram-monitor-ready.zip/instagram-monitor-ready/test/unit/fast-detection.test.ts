import { describe, it, expect } from 'vitest';

import {
  CircuitBreaker,
  breakerOutcomeForCode,
  isThrottleSignal,
  backOffForRoute,
  EGRESS_BREAKER_NAME,
} from '../../src/instagram/circuit-breaker';
import type { BreakerState, DurableBreakerState } from '../../src/instagram/circuit-breaker';
import { ProxySwitch, switchEgressRoute } from '../../src/instagram/proxy-switch';
import { egressStatus, egressSwitchResult } from '../../src/notifications/formatter/messages';
import { BrowserLoadGovernor, ESCALATION_STORM_STREAK } from '../../src/instagram/load-governor';
import type { GovernorSnapshot, GovernorStore } from '../../src/instagram/load-governor';
import { TieredDetector } from '../../src/instagram/detector/tiered-detector';
import type { TieredProbeOptions } from '../../src/instagram/detector/tiered-detector';
import { classifyHtml } from '../../src/instagram/detector/classify';
import { dispatcherFor } from '../../src/instagram/detector/http-probe';
import { loadConfig } from '../../src/config';
import { nullLogger } from '../../src/logging/logger';
import type { DetectorErrorCode, Detector, ProbeOptions, ProbeResult } from '../../src/domain';

const CONFIG = loadConfig({
  TELEGRAM_BOT_TOKEN: '123456789:AAtesttokenAAAAAAAAAAAAAAAAAAAAAAAA',
  OWNER_PAIRING_SECRET: 'pair-secret-123',
});

const META = {
  finalUrl: 'https://www.instagram.com/testuser/',
  responseStatus: 200,
  requestedUsername: 'testuser',
};

/** Injectable clock; the breaker is pure and clock-driven, so no timers are involved. */
function makeClock(start = 0): { now: () => number; advance: (ms: number) => void } {
  let t = start;
  return { now: () => t, advance: (ms) => void (t += ms) };
}

// ---------------------------------------------------------------------------
// Screenshot-safety: Instagram's "Something went wrong" page still carries the
// profile's og metadata, so before this signal existed it classified ACTIVE and
// got sent to clients as proof of recovery.
// ---------------------------------------------------------------------------
describe('error-page detection', () => {
  const ERROR_PAGE = `<html><head>
      <meta property="og:title" content="testuser (@testuser) • Instagram photos and videos" />
      <meta property="og:url" content="https://www.instagram.com/testuser/" />
      <meta property="og:type" content="profile" />
      <link rel="canonical" href="https://www.instagram.com/testuser/" />
    </head><body>
      <div>Something went wrong</div>
      <div>There's an issue and the page could not be loaded.</div>
      <button>Reload page</button>
    </body></html>`;

  it('classifies the error interstitial as UNKNOWN, never ACTIVE', () => {
    const r = classifyHtml(ERROR_PAGE, META);
    expect(r.classification).toBe('UNKNOWN');
    expect(r.evidence.errorCode).toBe('ERROR_PAGE');
  });

  it('still classifies a genuine profile as ACTIVE', () => {
    const ok = `<html><head>
        <meta property="og:title" content="testuser (@testuser) • Instagram" />
        <meta property="og:url" content="https://www.instagram.com/testuser/" />
        <meta property="og:type" content="profile" />
        <link rel="canonical" href="https://www.instagram.com/testuser/" />
      </head><body><header><h2>testuser</h2></header>
      <div>10 posts 100 followers 50 following</div></body></html>`;
    expect(classifyHtml(ok, META).classification).toBe('ACTIVE');
  });
});

// ---------------------------------------------------------------------------
// Egress pooling. The fast probe is one request; when it is unpooled, the DNS + TCP + TLS
// handshake in front of it costs more than the request itself, on every single check.
// ---------------------------------------------------------------------------
describe('fast-probe egress pooling', () => {
  it('the DIRECT route gets a pooled keep-alive dispatcher, not undefined', () => {
    // Production runs PROXY_MODE=direct. The pool settings used to be applied ONLY inside
    // `new ProxyAgent(...)`, so the direct path returned undefined, fetch fell through to
    // undici's global agent, and every probe re-handshook www.instagram.com from scratch.
    const direct = dispatcherFor(null);
    expect(direct).toBeDefined();
    // ...and it is the SAME agent every time: pooling is worthless if a fresh one is built per
    // probe, which is exactly what a naive fix would do.
    expect(dispatcherFor(null)).toBe(direct);
  });

  it('a proxied route still gets its own dispatcher, and a bad URI still fails closed', () => {
    const proxied = dispatcherFor({
      server: 'http://127.0.0.1:9',
      username: null,
      password: null,
    });
    expect(proxied).toBeDefined();
    expect(proxied).not.toBe(dispatcherFor(null)); // never silently exits over the wrong network
    // An unusable proxy URI must still THROW so the caller fails closed, rather than quietly
    // becoming a direct connection now that direct is a real dispatcher.
    expect(() =>
      dispatcherFor({ server: 'not-a-valid-uri', username: null, password: null }),
    ).toThrow();
  });
});

// ---------------------------------------------------------------------------
// Scheduling defaults that are pure latency. Guarded here because each one is a single number
// with no other test holding it, and each was measured costing seconds on every recovery.
// ---------------------------------------------------------------------------
describe('latency-critical scheduling defaults', () => {
  it('baseline jitter stays small — it de-synchronises the fleet, it does not pace it', () => {
    // Mean added delay is half this, paid on every poll of every account. 15s (the value the
    // live deployment carried) cost ~7.5s of mean detection delay for no benefit at fleet size.
    expect(CONFIG.scheduling.baselineJitterMaxSeconds).toBeLessThanOrEqual(3);
  });

  it('the confirmation gap is short — it is spent inside a recovery that already happened', () => {
    // Costs (requiredCount - 1) extra probes per recovery EVENT, not per poll.
    expect(CONFIG.scheduling.confirmationIntervalSeconds).toBeLessThanOrEqual(2);
  });

  it('the confirmation deadline outlasts the slowest measured browser leg', () => {
    // Burst-scoped (see MonitorWorker). A browser confirmation leg measured 85-96s through the
    // mobile proxy; a burst where every check escalates is ~292s. Anything under that discards
    // genuine recoveries mid-burst — the failure this value exists to prevent.
    expect(CONFIG.scheduling.confirmationDeadlineSeconds).toBeGreaterThanOrEqual(292);
  });
});

// ---------------------------------------------------------------------------
// Circuit breaker
// ---------------------------------------------------------------------------
describe('CircuitBreaker', () => {
  it('identifies throttle signals', () => {
    expect(isThrottleSignal('LOGIN_WALL')).toBe(true);
    expect(isThrottleSignal('HTTP_429')).toBe(true);
    expect(isThrottleSignal('ERROR_PAGE')).toBe(true);
    expect(isThrottleSignal('DNS')).toBe(false);
    expect(isThrottleSignal(null)).toBe(false);
  });

  it('opens after the threshold and blocks all further requests', () => {
    const c = makeClock();
    const b = new CircuitBreaker({ threshold: 3, initialCooldownMs: 1000, now: c.now });
    expect(b.allowRequest()).toBe(true);
    b.record(true);
    b.record(true);
    expect(b.currentState()).toBe('CLOSED');
    b.record(true);
    expect(b.currentState()).toBe('OPEN');
    expect(b.allowRequest()).toBe(false);
  });

  it('a clean result resets the streak', () => {
    const b = new CircuitBreaker({ threshold: 3 });
    b.record(true);
    b.record(true);
    b.record(false);
    b.record(true);
    b.record(true);
    expect(b.currentState()).toBe('CLOSED');
  });

  it('half-opens after the cooldown and admits exactly one probe', () => {
    const c = makeClock();
    const b = new CircuitBreaker({ threshold: 1, initialCooldownMs: 1000, now: c.now });
    b.record(true);
    expect(b.currentState()).toBe('OPEN');
    c.advance(1000);
    expect(b.currentState()).toBe('HALF_OPEN');
    expect(b.allowRequest()).toBe(true);
    expect(b.allowRequest()).toBe(false);
  });

  it('a failed half-open probe doubles the cooldown', () => {
    const c = makeClock();
    const b = new CircuitBreaker({
      threshold: 1,
      initialCooldownMs: 1000,
      maxCooldownMs: 10000,
      now: c.now,
    });
    b.record(true);
    c.advance(1000);
    b.allowRequest();
    b.record(true);
    expect(b.currentState()).toBe('OPEN');
    c.advance(1000);
    expect(b.currentState()).toBe('OPEN'); // cooldown is now 2000
    c.advance(1000);
    expect(b.currentState()).toBe('HALF_OPEN');
  });

  it('a successful half-open probe closes it and restores the cooldown', () => {
    const c = makeClock();
    const b = new CircuitBreaker({ threshold: 1, initialCooldownMs: 1000, now: c.now });
    b.record(true);
    c.advance(1000);
    b.allowRequest();
    b.record(false);
    expect(b.currentState()).toBe('CLOSED');
    expect(b.allowRequest()).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// DURABLE back-off. The breaker used to live only in process memory, so a restart
// mid-cooldown (deploy, OOM, crash, systemd) came back CLOSED with a zeroed streak and the
// whole fleet resumed full-rate checking against an IP that was still being throttled — a
// crash loop made back-off structurally impossible. That burned a residential IP once.
//
// These tests never hand-write the stored snapshot: the FIRST breaker produces it through the
// same onTransition callback production persists from, and the second one reads that back.
// ---------------------------------------------------------------------------
describe('CircuitBreaker durability across restarts', () => {
  const T0 = Date.parse('2026-07-30T12:00:00.000Z');
  const TEN_MIN = 10 * 60 * 1000;
  const OPTIONS = { threshold: 2, initialCooldownMs: TEN_MIN, maxCooldownMs: 60 * 60 * 1000 };

  /** A breaker wired to a store, exactly as the composition root wires it. */
  function boot(
    now: () => number,
    restored: DurableBreakerState | null = null,
  ): { breaker: CircuitBreaker; store: { saved: DurableBreakerState | null } } {
    const store: { saved: DurableBreakerState | null } = { saved: null };
    const breaker = new CircuitBreaker({
      ...OPTIONS,
      now,
      onTransition: (state) => {
        store.saved = state;
      },
    });
    breaker.rehydrate(restored);
    return { breaker, store };
  }

  /**
   * A row production code could never have written — a truncated write, a hand-edited DB, an
   * older schema. Manufacturing it is the point: this is the one input the app does not produce.
   */
  function corruptRow(row: {
    state: string;
    openedAtUtc: string | null;
    cooldownMs: number;
    consecutive: number;
  }): DurableBreakerState {
    return row as DurableBreakerState;
  }

  it('REGRESSION: a restart mid-cooldown resumes the REMAINING back-off, not a clean slate', () => {
    const c = makeClock(T0);
    const first = boot(c.now);
    first.breaker.record(true);
    first.breaker.record(true);
    expect(first.breaker.currentState()).toBe('OPEN');

    // Four of the ten minutes pass, then the container restarts.
    c.advance(4 * 60 * 1000);
    const second = boot(c.now, first.store.saved);

    expect(second.breaker.currentState()).toBe('OPEN');
    expect(second.breaker.retryAfterMs()).toBe(6 * 60 * 1000);
    expect(second.breaker.allowRequest()).toBe(false);

    // ...and the resumed cooldown still expires on the ORIGINAL schedule.
    c.advance(6 * 60 * 1000);
    expect(second.breaker.currentState()).toBe('HALF_OPEN');
    expect(second.breaker.allowRequest()).toBe(true);
  });

  it('a cooldown already doubled by a failed trial probe survives the restart', () => {
    const c = makeClock(T0);
    const first = boot(c.now);
    first.breaker.record(true);
    first.breaker.record(true);
    c.advance(TEN_MIN);
    expect(first.breaker.allowRequest()).toBe(true); // the single trial probe
    first.breaker.record(true); // which failed => back off harder (20 minutes)
    c.advance(60 * 1000);

    const second = boot(c.now, first.store.saved);
    expect(second.breaker.retryAfterMs()).toBe(19 * 60 * 1000);
  });

  it('a restart after the stored cooldown expired costs ONE trial probe, not a stampede', () => {
    // The crash-loop case: every boot must spend a single probe deciding, never resume at
    // full rate and never block forever.
    const c = makeClock(T0);
    const first = boot(c.now);
    first.breaker.record(true);
    first.breaker.record(true);
    c.advance(3 * TEN_MIN);

    const second = boot(c.now, first.store.saved);
    expect(second.breaker.currentState()).toBe('HALF_OPEN');
    expect(second.breaker.allowRequest()).toBe(true);
    expect(second.breaker.allowRequest()).toBe(false);
  });

  it('the rehydrated cooldown is capped at the CURRENT configured maximum', () => {
    const c = makeClock(T0);
    const store: { saved: DurableBreakerState | null } = { saved: null };
    const generous = new CircuitBreaker({
      threshold: 1,
      initialCooldownMs: TEN_MIN,
      maxCooldownMs: 60 * 60 * 1000,
      now: c.now,
      onTransition: (state) => {
        store.saved = state;
      },
    });
    generous.record(true);
    for (let i = 0; i < 4; i += 1) {
      c.advance(60 * 60 * 1000);
      generous.allowRequest();
      generous.record(true); // each failed trial doubles it, up to the old hour-long cap
    }
    expect(generous.retryAfterMs()).toBe(60 * 60 * 1000);

    // The owner lowers BREAKER_MAX_COOLDOWN_SECONDS and restarts: the stored hour must not
    // outlive the maximum now configured.
    const strict = new CircuitBreaker({
      threshold: 1,
      initialCooldownMs: TEN_MIN,
      maxCooldownMs: 15 * 60 * 1000,
      now: c.now,
    });
    strict.rehydrate(store.saved);
    expect(strict.currentState()).toBe('OPEN');
    expect(strict.retryAfterMs()).toBe(15 * 60 * 1000);
  });

  it('nothing stored means a clean CLOSED start', () => {
    const c = makeClock(T0);
    const fresh = boot(c.now, null);
    expect(fresh.breaker.currentState()).toBe('CLOSED');
    expect(fresh.breaker.allowRequest()).toBe(true);
  });

  it('a corrupt stored value degrades to a bounded posture, never a wedge', () => {
    const c = makeClock(T0);

    // Unreadable phase => the row means nothing; start clean rather than guessing.
    const garbagePhase = boot(
      c.now,
      corruptRow({
        state: 'BROKEN',
        openedAtUtc: 'not-a-date',
        cooldownMs: Number.NaN,
        consecutive: -5,
      }),
    );
    expect(garbagePhase.breaker.currentState()).toBe('CLOSED');
    expect(garbagePhase.breaker.allowRequest()).toBe(true);

    // Known phase but an unreadable open-time: one trial probe decides it. Trusting a garbage
    // timestamp for a whole cooldown would be a wedge; ignoring it would resume at full rate.
    const noTime = boot(
      c.now,
      corruptRow({
        state: 'OPEN',
        openedAtUtc: null,
        cooldownMs: Number.NaN,
        consecutive: Number.NaN,
      }),
    );
    expect(noTime.breaker.currentState()).toBe('HALF_OPEN');
    expect(noTime.breaker.allowRequest()).toBe(true);
    expect(noTime.breaker.allowRequest()).toBe(false);
    noTime.breaker.record(false);
    expect(noTime.breaker.currentState()).toBe('CLOSED'); // and it can always recover
  });

  it('a far-future stored open-time cannot block for longer than one cooldown', () => {
    // Clock skew (a host running hours fast, then corrected) or a corrupt row.
    const c = makeClock(T0);
    const skewed = boot(
      c.now,
      corruptRow({
        state: 'OPEN',
        openedAtUtc: new Date(T0 + 365 * 24 * 60 * 60 * 1000).toISOString(),
        cooldownMs: TEN_MIN,
        consecutive: 2,
      }),
    );
    expect(skewed.breaker.retryAfterMs()).toBeLessThanOrEqual(TEN_MIN);
    c.advance(TEN_MIN);
    expect(skewed.breaker.currentState()).toBe('HALF_OPEN');
  });

  it('a clean probe after a rehydrated block closes it and publishes the change', () => {
    const c = makeClock(T0);
    const first = boot(c.now);
    first.breaker.record(true);
    first.breaker.record(true);
    c.advance(TEN_MIN);

    const second = boot(c.now, first.store.saved);
    expect(second.breaker.allowRequest()).toBe(true);
    second.breaker.record(false);

    expect(second.breaker.currentState()).toBe('CLOSED');
    // The recovery must reach the store too, or the NEXT restart would re-apply a dead block.
    expect(second.store.saved?.state).toBe('CLOSED');
    expect(second.store.saved?.openedAtUtc).toBeNull();

    const third = boot(c.now, second.store.saved);
    expect(third.breaker.currentState()).toBe('CLOSED');
  });

  it('/proxy clearing the breaker is persisted, so a restart does not re-apply the old block', () => {
    const c = makeClock(T0);
    const first = boot(c.now);
    first.breaker.record(true);
    first.breaker.record(true);
    expect(first.breaker.currentState()).toBe('OPEN');

    first.breaker.reset(); // what a route switch does
    const second = boot(c.now, first.store.saved);
    expect(second.breaker.currentState()).toBe('CLOSED');
  });

  it('a store that throws never breaks detection', () => {
    const c = makeClock(T0);
    const breaker = new CircuitBreaker({
      ...OPTIONS,
      now: c.now,
      onTransition: () => {
        throw new Error('disk full');
      },
    });
    breaker.record(true);
    breaker.record(true);
    expect(breaker.currentState()).toBe('OPEN'); // back-off still engaged, just not stored
  });

  it('back-off is scoped to the egress route that earned it', () => {
    // The owner switches away from a burned proxy and restarts. Re-applying that route's block
    // to the new one would hold the whole fleet off-network for a cooldown it never earned.
    const c = makeClock(T0);
    const burned = boot(c.now);
    burned.breaker.record(true);
    burned.breaker.record(true);
    const saved = burned.store.saved;
    expect(saved).not.toBeNull();
    const row = {
      name: EGRESS_BREAKER_NAME,
      ...(saved as DurableBreakerState),
      egressRoute: 'proxy 10.0.0.1:8080',
      updatedAtUtc: new Date(T0).toISOString(),
    };

    expect(backOffForRoute(row, 'direct (this machine’s own connection)')).toBeNull();
    // ...but the SAME route keeps its block, or a restart loop would clear every cooldown.
    expect(backOffForRoute(row, 'proxy 10.0.0.1:8080')).not.toBeNull();
    expect(backOffForRoute(null, 'proxy 10.0.0.1:8080')).toBeNull();

    const restarted = new CircuitBreaker({ ...OPTIONS, now: c.now });
    restarted.rehydrate(backOffForRoute(row, 'direct (this machine’s own connection)'));
    expect(restarted.currentState()).toBe('CLOSED');
  });

  it('the phase union stays in step with the persisted one', () => {
    // Compile-time guard: BreakerState is an alias of the persisted BreakerPhase, so adding a
    // phase to one without the other cannot slip through.
    const phases: BreakerState[] = ['CLOSED', 'OPEN', 'HALF_OPEN'];
    expect(phases).toHaveLength(3);
  });
});

// ---------------------------------------------------------------------------
// Tiered detector: the cheap path must never weaken detection or lose screenshots.
// ---------------------------------------------------------------------------
describe('TieredDetector', () => {
  const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47]);

  function browserFake(
    classification: 'ACTIVE' | 'GONE' | 'UNKNOWN',
    withShot = true,
  ): { detector: Detector; calls: { username: string; options: ProbeOptions }[] } {
    const calls: { username: string; options: ProbeOptions }[] = [];
    const detector: Detector = {
      probe: async (username: string, options: ProbeOptions = {}): Promise<ProbeResult> => {
        calls.push({ username, options });
        return {
          result: {
            classification,
            evidence: {
              signalsVersion: 'v',
              activeSignals: [],
              goneSignals: [],
              identitySignalMatched: classification === 'ACTIVE',
              finalUrl: null,
              responseStatus: 200,
              errorCode: null,
            },
            durationMs: 5,
          },
          screenshot:
            withShot && options.captureScreenshot && classification === 'ACTIVE'
              ? { buffer: PNG, format: 'png', width: 1, height: 1 }
              : null,
        };
      },
    };
    return { detector, calls };
  }

  /**
   * The control account ('instagram') is what the CANARY probes. By default it reports a
   * healthy link (identity matched) so tests exercise the normal path; pass canaryHealthy
   * false to simulate a login-walled / flaky egress.
   */
  function fastProbeFake(
    classification: 'ACTIVE' | 'GONE' | 'UNKNOWN',
    errorCode: string | null = null,
    canaryHealthy = true,
  ): {
    impl: (username: string) => Promise<unknown>;
    calls: string[];
    target: () => string[];
  } {
    const calls: string[] = [];
    const impl = async (username: string): Promise<unknown> => {
      calls.push(username);
      const isCanary = username === CONFIG.controlUsername;
      const cls = isCanary ? (canaryHealthy ? 'ACTIVE' : 'UNKNOWN') : classification;
      const identity = isCanary ? canaryHealthy : classification === 'ACTIVE';
      return {
        result: {
          classification: cls,
          evidence: {
            signalsVersion: 'v',
            activeSignals: [],
            goneSignals: [],
            identitySignalMatched: identity,
            finalUrl: null,
            responseStatus: 200,
            errorCode: isCanary ? null : errorCode,
          },
          durationMs: 1,
        },
        transportFailed: false,
      };
    };
    return { impl, calls, target: () => calls.filter((u) => u !== CONFIG.controlUsername) };
  }

  it('no profile identity => still GONE, answered by the cheap probe alone', async () => {
    // A banned account's raw HTML has no metadata, so the fast probe cannot see the
    // client-rendered "unavailable" copy — it reports UNKNOWN/UNRECOGNIZED_DOM with no
    // identity. That is the signal the tier uses, and it must NOT hit the browser.
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const out = await d.probe('testuser');
    expect(out.result.classification).toBe('GONE');
    expect(f.target()).toHaveLength(1);
    expect(b.calls).toHaveLength(0);
  });

  // REGRESSION 2026-08-05: a check the detector DECLINES to make must say so.
  //
  // Breaker-open and governor-deferred results are UNKNOWN/HTTP_429 — shape-identical to
  // Instagram genuinely rate-limiting us — so without an explicit flag the health accounting
  // cannot tell "we looked and failed" from "we chose not to look". Counting the latter inverted
  // the unknown rate: the harder the fleet protected the IP, the more degraded it declared
  // itself, warning the owner all night about a fleet whose real checks were clean.
  it('a BREAKER-BLOCKED probe is flagged notObserved', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM');
    // Threshold 1 + a throttle code opens the breaker on the first check; the second is blocked.
    const breaker = new CircuitBreaker({ threshold: 1, initialCooldownMs: 600_000 });
    const throttling = fastProbeFake('UNKNOWN', 'LOGIN_WALL');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      breaker,
      httpProbeImpl: throttling.impl as never,
    });
    await d.probe('testuser'); // trips the breaker
    const blocked = await d.probe('testuser'); // short-circuits without touching the network

    expect(breaker.snapshot().state).not.toBe('CLOSED');
    expect(blocked.result.classification).toBe('UNKNOWN');
    expect(blocked.notObserved).toBe(true);
    void f;
  });

  it('a GOVERNOR-DEFERRED probe is flagged notObserved', async () => {
    const b = browserFake('GONE');
    // Transport failure forces escalation to the browser, where the governor refuses a ROUTINE
    // probe once the budget is spent.
    const f = fastProbeFake('UNKNOWN', 'NAVIGATION');
    // The governor floors its routine allowance at 1 (a hostile config must not lock routine
    // polling out entirely), so the budget is SPENT by a first real escalation — exactly how
    // production reaches deferral — and the second probe is the one that gets refused.
    const governor = new BrowserLoadGovernor({ capacity: 1, routineFraction: 0.1 });
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      governor,
      httpProbeImpl: f.impl as never,
    });
    const routine: TieredProbeOptions = { loadPriority: 'ROUTINE' };

    const admitted = await d.probe('testuser', routine); // spends the allowance
    expect(admitted.notObserved).toBeUndefined();
    expect(b.calls).toHaveLength(1);

    const deferred = await d.probe('testuser', routine); // budget gone
    expect(deferred.result.classification).toBe('UNKNOWN');
    expect(deferred.notObserved).toBe(true);
    expect(b.calls).toHaveLength(1); // no second page load
  });

  it('a REAL observed result is NOT flagged, so genuine faults still count', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const out = await d.probe('testuser');
    expect(out.notObserved).toBeUndefined();
  });

  // --- regressions from the 2026-07-27 multi-agent review ---------------------------------

  it('REGRESSION: /proxy clears an OPEN breaker (egress sync runs before the gate)', async () => {
    // The breaker reset used to live inside dispatcher(), which is only reachable AFTER the
    // breaker gate — so switching route to escape a throttled IP could not clear the block.
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'LOGIN_WALL');
    const breaker = new CircuitBreaker({ threshold: 2, initialCooldownMs: 600_000 });
    const config = {
      ...CONFIG,
      browserProxy: { server: 'http://127.0.0.1:1', username: null, password: null },
      proxyMode: 'proxy' as const,
    };
    const sw = new ProxySwitch(config);
    const d = new TieredDetector({
      browserDetector: b.detector,
      config,
      logger: nullLogger(),
      breaker,
      proxySwitch: sw,
      httpProbeImpl: f.impl as never,
    });
    await d.probe('a');
    await d.probe('b');
    expect(breaker.currentState()).toBe('OPEN');

    sw.set('direct'); // owner runs /proxy home to escape the throttled route
    await d.probe('c');
    expect(breaker.currentState()).not.toBe('OPEN');
  });

  it('REGRESSION: the first probe of a new process does not wipe the rehydrated back-off', async () => {
    // syncEgress() reset the shared breaker whenever the dispatcher generation moved — including
    // the very FIRST adoption, which is not a route change at all. So the back-off restored at
    // startup was destroyed by the first check, and the fleet resumed full rate against an IP
    // that was still mid-cooldown.
    const c = makeClock(Date.parse('2026-07-30T12:00:00.000Z'));
    const store: { saved: DurableBreakerState | null } = { saved: null };
    const before = new CircuitBreaker({
      threshold: 2,
      initialCooldownMs: 600_000,
      now: c.now,
      onTransition: (state) => {
        store.saved = state;
      },
    });
    const throttled = fastProbeFake('UNKNOWN', 'LOGIN_WALL');
    const d1 = new TieredDetector({
      browserDetector: browserFake('GONE').detector,
      config: CONFIG,
      logger: nullLogger(),
      breaker: before,
      httpProbeImpl: throttled.impl as never,
    });
    await d1.probe('a');
    await d1.probe('b');
    expect(before.currentState()).toBe('OPEN');

    // A minute later the container restarts and the new process rehydrates.
    c.advance(60_000);
    const after = new CircuitBreaker({ threshold: 2, initialCooldownMs: 600_000, now: c.now });
    after.rehydrate(store.saved);
    const b2 = browserFake('GONE');
    const f2 = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM');
    const d2 = new TieredDetector({
      browserDetector: b2.detector,
      config: CONFIG,
      logger: nullLogger(),
      breaker: after,
      httpProbeImpl: f2.impl as never,
    });

    const out = await d2.probe('c');
    expect(f2.calls.length + b2.calls.length).toBe(0); // nothing touched the network
    expect(out.result.classification).toBe('UNKNOWN');
    expect(after.currentState()).toBe('OPEN');
    expect(after.retryAfterMs()).toBe(540_000); // nine minutes still to serve
  });

  it('REGRESSION: a lagging detector cannot wipe a block re-earned on the NEW route', async () => {
    // app.ts builds TWO TieredDetectors over ONE breaker and ONE ProxySwitch: the monitor
    // fleet's, and the deletion watcher's (fast path off). Each learns about a /proxy switch
    // lazily, on its own next probe — and the deletion watcher only probes when a watch is due,
    // so it is reliably minutes-to-hours behind. While each detector decided for ITSELF whether
    // it was seeing a route change, that straggler's catch-up reset the shared breaker long
    // after the fleet had re-earned a block on the new route: the whole fleet resumed full-rate
    // checking against a throttled IP, and because reset() publishes, the durable row was
    // overwritten CLOSED so a restart in that window resumed at full rate too.
    const c = makeClock(Date.parse('2026-07-30T12:00:00.000Z'));
    const store: { saved: DurableBreakerState | null } = { saved: null };
    const breaker = new CircuitBreaker({
      threshold: 2,
      initialCooldownMs: 600_000,
      now: c.now,
      onTransition: (state) => {
        store.saved = state;
      },
    });
    const config = {
      ...CONFIG,
      browserProxy: { server: 'http://127.0.0.1:1', username: null, password: null },
      proxyMode: 'proxy' as const,
    };
    const sw = new ProxySwitch(config);

    // One knob for how the CURRENT route is behaving; the control account always resolves, so
    // the canary never stands in the way of the inference under test.
    let routeCode: string | null = 'UNRECOGNIZED_DOM';
    const fast = async (username: string): Promise<unknown> => {
      const isCanary = username === CONFIG.controlUsername;
      return {
        result: {
          classification: 'UNKNOWN',
          evidence: {
            signalsVersion: 'v',
            activeSignals: [],
            goneSignals: [],
            identitySignalMatched: isCanary,
            finalUrl: null,
            responseStatus: 200,
            errorCode: isCanary ? null : routeCode,
          },
          durationMs: 1,
        },
        transportFailed: false,
      };
    };
    const shared = { config, logger: nullLogger(), breaker, proxySwitch: sw, now: c.now };
    const monitor = new TieredDetector({
      ...shared,
      browserDetector: browserFake('GONE').detector,
      httpProbeImpl: fast as never,
    });
    const watcherBrowser = browserFake('GONE');
    const deletion = new TieredDetector({
      ...shared,
      browserDetector: watcherBrowser.detector,
      fastPath: false,
      httpProbeImpl: fast as never,
    });

    // Both detectors bind to the starting route through their own first probe — nothing here is
    // hand-seeded, this is exactly what the two workers do on boot.
    await monitor.probe('a');
    await deletion.probe('watched');
    expect(breaker.currentState()).toBe('CLOSED');

    // The owner runs /proxy home to escape a throttled IP. The monitor fleet catches up within a
    // second and correctly clears the block — but the new route turns out to be throttled too,
    // and the fleet earns a fresh one ON IT.
    sw.set('direct');
    routeCode = 'LOGIN_WALL';
    await monitor.probe('b');
    await monitor.probe('c');
    expect(breaker.currentState()).toBe('OPEN');
    expect(store.saved?.state).toBe('OPEN');

    // Five minutes later that deletion watch finally comes due and the watcher catches up to the
    // same switch. The route has not changed since the block was earned, so the block must hold.
    c.advance(5 * 60 * 1000);
    const seenBefore = watcherBrowser.calls.length;
    const out = await deletion.probe('watched');

    expect(breaker.currentState()).toBe('OPEN');
    expect(breaker.retryAfterMs()).toBe(5 * 60 * 1000);
    expect(watcherBrowser.calls.length).toBe(seenBefore); // nothing touched the throttled route
    expect(out.result.evidence.errorCode).toBe('HTTP_429');
    // ...and the durable row still describes a blocked route, so a restart here stays blocked.
    expect(store.saved?.state).toBe('OPEN');
  });

  it('REGRESSION: a truncated read is never inferred as "still gone"', async () => {
    // Absence of evidence in a partial page is not evidence of absence: the throttle copy may
    // simply not have been reached. It must escalate rather than assert GONE.
    const b = browserFake('ACTIVE');
    const impl = async (): Promise<unknown> => ({
      result: {
        classification: 'UNKNOWN',
        evidence: {
          signalsVersion: 'v',
          activeSignals: [],
          goneSignals: [],
          identitySignalMatched: false,
          finalUrl: null,
          responseStatus: 200,
          errorCode: 'EMPTY_PAGE',
        },
        durationMs: 1,
      },
      transportFailed: false,
      bodyTruncated: true,
    });
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: impl as never,
    });
    const out = await d.probe('testuser');
    expect(b.calls).toHaveLength(1);
    expect(out.result.classification).toBe('ACTIVE');
  });

  it('REGRESSION: browser-only mode still shares the breaker (deletion watcher)', async () => {
    const b = browserFake('UNKNOWN');
    const f = fastProbeFake('GONE');
    const breaker = new CircuitBreaker({ threshold: 5, initialCooldownMs: 1000 });
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      breaker,
      fastPath: false,
      httpProbeImpl: f.impl as never,
    });
    await d.probe('x');
    expect(f.calls).toHaveLength(0); // fast path fully disabled
    expect(b.calls).toHaveLength(1); // but it did go through the breaker-aware path
  });

  it('CANARY: an unhealthy link must NOT be read as "still gone" — it escalates', async () => {
    // This is the silent-blindness guard. On a login-walled egress EVERY account looks
    // metadata-less, so trusting that would manufacture GONE for accounts that recovered.
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM', false);
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const out = await d.probe('testuser');
    expect(b.calls).toHaveLength(1); // escalated rather than guessing
    expect(out.result.classification).toBe('ACTIVE'); // browser found the truth
  });

  it('CANARY: result is cached, so it does not probe the control on every check', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM', true);
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    await d.probe('a');
    await d.probe('b');
    await d.probe('c');
    const canaryCalls = f.calls.filter((u) => u === CONFIG.controlUsername).length;
    expect(canaryCalls).toBe(1);
    expect(f.target()).toHaveLength(3);
  });

  it('matched identity is ALWAYS re-verified in the browser', async () => {
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('ACTIVE');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const out = await d.probe('testuser');
    expect(out.result.classification).toBe('ACTIVE');
    expect(b.calls).toHaveLength(1);
  });

  // --- allowFastActive: one browser load per recovery instead of one per confirmation ---------
  // A recovery needs 3 consecutive ACTIVE results and every one of them used to buy its own
  // Chromium page load (20-50 requests, ~8s each) to re-read evidence the cheap tier had already
  // read correctly. Only the check that can actually CONFIRM needs that verdict.

  it('a NON-DECIDING confirmation may stand on the fast tier — no browser load at all', async () => {
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('ACTIVE');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const options: TieredProbeOptions = { allowFastActive: true };

    const out = await d.probe('testuser', options);

    expect(out.result.classification).toBe('ACTIVE');
    expect(b.calls).toHaveLength(0); // the 20-50 requests that are no longer sent
    expect(f.target()).toHaveLength(1); // replaced by exactly one
    // ...and /ping must see this as the cheap tier ANSWERING, not as an escalation.
    const report = await d.fastTierReport();
    expect(report.answered.fast).toBe(1);
    expect(report.answered.browser).toBe(0);
    expect(report.consecutiveEscalations).toBe(0);
  });

  it('the option NEVER promotes a fast result that classify() did not call ACTIVE', async () => {
    // Real markup through the REAL pipeline, not a hand-set flag: profile og metadata together
    // with the unavailable copy. classify() calls that CONTRADICTORY/UNKNOWN while identity
    // still matches — and identity is what the escalation branch keys on. Letting the option
    // key on identity rather than the verdict would turn pages like this (and the "Something
    // went wrong" throttle interstitial, which also carries og metadata) into confirmation steps.
    const contradictory = classifyHtml(
      `<html><head>
         <meta property="og:title" content="testuser (@testuser) • Instagram" />
         <link rel="canonical" href="https://www.instagram.com/testuser/" />
       </head><body>Sorry, this page isn't available.</body></html>`,
      META,
    );
    expect(contradictory.classification).toBe('UNKNOWN');
    expect(contradictory.evidence.identitySignalMatched).toBe(true);
    expect(isThrottleSignal(contradictory.evidence.errorCode)).toBe(false); // reaches the branch

    const b = browserFake('GONE');
    const impl = async (): Promise<unknown> => ({
      result: contradictory,
      transportFailed: false,
    });
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: impl as never,
    });
    const options: TieredProbeOptions = { allowFastActive: true };

    const out = await d.probe('testuser', options);

    expect(b.calls).toHaveLength(1); // escalated anyway
    expect(out.result.classification).toBe('GONE'); // and the browser had the final say
  });

  it('a DECIDING confirmation still goes to the browser even when the fast tier says ACTIVE', async () => {
    // The non-negotiable: nobody is ever told on fast-tier evidence alone.
    const b = browserFake('GONE');
    const f = fastProbeFake('ACTIVE');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const options: TieredProbeOptions = {}; // deciding check: the caller opts out

    const out = await d.probe('testuser', options);

    expect(b.calls).toHaveLength(1);
    expect(out.result.classification).toBe('GONE');
  });

  it('never reports ACTIVE from the cheap probe alone (browser has the final say)', async () => {
    // Fast says the profile is back, but the browser disagrees — the browser must win, so a
    // recovery alert can never fire on the cheap signal.
    const b = browserFake('GONE');
    const f = fastProbeFake('ACTIVE');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const out = await d.probe('testuser');
    expect(out.result.classification).toBe('GONE');
  });

  it('a screenshot request goes straight to the browser and returns the image', async () => {
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('GONE');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const out = await d.probe('testuser', { captureScreenshot: true });
    expect(f.calls).toHaveLength(0); // never wastes a cheap probe when a capture is needed
    expect(b.calls[0]?.options.captureScreenshot).toBe(true);
    expect(out.screenshot?.buffer).toEqual(PNG);
  });

  it('an open breaker blocks probes without touching the network', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'LOGIN_WALL');
    const breaker = new CircuitBreaker({ threshold: 2, initialCooldownMs: 60_000 });
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      breaker,
      httpProbeImpl: f.impl as never,
    });
    await d.probe('a');
    await d.probe('b');
    expect(breaker.currentState()).toBe('OPEN');

    const before = f.calls.length + b.calls.length;
    const out = await d.probe('c');
    expect(f.calls.length + b.calls.length).toBe(before); // nothing hit the network
    expect(out.result.classification).toBe('UNKNOWN');
  });

  it('a transport failure falls back to the browser', async () => {
    const b = browserFake('GONE');
    const impl = async (): Promise<unknown> => ({
      result: {
        classification: 'UNKNOWN',
        evidence: {
          signalsVersion: 'v',
          activeSignals: [],
          goneSignals: [],
          identitySignalMatched: false,
          finalUrl: null,
          responseStatus: null,
          errorCode: 'DNS',
        },
        durationMs: 1,
      },
      transportFailed: true,
    });
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: impl as never,
    });
    await d.probe('testuser');
    expect(b.calls).toHaveLength(1);
  });

  it('REGRESSION: the breaker can actually OPEN when the browser reports the throttle', async () => {
    // The fast probe cannot see body-rendered throttling (it stops at </head>), so during a
    // real throttle it returns a clean non-throttle code and the browser reports the truth.
    // Recording BOTH legs would zero the streak each check (0 -> 1 -> 0) and the breaker could
    // never reach its threshold — exactly the bug that let an IP get burned.
    const b = browserFake('UNKNOWN');
    // Browser reports a throttle.
    const throttlingBrowser: Detector = {
      probe: async () => ({
        result: {
          classification: 'UNKNOWN',
          evidence: {
            signalsVersion: 'v',
            activeSignals: [],
            goneSignals: [],
            identitySignalMatched: false,
            finalUrl: null,
            responseStatus: 200,
            errorCode: 'ERROR_PAGE',
          },
          durationMs: 5,
        },
        screenshot: null,
      }),
    };
    void b;
    // Fast probe: identity matched (so it escalates), no throttle code.
    const f = fastProbeFake('ACTIVE');
    const breaker = new CircuitBreaker({ threshold: 3, initialCooldownMs: 60_000 });
    const d = new TieredDetector({
      browserDetector: throttlingBrowser,
      config: CONFIG,
      logger: nullLogger(),
      breaker,
      httpProbeImpl: f.impl as never,
    });
    await d.probe('a');
    await d.probe('b');
    await d.probe('c');
    expect(breaker.currentState()).toBe('OPEN');
  });

  it('REGRESSION: a failed observation is never asserted as GONE', async () => {
    // HTTP_5XX / redirects / consent walls mean "we did not see the page", not "still banned".
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('UNKNOWN', 'HTTP_5XX');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const out = await d.probe('testuser');
    expect(b.calls).toHaveLength(1); // escalated
    expect(out.result.classification).toBe('ACTIVE');
  });

  // --- DEFECT C: the fast tier must be able to report on ITSELF -----------------------------
  // `probe()` cannot answer "did the fast tier work?": every fast-tier failure falls back to the
  // browser and returns the browser's verdict, so /ping saw ACTIVE either way and printed
  // "Fast probe: Working" with a completely dead fast tier.

  it('fastTierReport says ok when the control account resolves over the fast path', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM', true);
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const report = await d.fastTierReport();
    expect(report.state).toBe('ok');
    expect(report.canaryHealthy).toBe(true);
    // One cheap HTTP request, and never the browser — /ping must not pay for a second page load.
    expect(b.calls).toHaveLength(0);
    expect(f.calls).toEqual([CONFIG.controlUsername]);
  });

  it('fastTierReport says degraded when the fast path cannot resolve the control account', async () => {
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM', false);
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    const report = await d.fastTierReport();
    expect(report.state).toBe('degraded');
    expect(report.canaryHealthy).toBe(false);
    expect(b.calls).toHaveLength(0);
  });

  it('fastTierReport re-measures rather than reporting a stale canary verdict', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM', true);
    let t = 1_000_000;
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
      now: () => t,
    });
    await d.probe('a'); // warms the canary cache
    t += 61_000;
    await d.fastTierReport();
    const canaryCalls = f.calls.filter((u) => u === CONFIG.controlUsername).length;
    expect(canaryCalls).toBe(2); // a five-minute-old measurement is not a health check
  });

  // A failed canary costs the WHOLE fleet a browser load per check until it is retried, so the
  // diagnostic must not be able to manufacture that by being run repeatedly: a verdict younger
  // than the retry window is already as fresh as production's own view.
  //
  // The window is now 15s rather than 60s, and that is a LOAD bound, not a freshness one: while
  // the canary is red every fast negative escalates to a full Chromium load fleet-wide, so the
  // retry interval IS the length of time the fleet stays in the expensive posture after the route
  // has recovered. Both halves are asserted so neither can drift silently.
  it('fastTierReport does not re-roll a canary measured inside the retry window', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM', true);
    let t = 1_000_000;
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
      now: () => t,
    });
    await d.fastTierReport();
    t += 5_000;
    await d.fastTierReport();
    expect(f.calls.filter((u) => u === CONFIG.controlUsername)).toHaveLength(1);

    // ...and a red canary IS retried well inside a minute, because the fleet is paying browser
    // loads for every check until it goes green again.
    t += 11_000;
    await d.fastTierReport();
    expect(f.calls.filter((u) => u === CONFIG.controlUsername)).toHaveLength(2);
  });

  it('fastTierReport reports an open breaker WITHOUT touching the network', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'LOGIN_WALL');
    const breaker = new CircuitBreaker({ threshold: 2, initialCooldownMs: 60_000 });
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      breaker,
      httpProbeImpl: f.impl as never,
    });
    await d.probe('a');
    await d.probe('b');
    expect(breaker.currentState()).toBe('OPEN');

    const before = f.calls.length + b.calls.length;
    const report = await d.fastTierReport();
    expect(report.state).toBe('blocked');
    expect(report.breakerState).toBe('OPEN');
    expect(report.breakerRetryAfterMs).toBeGreaterThan(0);
    expect(f.calls.length + b.calls.length).toBe(before);
  });

  it('fastTierReport says disabled in browser-only mode', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('GONE');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      fastPath: false,
      httpProbeImpl: f.impl as never,
    });
    const report = await d.fastTierReport();
    expect(report.state).toBe('disabled');
    expect(f.calls).toHaveLength(0);
  });

  it('reports which tier actually answered each probe', async () => {
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM', true);
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    await d.probe('a'); // answered cheaply: no identity, healthy canary => still GONE
    await d.probe('b', { captureScreenshot: true }); // forced to the browser
    const report = await d.fastTierReport();
    expect(report.answered.fast).toBe(1);
    expect(report.answered.browser).toBe(1);
    expect(report.answered.blocked).toBe(0);
  });

  // DEFECT C, surviving half. The verdict rested SOLELY on the canary, and the canary only
  // proves the (heavily cached) control account resolves. When Instagram serves monitored
  // accounts something outside INFERABLE_GONE_CODES, every routine check escalates to a full
  // Chromium load while /ping keeps printing "Fast probe: Working" — the silent IP burn.
  it('fastTierReport is degraded when a green canary hides a tier answering nothing', async () => {
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('UNKNOWN', 'HTTP_5XX', true); // not inferable => always escalates
    let t = 1_000_000;
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
      now: () => t,
    });
    for (let i = 0; i < 19; i += 1) await d.probe(`acct${i}`);
    // A handful of escalations is ordinary; the tier is not condemned for them.
    expect((await d.fastTierReport()).state).toBe('ok');

    t += 61_000;
    for (let i = 0; i < 10; i += 1) await d.probe(`more${i}`);
    const report = await d.fastTierReport();
    expect(report.state).toBe('degraded');
    expect(report.canaryHealthy).toBe(true); // the canary itself is still perfectly happy
    expect(report.answered.fast).toBe(0);
    expect(report.answered.browser).toBe(29);
  });

  it('a fast-tier answer clears the escalation streak', async () => {
    const b = browserFake('ACTIVE');
    let errorCode = 'HTTP_5XX'; // not inferable, so every check escalates
    const impl = async (username: string): Promise<unknown> => {
      const isCanary = username === CONFIG.controlUsername;
      return {
        result: {
          classification: 'UNKNOWN',
          evidence: {
            signalsVersion: 'v',
            activeSignals: [],
            goneSignals: [],
            identitySignalMatched: isCanary,
            finalUrl: null,
            responseStatus: 200,
            errorCode: isCanary ? null : errorCode,
          },
          durationMs: 1,
        },
        transportFailed: false,
      };
    };
    let t = 1_000_000;
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: impl as never,
      now: () => t,
    });
    for (let i = 0; i < 25; i += 1) await d.probe(`acct${i}`);
    expect((await d.fastTierReport()).state).toBe('degraded');

    errorCode = 'UNRECOGNIZED_DOM'; // the cheap tier can conclude again
    t += 61_000;
    await d.probe('recovered');
    expect((await d.fastTierReport()).state).toBe('ok');
  });

  it('a throttled cheap probe does not escalate to the browser (no extra load)', async () => {
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'LOGIN_WALL');
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      httpProbeImpl: f.impl as never,
    });
    await d.probe('testuser');
    expect(b.calls).toHaveLength(0);
  });

  // -------------------------------------------------------------------------------------------
  // THE RATE GOVERNOR, as the detector actually uses it.
  //
  // Nothing in this system counted Chromium page loads, which is the resource that actually burns
  // the residential IP. The circuit breaker cannot substitute: it is a reactive brake on
  // THROTTLING, and an escalation storm or a red canary produces browser loads that SUCCEED — so
  // they report success and the breaker never opens while load is 20-50x normal.
  // -------------------------------------------------------------------------------------------

  /** A governor sized so a test can exhaust it in a handful of probes. */
  function governed(capacity: number, fraction: number, now: () => number): BrowserLoadGovernor {
    return new BrowserLoadGovernor({ capacity, routineFraction: fraction, now });
  }

  it('REGRESSION: a red canary can no longer drive UNBOUNDED browser load', async () => {
    // The mechanism that burned the first residential IP. A failed canary forces escalation on
    // every fast negative, fleet-wide — and correctly so, because on a login-walled route every
    // account looks metadata-less and inferring GONE would silently lose recoveries. What was
    // missing is a bound on the COST: 20 accounts at a 15s baseline is ~4,500 Chromium loads an
    // hour against a ~200/hour ceiling, and nothing stopped it.
    const c = makeClock(1_000_000);
    const b = browserFake('GONE');
    const f = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM', false); // canary RED
    const governor = governed(10, 0.5, c.now); // routine allowance = 5
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      governor,
      httpProbeImpl: f.impl as never,
      now: c.now,
    });

    const results = [];
    for (let i = 0; i < 30; i += 1) {
      results.push(await d.probe(`acct${i}`, { loadPriority: 'ROUTINE' } as TieredProbeOptions));
    }

    // Without the governor this is 30. The bound is what the whole task is about.
    expect(b.calls).toHaveLength(5);
    expect(governor.report().deferred).toBe(25);

    // ...and the 25 that were refused are DEFERRED, not dropped and — the part that matters most —
    // never inferred. A deferred check says "I did not look", never "still banned".
    const deferred = results.slice(5);
    expect(deferred.every((r) => r.result.classification === 'UNKNOWN')).toBe(true);
    expect(deferred.some((r) => r.result.classification === 'GONE')).toBe(false);
  });

  it('NON-NEGOTIABLE: a possible recovery is admitted even with the budget fully spent', async () => {
    // The single most important property in the task. Routine polling has exhausted the budget;
    // the fast tier then sees a monitored profile's own identity metadata come back, which is the
    // leading edge of a recovery. That escalation MUST happen — losing it is harm rank 1.
    const c = makeClock(1_000_000);
    const b = browserFake('ACTIVE');
    const governor = governed(10, 0.5, c.now); // routine allowance = 5
    // One fast probe that answers per username: everyone is an unreadable page (so routine checks
    // escalate and drain the budget) except `recovered`, whose identity metadata is back.
    const impl = async (username: string): Promise<unknown> => {
      const isCanary = username === CONFIG.controlUsername;
      const recovered = username === 'recovered';
      return {
        result: {
          classification: recovered ? 'ACTIVE' : 'UNKNOWN',
          evidence: {
            signalsVersion: 'v',
            activeSignals: [],
            goneSignals: [],
            identitySignalMatched: isCanary || recovered,
            finalUrl: null,
            responseStatus: 200,
            errorCode: isCanary || recovered ? null : 'HTTP_5XX',
          },
          durationMs: 1,
        },
        transportFailed: false,
      };
    };
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      governor,
      httpProbeImpl: impl as never,
      now: c.now,
    });

    // Drain the routine allowance, then keep going so the budget is genuinely spent.
    for (let i = 0; i < 12; i += 1) {
      await d.probe(`acct${i}`, { loadPriority: 'ROUTINE' } as TieredProbeOptions);
    }
    expect(governor.report().deferred).toBeGreaterThan(0);
    const routineLoads = b.calls.length;

    // The deciding confirmation check for an account that just came back.
    const out = await d.probe('recovered', { loadPriority: 'ROUTINE' } as TieredProbeOptions);

    // It went to the browser despite being labelled ROUTINE by the caller: the detector upgrades
    // the escalation from the EVIDENCE, so no caller can forget to and silently lose a recovery.
    expect(b.calls).toHaveLength(routineLoads + 1);
    expect(b.calls.at(-1)?.username).toBe('recovered');
    expect(out.result.classification).toBe('ACTIVE');
  });

  it('REGRESSION: an identity match that is NOT ACTIVE is governed, not forced through', async () => {
    // The one escalation shape that bypassed the budget entirely. Instagram can serve a page whose
    // head carries og:url/og:title/canonical for the account AND whose body carries "Sorry, this
    // page isn't available"; classify() calls that UNKNOWN/'CONTRADICTORY'. CONTRADICTORY is not a
    // THROTTLE code, so the throttle early-return does not catch it — and the identity branch used
    // to force loadPriority 'CONFIRMATION' on identity ALONE, which admit() never refuses. Every
    // routine check of such an account therefore became an ungovernable Chromium page load, for as
    // long as the page kept being served: ~107 loads/hour from ONE account against a ~200/hour
    // ceiling. Worse, the branch zeroed the escalation streak first, so `storm` stayed false and
    // /ping reported the fast tier healthy while the fleet did 10x the ceiling.
    const c = makeClock(1_000_000);
    const b = browserFake('UNKNOWN');
    // Identity matches (og metadata for the requested username) while the verdict is UNKNOWN —
    // a shape fastProbeFake cannot express, since it ties identity to an ACTIVE classification.
    const impl = async (username: string): Promise<unknown> => {
      const isCanary = username === CONFIG.controlUsername;
      return {
        result: {
          classification: isCanary ? 'ACTIVE' : 'UNKNOWN',
          evidence: {
            signalsVersion: 'v',
            activeSignals: [],
            goneSignals: [],
            identitySignalMatched: true,
            finalUrl: null,
            responseStatus: 200,
            errorCode: isCanary ? null : 'CONTRADICTORY',
          },
          durationMs: 1,
        },
        transportFailed: false,
      };
    };
    const governor = governed(10, 0.5, c.now); // routine allowance = 5
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      governor,
      httpProbeImpl: impl as never,
      now: c.now,
    });

    for (let i = 0; i < 30; i += 1) {
      await d.probe(`acct${i}`, { loadPriority: 'ROUTINE' } as TieredProbeOptions);
    }

    // Before the fix this was 30 loads and `deferred: 0`. A page we could not read is a FAILED
    // OBSERVATION, never the leading edge of a recovery, so it keeps the caller's priority.
    expect(b.calls).toHaveLength(5);
    expect(governor.report().deferred).toBe(25);
    // ...and the storm is finally VISIBLE to the brake instead of being pinned at zero on exactly
    // the path that generates the load.
    expect(governor.report().escalationStreak).toBe(30);
    expect(governor.report().storm).toBe(true);
    expect(governor.report().intervalMultiplier).toBeGreaterThan(1);
    expect((await d.fastTierReport()).state).toBe('degraded');
  });

  it('a genuine recovery edge is still forced through, even labelled ROUTINE', async () => {
    // The counterweight to the test above: narrowing the forced upgrade must not narrow it past
    // the case it exists for. Identity metadata back AND an ACTIVE verdict is the leading edge of
    // a recovery, and it is admitted with the routine allowance long gone.
    const c = makeClock(1_000_000);
    const b = browserFake('ACTIVE');
    const impl = async (username: string): Promise<unknown> => {
      const isCanary = username === CONFIG.controlUsername;
      const live = isCanary || username === 'recovered';
      return {
        result: {
          classification: live ? 'ACTIVE' : 'UNKNOWN',
          evidence: {
            signalsVersion: 'v',
            activeSignals: [],
            goneSignals: [],
            // Every account serves identity metadata; only `recovered` also classifies ACTIVE.
            identitySignalMatched: true,
            finalUrl: null,
            responseStatus: 200,
            errorCode: live ? null : 'CONTRADICTORY',
          },
          durationMs: 1,
        },
        transportFailed: false,
      };
    };
    const governor = governed(10, 0.5, c.now); // routine allowance = 5
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      governor,
      httpProbeImpl: impl as never,
      now: c.now,
    });

    for (let i = 0; i < 12; i += 1) {
      await d.probe(`acct${i}`, { loadPriority: 'ROUTINE' } as TieredProbeOptions);
    }
    expect(governor.report().deferred).toBeGreaterThan(0);
    const spent = b.calls.length;

    const out = await d.probe('recovered', { loadPriority: 'ROUTINE' } as TieredProbeOptions);

    expect(b.calls).toHaveLength(spent + 1);
    expect(b.calls.at(-1)?.username).toBe('recovered');
    expect(out.result.classification).toBe('ACTIVE');
  });

  it('an owner command and a screenshot capture are never starved by routine polling', async () => {
    const c = makeClock(1_000_000);
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('UNKNOWN', 'HTTP_5XX', true); // not inferable => always escalates
    const governor = governed(10, 0.5, c.now); // routine allowance = 5
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      governor,
      httpProbeImpl: f.impl as never,
      now: c.now,
    });

    for (let i = 0; i < 10; i += 1) {
      await d.probe(`acct${i}`, { loadPriority: 'ROUTINE' } as TieredProbeOptions);
    }
    const spent = b.calls.length;
    expect(governor.report().deferred).toBeGreaterThan(0);

    // An unlabelled probe is an owner command (/check, /unban, /ping) by default.
    await d.probe('owner-asked');
    // ...and a capture for a confirmed recovery.
    const shot = await d.probe('proof', { captureScreenshot: true });

    expect(b.calls).toHaveLength(spent + 2);
    expect(shot.screenshot?.buffer).toEqual(PNG);
  });

  it('wires the ESCALATION_STORM signal to something that actually throttles', async () => {
    // The signal existed and only ever REPORTED via /ping. Escalated browser probes succeed, so
    // the breaker is structurally blind to them; the streak has to reach the cadence instead.
    const c = makeClock(1_000_000);
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('UNKNOWN', 'HTTP_5XX', true);
    const governor = governed(1000, 1, c.now); // huge budget: isolate the STORM signal
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      governor,
      httpProbeImpl: f.impl as never,
      now: c.now,
    });

    expect(governor.report().storm).toBe(false);
    expect(governor.intervalMultiplier()).toBe(1);

    for (let i = 0; i < ESCALATION_STORM_STREAK; i += 1) {
      await d.probe(`acct${i}`, { loadPriority: 'ROUTINE' } as TieredProbeOptions);
    }

    const report = governor.report();
    expect(report.storm).toBe(true);
    expect(report.intervalMultiplier).toBeGreaterThan(1);
    expect(report.reason).toContain('escalation storm');

    // ...and a fast-tier answer clears it again, so the fleet speeds back up on its own.
    const recovering = fastProbeFake('UNKNOWN', 'UNRECOGNIZED_DOM', true);
    const d2 = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      governor,
      httpProbeImpl: recovering.impl as never,
      now: c.now,
    });
    await d2.probe('recovered', { loadPriority: 'ROUTINE' } as TieredProbeOptions);
    expect(governor.report().storm).toBe(false);
  });

  it('reports deferrals separately from breaker blocks, so /ping can tell them apart', async () => {
    const c = makeClock(1_000_000);
    const b = browserFake('ACTIVE');
    const f = fastProbeFake('UNKNOWN', 'HTTP_5XX', true);
    const governor = governed(4, 0.5, c.now); // routine allowance = 2
    const d = new TieredDetector({
      browserDetector: b.detector,
      config: CONFIG,
      logger: nullLogger(),
      governor,
      httpProbeImpl: f.impl as never,
      now: c.now,
    });
    for (let i = 0; i < 5; i += 1) {
      await d.probe(`acct${i}`, { loadPriority: 'ROUTINE' } as TieredProbeOptions);
    }
    const report = await d.fastTierReport();
    expect(report.answered.deferred).toBe(3);
    expect(report.answered.blocked).toBe(0);
    expect(report.browserBudget?.deferred).toBe(3);
  });
});

// ---------------------------------------------------------------------------
// /proxy — switching egress and MEASURING the route that was selected.
//
// These run against a REAL TieredDetector, a REAL CircuitBreaker and a REAL ProxySwitch. The only
// fake is the network itself, which answers according to the route currently in force — exactly
// how Instagram behaves, and the whole reason /proxy cannot report success from a boolean. So the
// verdict under test is produced by production code (canary -> dispatcher generation -> egress
// sync), never seeded by the test.
// ---------------------------------------------------------------------------
describe('switchEgressRoute', () => {
  /** Config with a proxy configured but running DIRECT — the owner's home-PC setup. */
  const PROXIED = {
    ...CONFIG,
    browserProxy: {
      server: 'http://gate.example.com:7000',
      username: 'proxy-user-secret',
      password: 'proxy-pass-secret',
    },
    proxyMode: 'direct' as const,
  };

  /**
   * A network that serves live profiles over SOME routes and not others.
   *
   * `serving` names the routes on which Instagram returns the control account's identity
   * metadata. The VPS scenario is `['proxy']`: the datacenter IP (direct) answers with no
   * identity, which is what "blind" means — measured 0/9 on the real thing.
   */
  function network(
    sw: ProxySwitch,
    serving: readonly ('direct' | 'proxy')[],
    /** Hold the FIRST probe open until this resolves, to stage a probe in flight over a switch. */
    hold?: { started: () => void; gate: Promise<void> },
  ): {
    impl: (username: string) => Promise<unknown>;
    /** The route in force for each probe, in order. */
    routes: ('direct' | 'proxy')[];
  } {
    const routes: ('direct' | 'proxy')[] = [];
    let first = true;
    const impl = async (_username: string): Promise<unknown> => {
      // Captured at CALL time, like a real request leaving over the route then in force.
      const route = sw.state().mode;
      routes.push(route);
      const identity = serving.includes(route);
      if (hold !== undefined && first) {
        first = false;
        hold.started();
        await hold.gate;
      }
      return {
        result: {
          classification: identity ? 'ACTIVE' : 'UNKNOWN',
          evidence: {
            signalsVersion: 'v',
            activeSignals: [],
            goneSignals: [],
            identitySignalMatched: identity,
            finalUrl: null,
            responseStatus: identity ? 200 : 429,
            errorCode: identity ? null : 'HTTP_429',
          },
          durationMs: 1,
        },
        transportFailed: false,
      };
    };
    return { impl, routes };
  }

  /**
   * A network that serves live profiles over EVERY route, except that the very first request hits
   * one transient failure and every later one succeeds.
   *
   * This shape is untestable with `network()` above, which is deterministic per route — which is
   * why no test in the suite modelled a route that fails once and then works, and why a
   * confirming reading that measured nothing looked correct for as long as it did.
   */
  function flakyOnce(sw: ProxySwitch): {
    impl: (username: string) => Promise<unknown>;
    routes: ('direct' | 'proxy')[];
  } {
    const routes: ('direct' | 'proxy')[] = [];
    let remainingFailures = 1;
    const impl = (_username: string): Promise<unknown> => {
      routes.push(sw.state().mode);
      // `httpProbe` NEVER throws: a timeout, a reset connection or a DNS blip all come back as a
      // result with no identity and a transport-ish error code. Modelling it any other way would
      // be modelling a failure production cannot actually produce.
      const blip = remainingFailures > 0;
      if (blip) remainingFailures -= 1;
      return Promise.resolve({
        result: {
          classification: blip ? 'UNKNOWN' : 'ACTIVE',
          evidence: {
            signalsVersion: 'v',
            activeSignals: [],
            goneSignals: [],
            identitySignalMatched: !blip,
            finalUrl: null,
            responseStatus: blip ? null : 200,
            errorCode: blip ? 'TIMEOUT' : null,
          },
          durationMs: 1,
        },
        transportFailed: false,
      });
    };
    return { impl, routes };
  }

  function build(serving: readonly ('direct' | 'proxy')[]): {
    sw: ProxySwitch;
    detector: TieredDetector;
    routes: ('direct' | 'proxy')[];
  } {
    const sw = new ProxySwitch(PROXIED);
    const net = network(sw, serving);
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      proxySwitch: sw,
      httpProbeImpl: net.impl as never,
    });
    return { sw, detector, routes: net.routes };
  }

  it('reports a switch to a WORKING route as verified, with the measured latency', async () => {
    const { sw, detector, routes } = build(['direct', 'proxy']);
    const clock = makeClock(1_000);
    const out = await switchEgressRoute('mobile', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
      now: () => {
        const t = clock.now();
        clock.advance(120); // the probe's wall time
        return t;
      },
    });

    expect(out.kind).toBe('switched');
    if (out.kind !== 'switched') throw new Error('unreachable');
    expect(out.verification.status).toBe('verified');
    expect(out.verification.latencyMs).toBe(120);
    // The switch really happened, and the measurement was taken ON THE NEW ROUTE.
    expect(sw.state().mode).toBe('proxy');
    expect(routes).toEqual(['proxy']);
  });

  it('REVERTS a switch to a BLIND route and leaves the fleet where it was', async () => {
    // The VPS case: 'direct' is a datacenter IP Instagram refuses, so a bot switched there
    // detects no recoveries at all. Only the proxy sees profiles.
    const sw = new ProxySwitch({ ...PROXIED, proxyMode: 'proxy' });
    const net = network(sw, ['proxy']);
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      proxySwitch: sw,
      httpProbeImpl: net.impl as never,
    });

    const out = await switchEgressRoute('direct', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
    });

    expect(out.kind).toBe('reverted');
    // The fleet is back on the route it was already using — not left blind.
    expect(sw.state().mode).toBe('proxy');
    // It was genuinely tried, and MEASURED TWICE over the requested route before the owner was
    // overridden. This assertion used to read ['direct'] and was defended as "confirming is free",
    // which was true only because the second reading was answered by the cache the first failure
    // had just written — i.e. it confirmed itself having measured nothing. Two cheap HTTP GETs is
    // the price of not auto-reverting a healthy route on one unlucky packet.
    expect(net.routes).toEqual(['direct', 'direct']);
  });

  it('honours the SAME command repeated: the second attempt is kept, blind and all', async () => {
    const sw = new ProxySwitch({ ...PROXIED, proxyMode: 'proxy' });
    const net = network(sw, ['proxy']);
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      proxySwitch: sw,
      httpProbeImpl: net.impl as never,
    });
    const deps = { proxySwitch: sw, detector, logger: nullLogger() };

    const first = await switchEgressRoute('direct', deps);
    expect(first.kind).toBe('reverted');

    const second = await switchEgressRoute('direct', deps);
    expect(second.kind).toBe('kept-blind');
    // The owner insisted, so the route STAYS — and is told the fleet is now blind.
    expect(sw.state().mode).toBe('direct');

    // ...and it did not ping-pong: exactly one revert happened across both commands.
    const third = await switchEgressRoute('mobile', deps);
    expect(third.kind).toBe('switched');
    expect(sw.state().mode).toBe('proxy');
  });

  it('does not revert when a canary in flight ACROSS the switch reads stale', async () => {
    // The detector discards a canary whose route changed mid-measurement, and that discard
    // surfaces as a "blind" reading of a route nothing ever measured. Reverting on it would undo
    // a good switch — and on the VPS would revert INTO the blind route. Staged with production
    // code: a real probe is left in flight over the real generation bump.
    const sw = new ProxySwitch(PROXIED);
    let started = (): void => undefined;
    const startedPromise = new Promise<void>((resolve) => {
      started = resolve;
    });
    let open = (): void => undefined;
    const gate = new Promise<void>((resolve) => {
      open = resolve;
    });
    const net = network(sw, ['direct', 'proxy'], { started: () => started(), gate });
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      proxySwitch: sw,
      httpProbeImpl: net.impl as never,
    });

    // A fleet canary is under way on 'direct'...
    const inFlight = detector.fastTierReport();
    await startedPromise;
    // ...and the owner switches while it is still out. `set()` runs synchronously inside, so by
    // the time this returns a promise the switch has happened and the stale canary is subscribed.
    const pending = switchEgressRoute('mobile', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
    });
    open();
    await inFlight;
    const out = await pending;

    expect(out.kind).toBe('switched');
    if (out.kind !== 'switched') throw new Error('unreachable');
    expect(out.verification.status).toBe('verified');
    expect(sw.state().mode).toBe('proxy');
    // The stale probe went out over 'direct'; the confirming one over 'proxy'.
    expect(net.routes).toEqual(['direct', 'proxy']);
  });

  it('a no-op reports "already on that route" and never claims a switch', async () => {
    const { sw, detector } = build(['direct', 'proxy']);
    const before = sw.gen();

    const out = await switchEgressRoute('direct', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
    });

    expect(out.kind).toBe('unchanged');
    // No generation bump means no needless browser relaunch either.
    expect(sw.gen()).toBe(before);
  });

  it('refuses mobile when no proxy is configured, without touching the network', async () => {
    const sw = new ProxySwitch(CONFIG); // no BROWSER_PROXY_SERVER
    const net = network(sw, ['direct']);
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: CONFIG,
      logger: nullLogger(),
      proxySwitch: sw,
      httpProbeImpl: net.impl as never,
    });

    const out = await switchEgressRoute('mobile', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
    });

    expect(out.kind).toBe('unavailable');
    expect(sw.state().mode).toBe('direct');
    expect(net.routes).toHaveLength(0);
  });

  it('reports "unverified" — never "blind" — when the breaker refused to look', async () => {
    // Nothing was observed, so nothing may be inferred. Calling this blind would blame the route
    // for a back-off earned elsewhere, and would trigger a revert on no evidence at all.
    const sw = new ProxySwitch(PROXIED);
    const breaker = new CircuitBreaker({ threshold: 1, initialCooldownMs: 600_000 });
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      breaker,
      proxySwitch: sw,
      httpProbeImpl: network(sw, ['direct', 'proxy']).impl as never,
    });
    // A no-op switch cannot clear the breaker (the route did not change), so the report is blocked.
    breaker.adoptRoute(sw.gen());
    breaker.record(true);
    expect(breaker.currentState()).toBe('OPEN');

    const out = await switchEgressRoute('direct', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
    });

    expect(out.kind).toBe('unchanged');
    if (out.kind !== 'unchanged') throw new Error('unreachable');
    expect(out.verification.status).toBe('unverified');
    expect(out.verification.detail).toContain('back-off');
  });

  it('bounds the verification, and a hang is "unverified" rather than a wrong verdict', async () => {
    const sw = new ProxySwitch(PROXIED);
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      proxySwitch: sw,
      httpProbeImpl: (() => new Promise(() => undefined)) as never, // never resolves
    });

    const out = await switchEgressRoute('mobile', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
      timeoutMs: 20,
    });

    expect(out.kind).toBe('switched');
    if (out.kind !== 'switched') throw new Error('unreachable');
    expect(out.verification.status).toBe('unverified');
    // Stayed put: absence of evidence is not evidence the route is blind.
    expect(sw.state().mode).toBe('proxy');
  });

  it('a REVERT puts back the fleet-wide back-off belonging to the route it returns to', async () => {
    // The most natural reaction to a throttled IP is to try the other route — and selecting a
    // route is what makes it measurable, so by the time the verdict comes back the detector has
    // already told the SHARED breaker it moved and the block earned on the route we are about to
    // return to has been cleared, in memory and in the store. Putting back only the ROUTE left the
    // fleet at full rate against an IP Instagram was actively throttling, under a reply that told
    // the owner nothing had changed: harm rank 3, which blinds the whole fleet and cascades to 1.
    const clock = makeClock(5_000_000);
    const sw = new ProxySwitch({ ...PROXIED, proxyMode: 'proxy' });
    const persisted: DurableBreakerState[] = [];
    const breaker = new CircuitBreaker({
      threshold: 3,
      initialCooldownMs: 600_000,
      now: clock.now,
      onTransition: (state) => persisted.push(state),
    });
    const net = network(sw, ['proxy']);
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      breaker,
      proxySwitch: sw,
      httpProbeImpl: net.impl as never,
    });
    // Exactly what the composition root does before anything can probe, and what lets a real
    // switch be told apart from a detector merely catching up to one.
    breaker.adoptRoute(sw.gen());
    // EARNED, never hand-set: three real throttle observations on the route in force.
    for (let i = 0; i < 3; i += 1) breaker.record(true);
    expect(breaker.currentState()).toBe('OPEN');
    expect(persisted.at(-1)?.state).toBe('OPEN');

    const out = await switchEgressRoute('direct', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
    });

    expect(out.kind).toBe('reverted');
    expect(sw.state().mode).toBe('proxy');
    // The brake is still on — so the next tick does NOT resume full-rate checking...
    expect(breaker.currentState()).toBe('OPEN');
    expect(breaker.allowRequest()).toBe(false);
    expect(breaker.snapshot().consecutive).toBe(3);
    // ...and the durable row matches, so a restart inside the cooldown cannot come back CLOSED.
    expect(persisted.at(-1)?.state).toBe('OPEN');
  });

  it('does not revert a healthy route because of ONE transient probe failure', async () => {
    // `httpProbe` never throws, so a reset connection, a slow exit, or a single 429 on a
    // freshly-rotated exit IP all arrive as "no identity" — indistinguishable, on a single
    // reading, from a genuinely blind route. Nothing below this retries, so without a second
    // MEASUREMENT one unlucky packet auto-reverts a route the owner deliberately chose: they shut
    // the PC down believing the fleet moved to the proxy, and it is pinned to a dead line instead.
    const sw = new ProxySwitch(PROXIED); // home PC: both routes serve profiles
    const net = flakyOnce(sw);
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      proxySwitch: sw,
      httpProbeImpl: net.impl as never,
    });

    const out = await switchEgressRoute('mobile', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
    });

    expect(out.kind).toBe('switched');
    if (out.kind !== 'switched') throw new Error('unreachable');
    expect(out.verification.status).toBe('verified');
    expect(sw.state().mode).toBe('proxy');
    // Both readings went out over the requested route, and the second one was a real request —
    // not the cache the first failure had just written.
    expect(net.routes).toEqual(['proxy', 'proxy']);
  });

  it('spends ONE timeout budget across both readings, not one each', async () => {
    // The bound exists because the Telegram polling loop awaits handlers ONE AT A TIME: two
    // independently-timed readings freeze all bot ingress — including the /ping the owner would
    // run to find out why — for twice as long as EGRESS_VERIFY_TIMEOUT_MS promises. Now that the
    // confirming reading costs a real measurement, that doubling is real, so an exhausted budget
    // must skip it rather than start a second full-length wait.
    const sw = new ProxySwitch({ ...PROXIED, proxyMode: 'proxy' });
    const net = network(sw, ['proxy']);
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      proxySwitch: sw,
      httpProbeImpl: net.impl as never,
    });
    const clock = makeClock(1_000);

    const out = await switchEgressRoute('direct', {
      proxySwitch: sw,
      detector,
      logger: nullLogger(),
      // Every reading of the clock advances it, so the first verification alone spends the budget.
      now: () => {
        const t = clock.now();
        clock.advance(200);
        return t;
      },
      timeoutMs: 300,
    });

    // No budget left to bound a second reading with, so it is not started — and running out of
    // time still yields the conservative outcome rather than a wrong verdict.
    expect(net.routes).toEqual(['direct']);
    expect(out.kind).toBe('reverted');
  });

  it('never puts a proxy credential in any reply, on any outcome', async () => {
    const sw = new ProxySwitch({ ...PROXIED, proxyMode: 'proxy' });
    const net = network(sw, ['proxy']);
    const detector = new TieredDetector({
      browserDetector: { probe: () => Promise.reject(new Error('no browser in this test')) },
      config: PROXIED,
      logger: nullLogger(),
      proxySwitch: sw,
      httpProbeImpl: net.impl as never,
    });
    const deps = { proxySwitch: sw, detector, logger: nullLogger() };

    const texts = [
      egressStatus({ current: sw.describe(), configured: true }).text,
      egressSwitchResult(await switchEgressRoute('direct', deps), CONFIG.controlUsername).text,
      egressSwitchResult(await switchEgressRoute('direct', deps), CONFIG.controlUsername).text,
      egressSwitchResult(await switchEgressRoute('mobile', deps), CONFIG.controlUsername).text,
      egressSwitchResult(await switchEgressRoute('mobile', deps), CONFIG.controlUsername).text,
    ];

    for (const text of texts) {
      expect(text).not.toContain('proxy-user-secret');
      expect(text).not.toContain('proxy-pass-secret');
    }
    // The host:port IS shown — it is what tells the owner which route they are on.
    expect(texts.some((t) => t.includes('gate.example.com:7000'))).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// BrowserLoadGovernor — the budget itself.
// ---------------------------------------------------------------------------
describe('BrowserLoadGovernor', () => {
  /** A store wired exactly as the composition root wires the file-backed one. */
  function memoryStore(): { store: GovernorStore; saved: () => GovernorSnapshot | null } {
    let saved: GovernorSnapshot | null = null;
    return {
      store: {
        load: () => saved,
        save: (s) => {
          saved = s;
        },
      },
      saved: () => saved,
    };
  }

  it('defers routine load once the routine allowance is spent, and says so', () => {
    const c = makeClock(1_000_000);
    const g = new BrowserLoadGovernor({ capacity: 10, routineFraction: 0.6, now: c.now });
    for (let i = 0; i < 6; i += 1) expect(g.admit('ROUTINE')).toBe(true);
    expect(g.admit('ROUTINE')).toBe(false);

    const r = g.report();
    expect(r.used).toBe(6);
    expect(r.routineAllowance).toBe(6);
    expect(r.deferred).toBe(1);
    expect(r.throttling).toBe(true);
    // No silent throttling: the reason is always populated and names the numbers.
    expect(r.reason).toContain('DEFERRED');
    expect(r.reason).toContain('6/10');
  });

  it('never refuses a confirmation, a capture or an owner command', () => {
    const c = makeClock(1_000_000);
    const g = new BrowserLoadGovernor({ capacity: 10, routineFraction: 0.6, now: c.now });
    for (let i = 0; i < 20; i += 1) g.admit('ROUTINE');
    expect(g.admit('ROUTINE')).toBe(false);

    // Both priority classes stay admitted even past the ceiling — losing a confirmation is harm
    // rank 1, and their volume is bounded by how often recoveries and owner commands happen.
    for (let i = 0; i < 12; i += 1) {
      expect(g.admit('CONFIRMATION')).toBe(true);
      expect(g.admit('OWNER')).toBe(true);
    }
    expect(g.report().overCapacity).toBe(true);
  });

  it('priority traffic squeezes ROUTINE, never the other way round', () => {
    const c = makeClock(1_000_000);
    const g = new BrowserLoadGovernor({ capacity: 10, routineFraction: 0.6, now: c.now });
    for (let i = 0; i < 6; i += 1) expect(g.admit('CONFIRMATION')).toBe(true);
    // Routine admission is gated on TOTAL consumption, so a busy recovery hour costs polling
    // rather than costing recoveries.
    expect(g.admit('ROUTINE')).toBe(false);
  });

  it('REGRESSION: a restart cannot burst past the ceiling', () => {
    // An in-memory window resets to zero on every boot, so a crash loop (deploy, OOM, systemd)
    // would hand each incarnation a fresh full budget — the governor would become a load
    // AMPLIFIER in exactly the situation it exists for.
    //
    // The snapshot is never hand-written here: the FIRST governor produces it through the same
    // save() production persists from, and the second reads that back.
    const c = makeClock(1_000_000);
    const { store, saved } = memoryStore();
    const first = new BrowserLoadGovernor({
      capacity: 10,
      routineFraction: 0.6,
      now: c.now,
      store,
    });
    first.rehydrate();
    for (let i = 0; i < 6; i += 1) {
      expect(first.admit('ROUTINE')).toBe(true);
      c.advance(6_000); // past the write debounce, so this is a CRASH, not a clean shutdown
    }
    expect(saved()).not.toBeNull();

    const second = new BrowserLoadGovernor({
      capacity: 10,
      routineFraction: 0.6,
      now: c.now,
      store,
    });
    second.rehydrate();

    expect(second.report().used).toBe(6);
    expect(second.admit('ROUTINE')).toBe(false); // would be `true` without durability
    expect(second.admit('CONFIRMATION')).toBe(true); // and recoveries still get through
  });

  it('a corrupt or future-dated stored window degrades to a clean start, never a wedge', () => {
    const c = makeClock(10 * 60 * 60 * 1000);
    const corrupt: GovernorStore = {
      load: () =>
        ({
          newestBucket: Number.NaN,
          buckets: [{ total: 'lots', routine: -3, deferred: null }],
        }) as unknown as GovernorSnapshot,
      save: () => undefined,
    };
    const g = new BrowserLoadGovernor({ capacity: 4, now: c.now, store: corrupt });
    g.rehydrate();
    expect(g.report().used).toBe(0);
    expect(g.admit('ROUTINE')).toBe(true); // a bad row must never stop every check

    // A window stored in the FUTURE (clock skew) is discarded rather than trusted, which would
    // otherwise suppress real checks for up to an hour.
    const future: GovernorStore = {
      load: () => ({
        newestBucket: Math.floor((c.now() + 60 * 60 * 1000) / 60_000),
        buckets: [{ total: 99, routine: 99, deferred: 0 }],
      }),
      save: () => undefined,
    };
    const g2 = new BrowserLoadGovernor({ capacity: 4, now: c.now, store: future });
    g2.rehydrate();
    expect(g2.report().used).toBe(0);
  });

  it('the window rolls: spend from an hour ago no longer counts against this hour', () => {
    const c = makeClock(1_000_000);
    const g = new BrowserLoadGovernor({ capacity: 10, routineFraction: 0.6, now: c.now });
    for (let i = 0; i < 6; i += 1) g.admit('ROUTINE');
    expect(g.admit('ROUTINE')).toBe(false);

    c.advance(61 * 60 * 1000);
    expect(g.report().used).toBe(0);
    expect(g.admit('ROUTINE')).toBe(true);
  });

  it('a clock that jumps BACKWARDS does not hand the fleet a fresh budget', () => {
    // The app runs a NetworkCorrectedClock that re-syncs hourly; a correction must not be able to
    // reset the window it has already spent.
    const c = makeClock(10 * 60 * 60 * 1000);
    const g = new BrowserLoadGovernor({ capacity: 10, routineFraction: 0.6, now: c.now });
    for (let i = 0; i < 6; i += 1) g.admit('ROUTINE');
    c.advance(-5 * 60 * 1000);
    expect(g.report().used).toBe(6);
    expect(g.admit('ROUTINE')).toBe(false);
  });

  it('the interval multiplier ramps with utilisation and is bounded at both ends', () => {
    const c = makeClock(1_000_000);
    const g = new BrowserLoadGovernor({ capacity: 100, routineFraction: 1, now: c.now });
    expect(g.intervalMultiplier()).toBe(1); // idle fleet polls at full speed

    for (let i = 0; i < 50; i += 1) g.admit('ROUTINE');
    expect(g.intervalMultiplier()).toBe(1); // half the budget is not yet pressure

    for (let i = 0; i < 50; i += 1) g.admit('ROUTINE');
    expect(g.intervalMultiplier()).toBe(8); // ...and it never stretches further than 8x

    for (let i = 0; i < 500; i += 1) g.admit('CONFIRMATION');
    expect(g.intervalMultiplier()).toBe(8);
  });
});

// ---------------------------------------------------------------------------
// REGRESSION — the 2026-08-01 fleet-wide outage.
//
// SYMPTOM: `/check` answered "UNKNOWN ... 0.0 seconds ... (HTTP_429)", which is the breaker
// short-circuiting every probe on every route, minutes after a `/proxy vps` that had SUCCEEDED and
// VERIFIED. Nine hundred lines of log around the trip contained not one LOGIN_WALL, HTTP_429,
// HTTP_403, ERROR_PAGE or CHALLENGE — only five NAVIGATION failures.
//
// TWO CAUSES, both here:
//   1. the brake was advanced by a two-state input derived as `isThrottleSignal(errorCode)`, so
//      every FAILED OBSERVATION arrived as the positive claim "the IP is serving us again" —
//      which both wiped genuine throttle streaks and force-CLOSED a HALF_OPEN breaker; and
//   2. a probe already in flight when `/proxy` switched routes still reported its outcome to the
//      breaker, which `adoptRoute` had just given a clean slate for the NEW route. Since the
//      switch itself tears the browser down, those probes are guaranteed to fail — so switching
//      away from a throttled route imported that route's dying probes onto the healthy one and
//      blocked both.
//
// Everything below asserts the fix in BOTH directions: failed observations move nothing, and
// genuine throttle evidence still opens the breaker, still doubles, still persists.
// ---------------------------------------------------------------------------
describe('circuit breaker: only genuine throttle evidence may advance it', () => {
  /** Config with a proxy configured but running DIRECT — the owner's home-PC setup. */
  const PROXIED = {
    ...CONFIG,
    browserProxy: {
      server: 'http://gate.example.com:7000',
      username: 'proxy-user-secret',
      password: 'proxy-pass-secret',
    },
    proxyMode: 'direct' as const,
  };

  /** What the browser tier hands back for a given error code. `null` = a page we read cleanly. */
  function browserResult(errorCode: DetectorErrorCode | null): ProbeResult {
    return {
      result: {
        classification: errorCode === null ? 'GONE' : 'UNKNOWN',
        evidence: {
          signalsVersion: 'v',
          activeSignals: [],
          goneSignals: [],
          identitySignalMatched: false,
          finalUrl: null,
          responseStatus: errorCode === null ? 200 : 429,
          errorCode,
        },
        durationMs: 5,
      },
      screenshot: null,
    };
  }

  /**
   * A browser-only detector (the deletion-watcher shape, and the shape every probe takes while the
   * fast path is off) whose verdicts are read from `codes`, one per probe.
   */
  function detectorOver(
    breaker: CircuitBreaker,
    codes: readonly (DetectorErrorCode | null)[],
    now?: () => number,
  ): TieredDetector {
    let i = 0;
    return new TieredDetector({
      browserDetector: {
        probe: (): Promise<ProbeResult> => {
          const code = i < codes.length ? codes[i] : null;
          i += 1;
          return Promise.resolve(browserResult(code ?? null));
        },
      },
      config: CONFIG,
      logger: nullLogger(),
      breaker,
      fastPath: false,
      ...(now !== undefined ? { now } : {}),
    });
  }

  it('reads every detector error code as throttle / served / inconclusive', () => {
    // The five that mean Instagram refused THIS IP. Unchanged, deliberately: this is the brake's
    // real purpose and the reason it exists at all.
    expect(breakerOutcomeForCode('LOGIN_WALL')).toBe('THROTTLED');
    expect(breakerOutcomeForCode('HTTP_429')).toBe('THROTTLED');
    expect(breakerOutcomeForCode('HTTP_403')).toBe('THROTTLED');
    expect(breakerOutcomeForCode('ERROR_PAGE')).toBe('THROTTLED');
    expect(breakerOutcomeForCode('CHALLENGE')).toBe('THROTTLED');

    // Failed observations. NAVIGATION and BROWSER_CRASH are precisely what a browser torn down by
    // an egress switch produces, for every probe that was in flight.
    expect(breakerOutcomeForCode('NAVIGATION')).toBe('INCONCLUSIVE');
    expect(breakerOutcomeForCode('BROWSER_CRASH')).toBe('INCONCLUSIVE');
    expect(breakerOutcomeForCode('TIMEOUT')).toBe('INCONCLUSIVE');
    expect(breakerOutcomeForCode('DNS')).toBe('INCONCLUSIVE');
    expect(breakerOutcomeForCode('HTTP_5XX')).toBe('INCONCLUSIVE');
    expect(breakerOutcomeForCode('UNKNOWN_ERROR')).toBe('INCONCLUSIVE');

    // A real document came back over this route; we just could not read the ACCOUNT from it.
    expect(breakerOutcomeForCode(null)).toBe('SERVED');
    expect(breakerOutcomeForCode('UNRECOGNIZED_DOM')).toBe('SERVED');
    expect(breakerOutcomeForCode('EMPTY_PAGE')).toBe('SERVED');
    expect(breakerOutcomeForCode('CONSENT_BLOCK')).toBe('SERVED');
  });

  it('a burst of NAVIGATION failures leaves it CLOSED — and does not wipe a real streak', async () => {
    // Before the fix these three arrived as `record(false)`, i.e. "the IP is serving us again", so
    // they zeroed a streak that had genuine evidence behind it. During a real throttle EVERY check
    // escalates to the browser and many of those fail, so the counter oscillated 0 -> 1 -> 0 and
    // the breaker could not reach its threshold while load was 20-50x normal.
    const breaker = new CircuitBreaker({ threshold: 3, initialCooldownMs: 600_000 });
    breaker.adoptRoute(0);
    const detector = detectorOver(breaker, [
      'LOGIN_WALL', // 1 — genuine
      'LOGIN_WALL', // 2 — genuine
      'NAVIGATION', // proves nothing either way
      'BROWSER_CRASH', // what a browser teardown looks like from in here
      'TIMEOUT', // ditto
      'LOGIN_WALL', // 3 — reaches the threshold
    ]);

    for (let n = 0; n < 5; n += 1) await detector.probe('someone');
    // The failed observations neither opened it nor reset the evidence that was already there.
    expect(breaker.currentState()).toBe('CLOSED');
    expect(breaker.snapshot().consecutive).toBe(2);

    await detector.probe('someone');
    expect(breaker.currentState()).toBe('OPEN');
  });

  it('a HALF_OPEN trial that dies mid-probe neither lifts the cooldown nor wedges the slot', async () => {
    // The worst shape of the same bug: in HALF_OPEN a single `record(false)` CLOSES the breaker
    // outright, so one crashed trial probe released the entire fleet back onto an IP Instagram was
    // still throttling — harm rank 3, which blinds every client.
    const c = makeClock(1_000_000);
    const breaker = new CircuitBreaker({ threshold: 1, initialCooldownMs: 60_000, now: c.now });
    breaker.adoptRoute(0);
    breaker.record(true); // EARNED, never hand-set
    expect(breaker.currentState()).toBe('OPEN');
    c.advance(60_000);
    expect(breaker.currentState()).toBe('HALF_OPEN');

    await detectorOver(breaker, ['NAVIGATION'], c.now).probe('someone');

    // Nothing was observed, so the cooldown may not be lifted...
    expect(breaker.currentState()).toBe('HALF_OPEN');
    // ...but the one trial admission IS given back, or the fleet waits out the slot TTL in the
    // dark for a probe that already reported.
    expect(breaker.allowRequest()).toBe(true);
  });

  it('an admitted probe that THROWS gives the trial slot back instead of blinding the fleet', async () => {
    const c = makeClock(1_000_000);
    const breaker = new CircuitBreaker({ threshold: 1, initialCooldownMs: 60_000, now: c.now });
    breaker.adoptRoute(0);
    breaker.record(true);
    c.advance(60_000);
    expect(breaker.currentState()).toBe('HALF_OPEN');

    const detector = new TieredDetector({
      browserDetector: { probe: (): Promise<ProbeResult> => Promise.reject(new Error('gone')) },
      config: CONFIG,
      logger: nullLogger(),
      breaker,
      fastPath: false,
      now: c.now,
    });
    await expect(detector.probe('someone')).rejects.toThrow('gone');

    expect(breaker.currentState()).toBe('HALF_OPEN');
    expect(breaker.allowRequest()).toBe(true);
  });

  it('REGRESSION: a /proxy switch cannot trip the brake with the old route’s dying probes', async () => {
    // THE OUTAGE. The owner switches BECAUSE the current route is walled, so the probes in flight
    // at that moment are the walled ones — and the switch itself tears their browser down. Those
    // failures are an artefact of our own action; counting them re-opened the fleet-wide brake on
    // a route that had never been measured, so the escape hatch blocked both routes.
    const sw = new ProxySwitch(PROXIED); // starts 'direct'
    const breaker = new CircuitBreaker({ threshold: 3, initialCooldownMs: 600_000 });
    breaker.adoptRoute(sw.gen()); // exactly what the composition root does before any probe

    const walled = new Set<string>(['direct']); // home line is being login-walled
    const routes: string[] = [];
    let release = (): void => undefined;
    const gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    let calls = 0;

    const detector = new TieredDetector({
      browserDetector: {
        probe: async (): Promise<ProbeResult> => {
          // Captured at CALL time, like a real request leaving over the route then in force.
          const route = sw.state().mode;
          routes.push(route);
          calls += 1;
          if (calls <= 3) await gate; // still in flight when the owner switches
          return browserResult(walled.has(route) ? 'LOGIN_WALL' : null);
        },
      },
      config: PROXIED,
      logger: nullLogger(),
      breaker,
      proxySwitch: sw,
      fastPath: false,
    });

    const inFlight = [detector.probe('a'), detector.probe('b'), detector.probe('c')];
    expect(routes).toEqual(['direct', 'direct', 'direct']);

    // The owner escapes to the proxy. The first probe on the new route adopts it, which clears the
    // block belonging to the route being left — by design.
    sw.set('proxy');
    await detector.probe('d');
    expect(breaker.currentState()).toBe('CLOSED');

    // Now the three walled probes finally report. Three LOGIN_WALLs, threshold three.
    release();
    await Promise.all(inFlight);

    // They describe a route the fleet is no longer on, so they move nothing.
    expect(breaker.currentState()).toBe('CLOSED');
    expect(breaker.snapshot().consecutive).toBe(0);
    expect(breaker.allowRequest()).toBe(true);

    // ...AND THE BRAKE STILL WORKS. Three genuine throttle observations on the route the fleet is
    // ACTUALLY on still open it, still with a real cooldown behind them.
    walled.add('proxy');
    for (let i = 0; i < 3; i += 1) await detector.probe('e');
    expect(breaker.currentState()).toBe('OPEN');
    expect(breaker.retryAfterMs()).toBeGreaterThan(0);
  });
});
