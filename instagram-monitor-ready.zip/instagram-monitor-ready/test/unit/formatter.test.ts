import { describe, it, expect } from 'vitest';
import {
  monitoringStarted,
  listView,
  recoveryCaption,
  recoveryButton,
  startGuide,
  ownerActionRequired,
  ownerActionRequiredDeletion,
  type MonitoredItem,
} from '../../src/notifications/formatter';

const IST = 'Asia/Kolkata';

describe('recoveryCaption', () => {
  it('produces the exact caption for a known start/confirmed pair', () => {
    const caption = recoveryCaption(
      'user',
      '2026-07-17T10:00:00.000Z',
      '2026-07-17T10:02:09.000Z',
      IST,
    );
    expect(caption).toBe(
      [
        'You can use @user again',
        '',
        'TAT: 0 days 00 hours 02 minutes 09 seconds',
        'Time: 17 July 2026, 3:32:09 PM IST',
        'By: @r.nmc',
      ].join('\n'),
    );
  });
});

describe('startGuide', () => {
  it('shows the Arabic welcome, supervisor details, and real contact links', () => {
    const guide = startGuide();
    expect(guide.text).toContain('مرحباً بك في نظام مراقبة الحسابات.');
    expect(guide.text).toContain('@r.nmc');
    expect(guide.text).toContain('@tj_0t');
    expect(guide.text).toContain('+967773875320');
    expect(guide.text).toContain('/unban username');

    const buttons = guide.replyMarkup?.inline_keyboard.flat() ?? [];
    expect(buttons).toContainEqual({
      text: '📷 Instagram',
      url: 'https://www.instagram.com/r.nmc/',
    });
    expect(buttons).toContainEqual({ text: '✈️ Telegram', url: 'https://t.me/tj_0t' });
    expect(buttons).toContainEqual({
      text: '📱 WhatsApp للتواصل',
      url: 'https://wa.me/967773875320',
    });
    expect(buttons.some((button) => button.text === '💰 إضافة رصيد')).toBe(true);
  });
});

describe('recoveryButton', () => {
  it('links to the normalized profile URL', () => {
    const markup = recoveryButton('user');
    expect(markup.inline_keyboard[0]?.[0]?.text).toBe('Open Instagram');
    expect(markup.inline_keyboard[0]?.[0]?.url).toBe('https://www.instagram.com/user/');
  });
});

describe('owner action-required escalations', () => {
  // These two are the message the OWNER retypes to a client by hand, so they are the one place a
  // recovery/deletion mix-up reaches a paying client as an outright lie. They must not be
  // interchangeable.
  it('the deletion escalation says the profile is gone and promises no screenshot', () => {
    const msg = ownerActionRequiredDeletion('acme');
    expect(msg.text).toContain('⚠️ @acme IS NO LONGER AVAILABLE');
    expect(msg.text).toContain('has gone down (deleted, deactivated, or banned)');
    expect(msg.text).toContain('please send it to the client manually');
    // A deletion alert has no screenshot at all — a gone page has nothing to capture.
    expect(msg.text.toLowerCase()).not.toContain('screenshot');
    expect(msg.text).not.toContain('IS ACTIVE');
    expect(msg.text).not.toContain('recovered');
  });

  it('the recovery escalation is unchanged and still promises the screenshot', () => {
    const msg = ownerActionRequired('acme');
    expect(msg.text).toContain('⚠️ @acme IS ACTIVE');
    expect(msg.text).toContain('has recovered');
    expect(msg.text).toContain('The screenshot and message are ready');
    expect(msg.text).not.toContain('NO LONGER AVAILABLE');
  });
});

describe('monitoringStarted', () => {
  it('contains the @username and an IST timestamp', () => {
    const msg = monitoringStarted('user', '2026-07-17T17:00:15.000Z', IST);
    expect(msg.text).toContain('👀 Monitoring Started');
    expect(msg.text).toContain('@user');
    expect(msg.text).toContain('17 July 2026, 10:30:15 PM IST');
    expect(msg.text).toContain('IST');
  });
});

describe('listView', () => {
  const now = new Date('2026-07-17T00:02:09.000Z');
  const started = '2026-07-17T00:00:00.000Z';

  it('renders the empty state', () => {
    const msg = listView([], now);
    expect(msg.text).toBe(
      '👀 Monitored Accounts\n\nNo Instagram accounts are currently being monitored.',
    );
  });

  it('renders every account as ONE compact line, grouped by status (the Discord shape)', () => {
    const items: MonitoredItem[] = [
      { username: 'alice', status: 'MONITORING', confirmationCount: 0, startedIso: started },
      { username: 'bob', status: 'CONFIRMING', confirmationCount: 2, startedIso: started },
      {
        username: 'carol',
        status: 'ERROR_BACKOFF',
        confirmationCount: 0,
        startedIso: started,
        nextCheckAtIso: '2026-07-17T00:02:43.000Z',
      },
    ];
    const msg = listView(items, now);
    expect(msg.text).toContain('👀 Monitored Accounts — 3');
    expect(msg.text).toContain('🟢 Monitoring: 1');
    expect(msg.text).toContain('@alice · 2m 09s');
    expect(msg.text).toContain('🟡 Confirming: 1');
    expect(msg.text).toContain('@bob · 2/3 · 2m 09s');
    expect(msg.text).toContain('🔴 Error backoff: 1');
    expect(msg.text).toContain('@carol · 2m 09s · retry in 34s');
    // The dense line IS the entry: none of the old five-line block survives.
    expect(msg.text).not.toContain('Status:');
    expect(msg.text).not.toContain('Monitoring time:');
  });

  it('NEVER paginates: dozens of accounts arrive in one message with no Page footer', () => {
    const items: MonitoredItem[] = Array.from({ length: 40 }, (_, i) => ({
      username: `acct${String(i + 1)}`,
      status: 'MONITORING' as const,
      confirmationCount: 0,
      startedIso: started,
    }));
    const msg = listView(items, now);
    expect(msg.text).toContain('👀 Monitored Accounts — 40');
    expect(msg.text).toContain('@acct1 ·');
    expect(msg.text).toContain('@acct40 ·');
    expect(msg.text).not.toContain('Page ');
    expect(msg.text.length).toBeLessThan(4096);
  });

  it('at absurd scale it truncates HONESTLY instead of overflowing the Telegram cap', () => {
    const items: MonitoredItem[] = Array.from({ length: 400 }, (_, i) => ({
      username: `averylongusername${String(i + 1)}`,
      status: 'MONITORING' as const,
      confirmationCount: 0,
      startedIso: started,
    }));
    const msg = listView(items, now);
    expect(msg.text.length).toBeLessThan(4096);
    expect(msg.text).toMatch(/… and \d+ more/);
    expect(msg.text).toContain('👀 Monitored Accounts — 400');
  });
});
