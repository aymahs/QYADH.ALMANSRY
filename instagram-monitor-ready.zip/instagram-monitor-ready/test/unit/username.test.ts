import { describe, it, expect } from 'vitest';
import { normalizeUsername, isValidUsername, parseUsernameInput, profileUrl } from '../../src/core';
import { isAppError } from '../../src/domain';

describe('normalizeUsername', () => {
  it('accepts all documented input formats', () => {
    expect(normalizeUsername('user')).toBe('user');
    expect(normalizeUsername('@user')).toBe('user');
    expect(normalizeUsername('https://instagram.com/user')).toBe('user');
    expect(normalizeUsername('https://www.instagram.com/user/')).toBe('user');
    expect(normalizeUsername('instagram.com/user/?hl=en')).toBe('user');
  });

  it('lowercases, trims, and strips protocol/fragment/extra path', () => {
    expect(normalizeUsername('  @User  ')).toBe('user');
    expect(normalizeUsername('http://www.instagram.com/User#bio')).toBe('user');
    expect(normalizeUsername('instagram.com/user/tagged/')).toBe('user');
  });

  it('normalizes empty-ish input to an empty string', () => {
    expect(normalizeUsername('')).toBe('');
    expect(normalizeUsername('@')).toBe('');
    expect(normalizeUsername('https://instagram.com/')).toBe('');
  });
});

describe('isValidUsername', () => {
  it('accepts valid usernames', () => {
    expect(isValidUsername('user')).toBe(true);
    expect(isValidUsername('nat.geo_99')).toBe(true);
    expect(isValidUsername('a')).toBe(true);
    expect(isValidUsername('a'.repeat(30))).toBe(true);
  });

  it('rejects bad characters', () => {
    expect(isValidUsername('user!')).toBe(false);
    expect(isValidUsername('user name')).toBe(false);
    expect(isValidUsername('usér')).toBe(false);
    expect(isValidUsername('User')).toBe(false);
  });

  it('rejects length violations', () => {
    expect(isValidUsername('')).toBe(false);
    expect(isValidUsername('a'.repeat(31))).toBe(false);
  });

  it('rejects leading/trailing dots and consecutive dots', () => {
    expect(isValidUsername('.user')).toBe(false);
    expect(isValidUsername('user.')).toBe(false);
    expect(isValidUsername('us..er')).toBe(false);
  });

  it('rejects reserved paths', () => {
    for (const reserved of ['explore', 'reels', 'reel', 'stories', 'p', 'login', 'challenge']) {
      expect(isValidUsername(reserved)).toBe(false);
    }
  });
});

describe('parseUsernameInput', () => {
  it('returns the normalized username for valid input', () => {
    const r = parseUsernameInput('https://www.instagram.com/NatGeo/');
    expect('username' in r).toBe(true);
    if ('username' in r) expect(r.username).toBe('natgeo');
  });

  it('rejects empty input', () => {
    expect('error' in parseUsernameInput('')).toBe(true);
    expect('error' in parseUsernameInput('@')).toBe(true);
    expect('error' in parseUsernameInput('https://instagram.com/')).toBe(true);
  });

  it('rejects invalid usernames including reserved words', () => {
    expect('error' in parseUsernameInput('bad name!')).toBe(true);
    expect('error' in parseUsernameInput('.leading')).toBe(true);
    expect('error' in parseUsernameInput('a'.repeat(31))).toBe(true);
    expect('error' in parseUsernameInput('explore')).toBe(true);
  });
});

describe('profileUrl', () => {
  it('builds the canonical profile URL for a valid username', () => {
    expect(profileUrl('user')).toBe('https://www.instagram.com/user/');
    expect(profileUrl('nat.geo_99')).toBe('https://www.instagram.com/nat.geo_99/');
  });

  it('throws AppError(INVALID_USERNAME) for invalid input (SSRF guard)', () => {
    expect(() => profileUrl('bad name')).toThrow();
    expect(() => profileUrl('explore')).toThrow();
    expect(() => profileUrl('')).toThrow();
    try {
      profileUrl('../etc/passwd');
      expect.unreachable('should have thrown');
    } catch (err) {
      expect(isAppError(err)).toBe(true);
      if (isAppError(err)) expect(err.code).toBe('INVALID_USERNAME');
    }
  });
});
