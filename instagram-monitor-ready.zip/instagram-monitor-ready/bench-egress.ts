/**
 * Benchmark every egress route: correctness first, then speed.
 *
 *   npx tsx --env-file=.env bench-egress.ts
 *
 * The proxy route under test is read from BROWSER_PROXY_SERVER / BROWSER_PROXY_USERNAME /
 * BROWSER_PROXY_PASSWORD — the same variables the bot itself uses. Never hardcode one here.
 *
 * For each route it measures the fast HTTP probe and the browser probe across known-LIVE and
 * known-BANNED accounts. A route is only USABLE if live accounts resolve — banned accounts
 * returning GONE proves nothing, because a login-walled route makes everything look banned.
 */

import { collectSecrets, loadConfig } from './src/config';
import {
  BrowserManager,
  PlaywrightDetector,
  httpProbe,
  dispatcherFor,
  ProxySwitch,
} from './src/instagram';
import { createLogger } from './src/logging/logger';

const LIVE = ['instagram', 'natgeo', 'cristiano'];
const BANNED = ['firearms', 'melofx', 'r0x'];

const base = loadConfig(process.env);

// The proxy route is whatever BROWSER_PROXY_* describes — never a literal in this file. Proxy
// credentials are live secrets, and a committed one is compromised the moment it lands in git
// history, where deleting it later does not reach. loadConfig already parses these, so the same
// .env that runs the bot benchmarks it.
if (base.browserProxy === null) {
  throw new Error(
    'BROWSER_PROXY_SERVER is not set, so there is no proxy route to benchmark against HOME. ' +
      'Set BROWSER_PROXY_SERVER (and BROWSER_PROXY_USERNAME / BROWSER_PROXY_PASSWORD if the ' +
      'provider requires auth) in .env, then re-run with --env-file=.env.',
  );
}

const ROUTES: {
  name: string;
  proxy: { server: string; username: string | null; password: string | null } | null;
}[] = [
  { name: 'HOME (direct)', proxy: null },
  // Deliberately unnamed: the label must not leak the endpoint the credentials belong to.
  { name: 'PROXY (BROWSER_PROXY_SERVER)', proxy: base.browserProxy },
  // The two Proxy-Cheap STATIC RESIDENTIAL IPs benchmarked on 2026-07-27 were RETIRED. Both
  // returned correct GONE for every banned account while resolving ZERO live accounts — the worst
  // possible failure shape, because the bot looks healthy while being blind to recoveries. Do not
  // reintroduce them.
];

// Redact the proxy credentials from anything this script's logger emits, the same way the bot
// does — an error surfacing a proxy URL would put the password back on screen.
const logger = createLogger({ level: 'error', secrets: collectSecrets(base) });
const med = (a: number[]): number =>
  a.length === 0 ? 0 : [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)]!;

interface Row {
  route: string;
  liveOk: number;
  bannedOk: number;
  fastMs: number;
  browserMs: number;
  usable: boolean;
}
const rows: Row[] = [];

for (const route of ROUTES) {
  const config = { ...base, browserProxy: route.proxy };
  const dispatcher = dispatcherFor(route.proxy);
  // The starting mode MUST come from the route under test, not from PROXY_MODE. BrowserManager
  // prefers proxySwitch.current() over config.browserProxy, so `new ProxySwitch(config)` on a host
  // with PROXY_MODE=direct (what production runs) launched Chromium unproxied while the fast probe
  // went through the proxy — the browser column measured the HOME connection, and a proxy that
  // serves Chromium nothing but login walls was reported USABLE.
  const sw = new ProxySwitch(config, route.proxy === null ? 'direct' : 'proxy');
  const browser = new BrowserManager({ config, logger, proxySwitch: sw });
  const detector = new PlaywrightDetector({ browser, config, logger });

  console.log(`\n${'='.repeat(70)}\n  ${route.name}\n${'='.repeat(70)}`);
  const fastTimes: number[] = [];
  const browserTimes: number[] = [];
  let liveOk = 0;
  let bannedOk = 0;

  for (const u of [...LIVE, ...BANNED]) {
    const isLive = LIVE.includes(u);
    const t0 = Date.now();
    const f = await httpProbe(u, { config, dispatcher }, 20000);
    const fMs = Date.now() - t0;
    fastTimes.push(fMs);

    const t1 = Date.now();
    const b = await detector.probe(u);
    const bMs = Date.now() - t1;
    browserTimes.push(bMs);

    const ident = f.result.evidence.identitySignalMatched;
    const fastVerdict = ident ? 'ACTIVE' : 'GONE';
    const want = isLive ? 'ACTIVE' : 'GONE';
    const ok = fastVerdict === want && b.result.classification === want;
    if (ok) {
      if (isLive) liveOk += 1;
      else bannedOk += 1;
    }
    console.log(
      `  ${u.padEnd(12)} ${(isLive ? 'live' : 'banned').padEnd(7)} ` +
        `fast=${(f.result.classification as string).padEnd(7)}(${String(fMs).padStart(5)}ms) ` +
        `browser=${(b.result.classification as string).padEnd(7)}(${String(bMs).padStart(6)}ms) ` +
        `${ok ? 'OK' : 'MISMATCH'}`,
    );
  }
  await browser.close().catch(() => undefined);

  const usable = liveOk === LIVE.length;
  rows.push({
    route: route.name,
    liveOk,
    bannedOk,
    fastMs: med(fastTimes),
    browserMs: med(browserTimes),
    usable,
  });
  console.log(
    `  -> live ${liveOk}/${LIVE.length}, banned ${bannedOk}/${BANNED.length}, ` +
      `median fast ${med(fastTimes)}ms / browser ${med(browserTimes)}ms — ` +
      (usable ? 'USABLE' : 'NOT USABLE (live accounts do not resolve)'),
  );
}

console.log(`\n${'='.repeat(78)}\n  SUMMARY\n${'='.repeat(78)}`);
console.log(
  'route'.padEnd(26) +
    'live'.padEnd(7) +
    'banned'.padEnd(8) +
    'fast'.padEnd(9) +
    'browser'.padEnd(10) +
    'verdict',
);
for (const r of [...rows].sort(
  (a, b) => Number(b.usable) - Number(a.usable) || a.fastMs - b.fastMs,
)) {
  console.log(
    r.route.padEnd(26) +
      `${r.liveOk}/${LIVE.length}`.padEnd(7) +
      `${r.bannedOk}/${BANNED.length}`.padEnd(8) +
      `${r.fastMs}ms`.padEnd(9) +
      `${r.browserMs}ms`.padEnd(10) +
      (r.usable ? 'USABLE' : 'NOT USABLE'),
  );
}
