# Instagram Monitoring & Public-Analytics — feature ideas (work-in-progress)

> **Status:** placeholder / brainstorming. Nothing here is built yet.
> Created 2026-07-20 as a parking spot for the "make the bot do more" direction.

## Scope & guardrails (read first)

This extends the existing bot into a **public-data monitoring & analytics** tool for
Instagram accounts the owner is **authorized** to track:

- accounts the owner **owns**, or
- **clients who have asked** to be monitored, or
- **public** brand / competitor / topic accounts.

It watches an account's **own public signals** (availability, public profile stats,
public posts). It is **not** a tool for gathering personal data about other people.

### Explicitly OUT OF SCOPE (do not build)

These are the "OSINT" capabilities from the surveyed tools that harvest third-party
personal data or bypass privacy — building them at bot-scale enables doxxing/stalking,
so they stay out:

- ❌ Extracting a target's **email / phone / obfuscated recovery contacts** (toutatis-style)
- ❌ **Geolocation** pattern-of-life from photos (instaloctrack-style)
- ❌ Deanonymizing **private** accounts' followers/content (Tenai-style)
- ❌ **Breach / password** correlation (SocialPwned-style)
- ❌ Email/phone → real-person account correlation (holehe / ignorant / yesitsme)
- ❌ Anything using brute force, phishing, or borrowed/stolen session cookies of others

## Good engineering patterns worth borrowing (not the data-harvesting)

From the repos reviewed on 2026-07-19 — take the _architecture_, not the PII features:

- **`instagram_monitor` (misiektoja)** — change-tracking done well: profile diffs,
  follower deltas, new-post detection, dashboards, instant notifications. Closest cousin
  to this bot; good reference for the monitoring UX.
- **`instaloader`** — clean, rate-limit-aware fetching of _public_ posts/metadata; solid
  session handling. Good model for a resilient fetch layer.
- **`web_profile_info` endpoint** (seen in toutatis/Osintgram) — `GET
i.instagram.com/api/v1/users/web_profile_info/?username=X` returns the public profile
  JSON (or 404 when gone). Through the bot's existing logged-in residential session this
  is a **lightweight active/gone + public-stats check** (KB, no full browser) — a possible
  cheaper detection path than rendering a page. Only public fields; owner's own session.

## Candidate features (public data only)

1. **Public profile change-tracking** — snapshot + diff over time:
   follower / following / post counts, bio, display name, profile-pic change, external URL,
   verified / business-account flags, private↔public toggle.
2. **Restriction / shadowban-suspicion signals** — e.g. "Restricted profile" age-gate seen,
   sudden reach/▽ signals on the owner's _own_ accounts.
3. **Availability history** — timeline of active / gone / restricted transitions (already
   have the detection; add persistence + a `/history <user>` view).
4. **Snapshots & dashboards** — periodic public snapshots; a simple web/Telegram summary.
5. **Digest notifications** — daily/weekly "what changed" summary per watched account.
6. **New-public-post alerts** — notify when a watched (authorized) account posts.

## Technical approach (reuse what exists)

- Reuse the existing detector, logged-in residential session, scheduler, lease/state-machine,
  outbox, and business-chat delivery.
- New `profile_snapshots` table (append-only) + a diff step; a `/history` and `/watchstats`
  command family; optional lightweight `web_profile_info` fetch path for cheap checks.
- Keep it a **separate module** (like the deletion feature) so it can't destabilize
  recovery/deletion.

## Open questions (decide when we pick this up)

- Whose accounts, concretely? (owner's / consenting clients' / public brands)
- Telegram-only output, or a small dashboard too?
- Snapshot cadence vs. cost/rate-limit budget.
