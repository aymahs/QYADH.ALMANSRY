# Instagram Unban Monitor — Complete System Map

*Reconstructed by reading source at `C:\Users\fazea\monitor bot` on the `feature/instagram-unban-monitor` branch. No README or prompt content was trusted. Every number below is a literal from the code; the file and symbol are cited so you can check any of them.*

---

## 0. Shape of the system

| Layer | Files | Role |
|---|---|---|
| Composition root | `src/app/app.ts` | Wires everything; owns `start()`/`stop()` |
| Ingress | `src/app/polling.ts`, `src/app/webhook-server.ts` | Telegram long-poll (default) or webhook + `/healthz` |
| Telegram commands | `src/bot/commands/router.ts` (1546 ln) | Owner DM commands **and** Telegram Business client-chat commands |
| Discord commands | `src/bot/discord/discord-commands.ts` (856 ln), `discord-gateway.ts` | Slash-command mirror; transport-neutral core + one `discord.js` file |
| Detection | `src/instagram/detector/{http-probe,tiered-detector,playwright-detector,signals,classify}.ts` | 2-tier probe → shared pure classifier |
| Egress control | `src/instagram/proxy-switch.ts`, `src/instagram/circuit-breaker.ts` | Runtime route switch + fleet-wide back-off |
| Recovery pipeline | `src/monitoring/scheduler/worker.ts` → `src/notifications/outbox/worker.ts` | Confirm → screenshot → durable outbox → owner + client |
| Deletion pipeline | `src/monitoring/deletion/{worker,state}.ts` | Independent ACTIVE→GONE watch, no outbox |
| Persistence | `src/persistence/{sqlite,postgres}-database.ts`, `migrations/schema.ts` | 9 tables, identical semantics across drivers |

Two **fully independent** features share only the pure scheduling helpers and the detector:

- **Recovery** (`/unban`) — `monitoring_cases` → `notification_outbox` → photo + text alert.
- **Deletion** (`/ban`) — `deletion_watches` → direct send, text-only, no outbox.

The same username can be enrolled in both at once (separate tables, separate partial-unique indexes).

---

## 1. User-facing commands — Telegram vs Discord

### 1a. Owner commands (Telegram private DM ↔ Discord slash)

`Cost` = Instagram page loads caused by one invocation. **HTTP** = one cheap GET (~0.3 s, 1 request). **BROWSER** = one full Chromium load (~4–12 s, 20–50 requests). "HTTP→maybe BROWSER" means the fast tier answers unless it must escalate.

| Command | Does | Owner-only | Works in client business chat | Cost per call | TG | DC | Parity |
|---|---|:--:|:--:|---|:--:|:--:|---|
| `/start <secret>` | Pairs the single owner (`OwnerAuthorizer.tryPair`) | no (that's the point) | no | 0 | ✅ | ❌ | **NOT AT PARITY — by design.** Discord identifies the owner from `DISCORD_OWNER_USER_ID` env, so there is no pairing flow. |
| `/unban <user> [YYYY-MM-DD HH:MM]` | Live pre-check, then enrol for recovery monitoring | yes | **yes** | 1× HTTP→maybe BROWSER | ✅ | ✅ | Near-parity. TG sends a `🔎 Checking @x…` progress line first; Discord does not. Backdate is a positional arg on TG, the `start` option on DC. |
| `/bulkunban <users…>` | Enrol up to **50** at once, one consolidated summary | yes | no | up to 50× HTTP→maybe BROWSER, bounded (§6) | ✅ | ✅ | **NOT AT PARITY (behaviour).** TG acknowledges then runs **detached** (`CommandRouter.track`) so ingress is never frozen. DC runs **inline** inside the deferred interaction. Same bounds, same summary copy. |
| `/check <user>` | One-off live diagnostic + screenshot. Never creates a case. May start (never advance) a confirmation burst | yes | **yes** | **1× BROWSER, always** (`captureScreenshot: true`) | ✅ | ✅ | Parity. 15 s cooldown both sides (per-chat on TG, per-user on DC). |
| `/list [page]` | Active recovery monitors | yes | no | 0 | ✅ | ✅ | **NOT AT PARITY.** TG paginates via an integer arg; the Discord spec declares **no options**, so `list` renders one embed with no page control. |
| `/clear <user>` | Stop a recovery monitor; points at `/unwatch` if it's actually a deletion watch | yes | no | 0 | ✅ | ✅ | Parity (identical copy). |
| `/ping` | End-to-end health: fast-tier self-report + control-account browser probe + DB + scheduler heartbeat | yes | no | 1× HTTP (canary) **+** 1× BROWSER; **0** while the breaker is OPEN | ✅ | ✅ | Parity (same `pingHealthy`/`pingUnhealthy`/`fastTierLine` formatters). |
| `/ban <user>` | Start a deletion watch. **Refuses** unless the account is ACTIVE right now | yes | **yes** | 1× HTTP→maybe BROWSER | ✅ | ✅ | Parity. |
| `/banlist` | Active deletion watches | yes | no | 0 | ✅ | ✅ | Parity (TG plain text, DC embed). |
| `/unwatch <user>` | Stop a deletion watch; points at `/clear` if it's actually a recovery monitor | yes | no | 0 | ✅ | ✅ | Parity. |
| `/clients` | Monitors grouped by client business chat, plus a "Direct" group | yes | no | 0 IG (may call Telegram `getChat`) | ✅ | ✅ | **NOT AT PARITY.** TG takes a page arg; the DC spec has no options. DC identity backfill only works because `app.ts` injects a Telegram-backed `getChat`. |
| `/proxy [direct\|mobile]` | Show or switch egress route | yes | no | 0 | ✅ | ✅ | Parity — **one shared `ProxySwitch`**, so switching on either platform moves *all* traffic. `home` still accepted as an alias. |

Telegram's registered menu (`VISIBLE_COMMANDS`, `src/domain/telegram.ts:161`) lists 11 commands; `DISCORD_COMMAND_SPECS` (`discord-commands.ts:70`) registers the same 11 minus `/start` = **11 vs 11 minus start**, i.e. Discord registers 11 entries including `proxy` but excluding `start`.

### 1b. Telegram Business client-chat commands (owner typing inside a paying client's chat)

Handled by `CommandRouter.handleBusinessMessage`. **Discord has no equivalent and cannot — this is a Telegram Business API feature.**

| Command | Behaviour | Authorization | Cost |
|---|---|---|---|
| `/unban <user> [backdate]` | Pre-checks, enrols, **links the monitor to this chat** (`client_chat_links`), sets `BUSINESS_DELIVERY_PENDING`. Recovery is later delivered **into this chat**. | Sender must be `connection.userId` **and** match the paired owner id | 1× HTTP→maybe BROWSER |
| `/ban <user>` | Same, for deletion. Reuses `client_chat_links` keyed by the watch id (monitor and watch ids are both UUIDs from separate tables → no collision, no schema change). | same | 1× HTTP→maybe BROWSER |
| `/check <user>` | Live diagnostic + screenshot **replied into the client chat** via `business_connection_id`. Changes no state. | same | **1× BROWSER** |

A client's own `/unban` is **ignored** — `if (from.id !== connection.userId) return`.

### 1c. Authorization rails

| Rail | Location | Value |
|---|---|---|
| Single owner, first-wins, single-use secret | `OwnerAuthorizer.tryPair` | Once an owner exists, the secret never pairs again |
| Constant-time compare | `secretsEqual` | SHA-256 both sides then `timingSafeEqual` — length never leaks |
| Per-user brute-force cap | `MAX_ATTEMPTS_PER_USER` | 5 failures / 15 min window |
| Global trigger | `MAX_ATTEMPTS_GLOBAL` | 20 failures / 15 min → reserve lane |
| Reserve lane (per-caller spacing) | `RESERVE_INTERVAL_MS` | 60 s, **keyed per user** |
| Memory bound | `MAX_TRACKED_USERS` | 5000, LRU-by-window eviction |
| Bare `/start` | `provided.length === 0` → `'no_secret'` | Spends **zero** budget, answered before the throttle |
| Ambiguous reply | `no_secret` / `throttled` / `invalid` all reply identically | Never reveals the bot is unclaimed |
| Discord gate | `DiscordGateway.onInteraction` | `interaction.user.id !== ownerUserId` → refused; optional channel pin; **all replies `MessageFlags.Ephemeral`** |

---

## 2. The detection pipeline, end to end

### 2a. Cost model (from the module docs)

| Tier | Latency | Requests to Instagram | Used for |
|---|---|---|---|
| Tier 1 — HTTP probe (`http-probe.ts`) | **~0.3 s** | **1** | Routine "is it still GONE?" polling |
| Tier 2 — Chromium (`playwright-detector.ts`) | **~4–12 s** | **20–50** | Every screenshot; every possible recovery; every failed observation |

Stated ratio: **~30× faster and ~30× less load** per routine check. On a mobile proxy, browser capture has been measured at **15–115 s** (`scheduler/worker.ts` comment).

### 2b. The pipeline

```
probe(username, opts)
  │
  ├─0  syncEgress()          ← MUST run before the breaker gate
  │       └ generation changed? rebuild undici dispatcher, reset canary, breaker.reset()
  │       └ dispatcher build FAILED? → dispatcherOk=false → browser-only (fail closed)
  │
  ├─1  breaker.allowRequest()?  no → answered.blocked++, return UNKNOWN/HTTP_429, ZERO network
  │
  ├─2  screenshot requested? | !egressOk | !fastPath  → viaBrowser()
  │
  ├─3  httpProbe()  1 GET, redirect:follow, read to </head> + 32 KB body peek, cap 128 KB
  │       └ extractSnapshot() → classify()      ← THE SAME pure pipeline as the browser
  │
  ├─4  transportFailed?             → escalate()   (browser answers AND records the breaker)
  ├─5  isThrottleSignal(code)?      → breaker.record(true); answered.fast++; RETURN (no browser)
  ├─6  identitySignalMatched?       → escalate-free viaBrowser()   ← POSSIBLE RECOVERY
  ├─7  code ∉ INFERABLE_GONE_CODES  → escalate()
  ├─8  bodyTruncated && EMPTY_PAGE  → escalate()
  ├─9  canaryOk()?  no              → escalate()
  ├─10 egress generation moved mid-check? → escalate()
  └─11 → breaker.record(false); answered.fast++; return stillGone(fast)
```

### 2c. The identity discriminator — why it works

`classify.ts` never uses the "Sorry, this page isn't available" copy as the primary signal, because **Instagram renders that text client-side** — a banned account's raw HTML contains no unavailable message. What differs is **identity metadata**:

| Signal | Constant | Source |
|---|---|---|
| `canonical` href username == requested | `CANONICAL_MATCHES` | `<link rel="canonical">` |
| `og:url` username == requested | `OG_URL_MATCHES` | `<meta property="og:url">` |
| `og:title` `@handle` == requested | `OG_TITLE_MATCHES` | `<meta property="og:title">` |
| `<header h2/h1>` username == requested | `HEADER_USERNAME_MATCHES` | DOM |

`identitySignalMatched = canonical ∨ ogUrl ∨ ogTitle ∨ header`. Measured **8/8 against the browser detector over live and banned accounts** (`tiered-detector.ts:456`).

Classification order (`classify()`):

| # | Condition | Verdict |
|---|---|---|
| 1 | transport error, 403, 429, 5xx, challenge redirect | `UNKNOWN` + code |
| 1b | `errorPagePresent` ("something went wrong" **and** no follower text) | `UNKNOWN`/`ERROR_PAGE` |
| 2 | unavailable message/title **and** identity matched | `UNKNOWN`/`CONTRADICTORY` |
| 2 | unavailable message/title, no identity | **`GONE`** |
| 3 | **identity matched** | **`ACTIVE`** — even behind a login wall |
| 4 | challenge / login / consent / redirect / empty / unrecognised | `UNKNOWN` + specific code |

> The step-3 rule is what makes recovery detectable from a login-walling IP: Instagram serves the *real* profile's og metadata on the login redirect, but shows "Profile isn't available" with **no identity** for a banned one.

### 2d. `INFERABLE_GONE_CODES` — the only codes from which "still banned" may be inferred

```ts
new Set(['UNRECOGNIZED_DOM', 'EMPTY_PAGE', null])   // tiered-detector.ts:41
```

Everything else (`HTTP_5XX`, `UNEXPECTED_REDIRECT`, `CONSENT_BLOCK`, `LOGIN_WALL`, `ERROR_PAGE`, `CHALLENGE`, `TIMEOUT`, `DNS`…) is a **failed observation**, never evidence about the account.

### 2e. The canary guard

| Property | Value | File |
|---|---|---|
| What it proves | The current egress route is being served **live profiles** at all | `TieredDetector.canaryOk` |
| Target | `config.controlUsername` (default `instagram`) | `config.ts:110` |
| Pass condition | `evidence.identitySignalMatched === true` | |
| Good-verdict TTL | `CANARY_TTL_MS = 5 min` | |
| Bad-verdict retry | `CANARY_RETRY_MS = 60 s` | |
| Concurrency | Single in-flight promise shared by all callers | |
| Generation pinning | A result measured on route A is **discarded** if `/proxy` moved to route B mid-flight | |
| Direct invalidation | A browser-observed throttle immediately clears a "healthy" canary | `viaBrowser()` |

**Failure it prevents:** on a login-walled link *every* account looks metadata-less, so the "no identity ⇒ still banned" inference would manufacture `GONE` for accounts that had actually recovered — a bot that looks perfectly healthy while missing every recovery.

### 2f. Circuit breaker (`circuit-breaker.ts`)

| Knob | Default | Env |
|---|---|---|
| Consecutive throttle signals to OPEN | 5 | `BREAKER_THRESHOLD` |
| First cooldown | 600 s | `BREAKER_COOLDOWN_SECONDS` |
| Max cooldown (doubling) | 3600 s | `BREAKER_MAX_COOLDOWN_SECONDS` |
| HALF_OPEN admission TTL | 2 min (`HALF_OPEN_SLOT_TTL_MS`) | — |
| Throttle codes | `LOGIN_WALL`, `HTTP_429`, `HTTP_403`, `ERROR_PAGE`, `CHALLENGE` | — |

**One breaker per process**, constructed in `app.ts:85` and shared by the fast detector *and* the browser-only deletion detector. Back-off is genuinely fleet-wide.

> Production incident this exists for (`circuit-breaker.ts:5`): per-account retry ladders amplified request rate exactly when it had to fall — **~1,270 checks/hour burned a residential IP for hours**.

**Exactly one breaker outcome is recorded per check** — whichever tier produced the final answer. Recording the fast leg unconditionally made the counter oscillate 0→1→0 so the threshold was unreachable, *while* every check escalated to a browser load.

### 2g. Confirmation burst → screenshot → outbox

| Stage | Rule | Constant |
|---|---|---|
| Baseline poll | **flat 15 s**, fleet-independent + 0–2 s jitter | `BASELINE_INTERVAL_SECONDS`, `BASELINE_JITTER_MAX_SECONDS` |
| ACTIVE seen | → `CONFIRMING`, count = 1 | `transitions.ts` |
| Confirmation cadence | exact **5 s**, no jitter | `CONFIRMATION_INTERVAL_SECONDS` |
| Required consecutive ACTIVE | **3** | `CONFIRMATION_REQUIRED_COUNT` |
| Burst deadline | 30 s → abandon back to `MONITORING` | `CONFIRMATION_DEADLINE_SECONDS` |
| GONE or UNKNOWN mid-burst | streak reset to 0, back to `MONITORING` | |
| `confirmed` edge | **true exactly once** in a case's lifetime | `TransitionOutput.confirmed` |
| Inconclusive ladder | 5, 10, 15, 30 s (last repeats), hard cap 30 s | `RETRY_DELAYS_SECONDS`, `ERROR_BACKOFF_MAX_SECONDS` |
| Backoff cycle limit | 8 → folds back to plain `MONITORING` | `BACKOFF_CYCLE_LIMIT` |

**A monitor is never parked in a long backoff.** Even a login wall reschedules within 5–30 s.

Then `handleConfirmed`:

| Constant | Value | Why |
|---|---|---|
| `SCREENSHOT_ATTEMPTS` | 3 | |
| `SCREENSHOT_RETRY_DELAY_MS` | 750 | |
| `SCREENSHOT_BUDGET_MS` | **30 000, shared across all attempts** | Bounds worst-case alert latency on a slow proxy |

Capture-probe verdict handling:

| Verdict at capture time | Action |
|---|---|
| `GONE` | **Cancel** — revert to `MONITORING`, no alert (a real contradiction) |
| `UNKNOWN` | **Keep the confirmation**, retry within budget, then alert text-first. Never cancels — it is no evidence about the account |
| `ACTIVE` + screenshot | Write PNG, `NOTIFYING` / `CAPTURED`, enqueue `RECOVERY_PHOTO` |
| `ACTIVE`, `restricted` age-gate | `NOTIFYING` / **`RESTRICTED`**, enqueue `RECOVERY_TEXT`, **no follow-up ever** |
| Budget spent / no image | `NOTIFYING` / `FAILED`, enqueue `RECOVERY_TEXT` + later `SCREENSHOT_FOLLOWUP` |

### 2h. Screenshot integrity — what will *not* be sent

`PlaywrightDetector.tryScreenshot` requires **all** of:

```
hasProfileStructures ∧ ¬loginFormPresent ∧ ¬loginWallPresent ∧ ¬redirectedToLogin
                     ∧ ¬restrictedProfilePresent ∧ ¬errorPagePresent ∧ ¬consentBlockPresent
                     ∧ ¬hasBlockingOverlay(page)
```

`hasProfileStructures` alone is **not** enough: Instagram serves `og:type=profile` on the logged-out login wall. Anything failing this degrades to an honest text-only recovery rather than mailing a client a picture of a login box.

Capture geometry (`capture.ts`): 1280×900 viewport, `deviceScaleFactor: 2`, preferred `<header>` clip + 28 px padding → fallback 950 px centred column × 420 px → fallback full viewport. Output validated by **PNG/JPEG magic bytes**; invalid bytes throw `SCREENSHOT_INVALID`.

---

## 3. Recovery and deletion notification paths

### 3a. Recovery — `OutboxWorker` (tick 1500 ms, one item per tick)

| Guard | Mechanism |
|---|---|
| Cleared cases never notify | Checked at `deliver()` **and** again via compare-and-save in `closeOutAsNotified` |
| At most one recovery per case | `c.notificationSentAtUtc !== null` → `markFailed('already_notified')` |
| Single winner across workers | `cases.claimNotification` — `SET notification_claimed_at_utc WHERE ... IS NULL`, returns `changes > 0` |
| Stale claim takeover | Only after `STALE_CLAIM_MS = 10 min` |
| Crashed claim recovery | `requeueStale` at the top of every tick: `CLAIMED` older than 10 min → `PENDING` |
| Attempt bound | `DEFAULT_MAX_ATTEMPTS = 3` claims, then `FAILED` |
| Unpaired owner | Item left `CLAIMED` (deferred), **claim never burned** |

Failure-mode table:

| Failure | What happens | Client outcome |
|---|---|---|
| Screenshot file missing at send | `enqueueOrRevive(RECOVERY_TEXT)` + `markFailed('screenshot_missing')` | Text recovery, still delivered |
| **Ambiguous** Telegram owner send (`TELEGRAM_AMBIGUOUS`) | `sendOwnerAlert` returns `null` — the owner alert is **closed out unretried**; `markSent(messageId=null)`; Discord mirror still fires; **client delivery still runs** | Reached exactly once |
| Ordinary send error | Deferred, retried up to 3 claims, then `FAILED` | Rescued by sweeps |
| `/clear` lands mid-send | `closeOutAsNotified` returns false → screenshot deleted, **client delivery skipped** | Nothing sent (cleared wins) |
| Business connection disabled / `can_reply` false | Link → `BUSINESS_CONNECTION_DISABLED` / `BUSINESS_PERMISSION_MISSING` + owner "action required" ping | Owner delivers by hand |
| Client send throws (24 h reply window closed) | Link → `OWNER_ACTION_REQUIRED` + owner ping. **Never** marked delivered | Owner delivers by hand |
| Crash between `markSent` and client delivery | `rescueStrandedClientDeliveries` (60 s sweep) finishes it | Reached |
| Crash between `markSent` and case close-out | `MonitorWorker.closeOutFromSentRow` repairs the case to `NOTIFIED` from the SENT row — sends nothing | No duplicate |
| Case stuck `CONFIRMED`/`NOTIFYING` with no usable row | `MonitorWorker.reapStrandedNotifications` (60 s) → `reopenFailed` or `enqueue` | Re-delivered |

**Exactly-once ledger.** Owner alert: `notification_claimed_at_utc` (claim) + `notification_sent_at_utc` (proof) + the outbox row's `SENT`. Client alert: `client_chat_links.client_delivery_status`. **These are independent on purpose** — the client half is not gated on the owner send, so an unreachable owner cannot strand a paying client.

**Deliberate trade-off, stated plainly:** an ambiguous owner send is *never retried*. If Telegram silently dropped it, the owner misses that one alert. The project accepts that because a duplicate "YOUR ACCOUNT IS BACK" to a client is unacceptable — and the client half proceeds regardless.

### 3b. Deletion — `DeletionWorker` (tick 1000 ms, no outbox, no screenshot)

State machine (`applyDeletionCheck`): `WATCHING` → GONE → `CONFIRMING` (1/3) → 3 consecutive GONE → `sealConfirmed` → `CONFIRMED`. ACTIVE or UNKNOWN mid-burst resets to `WATCHING`. UNKNOWN from `WATCHING` → `BACKOFF` on the same 5/10/15/30 ladder, folding back after 8.

The write-ahead rule (`worker.ts:242`):

> `next` already carries `CONFIRMED` **before a single alert leaves the process**. Nothing after that may retract it — a client about to be told "your account was deleted" must never be silently un-told. `DELETION_DECIDED_STATUSES = ['CONFIRMED','ALERTING','NOTIFIED']` is frozen against every later check result.

Fan-out claims, one per channel:

| Channel | Exactly-once claim | Retried on failure? |
|---|---|---|
| Discord `#deletions` mirror | The `CONFIRMED → ALERTING` status write, committed **before** the post | ❌ (a lost mirror is covered by the Telegram alert; unbounded duplicate deletion alerts are not recoverable) |
| Client business chat | `client_chat_links.client_delivery_status` | ✅ idempotently |
| Owner "action required" ping | `OWNER_PINGED_DELIVERY_STATUSES` | ❌ once per deletion, not once per retry pass |
| Owner Telegram alert | *(none — this is the only retried channel)* | ✅ re-armed via `nextCheckAtUtc` |

`reapStrandedAlerts` (60 s) reaches watches parked in `DELETION_PENDING_ALERT_STATUSES = ['CONFIRMED','ALERTING']` via `listActive()`, because `claimDue` only serves statuses that still need a probe. It skips rows another worker holds a live lease on, and treats `nextCheckAtUtc === null` as "due now" rather than "never".

---

## 4. Egress and proxy handling

### 4a. `ProxySwitch` (`src/instagram/proxy-switch.ts`)

| Mode | `current()` | Meaning |
|---|---|---|
| `direct` | `null` | The machine's own connection — your home line on your PC, **the datacenter IP on the VPS (Instagram blocks it)** |
| `proxy` | configured `{server, username, password}` | `BROWSER_PROXY_*` (residential / ISP / mobile) |

- Starting mode = `PROXY_MODE`, else `proxy` when `BROWSER_PROXY_SERVER` is set, else `direct`. Asking for `proxy` with none configured falls back to `direct`.
- `set(mode)` returns `false` (changing nothing) when proxy is unavailable. **A no-op switch does not bump the generation** — no needless browser restart.
- `describe()` prints `host:port` only. A schemeless `host:port` is defaulted to `http://` first so a misconfiguration shows the real host instead of a meaningless `proxy :80`; unparseable → `proxy (malformed BROWSER_PROXY_SERVER)`. **Credentials are never echoed.**

### 4b. What a generation bump rebuilds

| Consumer | Reaction | File |
|---|---|---|
| undici dispatcher (fast probe + canary) | Rebuilt via `dispatcherFor()`; pooled `keepAlive 60 s / max 300 s / 8 connections` | `TieredDetector.syncEgress` |
| Canary verdict | **Discarded** (`canaryCheckedAt = 0`, `canaryHealthy = false`) | same |
| Circuit breaker | **`breaker.reset()`** | same |
| Chromium | Torn down and relaunched (a local Chromium binds its proxy at launch). Old instance detached first, then closed in the background — disposing inline would deadlock against the `withPage` semaphore | `BrowserManager.ensureBrowser` |
| In-flight canary / check | Generation-pinned; a result measured on the old route escalates rather than being trusted | `canaryOk`, `probe` step 10 |

`syncEgress()` runs **before** the breaker gate. When it lived inside `dispatcher()` — only reachable *after* the gate — a `/proxy` issued to escape a throttled IP could never clear the block it was meant to escape.

### 4c. Fail-closed on a bad proxy URI

`dispatcherFor` **throws** rather than returning `undefined` for a URI undici rejects. A silent fallback would send the fast tier and canary out over this machine's own IP while Chromium still used the proxy — a hidden egress split and an IP leak. On throw: `dispatcherOk = false` → every probe goes browser-only, and `/ping` reports `degraded`.

---

## 5. Persistence

`ddlStatements(driver)` — identical column semantics on sqlite and postgres; only physical types differ. All `*_utc` are TEXT ISO-8601 UTC; signal arrays are TEXT JSON.

| Table | Purpose | Key constraint |
|---|---|---|
| `owner` | Single owner | `id INTEGER PRIMARY KEY` (fixed row 1) + `telegram_user_id UNIQUE` |
| `monitoring_cases` | Recovery lifecycle | **`ux_active_username` — UNIQUE partial index on `normalized_username` WHERE `status NOT IN ('NOTIFIED','CLEARED')`** |
| `monitoring_checks` | Append-only audit of every check | `ix_checks_case` |
| `telegram_updates` | Update dedup ledger | `update_id PRIMARY KEY` |
| `notification_outbox` | Durable send queue | **`UNIQUE (case_id, kind)`** |
| `scheduler_health` | Heartbeat + rolling UNKNOWN EMA | `name PRIMARY KEY` |
| `business_connections` | Telegram Business connections + rights | `id PRIMARY KEY` |
| `deletion_watches` | Deletion lifecycle | **`ux_active_deletion_username` — UNIQUE partial WHERE `status NOT IN ('NOTIFIED','CLEARED')`** |
| `clients` | Client display identity for `/clients` | `client_chat_id PRIMARY KEY` |
| `client_chat_links` | Monitor/watch → client chat | **`monitor_id UNIQUE`** |

### Invariants and the repository methods that enforce them

| Invariant | Enforced by | How |
|---|---|---|
| At most one active monitor per username | DB partial index + `cases.create` mapping a violation to `AppError('DUPLICATE_CASE')` | Every caller catches it and re-reads the racing row |
| At most one active deletion watch per username | `ux_active_deletion_username` + `deletionWatches.create` | same pattern |
| One worker per case at a time | `cases.claimDueCases` / `deletionWatches.claimDue` | `SELECT ... WHERE lease_owner IS NULL OR lease_expires_at_utc <= now` **then** `UPDATE`, inside `db.transaction`. `CONFIRMING` ordered first |
| Sole right to notify | `cases.claimNotification` | `UPDATE ... SET notification_claimed_at_utc WHERE id = ? AND notification_claimed_at_utc IS NULL`; `changes > 0` = won |
| `/clear` always wins | `cases.clearByNormalizedUsername` | Transactional: `status='CLEARED'`, `cleared_at_utc`, **`next_check_at_utc = NULL`, lease cleared** — a late result cannot notify |
| One outbox row per (case, kind) | `outbox.enqueue` | `ON CONFLICT DO NOTHING`, returns the existing row |
| Single-winner queue claim | `outbox.claimNextPending` | Transactional `SELECT ... PENDING ORDER BY created_at ASC LIMIT 1` + `UPDATE status='CLAIMED', attempts = attempts + 1` |
| **A delivered alert is never re-sent** | `outbox.markFailed` | `UPDATE ... SET status='FAILED' WHERE id = ? **AND status <> 'SENT'**` |
| An exhausted row can still be revived | `outbox.reopenFailed` | `FAILED → PENDING`, attempts 0, error cleared, **`created_at_utc` refreshed** (so backlog age is honest). Scoped to `FAILED` only — `PENDING`/`CLAIMED` are in flight and `SENT` was delivered |
| Crashed claims recovered | `outbox.requeueStale` | `CLAIMED` with `claimed_at_utc <= (now − 10 min)` → `PENDING` |
| Telegram retries are idempotent | `updates.registerIfNew` | Called **first**, before any routing |
| Client alert exactly once | `clientLinks.updateDeliveryStatus` | `BUSINESS_DELIVERED` / `FALLBACK_BOT_DELIVERED` short-circuit both delivery paths |

Startup recovery (`app.ts` §2 + `recoverOnStartup`): releases stale leases, restarts interrupted confirmation bursts, clamps future-dated `started_at` and far-future `next_check_at` (the clock is `NetworkCorrectedClock`, which corrects host skew against a trusted network `Date` header — a dev box was observed 4.5 h fast), and requeues outbox items claimed by a dead process.

---

## 6. Operational limits and safety rails

### 6a. Hard-coded rails

| Rail | Value | Where |
|---|---|---|
| Baseline poll interval | 15 s flat, fleet-independent + 0–2 s jitter | `BASELINE_INTERVAL_SECONDS` |
| Max concurrent browser work | **4** | `MAX_BROWSER_CONCURRENCY` + `BrowserManager` semaphore |
| Per-check timeout | 25 000 ms | `CHECK_TIMEOUT_MS` |
| Job lease | 120 s | `JOB_LEASE_SECONDS` |
| Asset blocking on classify-only loads | images, media, fonts, stylesheets aborted | `CLASSIFY_BLOCKED_TYPES` |
| HTTP probe body read | `</head>` + 32 KB peek, hard cap 128 KB (of a ~590 KB doc) | `BODY_PEEK_BYTES`, `MAX_BODY_BYTES` |
| Circuit breaker | 5 consecutive throttles → OPEN 10 min, doubling to 60 min | §2f |
| `/check` cooldown | 15 s (per chat on TG, per user on DC) | both surfaces |
| `/bulkunban` cap | **50** usernames | `BULK_MAX` |
| `/bulkunban` concurrency | **3** in flight | `BULK_PRECHECK_LIMITS.concurrency` |
| `/bulkunban` probe spacing | **200 ms between probe *starts*** | `.spacingMs` |
| `/bulkunban` deadline | **90 s** | `.deadlineMs` (kept well under Discord's 15-min interaction token) |
| Bulk queue serialisation | `CommandRouter.background` is a **chained** promise, not parallel — two `/bulkunban`s cannot double the probe rate | `track()` |
| Browser drain on shutdown/relaunch | 15 s | `DRAIN_TIMEOUT_MS` |
| SSRF guard | Only ever `https://www.instagram.com/{validated}/`, `^[a-z0-9._]{1,30}$` | both probes |

### 6b. The ~200 Instagram page loads/hour ceiling — honest assessment

**There is no hourly quota counter anywhere in the code.** The ~200/hr figure is an operational rule from the VPS/residential-proxy deployment, not an enforced limit. What the code actually gives you:

| Mechanism | Effect on the budget |
|---|---|
| Fast tier answers routine polls | **~30× reduction** — 1 request instead of 20–50, for every "still gone" check |
| Asset blocking | Cuts bytes and page time on the escalations that do happen |
| Breaker | The only **automatic** brake: 5 consecutive throttles halts *all* network traffic for 10–60 min |
| Bulk spacing (200 ms) | Caps a 50-account burst at ~5 probe-starts/s instead of ~10/s at 0.3 s per probe |
| `MAX_BROWSER_CONCURRENCY = 4` | Caps *simultaneous* browser loads, not the hourly rate |

Arithmetic at defaults: 15 s baseline = **240 checks/hour per monitored account**. While the fast tier is healthy those are 240 cheap GETs. **If the fast tier degrades, all 240 become full Chromium loads — one account alone then exceeds the ~200 page-loads/hour ceiling.** That is precisely why `/ping` was taught to report a degraded fast tier as a *failure* rather than a note (§7, Fix 5), and why the degraded copy reads: *"Every check now costs a full browser load."*

**Recommendation the code does not implement:** an explicit hourly page-load counter. Today the only thing standing between a fast-tier outage and a burned IP is you reading `/ping`.

### 6c. Security constraints held in code

| Constraint | Evidence |
|---|---|
| Never logs in | No credential handling anywhere; `IG_STORAGE_STATE` is opt-in, file-based, owner-created manually, never logged, warns and runs logged-out if absent |
| No stealth / evasion | `BrowserManager`: "No cookies, no persisted state, **no stealth**". UA is a plain realistic desktop Chrome string |
| No CAPTCHA solving | `CHALLENGE` is classified `UNKNOWN` and counts as a throttle signal → backs off |
| Public pages only | Single URL template, validated username, `redirect: 'follow'` on one origin |
| Privacy-preserving consent | `dismissOverlays` tries "Only allow essential cookies" / "Decline optional cookies" among its labels |
| Secret redaction | `collectSecrets()` feeds bot tokens, pairing secret, DB URL, WS endpoint, **and proxy server/user/pass** to the logger redactor |
| No HTML retained | `signals.ts`: "Never store the parsed HTML anywhere; only the derived, non-sensitive snapshot escapes" |
| Discord PII containment | Every slash reply is `MessageFlags.Ephemeral` — `/clients` identities and `/check` screenshots are visible only to the invoking owner |

---

## 7. What changed in this round — the six fixes

*Reconstructed from the current source and the regression tests that pin each behaviour (I was instructed not to run git). Each row cites the code site and the test that would fail if the fix were reverted.*

### Fix 1 — A confirmed deletion could be stranded forever mid-fan-out

| | |
|---|---|
| **Code** | `DeletionWorker.reapStrandedAlerts`; `DELETION_PENDING_ALERT_STATUSES` (`src/domain/deletion.ts:58`) |
| **Was** | The confirmation is written as `CONFIRMED` *before* any alert leaves the process, and a failed owner send re-arms the row while leaving it `ALERTING`. `claimDue` only serves statuses that still need a probe — so a decided watch was never returned again. A crash between the `CONFIRMED` write and the fan-out, or one unreachable-owner send, stranded it permanently: no Discord mirror, no owner alert, **no client delivery**, and a row stuck active in `/banlist` that also blocked re-running `/ban` on that username |
| **Now guarantees** | A 60 s sweep reaches those rows by **status** via `listActive()`, skips anything this tick's claim loop handled, skips rows another worker holds a live lease on, and treats `nextCheckAtUtc === null` as "due now". Nothing replays: every channel but the owner's Telegram alert carries its own durable marker |
| **Tests** | `'a CONFIRMED watch left behind by a killed process still alerts everyone after a restart'`; `'an ALERTING watch keeps retrying the owner alert even though claimDue never returns it'` |
| **Trade-off** | A `listActive()` scan every 60 s in the deletion worker. Negligible at this fleet size; O(active watches) if it grows |

### Fix 2 — A paying client's recovery could be stranded after the owner alert was recorded SENT

| | |
|---|---|
| **Code** | `OutboxWorker.rescueStrandedClientDeliveries`; `CLIENT_RESCUE_INTERVAL_MS = 60 s` |
| **Was** | `markSent` commits *before* both the case close-out and `deliverToClient`. A container restart in that window left the link at `BUSINESS_DELIVERY_PENDING` with nothing to drive it — the outbox row is `SENT` so it is never claimed again, and the scheduler's sweep deliberately refuses to revive a `SENT` row. **Permanent, silent loss of the client notification — the worst failure this system has** |
| **Now guarantees** | A 60 s sweep finds `BUSINESS_DELIVERY_PENDING` links, verifies the owner's alert really is `SENT` (proof the recovery is real, so it cannot jump ahead of a cancelled one), and re-runs `deliverToClient`. Idempotent via the link status. Only `BUSINESS_DELIVERY_PENDING` is retried — owner-escalated statuses are terminal for this sweep, or it would re-ping the owner every minute forever |
| **Test** | `'rescues a client delivery stranded by a crash after the owner alert was marked SENT'` |
| **Trade-off** | If the screenshot file was already cleaned up, the rescued delivery is **text-only**. Deliberate: an honest text alert beats no alert |

### Fix 3 — `markFailed` could demote a delivered row, causing a duplicate alert

| | |
|---|---|
| **Code** | `OutboxRepository.markFailed` contract (`src/domain/repositories.ts:96`) + both drivers: `... WHERE id = :id AND status <> 'SENT'` |
| **Was** | Steps that run *after* a successful send — case close-out, client delivery, screenshot cleanup — can throw and land in `markFailed`, flipping a `SENT` row to `FAILED`. The stranded-notification sweep reads `SENT` as "already delivered"; against a `FAILED` row it would instead **re-open and re-send**, so the owner (and potentially a client) got the same recovery twice |
| **Now guarantees** | `SENT` is a terminal, durable proof-of-delivery that no code path can retract. Paired with `reopenFailed`, scoped to `FAILED` only — `PENDING`/`CLAIMED` are in flight, `SENT` was delivered, neither may be resurrected into a duplicate |
| **Test** | `describe('outbox markFailed never demotes a delivered row')` → `'leaves a SENT row SENT when a post-send step fails into markFailed'` |
| **Trade-off** | None material. A genuinely failed post-send step now records nothing in the row; the log is the only trace |

### Fix 4 — A case whose alert went out but whose close-out never ran was parked forever

| | |
|---|---|
| **Code** | `MonitorWorker.closeOutFromSentRow`, called from `reapStrandedNotifications`; plus `reopenFailed` in the same sweep |
| **Was** | Two gaps. (a) A crash between `markSent` and the case save left the case in `NOTIFYING` forever — invisible to `/list`, never checked again, **still holding the username's active-monitor slot** so `/unban` on it was refused. Skipping it silently (the safe-looking option) *was* the bug. (b) The sweep called `enqueue`, which is `ON CONFLICT DO NOTHING` — against an exhausted `FAILED` row it silently did nothing while logging a "re-enqueued" rescue every 60 s forever |
| **Now guarantees** | (a) The case is repaired **forward** to `NOTIFIED` using the delivered row as the record of what the owner actually received (`sent.sentAtUtc`, `sent.telegramMessageId`, `screenshotStatus: 'SENT'` for a photo row). It sends nothing, so it cannot duplicate; it re-reads first so it never clobbers a `/clear`. (b) An exhausted row is explicitly `reopenFailed`, and **only a real change is logged** |
| **Tests** | `'repairs a case whose alert went out but whose close-out never ran'`; `'revives an outbox row that exhausted its attempts'`; `'never re-sends an alert that already went out, and claims no false rescue'`; `'leaves an in-flight row alone and claims no rescue'`; `'never resurrects a cleared case'` |
| **Trade-off** | None |

### Fix 5 — `/ping` reported "Fast probe: Working" with a fast tier answering nothing

| | |
|---|---|
| **Code** | `TieredDetector.fastTierReport()`, `DetectorDiagnostics`, `detectorDiagnostics()`, `ESCALATION_STORM = 20`, `consecutiveEscalations`, `answered: Record<AnsweringTier, number>`; consumed by `CommandRouter.handlePing` and `DiscordCommands.ping`; rendered by `fastTierLine()` |
| **Was** | Three compounding problems. (a) `/ping` inferred fast-tier health from a `probe()` classification — but the tiered detector returns the **browser's** verdict on every fast-tier failure, so a completely dead fast tier still printed "Working". (b) That inference probe matched identity and escalated, so **`/ping` cost two full Chromium loads**, halving how many `/ping`s the egress budget allows. (c) The canary alone cannot see the real storm: it only proves the heavily-cached control account resolves. If Instagram starts serving *monitored* accounts something outside `INFERABLE_GONE_CODES` — a consent interstitial, an explore redirect, an HTTP 5xx — every routine check silently becomes a full browser load while the tier reports healthy |
| **Now guarantees** | `/ping` asks the detector about **itself**. The verdict rests on two signals: a freshly re-measured canary (forced at most once per 60 s retry window — a health check must not be able to manufacture load by being spammed) **and** `consecutiveEscalations >= 20`, which at a 60 s cadence a real storm crosses in well under a minute while a lone recovery escalation never approaches. States: `ok` / `degraded` / `disabled` / `blocked`. **`degraded` is a `/ping` FAILURE**, not a footnote, with copy that spells out the cost. `blocked` names the breaker and its retry-in seconds instead of probing through it (**zero network while OPEN**). `/ping` is back to **one** browser load + at most one cheap GET. `/ping` also now prints which tier actually answered: *"answered N of M checks"* |
| **Additional honesty fixes riding along** | A missing screenshot is only a failure when the control page **actually rendered** (`PROFILE_STRUCTURES_RENDERED ∧ NOT_REDIRECTED_AWAY`) — a login-gated control account legitimately yields none, reported as `Screenshot capture: Limited`, still healthy. The canary line is **suppressed** in browser-only mode, where `canaryHealthy` is never measured and printing it would be a fabricated reading |
| **Tests** | `'fastTierReport is degraded when a green canary hides a tier answering nothing'`; `'a fast-tier answer clears the escalation streak'`; `'reports which tier actually answered each probe'`; `'fastTierReport re-measures rather than reporting a stale canary verdict'`; `'fastTierReport does not re-roll a canary measured inside the retry window'`; `'fastTierReport reports an open breaker WITHOUT touching the network'`; `'/ping prints which tier is actually carrying the checks'`; `'/ping names fleet back-off plainly instead of probing through an open breaker'`; and the Discord mirrors |
| **Trade-off** | `/ping` now costs **one extra cheap HTTP request** (the forced canary) up to once per 60 s. In exchange it stopped costing a second full browser load and stopped lying. Net: strictly cheaper and strictly more truthful. Secondary: `consecutiveEscalations` is per-process and resets on restart, so a storm in progress needs ~20 checks to be re-detected after a redeploy |

### Fix 6 — A fast-polling attacker could permanently lock the real owner out of pairing

| | |
|---|---|
| **Code** | `OwnerAuthorizer` — `RESERVE_INTERVAL_MS = 60 s` keyed **per user**; `globalFailures` as a true sliding window; `'no_secret'` outcome; `sweep()`; `evictIfFull()` / `MAX_TRACKED_USERS = 5000` |
| **Was** | Three distinct denial-of-service holes into the *owner's* ability to claim the bot. (a) A **hard global deny** at 20 failures/15 min: 20 messages from throwaway accounts kept the real owner permanently unable to pair. (b) A **shared global admission** was no better — whoever polls fastest takes it every time, and a refused poll costs the attacker nothing, so a script polling every second consumes every admission forever while the owner, holding the *correct* secret, is told "pairing failed" indefinitely. (c) Telegram sends a bare `/start` **automatically** the moment anyone opens the bot, and that was counted as a failed guess — so ordinary curiosity traffic spent the brute-force budget and locked the owner out |
| **Now guarantees** | Past the global budget the limiter drops into a **reserve lane keyed per caller**: an id with no recent failed guess of its own — the owner arriving for the first time — is admitted **immediately**. An attacker's traffic can make everyone slower but can never consume the admission belonging to a specific caller. A bare `/start` is answered *before* the throttle is consulted, so it is neither counted nor able to consume a reserve admission. `no_secret` / `throttled` / `invalid` still share one ambiguous reply, so a visitor never learns the bot is still claimable. Memory is hard-bounded |
| **Tests** | `'a fast-polling attacker cannot consume the route back that the owner needs'`; `'the reserve lane meters each caller separately, not one shared admission'`; `'the global budget never refuses a caller who has not guessed recently'`; `'a bare /start consumes no throttle budget, so the owner can still pair'`; `'evicts attempt records once their window has passed'` |
| **Trade-off — stated honestly** | The aggregate guess rate now **scales with the number of distinct Telegram accounts an attacker controls** (each still capped at 5 per 15 min and spaced 60 s apart). This is unavoidable: the limiter cannot tell the owner from an attacker before the secret is compared, so any bound it shares between them is a bound the attacker can take. The project chose "the owner can always get in, at the cost of a slightly higher ceiling on distributed guessing" over "nobody gets in". Counters remain in-memory and per-process, so a restart also clears them — the documented operator escape hatch, now no longer the *only* one |

### Adjacent hardening visible in the same round

Not counted among the six, but present and test-pinned:

| Change | Guarantee | Test |
|---|---|---|
| `/bulkunban` pre-check bounds **shared** between Telegram and Discord (`runBulkPrecheck` imported by `discord-commands.ts`) | One implementation of the thing that stops a 50-account burst from burning the budget — two copies would drift | `'/bulkunban never runs more than the configured number of probes at once'` |
| Breaker guard inside `runBulkPrecheck` | A burst that trips the breaker **stops** instead of self-cancelling. Otherwise every remaining probe returns UNKNOWN without touching the network and the tail of the batch is enrolled with no pre-check at all | `'/bulkunban reports "not pre-checked" separately when the breaker is open'` |
| `UNKNOWN` is never collapsed into "not active" | An account that was already public would otherwise be enrolled, confirmed ACTIVE within a minute, and fire a **false "ACCOUNT UNBANNED" at the client** — with the owner having been told it was checked. Unverified accounts are still enrolled (a missed recovery is worse) but reported in their own bucket | `'/bulkunban never reports an inconclusive probe as pre-checked'` |
| A throttled cheap probe does **not** escalate | During throttling, request volume no longer *rises* exactly when back-off is needed | `'a throttled cheap probe does not escalate to the browser (no extra load)'` |
| Telegram ambiguity re-classified at the transport | `SyntaxError` on a gateway/captive-portal page ⇒ definitely-not-delivered ⇒ **retryable**. A socket reset or our own abort while reading a **2xx** body ⇒ ambiguous (Telegram only writes a 2xx status line after accepting the send). Over-reporting AMBIGUOUS was suppressing retries of alerts that definitively never arrived | 7 cases in `describe('HttpTelegramClient send-failure classification')` |

---

## 8. Config reference (defaults as coded)

| Env | Default | Notes |
|---|---|---|
| `TELEGRAM_MODE` | `polling` | `webhook` requires `TELEGRAM_WEBHOOK_SECRET` + `PUBLIC_BASE_URL` |
| `CONTROL_USERNAME` | `instagram` | Canary + `/ping` target; cannot be monitored or watched |
| `DISPLAY_TIMEZONE` | `Asia/Kolkata` | All owner/client-facing timestamps |
| `BASELINE_INTERVAL_SECONDS` / `_JITTER_MAX` | `15` / `2` | Flat, fleet-independent |
| `CONFIRMATION_INTERVAL_SECONDS` / `_REQUIRED_COUNT` / `_DEADLINE_SECONDS` | `5` / `3` / `30` | |
| `MAX_BROWSER_CONCURRENCY` | `4` | |
| `JOB_LEASE_SECONDS` / `CHECK_TIMEOUT_MS` | `120` / `25000` | |
| `RETRY_DELAYS_SECONDS` / `ERROR_BACKOFF_MAX_SECONDS` | `5,10,15,30` / `30` | Last entry repeats, hard-capped |
| `FAST_PROBE` | `true` | Kill switch. Accepts `false/0/no/off/disabled` — anything else is true |
| `BREAKER_THRESHOLD` / `_COOLDOWN_SECONDS` / `_MAX_COOLDOWN_SECONDS` | `5` / `600` / `3600` | |
| `BROWSER_PROXY_SERVER` / `_USERNAME` / `_PASSWORD` | none | **Browser + HTTP probe only** — never Telegram/Discord traffic |
| `PROXY_MODE` | `proxy` if a server is set, else `direct` | Lets you keep the proxy configured but start direct |
| `IG_STORAGE_STATE` | none | Opt-in, local-only, owner-created. **The file IS the login — treat as a secret, keep out of git** |
| `DISCORD_BOT_TOKEN` + `_OWNER_USER_ID`, `_GUILD_ID`, `_UNBANS/_DELETIONS/_STATUS/_COMMANDS_CHANNEL_ID` | none | Entirely dormant without the token; per-channel opt-in |
| `DB_DRIVER` / `SQLITE_PATH` / `DATABASE_URL` | `sqlite` / `./data/monitor.sqlite` / none | `postgres` requires `DATABASE_URL` |

---

## 9. Known gaps (found while mapping, not fixed)

| Gap | Impact | Where |
|---|---|---|
| No hourly Instagram page-load counter | The ~200/hr ceiling is enforced only by your reading `/ping`. A degraded fast tier turns one account's 240 checks/hr into 240 browser loads | §6b |
| Discord `/list` and `/clients` have no pagination | Their specs declare no options while the Telegram handlers accept a page arg; long lists truncate at the 2000-char clamp or the embed limit | `DISCORD_COMMAND_SPECS`, `clampContent` |
| `Repositories` declares no `invitations` / `subscriptions` / `deliveries` | Those interfaces exist in `src/domain/repositories.ts` with **no implementation** — the client-notification feature is half-landed. `src/domain/client.ts` is dead weight today | `repositories.ts:260` comment |
| `consecutiveEscalations` is per-process | A fast-tier storm in progress needs ~20 fresh checks to be re-detected after a restart | `TieredDetector` |
| Pairing throttle counters are in-memory | A restart clears the brute-force window | `OwnerAuthorizer` |
| Business chats support only `/unban`, `/ban`, `/check` | `/status` and `/clear` in a client chat are explicitly flagged as follow-up work | `router.ts:505` |