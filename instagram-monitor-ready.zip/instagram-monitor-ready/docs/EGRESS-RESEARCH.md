# Instagram Recovery Monitor — Latency, Egress, and What to Actually Buy

> **Harness note before anything else:** the cost hook fired during my own verification pass — **session cost $5,969.28, 200 files flagged modified**. Upstream agents reported the same alert climbing from $1,185 → $5,953 across two calls. Review that before running this workflow again. It is unrelated to the findings below but you should see it.

---

## 1. The honest answer on "millisecond responses"

You already have millisecond responses and they are not the problem. Your fast HTTP probe measures **423 ms on the home route** — that is within about 2× of the physical floor for an HTTPS GET to Instagram (1 RTT + TLS + their server time). No proxy on earth sells you a meaningfully faster number, and upgrading from 1,288 ms to 400 ms would shave **0.9 seconds off a budget currently measured at 87 seconds**. The purchase you are contemplating buys noise.

Where the time actually goes: **you are not waiting on the network, you are waiting on your own polling clock.** A recovery happens, and on average it sits undetected for **33.8 seconds** because the next scheduled check is 60 + 0–15 s away. Then confirmation, browser escalation, and a blocking screenshot add another ~50 s. Detection latency is governed by one equation — `interval ÷ 2` — and interval is governed by how many Instagram requests per hour you can safely make, divided across how many accounts you watch. **Speed is bought with IP *count* and with code changes, not with IP *speed*.** The realistic end-to-end floor for this architecture, fully optimised, is **3–6 seconds** (one poll gap + one probe + one confirmation + one Telegram send). That is an excellent number to sell to a client. It is not milliseconds, and anyone who tells you otherwise is selling you a proxy.

---

## 2. Where the latency actually is

Ground truth from production `.env` (verified by me directly): `BASELINE_INTERVAL_SECONDS=60`, `BASELINE_JITTER_MAX_SECONDS=15`, `MAX_BROWSER_CONCURRENCY=4`, `CHECK_TIMEOUT_MS=45000`, `PROXY_MODE=direct`, `FAST_PROBE=true`. N=20 accounts, home residential route, happy path.

| # | Component | Bound | Current (mean) | Achievable | How |
|---|---|---|---|---|---|
| A | Blind polling window — next check at `now + 60 + U(0,15)` | **CODE** | **33.8 s** | 5.0 s → 1.5 s | interval 60→10 s; more IPs |
| A2 | Scheduler tick quantization (1 s tick) | CODE | 1.5 s | 0.5 s | 1000 → 300 ms tick |
| A3 | Serial `for…await processCase()` over claimed batch | CODE | 0–40 s | 0 s | bounded `Promise.all` |
| B | Fast probe RTT × 4 | NETWORK (~40% code) | 1.7 s | 0.9 s | real keep-alive (W7) |
| C1 | Browser escalation × 3 — every confirmation escalates | NETWORK + CODE | **24.0 s** | 5.5 s | 1 escalation, kill `networkidle` |
| C2 | Confirmation gaps × 2 @ 5 s, no jitter | **CODE** | 10.0 s | 4.0 s | interval 5→2 s |
| D | **Screenshot capture — blocks the alert** | NETWORK paint + CODE | **12.5 s** | 12.5 s → 0 s | async capture (trade-off) |
| E1 | DB save + outbox enqueue | CODE | 0.05 s | 0.05 s | — |
| E2 | Outbox tick pickup (1500 ms, one item/tick) | **CODE** | 0.75 s | 0.15 s | 1500 → 300 ms |
| E3 | `claimNotification` + re-read | CODE | 0.05 s | 0.05 s | — |
| E4 | Telegram `sendPhoto` → owner | NETWORK | 0.9 s | 0.9 s | irreducible |
| E5 | `markSent` + close-out | CODE | 0.05 s | 0.05 s | — |
| E6 | **Discord mirror — runs BEFORE the client send** | **CODE (ordering)** | 0.9 s | 0.0 s | move after client |
| E7 | Telegram `sendPhoto` → **CLIENT** ← the buzz | NETWORK | 0.9 s | 0.9 s | irreducible |
| | **TOTAL** | | **~87 s** | **~30 s → ~14 s** | |

**Best case today ~36 s. Worst realistic ~160 s.**

**The split is the headline: of 87 seconds, only ~1.7 s is network-irreducible** (one probe RTT + one confirmation RTT + one Telegram send). Everything else — 98% of it — is yours to fix in code and config, for free.

### Three corrections to the research you were given

I verified these against the repo. Two of the inputs you're holding are wrong on load-bearing numbers:

| Claim | Source | Verdict |
|---|---|---|
| "Configured at `BASELINE_INTERVAL_SECONDS=15`, emitting ~4,800 req/hr — your code will burn any proxy you buy" | Reality Check | **WRONG.** That is `.env.example` / the code default. Production `.env:15` is **60**. Actual rate is **~1,067 probes/hr**. The "your own code is the danger" verdict is overstated by 4.5×. |
| "Delete `networkidle` at `capture.ts:1030`, saves 5 s" | Latency Baseline | **STALE — already fixed.** `capture.ts` has no live `networkidle`; it was replaced by `probeRenderReady` polling, and the file's own header comment documents why. Only **one** remains, at `browser-manager.ts:246` (2500 ms). W1 saves 7.5–10 s, not 15 s. |
| "`dispatcherFor(null)` returns `undefined`, so the direct path gets no connection pooling" | Latency Baseline | **CONFIRMED.** `http-probe.ts:125-141` — the `POOL` constant (keepAlive 60 s, 8 connections) is applied **only inside `new ProxyAgent(...)`**. Production runs `PROXY_MODE=direct`, so every probe pays a fresh DNS + TCP + TLS handshake. Real bug, real fix. |
| "`retryDelaySeconds` clamps the ladder to `errorBackoffMaxSeconds`" | Latency Baseline | **CONFIRMED** at `scheduling.ts:89`. `ERROR_BACKOFF_MAX_SECONDS` is unset → defaults to 30 → your configured `120,300,600,900` ladder is **entirely inert**. Accidentally good today; a landmine tomorrow (see W10). |

---

## 3. The free wins, ranked by seconds saved per recovery

| # | Change | Saves | Risk | Rate-ceiling interaction |
|---|---|---|---|---|
| **W1** | Delete `await page.waitForLoadState('networkidle', {timeout: 2500})` at `src\instagram\browser\browser-manager.ts:246` | **7.5–10 s** | **Near zero** | None. Fires on every browser load; `networkidle` provably never fires on Instagram (your own 120 s measurement), so it can only ever burn its full timeout. The real settle is the `waitForSelector` two lines above. Best ratio in the system. |
| **W2** | Fast-tier confirmations 1 and 2; escalate to Chromium only on the **final** confirmation (`tiered-detector.ts:474-484`) | **10 s** (post-W1) | Low | **NEGATIVE cost — it buys budget back.** Drops 3 browser loads to 1 per suspected recovery, i.e. ~60 fewer Instagram requests per event. A full browser verdict still gates before anyone is told. |
| **W3** | `BASELINE_JITTER_MAX_SECONDS` **15 → 3** | **6.0 s** | Near zero | **Zero rate cost.** Mean interval 67.5 → 61.5 s. 15 s of de-synchronisation jitter is pointless on a 20-account fleet; `.env.example` already says 2. Free money. |
| **W4** | `CONFIRMATION_INTERVAL_SECONDS` **5 → 2** | **6.0 s** | Low | Negligible — 2 extra probes per recovery event, not per poll. |
| **W5** | Move the Discord mirror upload (`outbox\worker.ts:268-271`) to **after** the client send (`:275`) | **0.9 s** | Zero | None. The paying client currently waits behind your own Discord mirror. Pure ordering. |
| **W7** | Build a real pooled `undici.Agent({ keepAliveTimeout: 120_000, keepAliveMaxTimeout: 600_000, connections: 8, allowH2: true })` for the **direct** path in `http-probe.ts` | **0.8 s** | Low | **Strategically the most important small fix.** It collapses DNS caching, TLS session resumption and HTTP/2 into one change, and it makes a shorter poll interval *cheaper per probe*. (HTTP/3 is not available — Node has no production QUIC client.) |
| **W6** | Outbox tick `1500 → 300 ms`; drain up to K items per tick (`app.ts:56`) | 0.6 s | Low | Zero — Telegram-side only. |
| **W9** | Fix confirmation-deadline semantics: `scheduler\worker.ts:254-258` measures `now − lastCheckedAtUtc` **per gap**, not across the burst | 0 s home, **unbounded** on slow egress | Low | **Correctness, not speed.** A single browser leg through your mobile proxy measured 85–96 s vs a 30 s deadline → a genuine recovery is discarded and re-armed at a fresh 60–75 s baseline, potentially forever. Track `confirmingSinceUtc`. This is the difference between working and not on any non-home route. |
| **W10** | Pin `ERROR_BACKOFF_MAX_SECONDS=30` explicitly in `.env`, with a comment | 0 s | Zero | **Defusal.** Anyone who "fixes" the inert ladder by setting this to 900 creates a **15-minute detection hole** on every account that has ever returned UNKNOWN. Also note the current inversion: an UNKNOWN account rechecks at 30–45 s, *faster* than a healthy GONE account's 60–75 s. |
| **W8** | `BASELINE_INTERVAL_SECONDS` **60 → 20**, then → 10 | **20–25 s** | **HIGH — gated on an unmeasured number** | See §3.1. Do not jump. This is exactly how you burned an IP at ~1,270 checks/hr. |
| **W11** | *Optional:* enqueue `RECOVERY_TEXT` on the `confirmed` edge, capture asynchronously | **12.5 s, always** | Medium | Costs: (a) client gets two messages; (b) you lose `visiblyRendered` as a pre-send gate, which genuinely catches login walls and error pages that classify ACTIVE by identity. Also `reapMissingScreenshots()` is a 5-minute sweep, so you'd need to enqueue the follow-up directly. **Take only if two-message delivery is acceptable.** |

**Safe set (W1–W7, W9, W10, no interval change): ~32 seconds saved. 87 s → ~55 s. Zero dollars, zero additional Instagram request rate — W2 actually reduces it.**

### 3.1 The arithmetic that ties cadence, account count, and IPs together

With **N** accounts, **B** safe probes/hour/IP, and **P** egress IPs:

```
poll interval        T = 3600·N / (B·P)          seconds
mean detection         = T / 2 = 1800·N / (B·P)  seconds
IPs needed for latency L:  P = 1800·N / (B·L)
```

**Everything hinges on B, and B for the cheap tier has never been measured.** Your proven 200/hr ceiling was measured with **Chromium page loads** — 20–50 HTTP requests each. The fast probe is exactly **one** request. So:

- If Instagram limits **per navigation/document**: B ≈ 200 regardless of tier. The cheap probe buys speed and bytes but **zero cadence**.
- If it limits **per request**: B ≈ 200 × ~30 = **~6,000 probes/hour**.

That is a **30× uncertainty band on the single most important number in your system.**

One piece of circumstantial evidence: production is already sustaining **1,067 probes/hr** on the home IP and is not burning it. That is **5.3× a 200/hr ceiling**. Strong hint that B is materially above 200 for the cheap tier — but it is a side effect, not a measurement.

| B (probes/hr/IP) | P (IPs) | N | Interval T | **Mean detection** | Marginal cost |
|---|---|---|---|---|---|
| 200 (pessimistic) | 1 | 20 | 360 s | **180 s** | $0 |
| 1,067 (today, observed) | 1 | 20 | 67.5 s | **33.8 s** | $0 |
| 3,200 | 1 | 20 | 22.5 s | **11.3 s** | $0 (config only) |
| 6,000 (optimistic) | 1 | 20 | 12 s | **6 s** | $0 (config only) |
| 6,000 | 1 | 100 | 60 s | **30 s** | $0 |
| 6,000 | 4 | 100 | 15 s | **7.5 s** | ~$180–220/mo |
| 6,000 | 6 | 100 | 10 s | **5 s** | ~$300–360/mo |
| 6,000 | 12 | 20 | 1 s | **0.5 s** | ~$720/mo |

**Read the table this way:** if B turns out to be ~6,000, you get from 33.8 s to **6 s of detection latency by editing one line of `.env` and spending nothing.** Buying IPs only becomes necessary at N ≥ 100 or if you want sub-5 s. **Measure B before you spend a dollar.**

### 3.2 Can this ever be event-driven instead of polled? No.

- **No Instagram push exists** for "public profile became reachable." Graph API webhooks require a Business login on an account you own — barred by your own security constraints (no programmatic login, no credentials).
- **HEAD requests are not a cheaper tier.** Your own code (`tiered-detector.ts:470-473`) establishes that Instagram renders the unavailable copy *client-side*; the discriminator is `og:url` / `og:title` / `canonical` in the body. A status code alone cannot tell GONE from ACTIVE — and a HEAD still consumes the same request budget.
- **Third-party mirrors / oEmbed / search caches** shift load off your IP but are stale by hours to days. Viable only as a free coarse tier layered *underneath* polling, never as the primary.

**Polling is the only mechanism available. The table above is the ceiling. Your only two levers are B and P.**

---

## 4. Egress options ranked

The single most important finding across seven researched providers: **`igEvidence` returned "None found" for every one of them.** Zero Instagram-specific measurements exist in either direction. **The choice of vendor matters far less than the quality of your benchmark.** You are not picking a winner from data — you are buying a lottery ticket and then testing it. Optimise the test, not the ticket.

| Option | Real monthly cost | Latency (M = measured by you, C = vendor claim) | IG viability | The specific risk |
|---|---|---|---|---|
| **Keep running direct (home residential)** | **$0/GB, $0/mo** | **M: 423 ms probe, 2–5 s paint, 3/3 LIVE** | **PROVEN GOOD** | Single point of failure: home power, ISP, and PC uptime. One IP = one rate budget = no horizontal scaling. **Also: `PROXY_MODE=direct` means egress is whatever machine runs the process — see the check in §5.** |
| **Proxy-Cheap mobile (incumbent)** | ~$7.50/GB paid; **$5.99/GB listed** — check your dashboard | **M: 1,288 ms probe, 3/3 LIVE, paint 9.9 / 85.4 / 96.4 s** | **PROVEN GOOD (tier 1) / PROVEN BAD (tier 2)** | Paint times are the worst number in your entire stack and no price change fixes them. Their "unlimited bandwidth" copy on a metered per-GB product is simply false. **Free action: you may already be entitled to the lower listed rate.** |
| **AirProxy** (Vodafone IT, dedicated SIM) | €67/mo (~$73); **€9.90 / 72 h trial, full refund within 48 h** | C: "low latencies", no number. Realistic 400–800 ms; Italy-only egress | **MEDIUM (~70–80%)** | Italy only — from an Indian VPS you pay a pointless intercontinental hop; you'd need a Milan/Frankfurt VPS too. One-man operation (bus factor on a 24/7 service). Price contested: €67 on-site vs €87 in reviews. No IP whitelisting. **But it has the cleanest refund window in the entire set.** |
| **Proxy Poland** (4 carriers) | $60/mo; **1 h free trial, no card**; $11/day | C: "<40 ms ping" — not physically credible for your path (mobile RAN alone is 30–70 ms) | **MEDIUM (~60–75%)** | Their bandwidth pages contradict each other (300 GB cap vs "no fixed cap"). Every "independent review" in search results is their own SEO content citing itself. **Marketing explicitly courts antidetect/multi-accounting** — your neighbours on those carrier ranges run IG automation, which raises the odds Meta already scrutinises them. Four-carrier failover is genuine value. |
| **IPRoyal mobile (dedicated port)** | $130/mo; **$10.11 / 24 h** | C: "~0.8 s" — plausible, matches your own 1,288 ms measurement | **MEDIUM-HIGH (~70–85%)** | 2× the price for headroom (30 GB/day) you will never use. Largest operator = lowest counterparty risk. The safest port to run a revenue-generating client-facing service on, if uptime beats $70/mo. |
| **Coronium** (marketplace) | $27–129/mo by country; free `/free-proxy` trial | C: none. Independent test: **~2.0 s avg** | **MEDIUM but NON-DURABLE (~55–75%)** | **It is a marketplace, not an operator** (54/42/4 revenue split) — your modem belongs to a third-party seller, so **a pass on one port does not predict another port, even in the same country.** Your benchmark is not reproducible on re-order, which is fatal for a service you re-provision as you scale. Refunds exclude "working but blind" — your exact failure mode, declared non-refundable. Never top up balance (non-refundable by policy). |
| **ProxyEmpire $125 tier** | $125/mo | C: none | **DISQUALIFIED** | **IP rotation limited to 4–5 times per DAY.** Your known failure mode is burning an IP mid-hour. Architecturally incompatible. |
| **Proxidize** | metered pool | C: "99.5% success" (at what?) | **DISQUALIFIED** | Pooled, no dedicated port. **You cannot own a rate budget on an IP you share** — strangers consume your 200/hr invisibly. |
| **Bright Data ISP / IPRoyal ISP / Ping-Byteful ISP** | $1.80–8/IP + $5–8/GB | C: "99.9% success on Instagram" (affiliate content, untraceable) | **PROVEN BAD** | **This is the exact category that already took your money twice.** ISP/static-residential = datacenter-hosted machines holding consumer-ISP WHOIS. Your own result on this category is **0/3 and 0/3 against live profiles**, with the silent-blindness signature. Bright Data additionally gates restricted domains on the ISP network and does not publish whether `instagram.com` is on that list. Brand reputation does not overturn your own measurement. **Do not buy any of these three.** |

**The bottom three have negative expected value once you price in a third wasted purchase and the time to discover it.**

---

## 5. The recommended plan

### TODAY — free, ~2 hours, no purchase

| Step | Action | Effect |
|---|---|---|
| **0** | **Verify where the process actually runs.** `.env` says `PROXY_MODE=direct` — meaning egress is the host's own IP. If that host is your Hostinger VPS rather than your home machine, **you are currently on a datacenter IP, which is the category you measured at 0/3 against live profiles.** Run the live-account canary right now and confirm `identitySignalMatched === true`. | Possibly critical |
| 1 | **W1** — delete `browser-manager.ts:246` | −7.5 s |
| 2 | **W3** — `BASELINE_JITTER_MAX_SECONDS=3` | −6.0 s |
| 3 | **W5** — Discord mirror after the client send | −0.9 s |
| 4 | **W7** — pooled direct `undici.Agent` with `allowH2` | −0.8 s |
| 5 | **W2** — fast-tier confirmations 1 & 2 | −10.0 s |
| 6 | **W4** — `CONFIRMATION_INTERVAL_SECONDS=2` | −6.0 s |
| 7 | **W6** — outbox tick 300 ms, drain K per tick | −0.6 s |
| 8 | **W9** — burst-scoped confirmation deadline | correctness |
| 9 | **W10** — pin `ERROR_BACKOFF_MAX_SECONDS=30` with a comment | defusal |

**Result: ~87 s → ~55 s end-to-end. Cost: $0. Instagram request rate: unchanged or lower.**

### THIS WEEK — free — measure B, the number the whole business case rests on

Run this before considering any purchase, because it decides whether you need to buy anything at all.

1. Add a **rate limiter** (token bucket, per-egress-IP, configurable) — you currently have none anywhere in `src/`. This is the safety rail that makes the experiment reversible.
2. Ramp the cheap tier only, on the home IP, holding browser loads constant: **1,067 → 1,800 → 2,400 → 3,200 → 4,800 probes/hr**, 6 hours at each step.
3. At every step, keep a **live-account canary** running and log `identitySignalMatched`. Throttling shows up as the canary going blind — *not* as an error, and *not* as banned accounts misclassifying.
4. **Stop at the first step where canary success drops below 100%.** The previous step is your B.
5. Set `BASELINE_INTERVAL_SECONDS = 3600 × 20 / (0.7 × B)` — a 30% safety margin.

**If B ≥ 3,200 you reach ~11 s mean detection and ~30 s end-to-end for free, and you should buy nothing.**

### ONLY THEN — spend, in this order

| Order | Spend | Why |
|---|---|---|
| 1 | **$0** — check your Proxy-Cheap dashboard for the listed $5.99/GB and ask support about flat-rate static mobile pricing | Possibly free money, zero migration risk |
| 2 | **€9.90** — AirProxy 72 h trial. Run the §6 protocol in hours 0–24 so the 48 h full-refund window stays open | Cleanest refund terms of any provider researched |
| 3 | **$0** — Proxy Poland 1 h free trial (no card) as a second data point | Free |
| 4 | **$60–73/mo per additional IP** — only if §3.1 shows you need P > 1 for your target latency, and only for a route that passed §6 | Buy IP *count*, per the formula, not IP *speed* |

**Total spend to know the answer: ~€10 + $0 ≈ $11.** Everything above that is contingent on measurements you do not yet have.

**Do not buy:** anything in the ISP/static-residential category (proven 0/6 on live profiles), ProxyEmpire's $125 tier (4–5 rotations/day), or any pooled/shared product (you cannot own a rate budget on a shared IP).

---

## 6. The benchmark protocol

Designed for exactly one failure mode: **a route that returns correct GONE for banned accounts while being completely blind to live ones.** That route passes every naive test, every uptime check, and your `/ping`. It is what cost you money twice.

**Your codebase already contains the correct assertion: `TieredDetector.canaryOk()` asserts `identitySignalMatched` on a known-live control account. That function is the benchmark spec.**

| Step | Requirement | Reject if |
|---|---|---|
| **1. Control set** | **3+ accounts verified LIVE from your home IP within the same hour.** Never banned accounts. Re-verify at the end of the run too. | Any control account's status changed mid-run → discard and redo |
| **2. The assertion** | **`identitySignalMatched === true`** — `og:url` / `og:title` / `canonical` carrying the username. **Not HTTP 200. Not the absence of "page isn't available" copy.** Both of those pass on a blind proxy. | **Any** live account returns 200 without the identity signal → **reject immediately** |
| **3. Both tiers** | Test the HTTP probe **and** a full Chromium load. Record probe RTT and **paint time to `header+username+counters`** separately. | Paint p50 > 15 s → reject for the screenshot path even if tier 1 is perfect. *This is your incumbent's exact profile: 3/3 probes, 96 s paint.* |
| **4. Sustained load** | **≥ 1 hour at your intended sustained rate**, not a 3-request spot check. Bucket results per 10 minutes. | **Any 10-minute bucket below 100% live success** → reject. Degradation-under-load is the untested failure mode a 3-shot test is structurally incapable of seeing. |
| **5. Simultaneous control** | Run the identical script from your home IP in parallel throughout. | Home also degrades → it's an Instagram-side change, not the proxy. Do not misattribute. |
| **6. Latency bar** | Median probe RTT | > 1.5× your incumbent's 1,288 ms → reject |
| **7. Refund window** | Know the exact window **before** paying, and finish inside it | — |

### Refund traps that specifically defeat step 4

| Provider | Trap |
|---|---|
| **Coronium** | Refunds only if "the proxy is not working and we cannot replace it." **Working-but-blind — your exact failure mode — is explicitly non-refundable.** Balance top-ups are never refundable. Use only the free `/free-proxy` trial. |
| **IPRoyal ISP** | Refund requires < 24 h **and < 500 MB traffic**. A proper sustained-load benchmark exceeds 500 MB. **Testing properly voids the refund.** |
| **Proxidize** | Money-back void above 10 GB — same trap shape. |
| **Bright Data** | 7-day trial requires company registration and a corporate email domain; Gmail is not eligible. A Gmail-based owner likely gets no refundable window at all. |
| **AirProxy** | €9.90 / 72 h, full refund within 48 h of payment. **The only clean trial in the set.** |

### Bottom line

**Change the code and buy nothing this month.** ~32 seconds of latency, roughly 37% of your entire budget, is available today for free with near-zero risk. Another 20–25 seconds is available for free the moment you measure your cheap-tier rate ceiling — a measurement that costs a week of patience and nothing else. Only after both of those is proxy spend a rational purchase, and at that point you will be buying **IP count against a formula**, not vendor marketing. Every performance claim from every provider researched is unverified vendor copy; the only Instagram evidence that exists anywhere in this file is the evidence you generated yourself.

**Files referenced:** `C:\Users\fazea\monitor bot\.env` · `C:\Users\fazea\monitor bot\src\instagram\browser\browser-manager.ts` · `C:\Users\fazea\monitor bot\src\instagram\detector\http-probe.ts` · `C:\Users\fazea\monitor bot\src\instagram\detector\tiered-detector.ts` · `C:\Users\fazea\monitor bot\src\instagram\screenshot\capture.ts` · `C:\Users\fazea\monitor bot\src\monitoring\scheduling.ts` · `C:\Users\fazea\monitor bot\src\monitoring\scheduler\worker.ts` · `C:\Users\fazea\monitor bot\src\notifications\outbox\worker.ts` · `C:\Users\fazea\monitor bot\src\app\app.ts` · `C:\Users\fazea\monitor bot\bench-egress.ts`