# Deployment Guide

The monitoring service must run **continuously in the cloud** — a phone app or browser tab cannot
poll Instagram in the background. Your phone is the control surface (GitHub, the host's secret
manager, and Telegram); the bot runs on a host with a persistent Node process, Postgres, Chromium
(or a remote browser), and HTTPS webhooks.

Everything below is doable from a phone browser.

## 0. Secrets — never paste a token into chat, code, commits, or logs

Set real values **only** in the host's encrypted environment/secret manager:

| Variable                  | Required     | Notes                                                                     |
| ------------------------- | ------------ | ------------------------------------------------------------------------- |
| `TELEGRAM_BOT_TOKEN`      | yes          | From BotFather. If it ever leaks, revoke it in BotFather and replace it.  |
| `TELEGRAM_WEBHOOK_SECRET` | webhook mode | Long random string; sent + verified as the webhook secret header.         |
| `OWNER_PAIRING_SECRET`    | yes          | Long random string; used once to pair your Telegram id.                   |
| `CONTROL_USERNAME`        | yes          | `instagram` (known-good account for `/ping` + health).                    |
| `DATABASE_URL`            | postgres     | Managed Postgres connection string.                                       |
| `DB_DRIVER`               | yes          | `postgres` in production.                                                 |
| `TELEGRAM_MODE`           | yes          | `webhook` in production.                                                  |
| `PUBLIC_BASE_URL`         | webhook mode | Public HTTPS URL of the service, e.g. `https://your-app.example.com`.     |
| `BROWSER_WS_ENDPOINT`     | optional     | Set only if running against a remote Chromium instead of the bundled one. |

Generate strong secrets (on any machine): `openssl rand -hex 32`.

## 1. Option A — Railway or Render (simplest)

1. Push the branch and connect the repo in the host dashboard.
2. Add a **Postgres** database plugin/instance; it provides `DATABASE_URL`.
3. Set the environment variables from the table above (`DB_DRIVER=postgres`, `TELEGRAM_MODE=webhook`,
   `PUBLIC_BASE_URL=<the service URL>`).
4. The included `Dockerfile` builds automatically (Playwright base image ships Chromium + deps).
5. First boot runs migrations automatically; or run the migrate job manually:
   `npm run migrate`.
6. The service exposes `GET /healthz` for the platform health check (already wired in the Dockerfile).

## 2. Option B — Fly.io

1. `fly launch` (uses the `Dockerfile`), then `fly postgres create` and `fly postgres attach`
   (sets `DATABASE_URL`).
2. `fly secrets set TELEGRAM_BOT_TOKEN=... TELEGRAM_WEBHOOK_SECRET=... OWNER_PAIRING_SECRET=... CONTROL_USERNAME=instagram TELEGRAM_MODE=webhook PUBLIC_BASE_URL=https://<app>.fly.dev DB_DRIVER=postgres`.
3. `fly deploy`.

## 3. Option C — Remote browser (any lightweight host)

If the host cannot run Chromium (or you want better IP reputation), run a hosted Chromium
(e.g. Browserless) and set `BROWSER_WS_ENDPOINT=wss://...`. The app connects Playwright to it instead
of launching a local browser. Everything else is identical. A slimmer `node:22-slim` base image works
in this mode (documented in the `Dockerfile` header).

## 4. Register the webhook & pair (one time)

On first start in webhook mode the app calls Telegram `setWebhook` with `PUBLIC_BASE_URL` + the
secret and registers the four visible commands. Then, from your phone:

1. Open your bot in Telegram, send `/start <OWNER_PAIRING_SECRET>`. Your numeric id is stored as the
   owner and the pairing secret is consumed. All other users are rejected thereafter.
2. Send `/ping` — it launches/uses the real detector against `@instagram`, captures a screenshot,
   round-trips the database, checks the scheduler, and reports timing. Any failing component is named.

## 5. Verify

- `/unban <a username you're authorized to monitor>` → immediate first check + "Monitoring Started".
- `/list` → shows it under Monitoring.
- `/clear <username>` → removes it; a later browser result cannot notify.
- Restart the service → `/list` still shows active cases; no duplicate alerts fire.

## 6. Operations

- Logs are structured JSON with secrets redacted.
- Health warnings (`⚠️ MONITORING WARNING`) fire if checks go broadly `UNKNOWN` **and** the control
  account also fails; `✅ MONITORING RESTORED` follows recovery. These are rate-limited.
- Scaling: keep **one** worker instance. The design tolerates duplicate scheduler runs via database
  job leases, but a single instance is the simplest correct deployment.
