# PC primary / VPS standby failover

## Status

**INSTALLED AND LIVE since 2026-08-03.** The `InstagramUnbanMonitor` task now runs
`deploy/run-primary-guarded.ps1` (pre-HA task XML preserved at
`data/ha/InstagramUnbanMonitor.pre-ha.xml`), the `InstagramUnbanMonitorHASync` task heartbeats
every 60 s, and `monitor-ha-watchdog.timer` is enabled on the VPS. A live drill passed in both
directions: dead-bot takeover in 5 m 23 s (role published only after the service was active), then
a verified takeback, with zero notification rows minted throughout. Drills not yet run: torn
transfer, dead scheduler, channel partition, and per-phase crash injection — the partition drill
in particular must use a staging bot token.

Both Windows tasks run under the interactive logon token, so their actions MUST launch through
`wscript.exe //B deploy\run-hidden.vbs <script.ps1> <args...>` — never `powershell.exe` directly.
A bare `powershell.exe` action pops a visible terminal window on the desktop every 60 s (heartbeat)
plus a persistent one for the supervisor, and closing that window kills the running monitor
(exit `0xC000013A`). Fixed 2026-08-06; if a task is ever re-registered, keep the wscript wrapper.

Deviation from the original plan: the VPS keeps its pre-existing root-run `monitor-bot.service`
rather than the `monitorbot`-user unit in `deploy/systemd/`, because `/opt/monitor-bot` is
root-owned and the running service was already proven. The watchdog only ever calls
`systemctl start/stop` on it, which works with either unit.

This mechanism is for the current SQLite deployment. Do not use the snapshot or handback scripts
with `DB_DRIVER=postgres`.

## What the mechanism guarantees

The Windows PC is normally `ACTIVE`; the VPS is normally `STANDBY` with `monitor-bot.service`
stopped. A one-cycle Windows agent runs every 60 seconds and sends:

- the bot event-loop timestamp from `scheduler_health.__ping__`;
- the monitor worker's own `lastSchedulerRunUtc` timestamp;
- the PC role and a monotonically increasing `(agentBootId, seq)` pair; and
- every five cycles, a compressed SQLite online backup with its byte length and SHA-256 manifest.

The agent copies the two liveness timestamps verbatim. It cannot replace either with its own
current time. Therefore a healthy helper beside a dead bot keeps sending frozen values, which the
VPS detects. SQLite is never copied wholesale while it is live: `ha-snapshot.mjs` uses SQLite's
online backup API, includes committed WAL pages, runs `PRAGMA integrity_check`, then publishes the
manifest last.

The VPS watchdog runs once a minute under `flock`, verifies incoming snapshots before moving its
`latest.json` pointer, and applies these defaults:

| Observation                                                                              | Decision                                                             |
| ---------------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| Heartbeat channel no more than 3 minutes old; bot event-loop value frozen over 5 minutes | Take over                                                            |
| Heartbeat channel no more than 3 minutes old; scheduler value frozen over 12 minutes     | Take over                                                            |
| Heartbeat channel between 3 and 12 minutes old                                           | Hold; the channel is uncertain                                       |
| Heartbeat channel over 12 minutes old                                                    | Take over                                                            |
| PC explicitly sends `STANDDOWN` over a fresh channel                                     | Take over immediately                                                |
| VPS already owns `ACTIVE`, but its service is down                                       | Restart it on the VPS database; never reinstall an older PC snapshot |
| A takeback lock is younger than 10 minutes                                               | Hold while the handback transaction finishes                         |

The service is started and verified **before** the VPS publishes `ACTIVE`. A failed service start
therefore cannot make the PC stand down for a dead fallback. Conversely, a VPS service found
running without an `ACTIVE` role is fenced.

With a five-minute snapshot cadence, the normal database recovery-point objective is approximately
five minutes plus upload time. Expected detection is roughly 5–6 minutes for a dead process and
12–13 minutes for a dead link or wedged scheduler, because the watchdog samples once a minute.
These are bounds to validate in the drill, not availability promises.

### Honest split-brain limit

Two machines and no independent witness cannot distinguish “PC is dead” from “the network path
between PC and VPS is dead.” After a 12-minute one-way partition, the availability-biased policy
lets the VPS take over even if the PC might still be running. When connectivity returns, the PC
sync agent sees VPS `ACTIVE`, writes local `STANDBY`, and stops the PC task. This bounds but cannot
mathematically eliminate overlap.

Do not shorten the 12-minute channel guard casually. To guarantee single ownership through every
partition, add a third-party lease/witness or accept stopping the PC whenever it cannot reach the
VPS, which creates a monitoring blackout during ordinary link failures. For this bot, missed client
notifications are ranked worse than bounded duplicate risk, so the mechanism chooses availability.

## Files

| File                             | Purpose                                                           |
| -------------------------------- | ----------------------------------------------------------------- |
| `deploy/ha-decide.mjs`           | Pure, tested takeover decision                                    |
| `deploy/ha-snapshot.mjs`         | Inspect, online-backup, hash, integrity-check, and restore SQLite |
| `deploy/sync-to-vps.ps1`         | One Windows heartbeat/snapshot upload cycle                       |
| `deploy/pc-admission.ps1`        | Refuse PC startup when it is fenced or VPS is `ACTIVE`            |
| `deploy/run-primary-guarded.ps1` | HA-aware action for the existing monitor scheduled task           |
| `deploy/vps-watchdog.mjs`        | Verify/promote snapshots, decide, fence, and execute VPS takeover |
| `deploy/vps-watchdog.sh`         | Non-overlapping `flock` wrapper                                   |
| `deploy/takeback-to-pc.ps1`      | Locked, verified VPS-to-PC handback with rollback                 |
| `deploy/systemd/*`               | Stopped bot service plus watchdog service/timer                   |

Runtime state lives under `data/ha/`, which is already excluded by the repository's `data/` ignore
rule. Snapshot archives do not contain `.env`, proxy credentials, Telegram tokens, or the optional
Instagram storage-state file; provision those separately and securely on the VPS.

## Installation checklist — do not run blind

Use a maintenance window. Replace every value in angle brackets first, and preserve a copy of the
current scheduled-task definition and both databases before changing anything.

### 1. Preflight both hosts

- Confirm the PC is healthy with `/ping`, `/list`, local `GET /healthz`, and a recent scheduler
  timestamp.
- Confirm the VPS egress can actually classify a known live Instagram profile. Earlier production
  measurements showed datacenter/direct VPS egress can be blocked; failover to a host that cannot
  see Instagram is not availability.
- Confirm both hosts run Node 20+, the same commit, the same `.env` semantics, and compatible
  `better-sqlite3`/Playwright installations.
- Confirm the VPS has exactly one copy of the bot token and is configured for the same Telegram
  mode. Keep `monitor-bot.service` stopped during staging.
- If `IG_STORAGE_STATE` is used, transfer it only through a secret channel and keep it mode `0600`.
  It is the owner's login session. The application never creates or refreshes it programmatically.
- Establish and verify the PC user's SSH host key entry before scheduling anything. Both PC scripts
  use `BatchMode=yes` and `StrictHostKeyChecking=yes`; they will not accept a new key interactively.

### 2. Stage the VPS without enabling it

Create a dedicated `monitorbot` account, place the project at `/opt/instagram-monitor`, install
dependencies and Chromium, and make the application/data tree writable only where the service
needs it. At minimum, these directories must exist:

```text
/opt/instagram-monitor/data/ha/incoming
/opt/instagram-monitor/data/ha/snapshots
/opt/instagram-monitor/data/ha/rollback
```

The SSH account used by the PC must be able to create and atomically rename files in `data/ha`.
The watchdog unit runs as root because it fences the service and assigns snapshot ownership; the
bot service runs as `monitorbot`.

Install the three unit files from `deploy/systemd/`, reload systemd, but enable only
`monitor-ha-watchdog.timer` after all staging checks pass. Never enable `monitor-bot.service`; it
has no `[Install]` section intentionally and is started only after a takeover decision.

For deliberate takeback, grant the SSH account narrowly scoped passwordless sudo for only:

```text
/usr/bin/systemctl start monitor-bot.service
/usr/bin/systemctl stop monitor-bot.service
```

Initialize `/opt/instagram-monitor/data/ha/role.json` to `STANDBY`. Verify
`systemctl is-active monitor-bot.service` is not `active`.

### 3. Stage the PC agent

Initialize `data\ha\role.json` to:

```json
{ "version": 1, "role": "ACTIVE", "reason": "initial-install" }
```

Run one upload manually from the project directory, substituting the real host and key path:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deploy\sync-to-vps.ps1 `
  -VpsHost <vps-host> -VpsUser monitorbot -SshKeyPath <private-key-path>
```

Before scheduling it, verify on the VPS that:

- `pc-heartbeat.json` parses and carries non-null `procUtc` and `schedUtc`;
- `latest.json` points to a database and manifest that both exist;
- `node deploy/ha-snapshot.mjs inspect --db <latest-database>` succeeds;
- a manual watchdog cycle decides `STAND_BY`; and
- `monitor-bot.service` remains stopped.

Create a separate Windows scheduled task for `sync-to-vps.ps1` at startup and every 60 seconds,
with overlap disabled. Its action must include the same host, user, and key arguments used above.
The script also has a named mutex, so an accidental overlapping invocation exits harmlessly.

### 4. Add PC startup fencing last

Export the existing `InstagramUnbanMonitor` task XML for rollback. Only then change its action from
`run-monitor.ps1` to `deploy\run-primary-guarded.ps1` with the same VPS arguments. Keep its existing
logon/startup trigger and single-instance policy.

The wrapper calls `pc-admission.ps1` before starting the existing supervisor:

- local `STANDBY` always stays fenced, even when SSH is unavailable;
- remote `ACTIVE` changes local role to `STANDBY` and refuses startup; and
- local `ACTIVE` retains ownership when the remote role cannot be reached, matching the documented
  availability-biased partition policy.

Start the guarded PC task and verify one bot process, a new scheduler timestamp, and continuing
heartbeats. Only after that should the VPS watchdog timer be enabled.

## Verification plan

### Offline checks (safe on the working copy)

```powershell
npm.cmd run typecheck
npx.cmd vitest run test/unit/ha-decide.test.ts test/unit/ha-snapshot.test.ts test/unit/ha-watchdog.test.ts
node deploy/ha-snapshot.mjs inspect --db data/monitor.sqlite
```

The tests execute the production decision CLI, prove a helper restart/replay cannot fake bot life,
prove the 3–12 minute uncertainty band, back up committed pages that exist only in WAL, reject a
corrupted archive, and prove delayed snapshots cannot move `latest.json` backwards.

Parse all PowerShell deployment scripts before use:

```powershell
Get-ChildItem deploy\*.ps1 | ForEach-Object {
  $errors = $null
  [System.Management.Automation.Language.Parser]::ParseFile($_.FullName, [ref]$null, [ref]$errors) | Out-Null
  if ($errors.Count) { $errors }
}
```

### Live drill order

Use a staging bot token and disposable database for the partition test. It deliberately creates a
period where both hosts may believe they are active and must not be pointed at client chats.

1. **Passive cycle:** PC healthy, run several sync/watchdog cycles, confirm every VPS decision is
   `STAND_BY`, service stopped, and snapshot sequence monotonic.
2. **Torn transfer:** interrupt SCP after the archive but before the manifest. The watchdog must
   ignore the partial and preserve its previous `latest.json`.
3. **Dead bot, live PC agent:** stop only the PC monitor task, keep the sync task running. Confirm
   frozen bot liveness and takeover after the 5-minute process threshold. Confirm the VPS does not
   publish `ACTIVE` until its service is actually active.
4. **Takeback:** run `takeback-to-pc.ps1` below. Confirm VPS stops first, the restored PC database
   passes integrity, PC `/healthz` and scheduler both advance, a fresh PC snapshot returns to the
   VPS, the lock disappears last, and only PC remains active.
5. **Dead scheduler:** in staging, freeze scheduling while leaving `/healthz` responsive. Confirm no
   process takeover at 5 minutes and a scheduler takeover only after 12 minutes.
6. **Channel partition:** in staging only, block PC-to-VPS SSH while leaving the PC bot healthy.
   Confirm HOLD between minutes 3 and 12, then the documented availability takeover. Restore the
   link and confirm the PC task is fenced promptly.
7. **Crash each handback phase:** before remote stop, after remote stop, after local DB swap, and
   after PC start. Each failure must either leave the original host active or execute the scripted
   rollback; neither database may fail `PRAGMA integrity_check`.

During every drill, inspect Telegram/Discord outbox rows and delivery logs for duplicate or missing
notification IDs. “Both processes were running” is not sufficient verification of client safety.

## Deliberate takeback

Run only after the VPS is confirmed `ACTIVE` and the PC is ready:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deploy\takeback-to-pc.ps1 `
  -VpsHost <vps-host> -VpsUser monitorbot -SshKeyPath <private-key-path>
```

The script creates a remote handover lock, stops the VPS service, snapshots its stopped database,
verifies and stages it on the PC, stops the PC task, archives the old PC DB/WAL/SHM, swaps the
verified database, changes roles, and starts the PC. It does not declare success until local
`/healthz` works, the scheduler timestamp advances, and a post-takeback PC snapshot is committed
back to the VPS. The old PC database remains under `data\ha\rollback`; the stopped VPS database and
takeback archive remain available as another rollback point.

If any phase fails, the script fences the PC, restores its old DB set when it had been moved, and
tries to restart/reassert the VPS. Treat any reported `rollback errors` as an incident requiring
manual inspection before starting either host.

## Disable and roll back the HA installation

This is the escape hatch if the mechanism itself misbehaves:

1. Confirm which host has the newest valid database; do not guess from role files alone.
2. Stop and disable `monitor-ha-watchdog.timer` on the VPS, then stop `monitor-bot.service` unless
   the VPS is the host being preserved.
3. If the VPS owns the newest data, use the deliberate takeback above before disabling it.
4. Restore the exported original `InstagramUnbanMonitor` scheduled-task XML so its action again
   points directly to `run-monitor.ps1`.
5. Set local PC role `ACTIVE`, start the PC task, and require both `/healthz` and a new scheduler
   timestamp.
6. Disable the Windows HA sync task. Retain `data\ha\rollback` and the VPS snapshot tail until the
   bot has completed at least one normal monitoring cycle and database integrity is rechecked.

Removing unit files or snapshot history is cleanup, not rollback; defer it until the recovered host
has been stable and backups have been retained according to the operator's policy.
