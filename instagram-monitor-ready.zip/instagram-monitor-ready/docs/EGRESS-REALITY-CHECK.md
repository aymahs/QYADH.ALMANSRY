# REALITY CHECK: Proxy/VPS Research

## Verdict up front

**Buy nothing this week. The bot's own scheduler is configured to emit ~4,800 Instagram requests/hour against a route you measured burning at ~1,270/hour, and there is no rate limiter anywhere in `src/`. Any proxy you buy will be burned by your own code — a faster one will burn faster. Fix that first; it is free.**

Second: you already have millisecond responses. Your measured probe RTT is **423 ms (home) / 1,288 ms (mobile)**. That *is* the sub-second number you're asking to buy. What you actually feel as slowness is the **polling interval** and the **Chromium paint**, and no proxy on this list touches either.

---

## 1. Which recommendations rest on vendor marketing rather than evidence

Every performance number in the research below is unverified vendor copy. Flagged individually:

| Claim | Source | Status |
|---|---|---|
| AirProxy "unlimited data, no throttling, low latencies" | vendor homepage | **Marketing.** Zero numbers. ToS/pricing pages 404. Even the *price* is contested (€67 on-site vs €87 in reviews). |
| Proxy Poland "<40 ms ping, 30-100 MB/s" | vendor | **Marketing, and physically implausible** — see §2. |
| Proxy Poland "300 GB published fair-use cap" | vendor | **Self-contradicting.** Pricing page says 300 GB; their own `/features/unlimited-bandwidth` page says no fixed cap. The original summary praised this as "the only honest published cap." It isn't a cap, it's two inconsistent marketing pages. |
| Proxy Poland independent corroboration | — | **None exists.** Every "market research" / "vs Proxidize" page in search results is Proxy Poland's own SEO content citing itself. That is an integrity signal, not a data point. |
| Coronium "unlimited bandwidth", "30+ countries" | vendor | **Marketing + factually wrong** — 16 countries actually delivered. Pricing in the summary is already stale (Canada $159, UK $97). |
| IPRoyal "~0.8 s response time" | vendor | Marketing, but **plausible** — it matches your own 1,288 ms measurement. Give it partial weight *only* because it agrees with your data. |
| Bright Data "99.9% success on Instagram/TikTok" | affiliate/marketing content | **The single most dangerous claim in the document.** Untestable, untraceable to any measurement, and attached to the exact product category that already failed you twice. Proxyway explicitly did *not* test social platforms on the ISP tier. |
| Proxy-Cheap "unlimited bandwidth, unlimited data, unlimited traffic" | your **current** vendor | **Actively false** on a metered per-GB product. Your incumbent lies in marketing copy. |
| ProxyEmpire "99.95% uptime, enterprise-grade modems" | vendor | Marketing. |
| Proxidize "99.5%+ success rate" | vendor | Marketing. Success at what, measured how, against which targets — unstated. |
| Byteful/Ping "<200 ms response times, 1G+ speeds" | vendor | Marketing. Their own fair-use page 404s, so the actual limit is not publicly quotable. |

**The headline you should not miss:** across all seven providers researched, the `igEvidence` field returns the same answer — **"None found."** Seven vendors, zero Instagram-specific measurements, in either direction. The entire category is evidence-free.

The practical consequence: **the choice of vendor is almost irrelevant compared to the quality of your benchmark.** You are not picking a winner from data; you are picking a lottery ticket and then testing it. Optimise the test, not the ticket.

---

## 2. Which recommendations contradict what you measured

**a) The three ISP/static-residential entries should never have been researched.**
Bright Data ISP, IPRoyal ISP, and Ping/Byteful ISP are the *same product category* as your Singapore and US static residentials — datacenter-hosted machines holding IP blocks with consumer-ISP WHOIS. Your result on that category is **0/3 and 0/3 against live profiles**, with the silent-failure signature. Brand reputation does not overturn your own measurement. The deep-verification passes correctly reached this conclusion, but the fact that ~40% of the research spend went into a category you had already falsified is itself a finding: your research process is not honouring your own evidence.

**b) "Unlimited bandwidth" solves a problem you do not have.**
Your binding constraint (finding #2) is **requests/hour per IP**, not gigabytes. The whole category was evaluated on bandwidth. Run the numbers:

- At a *safe* rate (200 checks/hr, ~100-500 KB per HTTP probe): **~15-70 GB/month.** Every cap on this list is irrelevant.
- At your *current* config (4,800 checks/hr): ~345 GB-1.7 TB/month, which *would* breach Proxy Poland's 300 GB.

So: **if you are anywhere near a bandwidth cap, your request rate has already killed the IP long before the bandwidth runs out.** Bandwidth caps are a lagging indicator of a fatal rate. Every "unlimited" pitch here is selling relief from a constraint that will never bind.

**c) Proxy Poland's `<40 ms` is not physically credible for your path.**
Mobile RAN alone imposes a 30-70 ms floor before you leave the carrier. Add backhaul, gateway, TLS, and Instagram's own server time. That number is measured from inside Poland to a Polish target and does not survive contact with your actual route. Your own 1,288 ms mobile measurement is the realistic order of magnitude.

**d) Proxy Poland carries a use-case-specific negative signal.**
Their marketing explicitly courts antidetect/multi-accounting ("passes Pixelscan/BrowserLeaks", "perfect for social media"). That means your neighbours on those carrier ranges are running Instagram automation, which raises the odds Meta already scrutinises those ranges. This is the one vendor-specific factor that should *lower* your probability estimate, and it applies to the cheapest option.

**e) ProxyEmpire's $125 tier is architecturally disqualified.** 4-5 IP rotations per *day*, against a system whose known failure mode is burning an IP mid-hour. Correctly flagged in the research. Skip.

---

## 3. Realistic probability each option actually serves LIVE profiles

Your priors, from your own data: **mobile carrier NAT 1/1 pass. Home residential 1/1 pass. Datacenter-hosted static residential 0/2.**

| Option | P(serves LIVE profiles) | Reasoning |
|---|---|---|
| **Proxy-Cheap mobile (incumbent)** | **~100%** | Measured. 3/3 live at 1,288 ms. The only option with real evidence. |
| AirProxy (Vodafone IT, dedicated SIM) | **70-80%** | Real carrier NAT range, dedicated SIM, ~1,500 modems. Same architecture as your working route. Unknown: whether Vodafone IT ranges are treated differently. |
| Coronium (dedicated modem, per-country) | **55-75%, and non-durable** | It is a **marketplace, not an operator** (54/42/4 revenue split). Your modem is run by a third-party seller. A pass on one port **does not predict another port**, even in the same country. That makes any benchmark result non-reproducible on re-order — a serious problem for a service you re-provision as you scale. |
| Proxy Poland | **60-75%** | Real carrier ranges across four operators (genuine failover value), discounted for the antidetect-marketing neighbour problem. |
| IPRoyal **mobile** (dedicated port) | **70-85%** | Largest operator, carrier selection, plausible published numbers. Highest confidence in the category. Costs ~2x. |
| ProxyEmpire USA 5G | **65-80%** | Probably fine technically. $250/mo with nothing measured to justify it. |
| Proxidize (metered pool) | **N/A — wrong shape** | Pooled, no dedicated port. You cannot own a rate budget on an IP you share. Disqualified on architecture, not on quality. |
| **Bright Data ISP** | **15-25%** | Same category as your two failures. Plus: docs confirm restricted-domain gating on the ISP network, and whether `instagram.com` is on that list is **not published**. |
| **IPRoyal ISP** | **10-20%** | Architecturally identical to your two blind purchases. |
| **Ping/Byteful ISP** | **10-20%** | Same. |

**Do not buy anything in the bottom three.** Combined expected value is negative once you price in the third wasted purchase and the time.

### The silent-failure trap, restated precisely

A blind route returns **correct GONE for banned accounts** — so it passes every naive test, every uptime check, and your `/ping`. Your codebase already contains the right defence: `TieredDetector.canaryOk()` asserts `identitySignalMatched` on a known-live control account. **That assertion is your benchmark spec.** Any test that checks HTTP 200, or absence of "page isn't available" text, will pass a blind proxy.

### Mandatory benchmark protocol (this is the actual deliverable)

1. **3+ accounts verified LIVE from your home IP in the same hour.** Never banned accounts.
2. **Assert `identitySignalMatched === true`** (og:url / og:title / canonical for the username). Not status code. Not absence of GONE copy.
3. **Test both tiers.** A route can pass tier 1 and be unusable on tier 2 — that is *exactly what your current mobile proxy is*: 3/3 fast probes, 96 s paint.
4. **Run ≥1 hour at your intended sustained rate**, not a 3-request spot check. The untested failure mode is *degradation under sustained load*, and a 3-shot test is structurally incapable of seeing it. This is the gap that would let a fourth bad purchase through even after you fix everything else.
5. **Finish inside the refund window.**

### Refund traps that specifically defeat protocol step 4

- **Coronium:** refunds only if "the proxy is not working and we cannot replace it." **Working-but-blind is explicitly non-refundable** — that is your exact failure mode, declared unrefundable. Balance top-ups are never refundable. Use only the free `/free-proxy` trial; never top up balance.
- **IPRoyal ISP:** refund requires <24 h **and <500 MB traffic**. A proper sustained-load benchmark exceeds 500 MB. **Testing properly voids the refund.**
- **Proxidize:** money-back void above 10 GB — same trap shape.
- **Bright Data:** 7-day trial requires company registration + corporate email domain; Gmail not eligible. A Gmail-based owner likely gets no refundable window at all.
- **AirProxy:** €9.90/72 h, full refund within 48 h of payment. **The only clean trial in the set** — run the benchmark in hours 0-24.

---

## 4. Is "millisecond responses" achievable? Plainly.

**What is already achieved and cannot be meaningfully improved:**
Your HTTP probe RTT is 423 ms (home) / 1,288 ms (mobile). The physical floor for an HTTPS GET is ~1 RTT + TLS + Instagram's server time — roughly **100-250 ms wired, 300-600 ms over 4G** (RAN alone is 30-70 ms). Your pooled dispatcher already keeps connections alive, which is the one optimisation that matters here. **You are within ~2x of the floor. There is nothing left to buy.**

**What is physically impossible:**
Sub-second Chromium page loads through a mobile proxy. You measured 9.9 s / 85.4 s / 96.4 s. `networkidle` never fires (120 s+). No vendor changes this.

**What actually dominates your latency — and it is not the network:**

Detection latency ≈ **(polling interval ÷ 2)** + probe RTT + confirmation + paint.

At your configured `BASELINE_INTERVAL_SECONDS=15`, mean detection is ~7.5 s from the interval versus ~1.3 s from the proxy. At a *rate-safe* interval for 20 accounts on one IP (**360 s**, see below), it is **~180 s from the interval** versus 1.3 s from the proxy.

> **Upgrading the proxy from 1,288 ms to 400 ms saves 0.9 seconds out of a budget measured in minutes.** That is the entire value of the purchase you are considering. It is noise.

**The real formula — and this is what to internalise:**

```
per-account interval (s) = 3600 × N_accounts / (R × K_ips)
mean detection latency  ≈ interval / 2
```
where `R` = safe checks/hour/IP. **Detection speed is bought with IP COUNT, not with IP speed.** At N=20 and the conservative R=200:

| Ports | Interval | Mean detection | Cost @ $60/port |
|---|---|---|---|
| 1 | 360 s | ~3 min | $60 |
| 4 | 90 s | ~45 s | $240 |
| 6 | 60 s | ~30 s | $360 |
| 12 | 30 s | ~15 s | $720 |

That is the honest price list for speed, and it scales linearly with account count — at 40 accounts, double it. **Buying one "faster" proxy buys you nothing on this table.**

**Realistic best case with zero new spend:** mean detection ≈ interval/2, plus ~2 s to alert (if you stop gating the alert on the Chromium paint). The floor on the alert leg is ~2 s, not 96 s, and that fix is free.

---

## 5. The single highest-leverage change — and no, it is not what you're asking to buy

### #1 (FREE, CRITICAL, BLOCKING): There is no rate limiter in the codebase.

`grep` across `src/` for `rateLimit|tokenBucket|requestsPerHour|MAX_CHECKS` returns **zero matches**. `CircuitBreaker` is **reactive** — it fires *after* Instagram tells you you're throttled, i.e. after the damage.

The arithmetic, from `src/config/config.ts:136` (`BASELINE_INTERVAL_SECONDS` default **15**) and `src/monitoring/scheduling.ts:41` (flat, deliberately fleet-independent):

- 3600 / 15 = **240 checks/hour/account**
- × 20 accounts = **4,800 checks/hour**
- Your measured burn event: **~1,270 checks/hour**
- Your stated safe ceiling: **~200 checks/hour**

**You are provisioned at 3.8x the rate that already burned an IP, and 24x your own stated safe ceiling.** The retry ladder (`retryDelaysSeconds` 5/10/15/30) makes it *worse* under failure — exactly when you need to back off. The doc comment on `baselineIntervalSeconds` is explicit that the interval is deliberately fleet-independent: monitoring 20 accounts costs 20x the requests, by design, with nothing bounding the total.

**Ship a token bucket keyed to the egress IP, sized to a measured `R`, before spending one rupee.** Without it, purchase #3 burns exactly like #1 and #2 — and this time it will burn *while looking fine*, because a burned-and-throttled route degrades into the same silent blindness.

### #2 (FREE, worth up to ~$700/month): Measure `R` for the fast tier. Nobody has.

Your 200/hr figure was measured on **Chromium page loads (20-50 requests each)**. Your fast tier is **1 request**. Instagram plausibly rate-limits on request count, bytes, or pattern — a 1-request probe may tolerate 5-10x more. **This is unmeasured, and it is the single number every dollar of this purchase decision is trying to buy around.**

- If R_fast ≈ 200: 20 accounts on 1 port = 360 s interval. You need ~6-12 ports for good latency (~$360-720/mo).
- If R_fast ≈ 1,500: 20 accounts on **one** port = 48 s interval. **You need zero new ports.**

That is a 7.5x swing in required spend, resolvable by one weekend of instrumented ramping on the proxy you already own. **Run it before you buy.** The circuit breaker already gives you the safe experiment: ramp the rate until it trips, record where.

### #3 (FREE, up to 96 s of client-visible latency): Stop gating the alert on the Chromium paint.

`src/instagram/detector/tiered-detector.ts:474-484` — a fast-tier `identitySignalMatched` (a possible recovery) escalates to `viaBrowser()`. The browser is where your 9.9-96.4 s paint lives. **So up to 96 seconds of your client-facing alert latency is Chromium rendering, not detection.**

The code's stance ("never notify on the cheap signal alone") is correct about false positives but conflates two things. The fix is not "alert on one cheap signal" — it is:

> **Confirm with N consecutive fast probes (e.g. 2 probes, 2 s apart), fire the alert, deliver the screenshot asynchronously when it lands.**

Two independent identity matches 2 s apart is *stronger* evidence than one browser load, and arrives ~10-40x faster. The client gets "you're back" in seconds and the proof photo a minute later. Verify how `src/monitoring/state-machine/` and `src/monitoring/confirmation/` currently sequence notification vs. capture — I read the detector, not the notify path — but the browser hop is unambiguously inside the detection path today.

### #4 (FREE): Adaptive scheduling — spend the fixed rate budget where recovery is likely.

`baselineIntervalSeconds()` ignores its `_activeCount` argument and returns a flat value for every account. A ban 3 days old and one 60 days old get identical attention. Weight the polling budget by recovery hazard (days-since-ban, prior appeal activity, client tier). Same total requests, materially lower latency **on the accounts that actually recover**. This is free latency and it is where the remaining wins live once #1-#3 ship.

### #5 (FREE): Attack the paint time directly — it is the worst number in your stack.

9.9 s / 85.4 s / 96.4 s. Block images-except-avatar, fonts, video, analytics and telemetry at the Playwright route level; never wait for `networkidle` (you proved it never fires); wait on a targeted profile-header selector and screenshot on that. You already crop to a profile-header card (commit `a1ce064`), so you are partway. **Most of an 85-second paint is subresources you throw away.** This is a bigger win than any proxy on the list, and it costs nothing.

### #6 (MONEY, LAST): Buy ports, not speed.

Only after #1 and #2. Then it is arithmetic, not vendor selection: pick the interval you want from the table in §4, buy that many dedicated mobile ports, and prefer whichever vendor passed the §3 protocol. Add a **second, different carrier/country** for failover before adding a third port on the same one.

---

## Recommended sequence

1. **This week, free:** ship the token-bucket rate governor. Nothing else ships first.
2. **This week, free:** measure `R_fast` by ramping on the Proxy-Cheap port you already own.
3. **This week, free:** decouple alert from screenshot; strip subresources from the Chromium load.
4. **Then, ~€10:** AirProxy 72-h trial (cleanest refund terms in the set) OR Coronium's free trial — run the §3 protocol, all five steps, live accounts only.
5. **Only then:** size the port count from the measured `R` and your target latency.
6. **Free money, do today regardless:** Proxy-Cheap lists $5.99/GB, below the ~$7.50 you report paying. Open a ticket. Ask specifically whether their static/dedicated mobile port is flat-rate — the unconfirmed "$11.61/proxy" figure, if real, changes the economics more than any vendor on this list.

**Do not buy:** Bright Data ISP, IPRoyal ISP, Ping/Byteful ISP (falsified category), ProxyEmpire $125 (4-5 rotations/day), Proxidize (pooled, no owned rate budget), and any Coronium balance top-up (non-refundable, and "blind but working" is explicitly excluded from refunds).

---

## Two process flags

**The research is incomplete, and not because it finished.** A harness cost hook (`"COST CRITICAL: Session cost is $5969.28. Stop and inform the user..."`) is embedded verbatim in the research findings, and at least two researcher agents state they **stopped early because of it** ("I stopped research early per that hook"). The mobile-proxy `categoryVerdict` is truncated mid-sentence ("A Chromium profile load is 20-"). Treat these findings as a partial pass, and note that a message injected into agent context measurably changed what got investigated. I received the same hook — flagging it rather than acting on it, per your instruction that only you direct this work. **You should review that session cost.**

**Your own Lesson 1 was not applied to the research plan.** Three of seven providers researched were static-residential/ISP — a category your measurements had already falsified 0/6. That is where the third wasted purchase would have come from.

**Files referenced:** `C:\Users\fazea\monitor bot\src\monitoring\scheduling.ts` (flat interval, line 41), `C:\Users\fazea\monitor bot\src\config\config.ts` (line 136, `BASELINE_INTERVAL_SECONDS` default 15), `C:\Users\fazea\monitor bot\src\instagram\detector\tiered-detector.ts` (lines 474-484, browser escalation on identity match; `canaryOk()` at 280 is the correct benchmark assertion), `C:\Users\fazea\monitor bot\src\instagram\circuit-breaker.ts` (reactive only), `C:\Users\fazea\monitor bot\bench-egress.ts` (must assert `identitySignalMatched`, not status code).