# Incident evidence snapshot — 17 July 2026

Captured read-only at `2026-07-17T14:12:19.277Z`, before restarting, modifying, deleting, or recreating any monitor. This file deliberately excludes credentials, owner/chat identifiers, raw Telegram payloads, and browser page contents.

## Runtime and deployment evidence

- Configured runtime: local polling, SQLite `data/monitor.sqlite`, local Chromium (no remote browser endpoint configured), control username `instagram`, display timezone `Asia/Kolkata`.
- HTTP health endpoint returned `{ "ok": true }` during evidence capture.
- The scheduler health row was actively updated with a clock near `2026-07-17T09:43Z` while host UTC was `2026-07-17T14:13Z`.
- A read-only Telegram `HEAD` check at host UTC `2026-07-17T14:17:51Z` returned the stale Date header `Fri, 17 Jul 2026 09:47:35 GMT`; the app's measured offset formula would apply `-16,216,425ms`.
- No persisted application log file exists in this workspace; the application logger writes structured redacted events to stdout.

## Monitor state snapshot

| Username          | Monitor ID                             | Started UTC                | State           | Last result | Last check UTC             | Next check/backoff UTC     | UNKNOWN count | Confirmation | Lease | Recovery/outbox/screenshot                                          |
| ----------------- | -------------------------------------- | -------------------------- | --------------- | ----------- | -------------------------- | -------------------------- | ------------: | ------------ | ----- | ------------------------------------------------------------------- |
| `queenbuenrostro` | `638ce692-7f36-4126-b792-868ecbad3d8d` | `2026-07-17T09:11:14.098Z` | `ERROR_BACKOFF` | `UNKNOWN`   | `2026-07-17T09:33:44.625Z` | `2026-07-17T09:51:54.711Z` |             5 | 0            | none  | no confirmation, recovery, outbox, Telegram delivery, or screenshot |
| `firearms`        | `22118bdc-973e-41b0-a55a-8a79e637828b` | `2026-07-17T12:44:39.830Z` | `ERROR_BACKOFF` | `UNKNOWN`   | `2026-07-17T13:17:56.858Z` | `2026-07-17T13:52:10.641Z` |             6 | 0            | none  | no confirmation, recovery, outbox, Telegram delivery, or screenshot |
| `notswitzy`       | `045a2ea4-32be-4a5d-8125-4b34441a00ea` | `2026-07-17T12:59:50.193Z` | `ERROR_BACKOFF` | `UNKNOWN`   | `2026-07-17T13:17:43.122Z` | `2026-07-17T13:34:23.407Z` |             5 | 0            | none  | no confirmation, recovery, outbox, Telegram delivery, or screenshot |
| `try.maven`       | `6e425799-8657-46f8-a475-2c444a495009` | `2026-07-17T13:11:43.384Z` | `ERROR_BACKOFF` | `UNKNOWN`   | `2026-07-17T13:18:06.623Z` | `2026-07-17T13:22:17.387Z` |             3 | 0            | none  | no confirmation, recovery, outbox, Telegram delivery, or screenshot |

All recorded checks for the four monitors had `classification=UNKNOWN`, HTTP `200`, an on-username final URL, three weak URL/absence signals, zero profile identity signals, no gone signals, and sanitized error code `UNRECOGNIZED_DOM`. There are no notification-outbox rows for any of them.

## State transition history

- `queenbuenrostro`: five `UNKNOWN/UNRECOGNIZED_DOM` checks from `09:11:23Z` through `09:33:44Z`; entered error backoff after the third consecutive unknown.
- `firearms`: six `UNKNOWN/UNRECOGNIZED_DOM` checks from `12:44:44Z` through `13:17:56Z`; entered error backoff after the third consecutive unknown and remained due-but-unclaimed under the skewed scheduler clock.
- `notswitzy`: five `UNKNOWN/UNRECOGNIZED_DOM` checks from `12:59:54Z` through `13:17:43Z`; same transition path.
- `try.maven`: three `UNKNOWN/UNRECOGNIZED_DOM` checks from `13:11:52Z` through `13:18:06Z`; entered error backoff on the third check.

## Controlled browser evidence

Controlled checks used a fresh local headless Chromium context with the same worker user agent, viewport, timeout, public unauthenticated route, and network path. Browser screenshots were kept only in memory and not persisted.

| Username              | Result                         | Final URL match | Canonical/OG/header identity | Unavailable | Login/challenge/rate-limit | Screenshot | Duration |
| --------------------- | ------------------------------ | --------------- | ---------------------------- | ----------- | -------------------------- | ---------- | -------: |
| `firearms`            | `UNKNOWN` (`UNRECOGNIZED_DOM`) | yes             | absent                       | no          | no/no/no                   | success    |   8.790s |
| `instagram` (control) | `ACTIVE`                       | yes             | all match                    | no          | no/no/no                   | success    |   2.964s |
| `queenbuenrostro`     | `UNKNOWN` (`UNRECOGNIZED_DOM`) | yes             | absent                       | no          | no/no/no                   | success    |   8.688s |
| `notswitzy`           | `UNKNOWN` (`UNRECOGNIZED_DOM`) | yes             | absent                       | no          | no/no/no                   | success    |   8.700s |
| `try.maven`           | `UNKNOWN` (`UNRECOGNIZED_DOM`) | yes             | absent                       | no          | no/no/no                   | success    |   8.696s |

The current detector returned `UNKNOWN` for `firearms` because it ignores title-level unavailable evidence. A final controlled navigation recorded the title `Profile isn't available • Instagram` in 8.583s. Under the required detection rules, that is explicit unavailable-profile evidence and the correct diagnostic classification is `GONE`, not `ACTIVE`. No recovery event or Telegram notification was created or sent.
