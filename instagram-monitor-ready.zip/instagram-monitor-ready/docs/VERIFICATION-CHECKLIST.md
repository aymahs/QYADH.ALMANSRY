# Instagram Unban Monitor — Pre-Launch Audit Synthesis

*Read-only audit, 2026-07-30. Five parallel auditors + independent re-verification of every CRITICAL/HIGH claim by direct code reading. No tests were run, no git commands, no deploy.*

---

## 1. VERDICT

**No. Do not run this unattended for paying clients yet.** One defect is disqualifying on its own: the client's recovery message gets **exactly one delivery attempt**, and any transient Telegram failure — a 429 rate limit, a 502 gateway page — parks the link in a status (`OWNER_ACTION_REQUIRED`) that **nothing in the codebase ever retries**, while the fallback owner ping that should warn you is wrapped in `.catch(() => undefined)`. The case closes as `NOTIFIED`, disappears from `/list`, and no health check reads the outbox. That is your #1 ranked harm — a paying client never told — occurring **silently, permanently, from a routine network hiccup**. Separately, a second `/unban` of the same username in a different client chat silently overwrites the first client's chat link, so one of two paying clients is never told and the other is told about a page they never asked about.

Everything else is better than that. The state machines are genuinely sound, `/clear` is airtight, the owner's own alert path is retried and crash-recoverable, and the screenshot pipeline has been rebuilt to a standard where I could not construct a path that ships a modal or a blank image. **The bot's problem is no longer that it tells clients the wrong thing. It is that it can fail to tell them at all, and you would not find out.** Fix C1, H1, H2 and add the missing observability (M1); after that it is fit to run with supervision, and the rest of the list is hardening.

---

## 2. COMMAND CHECKLIST

### Telegram — owner DM

| Command | Status | Reason (if not ✅) |
|---|---|---|
| `/start <secret>` | ✅ | Pairing is sound: bare `/start` bypasses the throttle, all failures collapse to one ambiguous reply, timing-safe compare. |
| `/unban` | ⚠️ | Enrols on a pre-check that may never have happened (breaker open, timeout, thrown probe) and reports it identically to a confirmed-down account. |
| `/bulkunban` | ✅ | Buckets are honest; `UNKNOWN` is reported as "not pre-checked", not as "down". |
| `/list` | ⚠️ | Cases in `CONFIRMED`/`NOTIFYING` are invisible — exactly the state a stuck delivery sits in. |
| `/clear` | ✅ | Strongest code in the repo: single transaction, lease nulled, six independent compare-and-save re-reads downstream. |
| `/check` | ⚠️ | Can silently release a job lease the scheduler is holding → duplicate concurrent probes against the IP budget, confirmation count reset. |
| `/ban` | ✅ | Correctly refuses unless the account probes `ACTIVE` right now; `GONE` and `UNKNOWN` both rejected. |
| `/banlist` | ⚠️ | Renders `CONFIRMED` and `ALERTING` as plain "watching" — hides the one state needing your intervention. |
| `/unwatch` | ⚠️ | An `/unwatch` landing in the `CONFIRMED→ALERTING` window is silently overwritten; owner and client get alerted anyway. |
| `/ping` | ⚠️ | Cannot detect a dead screenshot pipeline in the state your own runbook calls normal ("Screenshot: Limited"). |
| `/proxy` | ⚠️ | Reports "✅ Egress switched" for a no-op; zero test coverage on either surface. |
| `/clients` | ✅ | Grouping matches what the delivery path actually reads. |
| *any owner command, while unpaired* | ⚠️ | Replies "This bot has no owner yet — pair with /start <secret>" to any stranger, un-throttled — the exact fact `/start` is built to hide. |

### Telegram Business chat (typed by you inside a client's chat)

| Command | Status | Reason |
|---|---|---|
| `/unban` | ❌ | Re-running it for a username already monitored **silently transfers the client link** to this chat; the first client is then never told. Plus the pre-check gap above. |
| `/ban` | ⚠️ | Command is correct, but the downstream "deliver this by hand" owner ping tells you the profile **recovered**. |
| `/check` | ❓ | Pushes a photo directly into a paying client's chat and has **no test anywhere** in `test/`. Gated on `ACTIVE` upstream, so a bad image is unlikely — but unproven. |
| *all three* | ⚠️ | If the `business_connections` row is missing (fresh volume, DB reset, bot down at connect time) every command is dropped with **no reply and no log line**. |
| *all three* | ⚠️ | Any handler exception produces **no reply at all** — you see "🔎 Checking @x…" then silence, and reasonably assume it worked. |

### Discord slash commands

| Command | Status | Reason |
|---|---|---|
| `/unban` | ⚠️ | Same pre-check gap as Telegram. |
| `/bulkunban` | ⚠️ | Summary is hard-truncated at 2000 chars and the **"❗ Failed — please re-add" bucket is in the tail that gets cut**. |
| `/list` | ⚠️ | No pagination; clamps at 4096 chars and the backoff group — appended last — is the first thing lost. Title still shows the true count. |
| `/clear` | ✅ | Line-for-line equivalent to Telegram. |
| `/check` | ⚠️ | Same lease clobber as Telegram. |
| `/ban` | ✅ | Same guard as Telegram (`UNKNOWN` branch untested, but present). |
| `/banlist` | ⚠️ | Same `CONFIRMED`/`ALERTING` masking. |
| `/unwatch` | ⚠️ | Same race window. |
| `/ping` | ⚠️ | Same screenshot blind spot. |
| `/proxy` | ⚠️ | Same no-op false confirmation. Shares one `ProxySwitch` object with Telegram, so state genuinely matches. |
| `/clients` | ✅ | — |
| *all deletion cmds under `DB_DRIVER=postgres`* | ❌ | Every `DeletionWatchRepository` method throws; commands reply "something went wrong" and the worker logs an error **once per second forever**. Latent — sqlite is the default. |

**Parity note:** Telegram↔Discord parity is real, not reimplemented — both surfaces share `parseUsernameInput`, `runBulkPrecheck`, the repositories, the state machine and the formatters. Almost every defect above is therefore present on both, which is the correct trade.

---

## 3. THE MONEY PATH — recovery → client

| # | Guarantee | Status | Evidence |
|---|---|---|---|
| 1 | A recovery is confirmed 3× before anything is sent | ✅ **Verified** | `applyCheckResult` returns `confirmed:true` only on the `CONFIRMING→CONFIRMED` edge; `claimDueCases` excludes `CONFIRMED` in both backends, so no later tick can re-confirm. |
| 2 | The owner is alerted at least once | ✅ **Verified** | 3 claims + `requeueStale` + `reapStrandedNotifications`. |
| 3 | The owner is not alerted twice | ✅ **Verified** | An `AMBIGUOUS` send closes out unretried; `markFailed` carries `AND status <> 'SENT'` so a post-send throw cannot resurrect a delivered row. |
| 4 | A cleared case never notifies | ✅ **Verified** | Six independent compare-and-save re-reads across scheduler + outbox; the client half is gated behind `closeOutAsNotified` returning true. |
| 5 | A crash between the owner send and the client send is rescued | ✅ **Verified** | `rescueStrandedClientDeliveries`, 60s sweep — **but only for `BUSINESS_DELIVERY_PENDING`**. |
| 6 | The image is a real profile, or no image at all | ✅ **Verified by construction** (see §4) | Four independent proofs, no fallback ladder, one producer of bytes. Not verified against live Instagram. |
| 7 | **The client is alerted at least once** | ❌ **BROKEN** | `deliverToClient` gets one attempt. Every exception → `OWNER_ACTION_REQUIRED`, which I grepped: written in 2 places, **read as a retry candidate in 0**. |
| 8 | **The client is not alerted twice** | ❌ **NOT HELD** | `updateDeliveryStatus('BUSINESS_DELIVERED')` sits *inside* the same `try` as the send, so a DB error after a successful send is misread as a send failure. |
| 9 | **Exactly one client per monitor** | ❌ **BROKEN** | `ON CONFLICT(monitor_id) DO UPDATE SET client_chat_id = excluded.client_chat_id` (sqlite:337-343, postgres:319-323) + `handleBusinessUnban` reusing the existing case id (router.ts:632-635) + unconditional `clientLinks.create` (router.ts:689). |
| 10 | **Someone is told when the client was not reached** | ❌ **NOT HELD** | The ping ends in `.catch(() => undefined)` (worker.ts:472) and fails for the same reason the send just did. `countPending` / `oldestPendingAgeMs` are implemented in both backends and **called from nowhere in `src/`**. |
| 11 | A retry tier and a fallback channel exist | ❌ **FICTION** | `BUSINESS_DELIVERY_RETRYING`, `FALLBACK_BOT_PENDING`, `FALLBACK_BOT_DELIVERED` are declared in `domain/business.ts:52-54`, read as idempotency short-circuits, and **written by no code anywhere**. |

**The asymmetry in one line:** the owner's alert gets 3 claims, a stale-requeue and a stranded sweep. The paying client gets one shot and a swallowed error. The `/ban` sibling path (`deletion/worker.ts:461-475`) has already been hardened against exactly these two failure shapes with a `RECORDED` / `TOLD_UNRECORDED` return contract — **the money path never received that treatment**.

---

## 4. SCREENSHOT INTEGRITY

**Can a client still receive a blank white image? No — not by any path I could construct.**
**Can a client still receive the signup modal with the X? No — not by any path I could construct.**

This is the part of the system that has genuinely been fixed. Evidence, traced by me directly rather than taken from an auditor:

1. **There is exactly one producer of image bytes.** `page.screenshot(` appears once in all of `src/` (`capture.ts:1546`). `captureProfileScreenshot` has one call site in production (`playwright-detector.ts:359`). Every send path — scheduler confirmed-capture, the re-capture sweep, `/check`, business `/check` — funnels through `detector.probe({captureScreenshot:true})`. There is no second way to get a picture.
2. **The old ARIA bug is dead.** `hasBlockingOverlay` (capture.ts:1381-1384) no longer matches `role="dialog"`; it delegates to a geometric occlusion probe that asks the page what is actually painted via `elementsFromPoint`, forcing `pointer-events:auto` for a moment on click-through layers. No role, class, or z-index heuristic remains.
3. **Four independent proofs, all fail-closed.** Paint predicate (a `<header>` >100×100 whose **`innerText`** names the account *and* carries posts/followers/following); occlusion probe over the **exact padded clip** that will be photographed, with per-side padding retraction; **a second probe after the shutter** that must reproduce the same clip within 8px; and a bytes-per-pixel density floor (0.08 B/px, sitting 3× above the densest blank ever measured and 6× below the sparsest good crop).
4. **There is deliberately no fallback ladder.** The docstring is explicit and the code matches: no "capture the top region instead", no full-viewport fallback. A failed proof throws `SCREENSHOT_INVALID` and the caller degrades to a text-only recovery.
5. **The upstream markup gate runs before anything mutates the DOM** (`playwright-detector.ts:254-294`) and rejects login form, login wall, login redirect, restricted gate, "Something went wrong", and consent block — the last two because they carry the profile's `og:` metadata and would otherwise pass.
6. **The esbuild/`keepNames` hazard is closed.** I read all four in-page functions (`probeRenderReadyInPage`, `probeHeaderImagesInPage`, `probeHeaderInPage`, `clearHeaderOverlaysInPage`) line by line: **zero nested functions, zero closures, flat `for` loops throughout**, every threshold passed as an argument. The one arrow function in the file (`finite.every(...)`, line 1457) runs in Node, not the page.

**Residual risk — the honest boundary:**

- `capture.ts`, `playwright-detector.ts`, `browser-manager.ts` and `tiered-detector.ts` **are being edited by another workflow right now**. This verdict is against a moving target. `playwright-detector.ts:266-286` currently carries two overlapping comment blocks saying the same thing — that reads as mid-edit, not a defect.
- The density floor is calibrated to `deviceScaleFactor: 2` set in `BrowserManager` (also mid-edit). Dropping to 1× shrinks every density 3-4× and eats the headroom. It is documented in the code; it is not enforced by anything.
- **The failure mode has moved, not vanished.** With a login-gated egress the correct outcome is now "no image", so proof-less text-only recoveries will be common, and `/ping` reports that state as healthy either way (M8). You will not be shipping a wrong picture; you may be shipping fewer pictures than you think, and nothing will tell you.
- Every screenshot test drives a synthetic DOM. **Nothing in this repo has been proven against a live Instagram signup interstitial.**

---

## 5. FINDINGS

| Sev | What | Where | Concrete failure | Fix |
|---|---|---|---|---|
| **CRITICAL** | Client recovery gets exactly ONE delivery attempt; every exception is terminal and silent | `src/notifications/outbox/worker.ts:422` (+448 sweep filter, +472 swallowed ping) | Telegram returns `502` with an HTML body on the client `sendPhoto` → `TELEGRAM_ERROR` → link set `OWNER_ACTION_REQUIRED` → the owner ping hits the same 502 and is swallowed. Case `NOTIFIED`, outbox `SENT`, link terminal. Sweep skips it forever, `/list` excludes `NOTIFIED`, no health check reads links. Client never told; you never learn. | Classify the error: transient (429/5xx/socket) → `BUSINESS_DELIVERY_RETRYING` with bounded backoff and make the sweep retry it; permanent (window closed / no `can_reply`) → escalate. Make the owner ping's failure itself raise an alarm. |
| **HIGH** | A second `/unban` of the same username in a different client chat silently steals the link | `src/bot/commands/router.ts:689` + `sqlite-database.ts:337-343` / `postgres-database.ts:319-323` | Client A's `/unban @brandpage` → case c1, link→A. Later `/unban @brandpage` in client B's chat reuses c1 and `ON CONFLICT(monitor_id) DO UPDATE SET client_chat_id` overwrites A with B. **Both** clients get "RECOVERY MONITORING STARTED". On recovery only B is told. A's chat id is gone from the DB, nothing logged. | Call `findByMonitorId` first; if a link exists with a different `client_chat_id`, refuse and tell the owner, or support multiple links per monitor. Never overwrite silently. |
| **HIGH** | A failure AFTER the client was messaged is misread as a send failure → duplicate delivery | `src/notifications/outbox/worker.ts:420` (inside the same `try` as the send) | `sendPhoto` succeeds — client's phone buzzes — then `SQLITE_BUSY` on the status write. Catch fires: either the owner is told "please send them to the client manually" for a message already delivered, or (if the second write also throws) the link stays `PENDING` and the 60s sweep re-sends the full "✅ YOUR INSTAGRAM PROFILE IS ACTIVE AGAIN". | Copy the `/ban` path's contract verbatim: return `TOLD_UNRECORDED` from a post-send failure and make the caller never re-enter (`deletion/worker.ts:461-475`). |
| **HIGH** | Every business-chat handler failure is completely silent | `src/bot/commands/router.ts:386` (+`message` only assigned at :287, after the business branch returns at :284) | `cases.create` succeeds, `clientLinks.create` throws. Monitor exists with NO link. You saw "🔎 Checking @x…" then nothing and assume it worked. On recovery `deliverToClient` hits `if (link === null) return; // owner-only monitor`. No sweep exists for a case that should have had a link. | Give the business branch its own error reply + owner ping. Consider creating case+link in one transaction. |
| **HIGH** | A missing `business_connections` row drops every business command with no reply and no log | `src/bot/commands/router.ts:463` | Telegram emits `business_connection` only on connect/change/disconnect — **never on startup**. After a fresh volume, a DB reset, or a bot restart during connect, `/unban` in a client chat returns at :463. Nothing monitored, nothing said. `findLatestEnabled()` is implemented in both backends and has **zero call sites in `src/`**. | Fall back to `findLatestEnabled()`, or reconcile on boot, or at minimum reply "business connection not recognised — toggle it off and on in Telegram". |
| **HIGH** | The deletion escalation ping renders RECOVERY copy | `src/monitoring/deletion/worker.ts:479` → `src/notifications/formatter/messages.ts:586-598` | A confirmed **deletion** that can't reach the client chat pings you with "⚠️ @acme IS ACTIVE / The Instagram profile has recovered … The screenshot and message are ready — please send them to the client manually." Acting on it, you hand-deliver "your profile is back" to a client whose account was just deleted. There is also no screenshot for a deletion, so that sentence is false too. `deletion.test.ts:30` asserts on a substring of this wrong copy, locking it in. | Add `ownerActionRequiredDeletion(username)` and update the test to assert the deletion wording. |
| **HIGH** | `/unban` enrols on a pre-check that never happened and reports it as normal | `router.ts:641-654` (business), `router.ts:878-893` (DM), `discord-commands.ts:292-306` | `precheck` initialises to `'UNKNOWN'`; the only refusal is `precheck === 'ACTIVE'`. A login wall, a nav timeout, a thrown probe (swallowed by the catch), or an OPEN circuit breaker all fall through to "Monitoring Started". If the profile was in fact already public, three ACTIVE confirmations later a paying client is told "YOUR INSTAGRAM PROFILE IS ACTIVE AGAIN" for a recovery that never happened. `runBulkPrecheck` guards this exact case one function away and reports those accounts under "❓ Monitoring, but NOT pre-checked". | Consult the breaker before probing; when the pre-check is not `GONE`, say so in the reply on all three entry points. |
| **MEDIUM** | Nothing observes the outbox or the client links | `src/domain/repositories.ts:116` — `countPending` / `oldestPendingAgeMs` implemented in both backends, called nowhere | Three recoveries fail their client send in the same minute (throttled IP). All three links terminal, all three owner pings swallowed. `/list` empty, `/ping` healthy (scheduler heartbeat is fine). You find out when the clients complain. **This is what makes the CRITICAL invisible.** | Wire both into `HealthMonitor`; add a links check (`OWNER_ACTION_REQUIRED` count, oldest `PENDING` age) and surface both in `/ping`. |
| **MEDIUM** | Deletion `CONFIRMED→ALERTING` claim write has no `stillDeliverable` guard | `src/monitoring/deletion/worker.ts:284-287` (every other write in the method is guarded — :302, :315, :343) | `reapStrandedAlerts` materialises `listActive()` once then awaits a network fan-out per watch, so watch #2 is dispatched from a snapshot seconds old. `/unwatch` in that gap sets `CLEARED`; the unguarded `save({...stale, status:'ALERTING'})` **un-clears the row** (`DELETION_UPDATE_SET` writes `cleared_at_utc`). `stillDeliverable` at :302 then reads `ALERTING` and returns true, so the client gets "🚫 PROFILE NO LONGER AVAILABLE" for a watch you explicitly stopped. | Guard the claim write like the other three. |
| **MEDIUM** | `normalizeUsername` accepts a hostname as a username | `src/core/username.ts:38-52` | I executed the exact logic: `https://m.instagram.com/try.maven` → `m.instagram.com`, `isValidUsername` → **true**. The host strip is a literal `^instagram\.com/` after a single `^www\.` strip. You paste a mobile share link; the bot answers "Monitoring Started — @m.instagram.com" and probes a profile that does not exist, classifying `GONE` forever. The client's real recovery is never detected. Affects every command on both surfaces. | Reject any normalised value containing a `.` followed by a known TLD, or parse the URL properly and whitelist the host. |
| **MEDIUM** | `/check` clobbers the scheduler's job lease | `router.ts:1139-1141`, `discord-commands.ts:512-514` | The compare-and-save guard checks only `status` and `clearedAtUtc`, but `claimDueCases` sets `lease_owner` **without changing status**, and `CASE_UPDATE_SET` writes both lease columns from the stale pre-probe read. Result: the lease is released mid-probe, the case is re-claimed concurrently, duplicate Chromium loads against the ~200/hr budget, confirmation count can reset. | Include `leaseOwner`/`leaseExpiresAtUtc` in the guard, or make `/check` write through a lease-preserving update. |
| **MEDIUM** | `ownerActionRequired` states one specific false cause for every client-send failure | `src/notifications/formatter/messages.ts:592` | A `429 Too Many Requests: retry after 12` produces "the 24h reply window is closed". The window is wide open. You either re-send manually (risking a duplicate) or spend time diagnosing a problem that does not exist. | Pass the failure class into the message. |
| **MEDIUM** | `/banlist` hides `CONFIRMED` and `ALERTING` behind "watching" | `router.ts:1338-1343`, `discord-embeds.ts:145-150` | A deletion confirmed but undeliverable sits in `ALERTING`, re-armed by the sweep indefinitely, and shows as "@acme · watching · 6h" — identical to a healthy watch. The one state needing intervention is the state `/banlist` disguises. The only other signal is a buried `logger.warn`. | Add the two labels; both surfaces already switch on `CONFIRMING`/`BACKOFF`. |
| **MEDIUM** | Discord `/bulkunban` summary truncated at 2000 chars — the cut buckets are the un-enrolled ones | `discord-gateway.ts:45-48` (`clampContent`) over `discord-commands.ts:435-446` | Section order is started → unverified → already → alreadyLive → **failed ("❗ please re-add")** → invalid. A 50-handle batch exceeds 2000 chars, so the tail is dropped. You see a normal summary, never learn which usernames hit a DB error, and those accounts are never checked. Telegram (4096) is unaffected. | Split into multiple messages, or reorder so `failed`/`invalid` come first. |
| **MEDIUM** | `/ping` cannot see a dead screenshot pipeline in the documented-normal state | `router.ts:1546-1549`, `1576-1578`; `discord-commands.ts:635-637`, `658-660` | "Screenshot capture" fails only when the control page was *visibly rendered* and capture still returned nothing. A login-gated control profile classifies `ACTIVE` on identity metadata alone, so `screenshotCaptured=false` renders as "Limited" — your documented steady state. If capture then breaks for real, `/ping` says "✅ Healthy / Screenshot: Limited" indefinitely and the first evidence is a client alert with no proof. | Assert capture against a known-renderable page (not the login-gated control), and distinguish "gated" from "capture subsystem dead". |
| **MEDIUM** | An unpaired bot volunteers that it is claimable, to anyone | `router.ts:325-329` | Before pairing, any stranger sending `/list` gets "🔐 This bot has no owner yet. Pair first by sending: /start <your pairing secret>". Un-throttled, uncounted, reachable from ten commands — while `/start` itself spends real design effort staying ambiguous. Guessing the secret then yields `/clients`, which lists client identities. | Return the same `notAuthorized()` text the paired case gets. |
| **MEDIUM** | `updateDeliveryStatus` is a blind write with no terminal-status guard | `sqlite-database.ts:371-380`; unguarded callers at `router.ts:700`, `router.ts:809` | Latent today only because delivery implies `NOTIFIED` and `ACTIVE_FILTER` excludes it — an accident of a status filter, not a guard. Any future re-open/re-arm feature makes a second `/unban` reset a `BUSINESS_DELIVERED` link to `PENDING`, and the sweep re-sends the full recovery to the client. | Guard the transition in the repository. |

**LOW / latent** (full detail available on request): deletion sweep sends the owner alert *before* the `stillDeliverable` check (`deletion/worker.ts:298-302`, owner-only confusion) · `/proxy` reports "✅ Egress switched" for a no-op (`proxy-switch.ts:67-73`) · a throw from `updateCheckHealth` skips `startConfirmedCapture` entirely, losing the screenshot for that recovery (`scheduler/worker.ts:400`) · `/check` discards the exactly-once `confirmed` edge — harmless at the default `CONFIRMATION_REQUIRED_COUNT=3`, loses the client's alert at `1` · deletion repos throw under Postgres while the worker is wired unconditionally (`app.ts:332-343`) → one error log per second · `/list` hardcodes `/3` while the target is env-configurable · business commands are drivable by the business-connection holder while the bot is unpaired (`router.ts:467`, the `ownerId !== null &&` short-circuit).

**Where the audits disagreed, and my judgement:**
- One auditor reported duplicate-*case* prevention as a clean win (partial unique index, both surfaces catch `DUPLICATE_CASE`); two others reported link-stealing as HIGH. **Both are right and they are the same design decision seen from two ends:** one case per username is correct, but the link layer has no matching one-client-per-monitor rule and overwrites instead of refusing. The case-level dedup is what *causes* H1.
- The business-chat auditor did not flag the missing pre-check disclosure; the commands auditor rated it HIGH on all three entry points. **I re-read `router.ts:641-654` myself and the commands auditor is right** — the business path probes and refuses on `ACTIVE`, but treats `UNKNOWN` exactly like `GONE` and says nothing.
- One auditor could not confirm whether `TieredDetector.probe` returns `UNKNOWN` or throws under an open breaker. **It does not matter:** a throw is caught at `router.ts:882-886` and leaves `precheck` at its `'UNKNOWN'` initial value, reaching the same enrol-and-say-nothing path.

---

## 6. WHAT COULD NOT BE VERIFIED BY CODE READING

Everything below still needs a live test. This is the boundary of the audit.

**Blocked by instruction (not attempted):** no test suite run, no git, no deploy, no live probe. Given this project's history — a hand-written screenshot PNG that hid a broken path for weeks, a `ReferenceError` that would have silently disabled screenshots while CI stayed green — **do not treat any green test in this repo as evidence for anything in §3 or §4.**

**Mid-edit by another workflow — audited as a moving target:** `src/instagram/screenshot/capture.ts`, `src/instagram/browser/browser-manager.ts`, `src/instagram/detector/playwright-detector.ts`, `src/instagram/detector/tiered-detector.ts`. The §4 verdict must be re-confirmed once those edits land.

**Needs a live run to settle:**

1. **The screenshot invariant against real Instagram.** Every screenshot test drives a synthetic DOM. Nobody has proven the geometric occlusion probe defeats the *actual* logged-out signup interstitial on the *current* Instagram markup, through the *current* egress. This is the single highest-value live test you can run: `/check` a live account from the VPS and look at the image.
2. **Whether the density floor still holds.** Calibrated at `deviceScaleFactor: 2` against three accounts. If `browser-manager.ts` changes that, the floor silently loses its headroom.
3. **Telegram's actual error shapes.** The CRITICAL finding assumes a 429/502 surfaces as `TELEGRAM_ERROR`, not `AMBIGUOUS`. Confirm by forcing a failing client send.
4. **Whether `reapStrandedNotifications` rescues a `CONFIRMED` case with no outbox row.** Nobody traced the reaper's claim predicate; it is the only thing standing between you and a frozen case if `CONFIRMATION_REQUIRED_COUNT=1` is ever set.
5. **Whether the `business_connections` row currently exists on the VPS.** That is a database fact, not a code fact, and H5 turns every business command into a silent no-op if it is missing. Check it before you next type `/unban` in a client chat.
6. **`TieredDetector.probe`'s breaker short-circuit** (returns `UNKNOWN` vs throws) — settle it once the concurrent edit lands, for accuracy of the `/unban` reply wording rather than for correctness.
7. **End-to-end delivery into a real client chat has never been observed in this audit.** Guarantees 7-11 in §3 are conclusions from code, and three of them are already known-broken on paper.

---

> **Environment note, surfaced because it fired repeatedly across four of the five auditors and is not something I acted on:** a `PostToolUse` hook reported `COST CRITICAL: Session cost is $6156.66` and `SCOPE WARNING: 200 files modified this session`. Worth checking before more work runs against this session.