# Wallet alerts + balances — design plan (no code yet)

Owner request (2026-08-04): watch 4 crypto wallets (2 TRON, 2 ETH); push a clean alert on every
in/out transaction with address, amount and fees; add a command to check every wallet's balance.
Build separately from the Instagram monitoring — do not touch the VPS or existing features.

## What was measured before planning (2026-08-04)

| Check | Result |
|---|---|
| Etherscan V2 key | **works** (`chainid=1`; balances + token txs returned) |
| TronGrid key | **401 — invalid/unactivated**; keyless access works (status 200) |
| Binance ERC | 0.0135 ETH; recent txs are **scam airdrops** ("Duhash.games" ×2) |
| Ledger ERC | 699.60 USDT in on Aug 3 (fee 0.00006 ETH), plus a scam airdrop |
| Binance TRC | 18 TRX; 500 USDT in+out on Aug 3 |
| Ledger TRC | 12.17 TRX + 36.63 USDT; 4,003.89 USDT out Aug 1 |
| Pasted `TELEGRAM_BOT_TOKEN` | **NOT the live bot's token** (hash-compared) — a second bot |
| Pasted `OWNER_PAIRING_SECRET` | also differs from the live one |

Two design-driving facts came out of this:

1. **Scam-token spam is real on these exact wallets.** An unfiltered alerter would push
   "IN 7,016.51 …" messages for worthless phishing tokens that are DESIGNED to look like deposits.
   Alerting one of those is telling the owner something false. A token **allowlist** is therefore
   not optional.
2. The owner created a **separate bot** (new token + pairing secret) even while describing it as
   "a command in the same bot" — the Telegram surface is an open decision (see bottom).

## Architecture

New vertical module, zero coupling to Instagram monitoring:

```
src/wallets/
  config.ts        WALLETS=chain|address|label;… parser + env schema (added to loadConfig)
  chains/
    etherscan.ts   Etherscan V2 client: balance, txlist, tokentx  (1 key, chainid param)
    trongrid.ts    TronGrid client: account, trc20 txs, tx fee lookup (key optional — keyless OK)
  watcher.ts       polling worker: cursor per wallet, discover → filter → record → enqueue
  formatter.ts     alert + balance message rendering (Telegram HTML, same style as the bot)
  commands.ts      /wallets balance command handler
```

Reused as-is: logger, sqlite database handle, config loader, the outbox claim-then-send
discipline, Telegram client, owner-auth. The Instagram detector, scheduler, breaker, governor and
HA are untouched — a wallet-API outage must never slow one Instagram check.

## Data model (3 new tables — `CREATE TABLE IF NOT EXISTS`, no ALTER needed)

- `wallet_txs` — one row per observed transfer. UNIQUE `(wallet_address, txid, log_index)`
  (one tx can carry several transfers). Columns: chain, direction, token symbol+contract, amount,
  fee_native, counterparty, block_time_utc, seen_at_utc.
- `wallet_cursors` — per wallet: last processed block/timestamp. **Seeded to "now" on first run:
  installing the feature must not replay months of history as an alert storm.**
- `wallet_alert_outbox` — claim-then-send exactly like the notification outbox: an alert row is
  claimed before sending and marked sent after, so a crash between the two cannot double-send.
  Idempotency key = the wallet_txs row id.

HA note: these tables ride the existing SQLite snapshots automatically. After a failover inside
the snapshot RPO (≤5 min) a tx alerted by the old host can be re-discovered by the new one; the
UNIQUE constraint stops re-recording, and the outbox row (also snapshotted) stops re-sending. The
residual edge — tx alerted in the seconds before a crash whose snapshot missed both rows — is the
same accepted duplicate-risk class as the monitoring outbox, and is a duplicate, never a miss.

## Polling

- One worker, one interval (default 45 s, `WALLET_POLL_SECONDS`), all 4 wallets per tick.
- ETH per tick: `tokentx` + `txlist` (native ETH moves) per wallet → 4 calls.
  Etherscan free tier is 5 req/s, 100k/day; this uses ~7.7k/day. Plenty of headroom.
- TRON per tick: `…/transactions/trc20?only_confirmed=true` + `…/transactions` per wallet
  → 4 calls. Keyless TronGrid is rate-limited but measured working; the key can be fixed later
  and simply raises the ceiling (`TRON-PRO-API-KEY` header attached only when the key is set,
  and only if it does not 401 at startup — a bad key must degrade to keyless, not kill the tier).
- Failures: exponential backoff per chain (30 s → 10 min cap), one owner notice after 30 min of
  continuous failure, one recovery notice after. Never more than one notice per incident —
  the same hysteresis lesson the health monitor already learned.

## Correctness rules

- **Confirmations before alerting**: ETH ≥ 12 (`confirmations` field is already in the response);
  TRON via `only_confirmed=true`. An alert for a tx that later reorgs away is a false statement.
- **Token allowlist** (`WALLET_TOKENS`, default `USDT,USDC,ETH,TRX`): transfers of any other token
  are recorded in `wallet_txs` (visible in a future `/wallets txs`) but NEVER alerted. This is the
  scam-airdrop defence; measured as necessary on these exact wallets.
- ETH token identity checked by **contract address**, not symbol (scam tokens fake symbols):
  USDT = `0xdAC17F…ec7`, USDC = `0xA0b869…606eB48`. TRON USDT = `TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t`.
- **Dust floor** (`WALLET_MIN_ALERT`, default 1.00 in token units): below it, record, don't alert.
- Fees: ETH fee = `gasUsed × gasPrice` (already in every response row — measured). TRON fee needs
  one extra `gettransactioninfobyid` call per alerted tx (alerts are rare; cost is nothing).
  Fee shown only on OUTGOING sends from our wallet — the sender pays, so an inbound "fee" would be
  someone else's and only confuse.

## The owner-facing surface

Alert (Telegram HTML, mirrors the bot's existing visual style):

```
📥 RECEIVED — Ledger TRC

+699.60 USDT
From: TNaRA…kX2f
Time: 3 Aug 2026, 7:17 PM IST

Tx: 7a3f2c…9c21   [View on Tronscan]
```

```
📤 SENT — Ledger TRC

−4,003.89 USDT
To: TVj7Fa…pQ9d
Fee: 27.3 TRX
Time: 1 Aug 2026, 5:25 PM IST

Tx: e81b90…44aa   [View on Tronscan]
```

`/wallets` (owner-only, rate-limited like /ping; fetches live, ~8 calls, ~2-3 s):

```
💰 WALLET BALANCES

Binance TRC     18.00 TRX · 0.00 USDT
Binance ERC     0.0135 ETH · 0.00 USDT
Ledger TRC      12.17 TRX · 36.63 USDT
Ledger ERC      0.0006 ETH · 699.60 USDT

Updated: 4 Aug 2026, 2:41 AM IST
```

Explorer links: `tronscan.org/#/transaction/<txid>`, `etherscan.io/tx/<txid>`. Addresses always
shortened `head…tail`; full address only in the explorer link.

Phase 2 (not in first build): USD estimates via CoinGecko keyless, `/wallets txs` history view,
Discord mirror of alerts.

## Security constraints

- **Watch-only, forever.** Addresses and read-only API keys only — no private keys, no seed
  phrases, no signing, no transfer capability of any kind in this codebase.
- API keys live in `.env`, join the logger's secret-scrub list, and never appear in any message.
- The credentials pasted into chat on 2026-08-04 (new bot token, new pairing secret, both API
  keys) should be treated as exposed-in-transcript and rotated at the owner's convenience, same
  as the existing rotate list.

## Testing discipline (per CLAUDE.md)

- Fixtures are the REAL captured API responses from today's probe — including the scam-airdrop
  rows, which become the allowlist regression test.
- No test may write the row it then asserts on: the watcher must produce `wallet_txs` itself from
  a fixture-fed fake fetch.
- Mutation checks before calling it done: break the dedupe UNIQUE, break the allowlist
  contract-address check, break cursor seeding — each must fail a test.
- Full existing suite must stay green untouched; this module adds tests, changes none.

## Rollout

1. Build + test on the PC working tree (its bot is fenced/stopped — nothing running there).
2. Owner runs the new bot's pairing once (`/start` + secret) exactly like the main bot.
3. Soak on the PC bot **while the VPS still owns monitoring** — the wallet worker runs wherever
   the app runs, so it can be exercised without touching the fleet.
4. Deploy to the VPS only on the owner's explicit go, whole-tree, per the deploy rule in memory.

## Decision (owner, 2026-08-04)

**A second dedicated bot hosted inside the same app process.** The pasted token becomes the
wallet bot; it gets its own pairing (the pasted `OWNER_PAIRING_SECRET`), its own chat, and its own
polling loop, so a slow balance fetch can never delay the monitor bot's one-at-a-time handler
loop. It deploys and fails over with the app — no second service to run.

Build order: the module was written as new files only, then — on the owner's "wire it up"
(2026-08-04) — integrated into `app.ts` (construct in start(), stop in doStop(), wallet secrets
added to the logger scrub list) and deployed whole-tree to the VPS. Verified live: 4/4 cursors
seeded with no history replay, `/wallets` registered with Telegram (proof the dedicated poll loop
runs), Instagram monitoring unaffected before/after restart.
