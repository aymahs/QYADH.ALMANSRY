## ⚠️ FIRST — SESSION COST ALERT (from the harness, not from me)

A `PostToolUse` hook fired twice during this task:

> `COST CRITICAL: Session cost is $1185.21` → then `COST CRITICAL: Session cost is $5953.41`
> `SCOPE WARNING: 200 files modified this session.`

The cost went from **$1,185 → $5,953 across two tool calls**. I stopped reading further files because of it and wrote this from what I had. **Surface this to the owner before spending anything more on this workflow.** Two files I would normally have read (`src/instagram/screenshot/capture.ts` in full, `src/app/app.ts` in full) were only grepped, so the screenshot term below is code-derived from constants rather than line-by-line verified.

---

# End-to-End Latency Budget: "profile becomes reachable" → "client's phone buzzes"

## 0. Ground truth: what production is actually configured to do

Read from `C:\Users\fazea\monitor bot\.env` (**not** `.env.example` — they disagree sharply):

| Setting | `.env` (production) | `.env.example` | Code default |
|---|---|---|---|
| `BASELINE_INTERVAL_SECONDS` | **60** | 15 | 15 |
| `BASELINE_JITTER_MAX_SECONDS` | **15** | 2 | 2 |
| `CONFIRMATION_INTERVAL_SECONDS` | *(unset)* | 5 | **5** |
| `CONFIRMATION_REQUIRED_COUNT` | *(unset)* | 3 | **3** |
| `CONFIRMATION_DEADLINE_SECONDS` | *(unset)* | 30 | **30** |
| `MAX_BROWSER_CONCURRENCY` | **4** | 1 | 4 |
| `CHECK_TIMEOUT_MS` | **45000** | 25000 | 25000 |
| `RETRY_DELAYS_SECONDS` | **120,300,600,900** | 5,10,15,30 | 5,10,15,30 |
| `ERROR_BACKOFF_MAX_SECONDS` | *(unset)* | — | **30** |
| `FAST_PROBE` | true | true | true |
| `PROXY_MODE` | **direct** | — | — |

Tick loops, from `src\app\app.ts:55-57`: `MONITOR_INTERVAL_MS = 1000`, `OUTBOX_INTERVAL_MS = 1500`, `HEALTH_INTERVAL_MS = 300000`.

**Config bug found immediately.** `retryDelaySeconds()` in `src\monitoring\scheduling.ts:84-90` ends with `return Math.min(delay, p.errorBackoffMaxSeconds);`. `ERROR_BACKOFF_MAX_SECONDS` is unset → defaults to **30**. So the configured ladder `120,300,600,900` is **entirely inert** — every rung clamps to 30s. Today that is accidentally *good* (fast retries). It is also a landmine: anyone "fixing" the config by setting `ERROR_BACKOFF_MAX_SECONDS=900` to match would silently create a **15-minute detection hole** on every account that has ever returned UNKNOWN. Side effect worth noting: an account in `UNKNOWN_BACKOFF` rechecks at **30–45s**, *faster* than a healthy GONE account's **60–75s**. That inversion is almost certainly unintended.

---

## 1. The critical path, component by component

Home residential IP (the measured-good route), N=20, happy path, everything succeeds.

| # | Component | Time (mean) | Range | Bound | Source |
|---|---|---|---|---|---|
| **A** | **Polling blind window** — case is MONITORING, next check at `now + 60 + U(0,15)` | **33.8 s** | 0–75 s | **CODE** | `scheduling.ts:60-72`, `.env:15,37` |
| A2 | Scheduler tick quantization (1 s tick × 3 checks) | 1.5 s | 0–3 s | CODE | `app.ts:55` |
| A3 | Head-of-line block: `for (const c of claimed) await processCase(c)` is **serial** over ≤4 claimed cases | 0 s | 0–40 s | CODE | `scheduler\worker.ts:189-197` |
| **B** | **Fast HTTP probe RTT** ×4 (3 confirms + capture) | **1.7 s** | 1.2–2.4 s | NETWORK (~40% CODE) | measured 423 ms; `http-probe.ts` |
| **C1** | Browser escalation on identity match ×3 — *every* confirmation escalates | **24.0 s** | 12–36 s | NETWORK (paint) + **7.5 s CODE** | `tiered-detector.ts:474-484` |
| **C2** | Confirmation gaps ×2 @ 5 s, no jitter | **10.0 s** | 10 s exactly | **CODE** | `transitions.ts:97`, `scheduling.ts:75-77` |
| **D** | **Screenshot capture** (blocks the alert) | **12.5 s** | 11–14 s, hard cap 30 s | 2–5 s NETWORK, **~9 s CODE** | `scheduler\worker.ts:486-563` |
| E1 | DB save + outbox enqueue | 0.05 s | — | CODE | `worker.ts:576-608` |
| **E2** | **Outbox tick pickup** (1500 ms, one item/tick) | **0.75 s** | 0–1.5 s | **CODE** | `app.ts:56`, `outbox\worker.ts:136` |
| E3 | `claimNotification` + re-read (2 DB round trips) | 0.05 s | — | CODE | `outbox\worker.ts:603-632` |
| E4 | Telegram `sendPhoto` → **owner** | 0.9 s | 0.3–1.5 s | NETWORK | `outbox\worker.ts:240-247` |
| E5 | `markSent` + `closeOutAsNotified` | 0.05 s | — | CODE | `outbox\worker.ts:249-258` |
| E6 | **Discord mirror upload** — runs *before* the client | 0.9 s | 0.3–1.5 s | **CODE (ordering)** | `outbox\worker.ts:268-271` |
| **E7** | **Telegram `sendPhoto` → CLIENT** ← the buzz | **0.9 s** | 0.3–1.5 s | NETWORK | `outbox\worker.ts:275`, `348-403` |

### Totals — home residential IP

- **Mean: ~87 seconds**
- **Best case: ~36 s** (recovery lands just before a due check, 4 s paints, fast sends)
- **Worst realistic: ~160 s** (75 s blind window, 12 s paints, 30 s capture budget spent, slow sends)

**Split: ~28 s NETWORK-BOUND, ~59 s CODE-BOUND. Roughly 68% of end-to-end latency is ours to fix.**

### Totals — mobile 4G proxy

Estimated **120–400 s, with a real probability of never confirming at all.** Two hard failures:

1. **The confirmation deadline aborts real recoveries.** `scheduler\worker.ts:254-258` computes `confirmationDeadlineExceeded` as `now − lastCheckedAtUtc > 30 s` — **per gap, not per burst**. A single browser leg through the mobile proxy was measured at 85.4 s and 96.4 s. That exceeds 30 s, so `transitions.ts:77-82` throws the burst away and re-arms a fresh 60–75 s baseline. On a slow route a genuine recovery can be discarded repeatedly and indefinitely.
2. **The screenshot budget is always exceeded.** `SCREENSHOT_BUDGET_MS = 30_000` vs. a measured 85–96 s paint → always text-first, always waiting the full 30 s first.

---

## 2. Premise correction: the alert is **NOT** sent before the screenshot

The task brief says this is "already partly done." **It is not.** Verified in `src\monitoring\scheduler\worker.ts:486-608`:

`handleConfirmed()` runs the capture loop to completion (up to `SCREENSHOT_BUDGET_MS = 30_000`) and *only then* saves `NOTIFYING` and calls `outbox.enqueue(...)`. **The screenshot is fully synchronous on the critical path.**

What *does* exist is a well-built **text-first fallback on failure**: budget exhausted, throttle signal, or capture miss → `screenshotStatus: 'FAILED'` → `RECOVERY_TEXT` now, picture later via `reapMissingScreenshots()`. That is bounded-loss engineering, not send-first. On the happy path the client waits the full 11–14 s for a picture before the message is even *queued*.

Note also `RECAPTURE_SWEEP_INTERVAL_MS = 5 * 60_000` (`worker.ts:68`) — a picture that misses the critical path arrives **up to 5 minutes later**, one case per sweep.

---

## 3. THE CENTRAL ARITHMETIC — theoretical floor given the 200/hr ceiling

This is the heart of the whole question, and it resolves to a single formula.

With **N** monitored accounts, a per-IP budget of **B** probes/hour, and **P** egress IPs:

```
poll interval  T    = 3600·N / (B·P)     seconds
mean detection      = T / 2 = 1800·N / (B·P)   seconds
IPs needed for latency L  =  P = 1800·N / (B·L)
```

**Everything depends on B — and B for the cheap tier has never been measured.**

The proven 200/hr figure was measured with **Chromium page loads**. A browser load is 20–50 HTTP requests; the fast probe is exactly 1 (`http-probe.ts`, one `fetch`). So:

- **If Instagram rate-limits per navigation/document:** B ≈ 200 regardless of tier. The cheap probe buys speed and bytes but **zero cadence**.
- **If it limits per request:** B ≈ 200 × ~30 = **~6,000 fast probes/hour**.

**Current production is already running at 1,067 probes/hour** (20 accounts ÷ 67.5 s mean interval × 3600). That is **5.3× over a 200/hr ceiling** — and it is *not* burning the IP. That is decent circumstantial evidence that B for cheap probes is materially above 200, but it is not a measurement.

### Latency table

| B (probes/hr/IP) | P (IPs) | N | Interval T | **Mean detection** |
|---|---|---|---|---|
| 200 | 1 | 20 | 360 s | **180 s** |
| 1,067 *(today)* | 1 | 20 | 67.5 s | **33.8 s** |
| 6,000 | 1 | 20 | 12 s | **6 s** |
| 6,000 | 1 | 100 | 60 s | **30 s** |
| 6,000 | 4 | 100 | 15 s | **7.5 s** |
| 6,000 | 6 | 100 | 10 s | **5 s** |
| 6,000 | 12 | 20 | 1 s | **0.5 s** |

### The honest answer to "millisecond responses"

**Detection latency is not network-bound. It is bound by IP budget ÷ N.** The 423 ms round trip is *irrelevant* next to a 33.8 s mean polling wait — the network is **0.5%** of the blind window.

Sub-second detection requires `T ≈ 1 s`, i.e. `B·P ≥ 3600·N` = **72,000 probes/hour for 20 accounts** ≈ **12 residential IPs** at B=6000. That is buyable. But even then the *end-to-end* floor is not milliseconds: **1 warm-connection RTT (~0.05–0.4 s) + one confirmation observation + one Telegram send ≈ 2–4 seconds.** That is the real floor, and it is a good number to sell.

### Can detection ever be event-driven? — No, within the constraints.

- **No Instagram push exists** for "public profile became reachable." Graph API webhooks require a Business login on an account you own — prohibited (no programmatic login, no credentials).
- **HEAD requests don't work as a cheaper tier.** The code's own finding (`tiered-detector.ts:470-473`) is that Instagram renders the unavailable copy *client-side*; the discriminator is `og:url`/`og:title`/`canonical` in the body. A status code alone cannot distinguish GONE from ACTIVE. A HEAD also still consumes the same request budget.
- **Third-party mirrors / oEmbed / search caches** shift load off your IP but are stale by hours-to-days. Useful only as a free zero-cost coarse tier layered *underneath* polling, never as the primary.

**Conclusion: polling is the only mechanism available. The arithmetic above is the ceiling. The only two levers are B (probes/hour/IP) and P (number of IPs).**

---

## 4. CODE-BOUND wins, ranked by seconds saved per recovery

### W1 — Delete two guaranteed-to-timeout `networkidle` waits · **saves 15.0 s** · risk: **near zero** ⭐

The project has *already proven* Instagram's `networkidle` never fires (measured 120 s+). Two calls sit on the critical path and can therefore only ever burn their full timeout:

- `src\instagram\browser\browser-manager.ts:246` — `await page.waitForLoadState('networkidle', { timeout: 2500 })`. Fires on **every** browser load: 3 confirmation escalations + 1 capture = **10.0 s**.
- `src\instagram\screenshot\capture.ts:1030` — `await page.waitForLoadState('networkidle', { timeout: 5000 })`. Once per capture = **5.0 s**.

Both are already `.catch(() => undefined)` — they contribute *nothing but delay*. The real settle is the `waitForSelector(...)` on `browser-manager.ts:240-245`, which returns as soon as the header or the unavailable copy attaches. **This is the single best win in the system: 15 seconds for a two-line deletion.**

### W2 — Fast-tier confirmations (escalate only on the final one) · **saves 16.5 s** · risk: **low** ⭐

`tiered-detector.ts:474-484` escalates to a full Chromium load on **every** `identitySignalMatched`. So all three confirmation checks are browser loads (8 s each mean; 5.5 s after W1).

Change to: confirmations 1 and 2 answered by the fast tier; only the **final** confirmation escalates (and the capture always does). Three consecutive-in-time observations are preserved, and a full browser verdict still gates before anyone is told. The code's own note says the fast identity signal measured **8/8 against the browser detector** — and here it is never the last word.

Post-W1 saving: 2 × 5.5 s browser legs replaced by 2 × 0.42 s probes = **~10.2 s**. Pre-W1 baseline: 16.5 s.

### W3 — Cut the poll interval · **saves up to 25 s** · risk: **HIGH, currently unquantified** ⭐

The blind window (33.8 s) is **39% of the whole budget** and it is a pure config number. But it is the *only* term gated on the unmeasured B.

- `60 → 20 s`: saves **20 s mean**; probe rate 1,067 → 3,200/hr
- `60 → 10 s`: saves **25 s mean**; probe rate → 6,400/hr

**Do not ramp blind — that is exactly how the IP was burned at 1,270 checks/hr.** Required experiment (see §6).

**Free component available now:** `BASELINE_JITTER_MAX_SECONDS` **15 → 3**. Saves **6 s mean at zero rate cost**. 15 s of jitter on a 60 s interval buys de-synchronization value a 20-account fleet does not need; `.env.example` already says 2.

### W4 — Shorten the confirmation interval · **saves 6.0 s** · risk: **low**

`CONFIRMATION_INTERVAL_SECONDS` **5 → 2** (`transitions.ts:97` → `nextConfirmationCheckAt`, no jitter). Two gaps × 3 s = 6 s. Instagram recovery is a state flip at their edge, not a flicker; 2 s still gives distinct edge hits. Combine with W2 and the whole burst becomes ~2 s + 0.4 s + 2 s + 5.9 s ≈ **10.3 s**, down from 34.8 s.

### W5 — Cap the screenshot budget on the critical path · **saves 0 s home / up to 22 s slow-egress** · risk: **low**

`SCREENSHOT_BUDGET_MS` **30_000 → 8_000** (`scheduler\worker.ts:59`). Post-W1 a home capture completes in ~5 s, so nothing changes there. On any slow egress the alert goes out **22 s sooner**. The text-first path and `reapMissingScreenshots()` already exist and are well built — this just stops the critical path waiting on a capture that measurement says will not land.

**Higher-reward, higher-risk variant:** enqueue `RECOVERY_TEXT` immediately on the `confirmed` edge and capture asynchronously. Saves the full 5–14 s *always*. Two real costs: (a) the client gets two messages; (b) you lose the `visiblyRendered` gate (`playwright-detector.ts:174-192`) as a pre-send check — that gate genuinely catches login walls and "Something went wrong" pages that classify ACTIVE by identity, so text-first raises false-alert risk. Also `reapMissingScreenshots` is a 5-minute sweep, so you would need to enqueue `SCREENSHOT_FOLLOWUP` directly when the async capture lands. **Recommend W5 as stated; take the variant only if the owner accepts two-message delivery.**

### W6 — Fix the confirmation deadline semantics · **saves 0 s home / unbounded on slow egress** · risk: **low** ⭐

`scheduler\worker.ts:254-258` measures the deadline **per gap** (`now − lastCheckedAtUtc`), not across the burst. `CONFIRMATION_DEADLINE_SECONDS = 30` is *shorter than a single slow browser leg* (mobile: 85–96 s measured). A real recovery is thrown away and re-armed at a fresh 60–75 s baseline — potentially forever. Fix: track `confirmingSinceUtc` and measure from burst start, and/or raise the deadline above `confirmationInterval + checkTimeoutMs`. This is a correctness fix that removes an unbounded-latency tail, not a millisecond win — but on any non-home egress it is the difference between working and not.

### W7 — Real keep-alive on the DIRECT path · **saves 0.8 s** · risk: **low** ⭐

`http-probe.ts:125-141`: `dispatcherFor(null)` returns **`undefined`** for a direct connection, so `fetch` falls through to Node's **global** undici agent — `keepAliveTimeout` **4 seconds**. Production runs `PROXY_MODE=direct` at a **60 s** cadence. **Connection reuse therefore never happens.** Every single probe pays DNS + TCP + a full TLS handshake — roughly 4 RTTs ≈ 150–250 ms on home, 500–800 ms on mobile. The carefully-written `POOL` constant (`http-probe.ts:118-122`, keepAlive 60 s / 300 s, 8 connections) is applied **only when a proxy is configured**.

Fix: build a persistent `undici.Agent({ keepAliveTimeout: 120_000, keepAliveMaxTimeout: 600_000, connections: 8, allowH2: true })` for the direct path too and reuse it across probes.

Per recovery: ~0.8 s home, ~2–3 s mobile. **The strategic value is larger than the number**: it lowers the *cost* of W3's shorter cadence, and it collapses three separate items on the brief into one fix —

- **DNS caching**: free. With a warm pool there is no new connection, so no lookup.
- **TLS session resumption**: free. Session tickets are reused inside a pooled agent.
- **HTTP/2**: `allowH2: true` on the Agent. Warm h2 connection → a probe becomes ~1 RTT + server think time.
- **HTTP/3 / QUIC**: not available — Node has no production QUIC client. Skip.
- **Conditional requests (`If-None-Match`)**: dead end. Instagram serves profile HTML `no-store`, and the probe *itself* sends `Cache-Control: no-cache, Pragma: no-cache` (`http-probe.ts:59-60`). No ETag to condition on.

### W8 — Stop reading 32 KB of body on the ACTIVE path · **saves 0.05–0.15 s home, 0.15–0.5 s mobile** · risk: **low**

`BODY_PEEK_BYTES = 32 * 1024` (`http-probe.ts:70`) is read past `</head>` on **every** probe, but its only purpose is recognizing throttle/interstitial copy **when identity is absent**. On the recovery path (identity present) it is pure waste. Change: stop reading the instant an `og:url`/`canonical` matching the username is seen in `<head>`; keep the full head+body read whenever identity is missing. Small per-probe, but it cuts bytes on ~1,000 probes/hour — which is what proxies bill on, and what the rate limiter counts.

### W9 — Parallelize the claimed-case loop · **saves 0 s quiet / 5–40 s whenever anything escalates** · risk: **low-medium** ⭐

`scheduler\worker.ts:189-197` is a **serial** `for (const c of claimed) { await this.processCase(c) }` over up to `maxBrowserConcurrency = 4` claimed cases, and `start()` skips a tick while `inFlight !== null` (`worker.ts:204`). One browser escalation (5.5 s post-W1, or 15–115 s on mobile) blocks the other three claimed cases **and every subsequent tick**.

`BrowserManager` already has its own semaphore bounded by the same `maxBrowserConcurrency` (`browser-manager.ts:275-293`), so the outer serialization is **redundant**. Replace with a bounded `Promise.all`. At N=20 on a quiet fleet this saves nothing; it is a **hard prerequisite for scaling N**, and it removes the head-of-line stall that hits precisely when a recovery is being confirmed. Pair with W3's measurement — it raises instantaneous request rate.

### W10 — Outbox tick 1500 → 300 ms · **saves 0.6 s** · risk: **low**

`app.ts:56`. Mean pickup 750 ms → 150 ms. `requeueStale` runs every tick (an UPDATE with a WHERE) — cheap on SQLite/WAL; verify on Postgres before shipping.

### W11 — Reorder the sends so the paying client is not last · **saves 0.9–3.0 s** · risk: **low (half) / medium (full)**

`outbox\worker.ts:240-276`, in order: owner `sendPhoto` → DB writes → **Discord mirror upload** → **client delivery**. The client — the person the latency promise is actually about — is dead last, behind a second full image upload.

- **Low-risk half-measure:** move `discord.unban(...)` to *after* `deliverToClient(...)`. Saves **0.9 s** at essentially zero risk; Discord is explicitly best-effort and never throws.
- **Full version:** `Promise.allSettled` the owner and client sends. Saves ~1–3 s, but `rescueStrandedClientDeliveries` (`outbox\worker.ts:418-435`) keys off `ownerAlerted` being SENT before it will rescue a client. That invariant must be reworked first.

### W12 — Make the retry ladder honest · **saves 0 s today, prevents a 15-minute regression** · risk: **low**

See §0. `RETRY_DELAYS_SECONDS=120,300,600,900` is inert because `ERROR_BACKOFF_MAX_SECONDS` defaults to 30. Either set the ladder to what is actually wanted, or set `ERROR_BACKOFF_MAX_SECONDS` explicitly — but **do not** set it to 900 without understanding it creates a 15-minute detection hole.

### W13 — Hazard-weighted cadence · **the scaling lever** · risk: **low technically**

Poll accounts in proportion to their probability of recovering *right now* (time since appeal filed, historical unban windows) rather than uniformly. With a 5:1 concentration on the hot subset, hot accounts get ~5× shorter intervals **at identical total IP spend**. Given the arithmetic in §3 — where latency is IP-budget-divided-by-N — this is the **only** way to buy sub-10 s detection for the accounts that matter without buying IPs. Requires the owner to record appeal timestamps.

---

## 5. Cumulative effect

Applying W1, W2, W4, W7, W10, W11-half, and the jitter half of W3 — **no cadence change, no meaningful false-positive risk added**:

| Term | Now | After | Δ |
|---|---|---|---|
| Blind window | 33.8 s | 30.8 s | −3.0 |
| Tick quantization | 1.5 s | 1.5 s | — |
| Probe RTTs (keep-alive) | 1.7 s | 0.9 s | −0.8 |
| Browser confirmation legs | 24.0 s | 5.5 s | −18.5 |
| Confirmation gaps | 10.0 s | 4.0 s | −6.0 |
| Screenshot capture | 12.5 s | 5.0 s | −7.5 |
| Outbox pickup | 0.75 s | 0.15 s | −0.6 |
| Sends (owner/Discord/client) | 2.7 s | 1.8 s | −0.9 |
| **TOTAL** | **~87 s** | **~50 s** | **−37 s (−43%)** |

**Then the blind window is 30.8 s = 62% of everything that remains**, and it can only be reduced by raising probes/hour.

| Configuration | Mean end-to-end |
|---|---|
| Today | **~87 s** |
| After W1/W2/W4/W7/W10/W11 (no cadence change) | **~50 s** |
| + cadence 10 s (needs ~6,400 probes/hr on 1 IP — **unverified**) | **~13 s** |
| + cadence 2 s (needs ~36,000 probes/hr ≈ 6 IPs at B=6000) | **~5 s** |
| Absolute floor: warm h2 connection, 1 confirmation, 1 Telegram send | **~2–4 s** |

---

## 6. The one experiment that must run before any provider is researched

**Measure B — the fast-probe rate ceiling per IP — against LIVE accounts.**

Everything in §3 pivots on it, and it has never been measured. The 200/hr figure came from browser loads. The protocol, following the discipline already learned the hard way:

1. Use **LIVE control accounts only**, never banned ones. (Proven lesson: Singapore and US static residential looked healthy against banned accounts while being completely blind — they still returned correct GONE. Only a live profile distinguishes "serving" from "walled.")
2. The pass/fail signal is `evidence.identitySignalMatched` on a **live** profile — the same discriminator `tiered-detector.ts:474` uses.
3. Ramp fast-probe rate on the home IP: 200 → 500 → 1,000 → 2,000 → 4,000 → 8,000 probes/hour, ~20 minutes per step, watching for the identity signal to start failing or `isThrottleSignal` codes to appear.
4. Stop at the **first** degradation. Do not push through it — that is how the IP was burned.
5. Run this **after W7** (persistent keep-alive), so you are measuring the request pattern you will actually ship.

The number that falls out of that experiment tells you, via `P = 1800·N / (B·L)`, exactly how many residential IPs the owner must buy to hit any given latency target at any given N. **That is the real answer to "find me the best and fastest VPS/proxy" — the question is not which provider, it is how many IPs, and that number is unanswerable until B is measured.**

---

## Files referenced (absolute paths)

```
C:\Users\fazea\monitor bot\.env                                        # production config
C:\Users\fazea\monitor bot\.env.example                                # disagrees with .env
C:\Users\fazea\monitor bot\src\config\config.ts                        # defaults, esp. ERROR_BACKOFF_MAX_SECONDS=30
C:\Users\fazea\monitor bot\src\app\app.ts                              # :55-57 tick intervals
C:\Users\fazea\monitor bot\src\monitoring\scheduling.ts                # :60-72 baseline, :84-90 the clamp bug
C:\Users\fazea\monitor bot\src\monitoring\state-machine\transitions.ts # :75-118 confirmation burst
C:\Users\fazea\monitor bot\src\monitoring\scheduler\worker.ts          # :59 budget, :189-197 serial loop, :254-258 deadline, :486-608 capture-blocks-alert
C:\Users\fazea\monitor bot\src\notifications\outbox\worker.ts          # :136 tick, :240-276 send ordering
C:\Users\fazea\monitor bot\src\instagram\detector\tiered-detector.ts   # :474-484 every confirmation escalates
C:\Users\fazea\monitor bot\src\instagram\detector\http-probe.ts        # :70 body peek, :118-141 pool never used on direct
C:\Users\fazea\monitor bot\src\instagram\browser\browser-manager.ts    # :246 dead networkidle
C:\Users\fazea\monitor bot\src\instagram\screenshot\capture.ts         # :1030 dead networkidle
C:\Users\fazea\monitor bot\src\instagram\detector\playwright-detector.ts # :174-192 visiblyRendered gate
```