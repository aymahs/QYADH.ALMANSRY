/**
 * Create the bot's Instagram session — WITHOUT the bot (or Claude) ever handling your
 * credentials. This opens a real, visible Chrome window at Instagram's login page; YOU log in
 * by hand (manual login is much less bot-detectable than auto-filling). When your feed loads,
 * press Enter here and it saves the authenticated session to `instagram-auth.json`.
 *
 * Then point the bot at it:  set  IG_STORAGE_STATE=./instagram-auth.json  in .env  and restart.
 *
 * Run:  npm run login
 *
 * SECURITY: `instagram-auth.json` IS your login (session cookies). It's gitignored — never
 * commit it, never paste it anywhere, never put it on a datacenter/cloud host. Local use only.
 * Instagram's ToS discourages automated access; your account, your risk. Sessions expire — re-run
 * this when the bot starts hitting login walls again.
 */
import { createInterface } from 'node:readline';
import { chromium } from 'playwright';

const OUTPUT = 'instagram-auth.json';

function waitForEnter(prompt: string): Promise<void> {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(prompt, () => resolve(rl.close())));
}

async function main(): Promise<void> {
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto('https://www.instagram.com/accounts/login/', { waitUntil: 'domcontentloaded' });

  console.log('\n──────────────────────────────────────────────────────────────');
  console.log('  A Chrome window is open. Log in to Instagram BY HAND there.');
  console.log('  (Complete any 2FA / "save login" prompts until your feed loads.)');
  console.log('──────────────────────────────────────────────────────────────');
  await waitForEnter('\n  When you are fully logged in, press Enter here to save the session… ');

  await context.storageState({ path: OUTPUT });
  console.log(`\n✅ Saved session to ${OUTPUT}`);
  console.log(`   Next: add  IG_STORAGE_STATE=./${OUTPUT}  to .env, then restart the bot.`);
  console.log('   Keep this file secret — it is your login.\n');

  await browser.close();
  process.exit(0);
}

main().catch((e) => {
  console.error('save-login failed:', (e as Error)?.message);
  process.exit(1);
});
