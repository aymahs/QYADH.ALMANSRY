# Windows-primary heartbeat and consistent SQLite snapshot sender.
#
# This script is intentionally ONE cycle. Install it as a non-overlapping scheduled task every
# 60 seconds; its named mutex also rejects accidental overlap. It never copies monitor.sqlite
# directly. Snapshots are made through deploy\ha-snapshot.mjs (SQLite online backup + integrity
# check), uploaded under unique names, and published by renaming the manifest last.

[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [ValidatePattern('^[A-Za-z0-9.:[\]-]+$')]
  [string]$VpsHost,

  [ValidatePattern('^[a-z_][a-z0-9_-]*$')]
  [string]$VpsUser = 'monitorbot',

  [Parameter(Mandatory = $true)]
  [string]$SshKeyPath,

  [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot),

  [ValidatePattern('^/[A-Za-z0-9._/-]+$')]
  [string]$RemoteHaDir = '/opt/monitor-bot/data/ha',

  [string]$DatabasePath = '',

  [string]$NodePath = '',

  [ValidateRange(1, 60)]
  [int]$SnapshotEveryCycles = 5,

  [ValidateRange(1, 65535)]
  [int]$HealthPort = 8080,

  [string]$MonitorTaskName = 'InstagramUnbanMonitor'
)

$ErrorActionPreference = 'Stop'

function Write-Utf8NoBomAtomic {
  param([string]$Path, [string]$Text)
  $parent = Split-Path -Parent $Path
  New-Item -ItemType Directory -Force -Path $parent | Out-Null
  $temp = "$Path.partial-$PID-$([guid]::NewGuid().ToString('N'))"
  $encoding = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($temp, $Text, $encoding)
  Move-Item -Force -LiteralPath $temp -Destination $Path
}

function Read-JsonOrNull {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { return $null }
  try { return (Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json) } catch { return $null }
}

function Invoke-CheckedNative {
  param([string]$Program, [string[]]$Arguments)
  $output = & $Program @Arguments
  if ($LASTEXITCODE -ne 0) {
    throw "$([System.IO.Path]::GetFileName($Program)) exited $LASTEXITCODE"
  }
  return $output
}

$resolvedRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$resolvedKey = (Resolve-Path -LiteralPath $SshKeyPath).Path
if ($DatabasePath -eq '') { $DatabasePath = Join-Path $resolvedRoot 'data\monitor.sqlite' }
$resolvedDb = (Resolve-Path -LiteralPath $DatabasePath).Path
if ($NodePath -eq '') {
  $candidate = Join-Path $env:LOCALAPPDATA 'hermes\node\node.exe'
  $NodePath = if (Test-Path -LiteralPath $candidate) { $candidate } else { (Get-Command node).Source }
}
$resolvedNode = (Resolve-Path -LiteralPath $NodePath).Path
$snapshotTool = Join-Path $resolvedRoot 'deploy\ha-snapshot.mjs'
if (-not (Test-Path -LiteralPath $snapshotTool)) { throw "Missing $snapshotTool" }

$ssh = (Get-Command ssh.exe).Source
$scp = (Get-Command scp.exe).Source
$target = "$VpsUser@$VpsHost"
# ConnectTimeout alone bounds only the TCP handshake. Once a session is ESTABLISHED and then
# stalls — a dropped NAT mapping, a sleeping link, a half-open connection — ssh waits forever with
# no timer of any kind. That is not hypothetical: on 2026-08-03 this agent hung for 105 minutes on
# an established session, so no heartbeat reached the VPS, the channel aged past the 12-minute
# guard, and the VPS took over from a PC that was in fact perfectly healthy. Keepalives give the
# stall a deadline (~15 s) so the cycle FAILS and the next one retries, which is recoverable;
# hanging forever is not.
$sshOptions = @(
  '-i', $resolvedKey,
  '-o', 'BatchMode=yes',
  '-o', 'StrictHostKeyChecking=yes',
  '-o', 'ConnectTimeout=10',
  '-o', 'ServerAliveInterval=5',
  '-o', 'ServerAliveCountMax=3'
)
$localHaDir = Join-Path $resolvedRoot 'data\ha'
$outgoing = Join-Path $localHaDir 'outgoing'
$statePath = Join-Path $localHaDir 'pc-agent-state.json'
$rolePath = Join-Path $localHaDir 'role.json'
New-Item -ItemType Directory -Force -Path $outgoing | Out-Null

# A second scheduled invocation exits instead of racing sequence numbers or remote atomic renames.
$mutex = New-Object System.Threading.Mutex($false, 'Local\InstagramMonitorHaSync')
$ownsMutex = $false
try {
  $ownsMutex = $mutex.WaitOne(0)
  if (-not $ownsMutex) { exit 0 }

  $prior = Read-JsonOrNull $statePath
  $agentBootId = if ($null -ne $prior -and $prior.agentBootId -is [string]) {
    $prior.agentBootId
  } else {
    [guid]::NewGuid().ToString('N')
  }
  $seq = if ($null -ne $prior -and $null -ne $prior.seq) { [int64]$prior.seq + 1 } else { 1 }
  $lastSnapshot = if ($null -ne $prior) { $prior.lastSnapshot } else { $null }
  $healthFailureStreak = if ($null -ne $prior -and $null -ne $prior.healthFailureStreak) {
    [int]$prior.healthFailureStreak
  } else { 0 }

  # Reserve the sequence before any network work. A crash after a remote manifest commit but
  # before the final state write must advance on the next run, never publish different snapshots
  # under one (agentBootId, seq) identity.
  Write-Utf8NoBomAtomic $statePath (([ordered]@{
    version = 1
    agentBootId = $agentBootId
    seq = $seq
    healthFailureStreak = $healthFailureStreak
    lastSnapshot = $lastSnapshot
    lastAttemptUtc = [DateTime]::UtcNow.ToString('o')
    lastSuccessUtc = if ($null -ne $prior) { $prior.lastSuccessUtc } else { $null }
  } | ConvertTo-Json -Depth 5 -Compress) + "`n")

  $role = Read-JsonOrNull $rolePath
  $pcRole = if ($null -ne $role -and $role.role -in @('ACTIVE', 'STANDBY', 'STANDDOWN')) {
    [string]$role.role
  } else { 'ACTIVE' }

  # If the fallback already owns the role, fence this PC before it can keep polling Telegram or
  # Instagram after a reboot/resume. An unreachable VPS does NOT revoke the PC role here; that
  # two-node partition trade-off is documented in docs/HA-FAILOVER.md.
  try {
    $remoteRoleRaw = Invoke-CheckedNative $ssh ($sshOptions + @(
      $target,
      "test -f '$RemoteHaDir/role.json' && cat '$RemoteHaDir/role.json' || true"
    ))
    $remoteRoleText = ($remoteRoleRaw -join "`n").Trim()
    if ($remoteRoleText -ne '') {
      $remoteRole = $remoteRoleText | ConvertFrom-Json
      if ($remoteRole.role -eq 'ACTIVE') {
        $pcRole = 'STANDBY'
        Write-Utf8NoBomAtomic $rolePath (([ordered]@{
          role = 'STANDBY'; updatedAtUtc = [DateTime]::UtcNow.ToString('o'); reason = 'vps-active'
        } | ConvertTo-Json -Compress) + "`n")
        try { Stop-ScheduledTask -TaskName $MonitorTaskName -ErrorAction Stop } catch {
          Write-Warning "VPS is ACTIVE but the local monitor task could not be stopped: $($_.Exception.Message)"
        }
      }
    }
  } catch {
    Write-Warning "Could not read the VPS role this cycle: $($_.Exception.Message)"
  }

  # Calling the real endpoint advances scheduler_health.__ping__ INSIDE the bot event loop.
  $healthOk = $false
  try {
    $health = Invoke-RestMethod -Uri "http://127.0.0.1:$HealthPort/healthz" -TimeoutSec 10
    $healthOk = $health.ok -eq $true
  } catch { $healthOk = $false }
  $healthFailureStreak = if ($healthOk) { 0 } else { $healthFailureStreak + 1 }

  $inspectRaw = Invoke-CheckedNative $resolvedNode @($snapshotTool, 'inspect', '--db', $resolvedDb)
  $inspect = (($inspectRaw -join "`n") | ConvertFrom-Json)

  # A compressed full snapshot every N cycles bounds data loss without copying a live WAL file.
  $needSnapshot = $null -eq $lastSnapshot -or ($seq % $SnapshotEveryCycles) -eq 0 -or $pcRole -eq 'STANDDOWN'
  if ($needSnapshot) {
    $base = "snapshot-$agentBootId-$seq"
    $archive = Join-Path $outgoing "$base.sqlite.gz"
    $manifest = Join-Path $outgoing "$base.json"
    try {
      $createRaw = Invoke-CheckedNative $resolvedNode @(
        $snapshotTool, 'create', '--db', $resolvedDb, '--archive', $archive,
        '--manifest', $manifest, '--seq', "$seq", '--agent-boot-id', $agentBootId
      )
      $created = (($createRaw -join "`n") | ConvertFrom-Json)

      # Archive ready first, manifest ready last. The watchdog treats the manifest as the commit.
      $remoteArchivePartial = "$RemoteHaDir/incoming/$base.sqlite.gz.partial"
      $remoteArchiveReady = "$RemoteHaDir/incoming/$base.sqlite.gz.ready"
      $remoteManifestPartial = "$RemoteHaDir/incoming/$base.json.partial"
      $remoteManifestReady = "$RemoteHaDir/incoming/$base.json.ready"
      Invoke-CheckedNative $scp ($sshOptions + @($archive, "${target}:$remoteArchivePartial")) | Out-Null
      Invoke-CheckedNative $ssh ($sshOptions + @($target, "mv -f -- '$remoteArchivePartial' '$remoteArchiveReady'")) | Out-Null
      Invoke-CheckedNative $scp ($sshOptions + @($manifest, "${target}:$remoteManifestPartial")) | Out-Null
      Invoke-CheckedNative $ssh ($sshOptions + @($target, "mv -f -- '$remoteManifestPartial' '$remoteManifestReady'")) | Out-Null
      $lastSnapshot = [ordered]@{
        seq = [int64]$created.seq
        agentBootId = [string]$created.agentBootId
        createdAtUtc = [string]$created.createdAtUtc
        archiveSha256 = [string]$created.archiveSha256
      }
    } finally {
      # These are transient staging files. The remote verified history is retained independently.
      Remove-Item -Force -ErrorAction SilentlyContinue -LiteralPath $archive, $manifest
    }
  }

  $heartbeat = [ordered]@{
    version = 1
    agentBootId = $agentBootId
    seq = $seq
    generatedAtUtc = [DateTime]::UtcNow.ToString('o')
    pcRole = $pcRole
    healthRequestOk = $healthOk
    healthFailureStreak = $healthFailureStreak
    liveness = [ordered]@{
      # Copied verbatim. Never substitute generatedAtUtc here: a dead bot must stay frozen.
      procUtc = $inspect.liveness.procUtc
      schedUtc = $inspect.liveness.schedUtc
    }
    lastSnapshot = $lastSnapshot
  }
  $heartbeatPath = Join-Path $outgoing "heartbeat-$agentBootId-$seq.json"
  Write-Utf8NoBomAtomic $heartbeatPath (($heartbeat | ConvertTo-Json -Depth 6 -Compress) + "`n")
  $remoteHeartbeatPartial = "$RemoteHaDir/incoming/heartbeat-$agentBootId-$seq.json.partial"
  Invoke-CheckedNative $scp ($sshOptions + @($heartbeatPath, "${target}:$remoteHeartbeatPartial")) | Out-Null
  Invoke-CheckedNative $ssh ($sshOptions + @(
    $target,
    "mv -f -- '$remoteHeartbeatPartial' '$RemoteHaDir/pc-heartbeat.json'"
  )) | Out-Null
  Remove-Item -Force -LiteralPath $heartbeatPath

  $state = [ordered]@{
    version = 1
    agentBootId = $agentBootId
    seq = $seq
    healthFailureStreak = $healthFailureStreak
    lastSnapshot = $lastSnapshot
    lastSuccessUtc = [DateTime]::UtcNow.ToString('o')
  }
  Write-Utf8NoBomAtomic $statePath (($state | ConvertTo-Json -Depth 5 -Compress) + "`n")
} finally {
  if ($ownsMutex) { $mutex.ReleaseMutex() }
  $mutex.Dispose()
}
