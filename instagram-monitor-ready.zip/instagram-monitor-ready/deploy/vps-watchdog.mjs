/* global process */
/**
 * Linux standby executor. `ha-decide.mjs` decides; this file gathers facts and performs only the
 * returned action. Run through vps-watchdog.sh under `flock`, once per minute.
 */

import { spawnSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { constants as fsConstants, promises as fs } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { decide } from './ha-decide.mjs';
import { restoreSnapshot, verifyDatabase } from './ha-snapshot.mjs';

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));
const APP_DIR = resolve(process.env.MONITOR_HA_APP_DIR ?? join(SCRIPT_DIR, '..'));
const DATA_DIR = resolve(process.env.MONITOR_HA_DATA_DIR ?? join(APP_DIR, 'data'));
const HA_DIR = resolve(process.env.MONITOR_HA_DIR ?? join(DATA_DIR, 'ha'));
const INCOMING_DIR = join(HA_DIR, 'incoming');
const SNAPSHOT_DIR = join(HA_DIR, 'snapshots');
const ROLLBACK_DIR = join(HA_DIR, 'rollback');
const HEARTBEAT_PATH = join(HA_DIR, 'pc-heartbeat.json');
const STATE_PATH = join(HA_DIR, 'watchdog-state.json');
const ROLE_PATH = join(HA_DIR, 'role.json');
const HANDOVER_LOCK_PATH = join(HA_DIR, 'handover.lock');
const LATEST_PATH = join(HA_DIR, 'latest.json');
const ACTIVE_DB = resolve(process.env.MONITOR_HA_ACTIVE_DB ?? join(DATA_DIR, 'monitor.sqlite'));
const SERVICE = process.env.MONITOR_HA_SERVICE ?? 'monitor-bot.service';
const MONITOR_USER = process.env.MONITOR_HA_SERVICE_USER ?? 'monitorbot';
const SNAPSHOTS_TO_KEEP = 5;

function log(level, msg, fields = {}) {
  process.stdout.write(
    JSON.stringify({ ts: new Date().toISOString(), level, msg, ...fields }) + '\n',
  );
}

async function readJson(path) {
  try {
    return JSON.parse(await fs.readFile(path, 'utf8'));
  } catch {
    return null;
  }
}

async function writeJsonAtomic(path, value) {
  await fs.mkdir(dirname(path), { recursive: true });
  const temp = `${path}.partial-${process.pid}-${randomUUID()}`;
  await fs.writeFile(temp, JSON.stringify(value) + '\n', { encoding: 'utf8', flag: 'wx' });
  await fs.rename(temp, path);
}

function command(program, args, { allowFailure = false } = {}) {
  const out = spawnSync(program, args, { encoding: 'utf8' });
  if (!allowFailure && out.status !== 0) {
    throw new Error(`${program} ${args.join(' ')} failed (${out.status}): ${out.stderr.trim()}`);
  }
  return out;
}

function serviceActive() {
  return (
    command('systemctl', ['is-active', '--quiet', SERVICE], { allowFailure: true }).status === 0
  );
}

function service(action) {
  command('systemctl', [action, SERVICE]);
}

function safeSnapshotName(value) {
  return typeof value === 'string' && /^snapshot-[A-Za-z0-9_-]+-\d+\.(sqlite|json)$/.test(value);
}

async function promoteIncomingSnapshots() {
  await fs.mkdir(INCOMING_DIR, { recursive: true });
  await fs.mkdir(SNAPSHOT_DIR, { recursive: true });
  const entries = await fs.readdir(INCOMING_DIR);
  const manifests = entries.filter((name) => /^snapshot-.+\.json\.ready$/.test(name));
  // Process oldest first and advance `current` after every promotion. readdir() order is not a
  // contract; without this, two snapshots arriving between watchdog ticks could promote newest
  // first and then move the pointer backwards to the older one in the same cycle.
  const orderedManifests = await Promise.all(
    manifests.map(async (name) => ({
      name,
      mtimeMs: (await fs.stat(join(INCOMING_DIR, name))).mtimeMs,
    })),
  );
  orderedManifests.sort((a, b) => a.mtimeMs - b.mtimeMs || a.name.localeCompare(b.name));
  let current = await readJson(LATEST_PATH);

  for (const { name: manifestReady } of orderedManifests) {
    const base = manifestReady.slice(0, -'.json.ready'.length);
    const identity = /^snapshot-([A-Za-z0-9_-]+)-(\d+)$/.exec(base);
    if (identity === null) continue;
    const archiveReady = `${base}.sqlite.gz.ready`;
    if (!entries.includes(archiveReady)) continue; // archive transfer has not committed yet
    const manifestPath = join(INCOMING_DIR, manifestReady);
    const archivePath = join(INCOMING_DIR, archiveReady);
    const manifest = await readJson(manifestPath);
    if (manifest === null) {
      log('error', 'discarding malformed incoming snapshot manifest', { manifestReady });
      await fs.rm(manifestPath, { force: true });
      continue;
    }

    const filenameAgent = identity[1];
    const filenameSeq = Number(identity[2]);
    const createdAtMs = Date.parse(manifest.createdAtUtc);
    const identityMatches =
      manifest.agentBootId === filenameAgent &&
      Number.isSafeInteger(manifest.seq) &&
      manifest.seq === filenameSeq &&
      Number.isFinite(createdAtMs);
    if (!identityMatches) {
      log('error', 'discarding snapshot whose manifest identity does not match its filename', {
        manifestReady,
      });
      await fs.rm(manifestPath, { force: true });
      await fs.rm(archivePath, { force: true });
      continue;
    }

    const sameAgent = current?.agentBootId === manifest.agentBootId;
    const olderForSameAgent =
      sameAgent && Number.isFinite(current?.seq) && Number(manifest.seq) <= Number(current.seq);
    // A different agent id means the PC agent state was lost/reinitialized, not merely restarted.
    // Its sequence cannot be compared with the previous epoch, so use the PC-created snapshot
    // time to stop a delayed file from an older epoch moving the pointer backwards. If the prior
    // pointer itself has no valid time, preserve it and require operator repair rather than guess.
    const currentCreatedAtMs = Date.parse(current?.createdAtUtc);
    const olderForDifferentAgent =
      current !== null &&
      !sameAgent &&
      (!Number.isFinite(currentCreatedAtMs) || createdAtMs <= currentCreatedAtMs);
    if (olderForSameAgent || olderForDifferentAgent) {
      await fs.rm(manifestPath, { force: true });
      await fs.rm(archivePath, { force: true });
      continue;
    }

    const dbFile = `${base}.sqlite`;
    const manifestFile = `${base}.json`;
    const restoredPath = join(SNAPSHOT_DIR, dbFile);
    const promotedManifestPath = join(SNAPSHOT_DIR, manifestFile);
    try {
      await restoreSnapshot({ archivePath, manifestPath, outPath: restoredPath });
      await fs.copyFile(manifestPath, promotedManifestPath, fsConstants.COPYFILE_EXCL);
      const received = {
        version: 1,
        agentBootId: manifest.agentBootId,
        seq: manifest.seq,
        createdAtUtc: manifest.createdAtUtc,
        receivedAtUtc: new Date().toISOString(),
        dbFile,
        manifestFile,
        liveness: manifest.liveness,
      };
      // The pointer is the commit. A crash before this leaves an unreferenced but harmless file;
      // a crash after it leaves a complete verified pair under unique names.
      await writeJsonAtomic(LATEST_PATH, received);
      current = received;
      log('info', 'promoted verified PC snapshot', { seq: manifest.seq, dbFile });
    } catch (err) {
      log('error', 'incoming snapshot failed verification; previous snapshot preserved', {
        manifestReady,
        error: err instanceof Error ? err.message : String(err),
      });
      await fs.rm(restoredPath, { force: true });
      await fs.rm(promotedManifestPath, { force: true });
    } finally {
      await fs.rm(manifestPath, { force: true });
      await fs.rm(archivePath, { force: true });
    }
  }

  // Retain a small rollback tail. Only complete SQLite files are considered, never partials.
  const snapshots = (await fs.readdir(SNAPSHOT_DIR, { withFileTypes: true }))
    .filter((entry) => entry.isFile() && entry.name.endsWith('.sqlite'))
    .map((entry) => entry.name);
  const withTimes = await Promise.all(
    snapshots.map(async (name) => ({
      name,
      mtimeMs: (await fs.stat(join(SNAPSHOT_DIR, name))).mtimeMs,
    })),
  );
  withTimes.sort((a, b) => b.mtimeMs - a.mtimeMs);
  const latest = await readJson(LATEST_PATH);
  for (const stale of withTimes.slice(SNAPSHOTS_TO_KEEP)) {
    if (stale.name === latest?.dbFile) continue;
    await fs.rm(join(SNAPSHOT_DIR, stale.name), { force: true });
    await fs.rm(join(SNAPSHOT_DIR, stale.name.replace(/\.sqlite$/, '.json')), { force: true });
  }
}

async function ageMs(path, nowMs) {
  try {
    return Math.max(0, nowMs - (await fs.stat(path)).mtimeMs);
  } catch {
    return null;
  }
}

async function writeRole(role, reason) {
  await writeJsonAtomic(ROLE_PATH, {
    version: 1,
    role,
    reason,
    updatedAtUtc: new Date().toISOString(),
  });
  await fs.chmod(ROLE_PATH, 0o644);
}

async function ownershipForService(path) {
  const uid = Number(command('id', ['-u', MONITOR_USER]).stdout.trim());
  const gid = Number(command('id', ['-g', MONITOR_USER]).stdout.trim());
  if (!Number.isInteger(uid) || !Number.isInteger(gid))
    throw new Error('could not resolve service uid/gid');
  await fs.chown(path, uid, gid);
  await fs.chmod(path, 0o660);
}

async function installLatestSnapshot() {
  const latest = await readJson(LATEST_PATH);
  if (
    latest === null ||
    !safeSnapshotName(latest.dbFile) ||
    !safeSnapshotName(latest.manifestFile)
  ) {
    throw new Error('no verified PC snapshot is available for takeover');
  }
  const source = join(SNAPSHOT_DIR, latest.dbFile);
  const manifest = await readJson(join(SNAPSHOT_DIR, latest.manifestFile));
  if (manifest === null) throw new Error('latest snapshot manifest is missing');
  const verified = verifyDatabase(source);
  if (JSON.stringify(verified.liveness) !== JSON.stringify(manifest.liveness)) {
    throw new Error('latest snapshot no longer matches its manifest');
  }

  await fs.mkdir(dirname(ACTIVE_DB), { recursive: true });
  await fs.mkdir(ROLLBACK_DIR, { recursive: true });
  const staged = `${ACTIVE_DB}.takeover-${process.pid}-${randomUUID()}.partial`;
  await fs.copyFile(source, staged, fsConstants.COPYFILE_EXCL);
  verifyDatabase(staged);
  const handle = await fs.open(staged, 'r');
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
  await ownershipForService(staged);

  // The service is stopped before this function is called, so WAL/SHM can be archived as a unit.
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  for (const suffix of ['', '-wal', '-shm']) {
    const current = `${ACTIVE_DB}${suffix}`;
    try {
      await fs.rename(current, join(ROLLBACK_DIR, `monitor.sqlite${suffix}.${stamp}`));
    } catch (err) {
      if (err?.code !== 'ENOENT') throw err;
    }
  }
  await fs.rename(staged, ACTIVE_DB);
  log('warn', 'installed verified PC snapshot for VPS takeover', {
    seq: latest.seq,
    snapshotCreatedAtUtc: latest.createdAtUtc,
  });
}

async function main() {
  await fs.mkdir(HA_DIR, { recursive: true });
  await promoteIncomingSnapshots();
  const nowMs = Date.now();
  const heartbeat = await readJson(HEARTBEAT_PATH);
  const state = await readJson(STATE_PATH);
  const role = await readJson(ROLE_PATH);
  const active = serviceActive();
  const verdict = decide({
    nowMs,
    heartbeat,
    heartbeatMtimeMs:
      (await ageMs(HEARTBEAT_PATH, nowMs)) === null
        ? null
        : (await fs.stat(HEARTBEAT_PATH)).mtimeMs,
    state,
    vpsRole: typeof role?.role === 'string' ? role.role : null,
    serviceActive: active,
    handoverLockAgeMs: await ageMs(HANDOVER_LOCK_PATH, nowMs),
  });
  await writeJsonAtomic(STATE_PATH, verdict.state);
  log(verdict.action === 'TAKEOVER' ? 'warn' : 'info', 'HA decision', {
    action: verdict.action,
    reason: verdict.reason,
    detail: verdict.detail,
    ages: verdict.ages,
  });

  if (verdict.action === 'HOLD') {
    // HOLD means "do not acquire the role", not "allow an unowned bot to keep running". This
    // covers the install grace window and the channel-uncertain split-brain guard.
    if (active && role?.role !== 'ACTIVE') {
      log('error', 'non-active VPS had a running monitor service during HOLD; fencing it now');
      service('stop');
    }
    return;
  }
  if (verdict.action === 'ALREADY_ACTIVE') return;
  if (verdict.action === 'STAND_BY') {
    if (active) {
      log('error', 'standby role had a running monitor service; fencing it now');
      service('stop');
    }
    await writeRole('STANDBY', verdict.reason);
    return;
  }

  // TAKEOVER. Stop first even if the role file claimed standby: no snapshot is ever installed
  // under a live SQLite writer.
  if (active) service('stop');
  if (verdict.installSnapshot) await installLatestSnapshot();
  service('start');
  if (!serviceActive()) throw new Error('monitor service did not become active after takeover');
  // Publish ownership LAST. If start fails, the PC never sees a false ACTIVE claim and remains
  // available to retry/repair instead of standing down for a dead fallback.
  await writeRole('ACTIVE', verdict.reason);
  log('warn', 'VPS is ACTIVE and monitor service is running', { reason: verdict.reason });
}

const invokedDirectly =
  process.argv[1] !== undefined && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  main().catch((err) => {
    log('error', 'VPS watchdog cycle failed', {
      error: err instanceof Error ? err.message : String(err),
    });
    process.exit(1);
  });
}

export { promoteIncomingSnapshots };
