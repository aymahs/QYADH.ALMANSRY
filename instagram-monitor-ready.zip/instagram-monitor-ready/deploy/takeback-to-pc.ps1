# Deliberate VPS -> Windows handback transaction. This script is never scheduled automatically.
# It stops the VPS writer, transfers a verified SQLite snapshot, swaps only while the PC writer is
# stopped, starts and verifies the PC, forces a fresh PC snapshot back to the VPS, then unlocks.

[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [ValidatePattern('^[A-Za-z0-9.:[\]-]+$')]
  [string]$VpsHost,

  [ValidatePattern('^[a-z_][a-z0-9_-]*$')]
  [string]$VpsUser = 'monitorbot',

  [Parameter(Mandatory = $true)]
  [string]$SshKeyPath,

  [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot),

  [ValidatePattern('^/[A-Za-z0-9._/-]+$')]
  [string]$RemoteAppDir = '/opt/monitor-bot',

  [ValidatePattern('^/[A-Za-z0-9._/-]+$')]
  [string]$RemoteHaDir = '/opt/monitor-bot/data/ha',

  [ValidatePattern('^/[A-Za-z0-9._/-]+$')]
  [string]$RemoteDatabasePath = '/opt/monitor-bot/data/monitor.sqlite',

  [ValidatePattern('^[A-Za-z0-9_.@-]+$')]
  [string]$RemoteService = 'monitor-bot.service',

  [string]$DatabasePath = '',

  [string]$NodePath = '',

  [ValidateRange(1, 65535)]
  [int]$HealthPort = 8080,

  [string]$MonitorTaskName = 'InstagramUnbanMonitor'
)

$ErrorActionPreference = 'Stop'

function Write-Utf8NoBomAtomic {
  param([string]$Path, [string]$Text)
  $parent = Split-Path -Parent $Path
  New-Item -ItemType Directory -Force -Path $parent | Out-Null
  $temp = "$Path.partial-$PID-$([guid]::NewGuid().ToString('N'))"
  $encoding = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($temp, $Text, $encoding)
  Move-Item -Force -LiteralPath $temp -Destination $Path
}

function Read-JsonOrNull {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { return $null }
  try { return (Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json) } catch { return $null }
}

function Invoke-CheckedNative {
  param([string]$Program, [string[]]$Arguments)
  $output = & $Program @Arguments
  if ($LASTEXITCODE -ne 0) {
    throw "$([System.IO.Path]::GetFileName($Program)) exited $LASTEXITCODE"
  }
  return $output
}

function Test-Health {
  param([int]$Port)
  try {
    $result = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/healthz" -TimeoutSec 3
    return $result.ok -eq $true
  } catch { return $false }
}

function Assert-UnderRoot {
  param([string]$Path, [string]$Root)
  $full = [System.IO.Path]::GetFullPath($Path)
  $prefix = [System.IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
  if (-not $full.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing database path outside the project root: $full"
  }
  return $full
}

$resolvedRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$resolvedKey = (Resolve-Path -LiteralPath $SshKeyPath).Path
if ($DatabasePath -eq '') { $DatabasePath = Join-Path $resolvedRoot 'data\monitor.sqlite' }
$resolvedDb = Assert-UnderRoot $DatabasePath $resolvedRoot
if (-not (Test-Path -LiteralPath $resolvedDb)) { throw "Database not found: $resolvedDb" }
if ($NodePath -eq '') {
  $candidate = Join-Path $env:LOCALAPPDATA 'hermes\node\node.exe'
  $NodePath = if (Test-Path -LiteralPath $candidate) { $candidate } else { (Get-Command node).Source }
}
$resolvedNode = (Resolve-Path -LiteralPath $NodePath).Path
$snapshotTool = Join-Path $resolvedRoot 'deploy\ha-snapshot.mjs'
$syncTool = Join-Path $resolvedRoot 'deploy\sync-to-vps.ps1'
if (-not (Test-Path -LiteralPath $snapshotTool)) { throw "Missing $snapshotTool" }
if (-not (Test-Path -LiteralPath $syncTool)) { throw "Missing $syncTool" }

$ssh = (Get-Command ssh.exe).Source
$scp = (Get-Command scp.exe).Source
$powershell = (Get-Command powershell.exe).Source
$target = "$VpsUser@$VpsHost"
$sshOptions = @(
  '-i', $resolvedKey,
  '-o', 'BatchMode=yes',
  '-o', 'StrictHostKeyChecking=yes',
  '-o', 'ConnectTimeout=10',
  # See sync-to-vps.ps1: without keepalives a stalled-but-established session hangs forever, and
  # here that would strand a handover with the VPS stopped and the PC not yet started.
  '-o', 'ServerAliveInterval=5',
  '-o', 'ServerAliveCountMax=3'
)

function Invoke-Remote {
  param([string]$Command)
  return Invoke-CheckedNative $ssh ($sshOptions + @($target, $Command))
}

function Set-RemoteRole {
  param([ValidateSet('ACTIVE', 'STANDBY')][string]$Role, [string]$Reason)
  $json = ([ordered]@{
    version = 1
    role = $Role
    reason = $Reason
    updatedAtUtc = [DateTime]::UtcNow.ToString('o')
  } | ConvertTo-Json -Compress)
  # Base64 through the wire, decoded remotely. Embedding the JSON directly in the command line
  # let the Windows-ssh -> remote-shell quoting chain STRIP its double quotes, so the file arrived
  # as {version:1,role:STANDBY,...} — unparseable. The PC admission then threw (fenced), the VPS
  # watchdog saw a running service without a provable ACTIVE role and fenced ITS OWN service, and
  # both hosts went dark at once: a total monitoring outage manufactured by a quoting layer.
  # Base64 is alphanumeric+/= only, which survives every layer unchanged.
  $b64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($json + "`n"))
  $partial = "$RemoteHaDir/role.json.partial-$handoverId"
  Invoke-Remote "printf '%s' '$b64' | base64 -d > '$partial' && mv -f -- '$partial' '$RemoteHaDir/role.json'" | Out-Null
  # Read back and parse. A role file only one side can read is exactly the failure being repaired,
  # so prove BOTH sides see the same verdict before continuing the handover.
  $readBack = (Invoke-Remote "cat '$RemoteHaDir/role.json'") -join "`n"
  if (($readBack.Trim() | ConvertFrom-Json).role -ne $Role) {
    throw "Remote role write verification failed: expected $Role"
  }
}

$localHaDir = Join-Path $resolvedRoot 'data\ha'
$incomingDir = Join-Path $localHaDir 'takeback-incoming'
$rollbackRoot = Join-Path $localHaDir 'rollback'
$localRolePath = Join-Path $localHaDir 'role.json'
New-Item -ItemType Directory -Force -Path $incomingDir, $rollbackRoot | Out-Null

$handoverId = [guid]::NewGuid().ToString('N')
$handoverStartedUtc = [DateTime]::UtcNow
$seq = [int64](($handoverStartedUtc - [DateTime]'1970-01-01').TotalMilliseconds)
$base = "snapshot-vps-$handoverId-$seq"
$localArchive = Join-Path $incomingDir "$base.sqlite.gz"
$localManifest = Join-Path $incomingDir "$base.json"
$stagedDb = "$resolvedDb.takeback-$handoverId.partial"
$rollbackSet = Join-Path $rollbackRoot "pc-before-takeback-$handoverId"
$remoteTransferDir = "$RemoteHaDir/takeback"
$remoteArchive = "$remoteTransferDir/$base.sqlite.gz"
$remoteManifest = "$remoteTransferDir/$base.json"
$remoteServiceStopped = $false
$localDbBackedUp = $false
$swapped = $false
$localStarted = $false
$success = $false

$mutex = New-Object System.Threading.Mutex($false, 'Local\InstagramMonitorHaTakeback')
$ownsMutex = $false
try {
  $ownsMutex = $mutex.WaitOne(0)
  if (-not $ownsMutex) { throw 'Another HA takeback is already running.' }

  $remoteRoleRaw = Invoke-Remote "test -f '$RemoteHaDir/role.json' && cat '$RemoteHaDir/role.json' || true"
  $remoteRoleText = ($remoteRoleRaw -join "`n").Trim()
  if ($remoteRoleText -eq '' -or ($remoteRoleText | ConvertFrom-Json).role -ne 'ACTIVE') {
    throw 'Refusing takeback because the VPS does not currently claim ACTIVE.'
  }

  $lockJson = ([ordered]@{
    version = 1
    handoverId = $handoverId
    owner = 'pc-takeback'
    createdAtUtc = $handoverStartedUtc.ToString('o')
  } | ConvertTo-Json -Compress)
  # Same base64 transport as Set-RemoteRole, for the same reason: inline JSON loses its quotes
  # crossing the Windows-ssh -> remote-shell boundary.
  $lockB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($lockJson + "`n"))
  $lockPartial = "$RemoteHaDir/handover.lock.partial-$handoverId"
  Invoke-Remote "printf '%s' '$lockB64' | base64 -d > '$lockPartial' && mv -f -- '$lockPartial' '$RemoteHaDir/handover.lock'" | Out-Null

  Invoke-Remote "sudo -n systemctl stop '$RemoteService'" | Out-Null
  $remoteServiceStopped = $true
  Invoke-Remote "if systemctl is-active --quiet '$RemoteService'; then exit 41; fi" | Out-Null

  Invoke-Remote "mkdir -p '$remoteTransferDir' && /usr/bin/node '$RemoteAppDir/deploy/ha-snapshot.mjs' create --db '$RemoteDatabasePath' --archive '$remoteArchive' --manifest '$remoteManifest' --seq '$seq' --agent-boot-id 'vps-$handoverId'" | Out-Null
  Invoke-CheckedNative $scp ($sshOptions + @("${target}:$remoteArchive", $localArchive)) | Out-Null
  Invoke-CheckedNative $scp ($sshOptions + @("${target}:$remoteManifest", $localManifest)) | Out-Null

  $restoreRaw = Invoke-CheckedNative $resolvedNode @(
    $snapshotTool, 'restore', '--archive', $localArchive, '--manifest', $localManifest,
    '--out', $stagedDb
  )
  $restored = (($restoreRaw -join "`n") | ConvertFrom-Json)
  $beforeSchedUtc = $restored.liveness.schedUtc

  try { Stop-ScheduledTask -TaskName $MonitorTaskName -ErrorAction Stop } catch {
    throw "Could not stop the local monitor task: $($_.Exception.Message)"
  }
  for ($i = 0; $i -lt 30 -and (Test-Health $HealthPort); $i += 1) {
    Start-Sleep -Seconds 1
  }
  if (Test-Health $HealthPort) { throw 'Local /healthz still answers; refusing to swap a live database.' }

  New-Item -ItemType Directory -Path $rollbackSet | Out-Null
  foreach ($suffix in @('', '-wal', '-shm')) {
    $current = "$resolvedDb$suffix"
    if (Test-Path -LiteralPath $current) {
      Move-Item -LiteralPath $current -Destination (Join-Path $rollbackSet "monitor.sqlite$suffix")
    }
  }
  $localDbBackedUp = $true
  Move-Item -LiteralPath $stagedDb -Destination $resolvedDb
  $swapped = $true

  # The PC admission wrapper requires both facts: local ACTIVE and remote not ACTIVE.
  Set-RemoteRole 'STANDBY' 'takeback-to-pc'
  Write-Utf8NoBomAtomic $localRolePath (([ordered]@{
    version = 1
    role = 'ACTIVE'
    reason = 'verified-vps-takeback-snapshot-installed'
    updatedAtUtc = [DateTime]::UtcNow.ToString('o')
  } | ConvertTo-Json -Compress) + "`n")

  Start-ScheduledTask -TaskName $MonitorTaskName -ErrorAction Stop
  $localStarted = $true
  $healthy = $false
  $advancedSchedUtc = $null
  for ($i = 0; $i -lt 180; $i += 1) {
    if (Test-Health $HealthPort) {
      $inspectRaw = Invoke-CheckedNative $resolvedNode @($snapshotTool, 'inspect', '--db', $resolvedDb)
      $inspect = (($inspectRaw -join "`n") | ConvertFrom-Json)
      $advancedSchedUtc = $inspect.liveness.schedUtc
      if ($null -ne $advancedSchedUtc -and $advancedSchedUtc -ne $beforeSchedUtc) {
        $healthy = $true
        break
      }
    }
    Start-Sleep -Seconds 1
  }
  if (-not $healthy) { throw 'PC did not produce both /healthz and a new scheduler tick within 180 seconds.' }

  # Close the rollback gap before releasing the lock: force an immediate snapshot from the now
  # ACTIVE PC back to the VPS and prove the remote pointer has moved onto (or past) it.
  #
  # UPLOAD ONCE, THEN POLL. The remote pointer is moved by the VPS watchdog, which runs at most
  # once a minute — but the previous shape of this gate re-ran the sync on every retry, and each
  # re-run minted a NEW snapshot sequence with SnapshotEveryCycles=1. The pointer could therefore
  # never catch up to the value being demanded of it: the gate moved its own goalposts, timed out
  # while the handover had actually succeeded, and pushed a healthy takeback into rollback.
  #
  # The pointer is accepted at the uploaded seq OR NEWER from the same agent: the regular 60s sync
  # task keeps running during this window, and a later sequence from this PC is strictly stronger
  # evidence that a post-takeback snapshot is committed.
  $syncedBack = $false
  for ($attempt = 0; $attempt -lt 2 -and -not $syncedBack; $attempt += 1) {
    & $powershell -NoProfile -ExecutionPolicy Bypass -File $syncTool `
      -VpsHost $VpsHost -VpsUser $VpsUser -SshKeyPath $resolvedKey `
      -ProjectRoot $resolvedRoot -RemoteHaDir $RemoteHaDir -DatabasePath $resolvedDb `
      -NodePath $resolvedNode -SnapshotEveryCycles 1 -HealthPort $HealthPort `
      -MonitorTaskName $MonitorTaskName
    if ($LASTEXITCODE -ne 0) { Start-Sleep -Seconds 10; continue }

    # 15 polls x 10s spans at least two watchdog promotion cycles.
    for ($poll = 0; $poll -lt 15 -and -not $syncedBack; $poll += 1) {
      # Re-read local state each poll: the 60s sync task may legitimately advance it meanwhile.
      $pcState = Read-JsonOrNull (Join-Path $localHaDir 'pc-agent-state.json')
      $freshEnough =
        $null -ne $pcState -and
        $null -ne $pcState.lastSnapshot -and
        [DateTime]::Parse([string]$pcState.lastSnapshot.createdAtUtc).ToUniversalTime() -ge $handoverStartedUtc
      if ($freshEnough) {
        $latestRaw = Invoke-Remote "test -f '$RemoteHaDir/latest.json' && cat '$RemoteHaDir/latest.json' || true"
        $latestText = ($latestRaw -join "`n").Trim()
        $latest = if ($latestText -ne '') { $latestText | ConvertFrom-Json } else { $null }
        $syncedBack =
          $null -ne $latest -and
          $latest.agentBootId -eq $pcState.lastSnapshot.agentBootId -and
          [int64]$latest.seq -ge [int64]$pcState.lastSnapshot.seq
      }
      if (-not $syncedBack) { Start-Sleep -Seconds 10 }
    }
  }
  if (-not $syncedBack) { throw 'PC is healthy, but its post-takeback snapshot was not committed on the VPS.' }

  Invoke-Remote "rm -f -- '$RemoteHaDir/handover.lock'" | Out-Null
  $success = $true
  [ordered]@{
    ok = $true
    activeHost = 'PC'
    schedulerUtc = $advancedSchedUtc
    localRollbackDirectory = $rollbackSet
    remoteTakebackSnapshot = $remoteArchive
  } | ConvertTo-Json -Compress
} catch {
  $original = $_.Exception.Message
  $recoveryErrors = New-Object System.Collections.Generic.List[string]

  if ($localStarted -or $localDbBackedUp) {
    try { Stop-ScheduledTask -TaskName $MonitorTaskName -ErrorAction Stop } catch {
      $recoveryErrors.Add("stop PC: $($_.Exception.Message)")
    }
  }
  if ($localDbBackedUp) {
    try {
      $failedSet = Join-Path $rollbackRoot "failed-takeback-$handoverId"
      New-Item -ItemType Directory -Force -Path $failedSet | Out-Null
      foreach ($suffix in @('', '-wal', '-shm')) {
        $current = "$resolvedDb$suffix"
        if (Test-Path -LiteralPath $current) {
          Move-Item -LiteralPath $current -Destination (Join-Path $failedSet "monitor.sqlite$suffix")
        }
        $old = Join-Path $rollbackSet "monitor.sqlite$suffix"
        if (Test-Path -LiteralPath $old) { Move-Item -LiteralPath $old -Destination $current }
      }
    } catch { $recoveryErrors.Add("restore old PC database: $($_.Exception.Message)") }
  }
  try {
    Write-Utf8NoBomAtomic $localRolePath (([ordered]@{
      version = 1
      role = 'STANDBY'
      reason = 'takeback-rolled-back'
      updatedAtUtc = [DateTime]::UtcNow.ToString('o')
    } | ConvertTo-Json -Compress) + "`n")
  } catch { $recoveryErrors.Add("fence PC role: $($_.Exception.Message)") }

  if ($remoteServiceStopped) {
    try {
      Invoke-Remote "sudo -n systemctl start '$RemoteService'" | Out-Null
      Invoke-Remote "systemctl is-active --quiet '$RemoteService'" | Out-Null
      Set-RemoteRole 'ACTIVE' 'takeback-rolled-back'
    } catch { $recoveryErrors.Add("restart VPS: $($_.Exception.Message)") }
  }
  try { Invoke-Remote "rm -f -- '$RemoteHaDir/handover.lock'" | Out-Null } catch {
    $recoveryErrors.Add("remove handover lock: $($_.Exception.Message)")
  }

  $recovery = if ($recoveryErrors.Count -eq 0) { 'rollback succeeded' } else {
    'rollback errors: ' + ($recoveryErrors -join '; ')
  }
  throw "Takeback failed: $original ($recovery)"
} finally {
  if (-not $success) { Remove-Item -Force -ErrorAction SilentlyContinue -LiteralPath $stagedDb }
  Remove-Item -Force -ErrorAction SilentlyContinue -LiteralPath $localArchive, $localManifest
  if ($ownsMutex) { $mutex.ReleaseMutex() }
  $mutex.Dispose()
}
