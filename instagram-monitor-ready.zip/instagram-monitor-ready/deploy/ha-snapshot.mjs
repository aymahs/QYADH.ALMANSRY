/* global process */
/**
 * Consistent SQLite snapshot tooling shared by the Windows primary and Linux standby.
 *
 * Never copy `monitor.sqlite` with an ordinary file copy while the bot is running. In WAL mode,
 * committed pages may still live in `monitor.sqlite-wal`; copying only the main file can produce
 * an old or inconsistent database. `createSnapshot` uses SQLite's online backup API, validates the
 * resulting standalone file, then compresses it. `restoreSnapshot` verifies the archive hash,
 * decompresses to a unique staging path and runs `PRAGMA integrity_check` before anything may
 * promote it.
 */

import { createHash, randomUUID } from 'node:crypto';
import { createReadStream, createWriteStream, existsSync, promises as fs } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createGunzip, createGzip } from 'node:zlib';
import { pipeline } from 'node:stream/promises';
import Database from 'better-sqlite3';

const SNAPSHOT_VERSION = 1;

function nonEmpty(value, name) {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${name} is required`);
  return value.trim();
}

function integer(value, name) {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 0) throw new Error(`${name} must be >= 0`);
  return parsed;
}

function tempBeside(path) {
  return `${path}.partial-${process.pid}-${randomUUID()}`;
}

async function removeQuietly(path) {
  await fs.rm(path, { force: true }).catch(() => undefined);
}

async function sha256(path) {
  const hash = createHash('sha256');
  await pipeline(createReadStream(path), hash);
  return hash.digest('hex');
}

function readLiveness(db) {
  try {
    const proc = db
      .prepare(`SELECT updated_at_utc FROM scheduler_health WHERE name = '__ping__'`)
      .get();
    const sched = db
      .prepare(`SELECT last_scheduler_run_utc FROM scheduler_health WHERE name = 'scheduler'`)
      .get();
    return {
      procUtc:
        typeof proc?.updated_at_utc === 'string' && proc.updated_at_utc !== ''
          ? proc.updated_at_utc
          : null,
      schedUtc:
        typeof sched?.last_scheduler_run_utc === 'string' && sched.last_scheduler_run_utc !== ''
          ? sched.last_scheduler_run_utc
          : null,
    };
  } catch {
    // A pre-migration or damaged schema has no trustworthy liveness. The snapshot verifier still
    // decides integrity separately; null can never be interpreted as life by ha-decide.mjs.
    return { procUtc: null, schedUtc: null };
  }
}

/** Read the two bot-produced liveness values without mutating the database. */
export async function inspectDatabase(dbPath) {
  const absolute = resolve(nonEmpty(dbPath, 'db'));
  const db = new Database(absolute, { readonly: true, fileMustExist: true });
  try {
    return {
      version: SNAPSHOT_VERSION,
      inspectedAtUtc: new Date().toISOString(),
      liveness: readLiveness(db),
      sizeBytes: (await fs.stat(absolute)).size,
    };
  } finally {
    db.close();
  }
}

/** Full SQLite integrity check plus the liveness values carried by this standalone file. */
export function verifyDatabase(dbPath) {
  const absolute = resolve(nonEmpty(dbPath, 'db'));
  const db = new Database(absolute, { readonly: true, fileMustExist: true });
  try {
    const rows = db.pragma('integrity_check');
    const ok =
      Array.isArray(rows) &&
      rows.length === 1 &&
      rows[0] !== null &&
      typeof rows[0] === 'object' &&
      Object.values(rows[0])[0] === 'ok';
    if (!ok) throw new Error('SQLite integrity_check failed');
    return { liveness: readLiveness(db), userVersion: db.pragma('user_version', { simple: true }) };
  } finally {
    db.close();
  }
}

/**
 * Build a compressed, self-describing snapshot. Archive and manifest paths must be unique; this
 * function refuses to overwrite either, so a failed cycle cannot destroy the previous good copy.
 */
export async function createSnapshot({ dbPath, archivePath, manifestPath, seq, agentBootId }) {
  const source = resolve(nonEmpty(dbPath, 'db'));
  const archive = resolve(nonEmpty(archivePath, 'archive'));
  const manifestFile = resolve(nonEmpty(manifestPath, 'manifest'));
  const sequence = integer(seq, 'seq');
  const bootId = nonEmpty(agentBootId, 'agentBootId');
  if (!/^[A-Za-z0-9_-]+$/.test(bootId)) {
    throw new Error('agentBootId may contain only letters, digits, underscore and hyphen');
  }
  if (source === archive || source === manifestFile || archive === manifestFile) {
    throw new Error('db, archive and manifest paths must be different');
  }
  if (existsSync(archive) || existsSync(manifestFile)) {
    throw new Error('refusing to overwrite an existing snapshot output');
  }

  await fs.mkdir(dirname(archive), { recursive: true });
  await fs.mkdir(dirname(manifestFile), { recursive: true });
  const standalone = tempBeside(archive) + '.sqlite';
  const archiveTemp = tempBeside(archive);
  const manifestTemp = tempBeside(manifestFile);
  const db = new Database(source, { readonly: true, fileMustExist: true });
  try {
    // SQLite's backup API reads the live WAL transactionally and produces one standalone DB.
    await db.backup(standalone);
  } finally {
    db.close();
  }

  try {
    const verified = verifyDatabase(standalone);
    await pipeline(
      createReadStream(standalone),
      createGzip({ level: 6 }),
      createWriteStream(archiveTemp, { flags: 'wx' }),
    );
    const stat = await fs.stat(archiveTemp);
    const manifest = {
      version: SNAPSHOT_VERSION,
      seq: sequence,
      agentBootId: bootId,
      createdAtUtc: new Date().toISOString(),
      archiveSha256: await sha256(archiveTemp),
      archiveBytes: stat.size,
      liveness: verified.liveness,
      sqliteUserVersion: verified.userVersion,
    };
    await fs.writeFile(manifestTemp, JSON.stringify(manifest) + '\n', {
      encoding: 'utf8',
      flag: 'wx',
    });
    // Archive first, manifest last. A receiver can therefore treat the manifest as the ready flag.
    await fs.rename(archiveTemp, archive);
    await fs.rename(manifestTemp, manifestFile);
    return manifest;
  } finally {
    await removeQuietly(standalone);
    await removeQuietly(archiveTemp);
    await removeQuietly(manifestTemp);
  }
}

/** Verify and decompress an archive to a new standalone SQLite file. Never overwrites `outPath`. */
export async function restoreSnapshot({ archivePath, manifestPath, outPath }) {
  const archive = resolve(nonEmpty(archivePath, 'archive'));
  const manifestFile = resolve(nonEmpty(manifestPath, 'manifest'));
  const output = resolve(nonEmpty(outPath, 'out'));
  if (existsSync(output)) throw new Error('refusing to overwrite restore output');

  const manifest = JSON.parse(await fs.readFile(manifestFile, 'utf8'));
  if (manifest?.version !== SNAPSHOT_VERSION) throw new Error('unsupported snapshot version');
  if (
    typeof manifest.archiveSha256 !== 'string' ||
    !/^[a-f0-9]{64}$/.test(manifest.archiveSha256)
  ) {
    throw new Error('manifest has no valid archive hash');
  }
  const stat = await fs.stat(archive);
  if (stat.size !== manifest.archiveBytes) throw new Error('snapshot archive size mismatch');
  if ((await sha256(archive)) !== manifest.archiveSha256) {
    throw new Error('snapshot archive sha256 mismatch');
  }

  await fs.mkdir(dirname(output), { recursive: true });
  const outputTemp = tempBeside(output);
  try {
    await pipeline(
      createReadStream(archive),
      createGunzip(),
      createWriteStream(outputTemp, { flags: 'wx' }),
    );
    const verified = verifyDatabase(outputTemp);
    if (JSON.stringify(verified.liveness) !== JSON.stringify(manifest.liveness)) {
      throw new Error('restored snapshot liveness does not match its manifest');
    }
    await fs.rename(outputTemp, output);
    return { manifest, ...verified, sizeBytes: (await fs.stat(output)).size };
  } finally {
    await removeQuietly(outputTemp);
  }
}

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 2) {
    const key = argv[i];
    const value = argv[i + 1];
    if (typeof key !== 'string' || !key.startsWith('--') || value === undefined) {
      throw new Error('arguments must be --name value pairs');
    }
    out[key.slice(2)] = value;
  }
  return out;
}

async function main() {
  const command = process.argv[2];
  const args = parseArgs(process.argv.slice(3));
  let result;
  if (command === 'inspect') {
    result = await inspectDatabase(args.db);
  } else if (command === 'create') {
    result = await createSnapshot({
      dbPath: args.db,
      archivePath: args.archive,
      manifestPath: args.manifest,
      seq: args.seq,
      agentBootId: args['agent-boot-id'],
    });
  } else if (command === 'restore') {
    result = await restoreSnapshot({
      archivePath: args.archive,
      manifestPath: args.manifest,
      outPath: args.out,
    });
  } else {
    throw new Error('usage: ha-snapshot.mjs inspect|create|restore --name value ...');
  }
  process.stdout.write(JSON.stringify(result) + '\n');
}

const invokedDirectly =
  process.argv[1] !== undefined && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  main().catch((err) => {
    process.stderr.write(`ha-snapshot: ${err instanceof Error ? err.message : String(err)}\n`);
    process.exit(2);
  });
}
