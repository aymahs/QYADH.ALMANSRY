# Scheduled-task entrypoint for the Windows primary after HA is installed. It performs the remote
# role admission once before handing control to the existing long-running run-monitor.ps1.

[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [ValidatePattern('^[A-Za-z0-9.:[\]-]+$')]
  [string]$VpsHost,

  [ValidatePattern('^[a-z_][a-z0-9_-]*$')]
  [string]$VpsUser = 'monitorbot',

  [Parameter(Mandatory = $true)]
  [string]$SshKeyPath,

  [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot),

  [ValidatePattern('^/[A-Za-z0-9._/-]+$')]
  [string]$RemoteHaDir = '/opt/monitor-bot/data/ha',

  [ValidateRange(10, 300)]
  [int]$StandbyPollSeconds = 30
)

$ErrorActionPreference = 'Continue'
$resolvedRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$admission = Join-Path $resolvedRoot 'deploy\pc-admission.ps1'
$supervisor = Join-Path $resolvedRoot 'run-monitor.ps1'
$logDir = Join-Path $resolvedRoot 'logs'
$log = Join-Path $logDir 'ha-primary.log'
$powershell = (Get-Command powershell.exe).Source
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

while ($true) {
  & $powershell -NoProfile -ExecutionPolicy Bypass -File $admission `
    -VpsHost $VpsHost -VpsUser $VpsUser -SshKeyPath $SshKeyPath `
    -ProjectRoot $resolvedRoot -RemoteHaDir $RemoteHaDir
  $admissionCode = $LASTEXITCODE
  if ($admissionCode -eq 0) {
    "$(Get-Date -Format o) [ha-primary] admission granted; starting supervisor" |
      Out-File -Append -Encoding utf8 $log
    & $supervisor
    "$(Get-Date -Format o) [ha-primary] supervisor returned; rechecking role in 10s" |
      Out-File -Append -Encoding utf8 $log
    Start-Sleep -Seconds 10
    continue
  }

  "$(Get-Date -Format o) [ha-primary] fenced (admission exit $admissionCode); retrying in $StandbyPollSeconds seconds" |
    Out-File -Append -Encoding utf8 $log
  Start-Sleep -Seconds $StandbyPollSeconds
}
