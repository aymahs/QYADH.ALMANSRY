#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${MONITOR_HA_APP_DIR:-/opt/monitor-bot}"
NODE_BIN="${MONITOR_HA_NODE_BIN:-/usr/bin/node}"
LOCK_FILE="${MONITOR_HA_LOCK_FILE:-/run/lock/instagram-monitor-ha.lock}"

cd "$APP_DIR"
exec 9>"$LOCK_FILE"
if ! /usr/bin/flock -n 9; then
  # A previous slow cycle still owns the lock. Skipping is expected, not a failed systemd unit.
  exit 0
fi
exec "$NODE_BIN" "$APP_DIR/deploy/vps-watchdog.mjs"
