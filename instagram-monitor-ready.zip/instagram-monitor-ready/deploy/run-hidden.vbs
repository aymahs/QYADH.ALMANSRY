' Launch a PowerShell script with NO console window.
'
' Task Scheduler running powershell.exe under an interactive logon pops a console window every
' time it fires — once a minute for the HA heartbeat, which is a visible flash on the desktop all
' day. wscript.exe belongs to the WINDOWS subsystem (not the console subsystem), so when Task
' Scheduler launches THIS instead, no console is ever attached; WshShell.Run with window-style 0
' then starts PowerShell already hidden, so there is not even a brief flash.
'
' Usage: wscript run-hidden.vbs "<script.ps1>" [args...]
' Every argument after the script path is forwarded verbatim; only arguments containing spaces are
' re-quoted, so parameter switches like -VpsHost stay recognisable to PowerShell.
Option Explicit
Dim sh, args, cmd, i, a
Set sh = CreateObject("WScript.Shell")
Set args = WScript.Arguments
cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File"
For i = 0 To args.Count - 1
  a = args(i)
  If InStr(a, " ") > 0 Then a = """" & a & """"
  cmd = cmd & " " & a
Next
' 0 = hidden window; True = wait, so the task stays "running" for the sync's ~3s and its
' ExecutionTimeLimit backstop and single-instance policy still apply.
sh.Run cmd, 0, True
