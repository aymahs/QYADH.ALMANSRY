#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Instagram monitoring — VPS IP viability test (standalone, no repo needed).
#
# Paste this whole thing into a fresh Ubuntu VPS as root. It installs Node +
# Chromium, then answers ONE question: will Instagram monitoring actually work
# from this machine's IP, logged OUT?
#
#   USABLE      -> deploy here, run logged-out, nothing at risk.
#   NOT USABLE  -> datacenter IP is gated; you need a residential/mobile proxy.
# ---------------------------------------------------------------------------
set -euo pipefail

echo "==> Installing Node 20 + Chromium (2-3 min)…"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
apt-get install -y -qq nodejs >/dev/null
mkdir -p /root/ig-test && cd /root/ig-test
npm init -y >/dev/null 2>&1
npm install --silent playwright@1.48.0 >/dev/null 2>&1
npx playwright install --with-deps chromium >/dev/null 2>&1
echo "==> Ready. Running probe…"

cat > /root/ig-test/test.mjs <<'NODEEOF'
import { chromium } from 'playwright';

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) ' +
  'Chrome/124.0.0.0 Safari/537.36';
const USER = process.argv[2] ?? 'instagram';
const bar = () => console.log('-'.repeat(66));

const browser = await chromium.launch({
  headless: true,
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
});
const ctx = await browser.newContext({
  viewport: { width: 1280, height: 900 },
  userAgent: UA,
  locale: 'en-US',
});
ctx.setDefaultTimeout(25000);

bar();
console.log('  INSTAGRAM MONITORING — VPS IP VIABILITY TEST');
bar();

// 1. What IP / network does the outside world see?
let dc = false;
try {
  const p = await ctx.newPage();
  await p.goto('https://ipinfo.io/json', { waitUntil: 'domcontentloaded', timeout: 15000 });
  const info = JSON.parse(await p.evaluate(() => document.body.innerText));
  dc =
    /amazon|google|microsoft|azure|hetzner|ovh|digitalocean|linode|vultr|contabo|oracle|hostinger|colo|hosting|datacenter|data center|leaseweb|m247|scaleway/i.test(
      info.org ?? '',
    );
  console.log(`Exit IP   : ${info.ip}  (${info.city ?? '?'}, ${info.country ?? '?'})`);
  console.log(`Network   : ${info.org ?? '?'}`);
  console.log(`IP class  : ${dc ? 'DATACENTER / hosting ASN' : 'looks residential / ISP / mobile'}`);
  await p.close();
} catch (e) {
  console.log(`Exit IP   : lookup failed (${e.message})`);
}
bar();

// 2. Logged-out probe of a known-good public profile — the real question.
const page = await ctx.newPage();
const t0 = Date.now();
let status = null;
try {
  const res = await page.goto(`https://www.instagram.com/${USER}/`, {
    waitUntil: 'domcontentloaded',
    timeout: 25000,
  });
  status = res ? res.status() : null;
} catch (e) {
  console.log(`Navigation failed: ${e.message}`);
}
await page
  .waitForSelector('header, main img, :text("this page isn\'t available")', {
    timeout: 8000,
    state: 'attached',
  })
  .catch(() => {});
await page.waitForLoadState('networkidle', { timeout: 2500 }).catch(() => {});

const ev = await page.evaluate((u) => {
  const meta = (p) => document.querySelector(`meta[property="${p}"]`)?.content ?? '';
  const canonical = document.querySelector('link[rel="canonical"]')?.href ?? '';
  const text = document.body?.innerText ?? '';
  return {
    url: location.href,
    ogUrl: meta('og:url'),
    ogTitle: meta('og:title'),
    canonical,
    hasHeader: !!document.querySelector('header'),
    unavailable: /page isn.t available|Sorry, this page/i.test(text),
    loginish:
      /log in|sign up/i.test(text.slice(0, 400)) ||
      /accounts\/login|\/challenge/i.test(location.href),
    identity:
      new RegExp(`instagram\\.com/${u}/?$`, 'i').test(canonical) ||
      new RegExp(`instagram\\.com/${u}/?$`, 'i').test(meta('og:url')) ||
      new RegExp(`\\(@${u}\\)`, 'i').test(meta('og:title')),
  };
}, USER);

const shot = await page.screenshot().catch(() => null);
const secs = ((Date.now() - t0) / 1000).toFixed(1);
const redirected = /accounts\/login|\/challenge/i.test(ev.url);
const ACTIVE = ev.identity && !ev.unavailable && !redirected;

console.log('LOGGED-OUT probe');
console.log(`  HTTP status   : ${status}`);
console.log(`  Final URL     : ${ev.url}`);
console.log(`  og:url        : ${ev.ogUrl || '(none)'}`);
console.log(`  canonical     : ${ev.canonical || '(none)'}`);
console.log(`  Profile match : ${ev.identity ? 'yes' : 'NO'}`);
console.log(`  Unavailable   : ${ev.unavailable ? 'yes' : 'no'}`);
console.log(`  Login wall    : ${redirected ? 'YES (redirected)' : ev.loginish ? 'likely' : 'no'}`);
console.log(`  Header render : ${ev.hasHeader ? 'yes' : 'no'}`);
console.log(`  Screenshot    : ${shot ? shot.length + ' bytes' : 'failed'}`);
console.log(`  Took          : ${secs}s`);
bar();
console.log('  VERDICT');
bar();
if (ACTIVE) {
  console.log('USABLE  — logged-out detection works from this IP.');
  console.log('          Deploy here. No Instagram account needed, nothing to maintain.');
} else if (redirected || ev.loginish) {
  console.log('NOT USABLE — Instagram serves this IP a login wall.');
  console.log('          Every check would return UNKNOWN. You need a residential/mobile');
  console.log('          proxy in front of it (BROWSER_PROXY_SERVER), or a different host.');
} else {
  console.log('INCONCLUSIVE — page loaded but no identity signal matched.');
  console.log('          Check the og:url / canonical values above.');
}
bar();

await browser.close();
process.exit(ACTIVE ? 0 : 1);
NODEEOF

node /root/ig-test/test.mjs "${1:-instagram}"
