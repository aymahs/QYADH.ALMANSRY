/* global process */
/**
 * THE takeover decision. Given what the VPS can observe, should the VPS start the bot?
 *
 * This file is deliberately a PURE FUNCTION plus a thin stdin/stdout shim, and it is deliberately
 * separate from `vps-watchdog.sh`. The shell around it does process control (flock, systemctl,
 * sqlite, scp) which cannot be unit-tested honestly; this is the part that decides whether the
 * owner's clients are monitored or not, so it is the part that gets tested. `test/unit/ha-decide.test.ts`
 * exercises THIS FILE by executing it, not a re-implementation of it.
 *
 * ---------------------------------------------------------------------------------------------
 * THE ONE PROPERTY EVERYTHING ELSE HANGS OFF
 *
 * A dead bot must not be able to look alive.
 *
 * The PC agent copies two timestamps VERBATIM out of the PC's sqlite file into the heartbeat; it
 * has no code path that writes "now" into either. Both are produced by the BOT PROCESS ITSELF:
 *
 *   procUtc  - `scheduler_health` row `__ping__`, advanced only when the bot's own /healthz
 *              handler executes `db.ping()` inside the bot's event loop.
 *   schedUtc - `scheduler_health` row `scheduler`, advanced by MonitorWorker.recordSchedulerRun
 *              as the first statement of every scheduling pass.
 *
 * This function then decides on CHANGE, not on freshness: it remembers the last value it saw plus
 * the moment (on the VPS's own clock) that value last changed. An agent that keeps pushing while
 * the bot is dead pushes a FROZEN value, and a frozen value does not move the change clock. The
 * failure mode the brief called out - "a helper script that keeps writing while the bot is dead
 * would make the VPS stay passive forever" - is therefore unreachable by construction rather than
 * by convention. Measuring the change on the VPS's clock is also what makes the whole decision
 * immune to clock skew between the two hosts: the PC's timestamps are only ever compared with
 * THEMSELVES.
 *
 * ---------------------------------------------------------------------------------------------
 * WHY POSITIVE EVIDENCE AND ABSENCE OF EVIDENCE GET DIFFERENT THRESHOLDS
 *
 * `procStaleMs` and `schedStaleMs` are only consulted while the channel is fresh - i.e. while a
 * recent heartbeat file proves the PC agent is reaching us and we are looking at real, current
 * readings. A frozen reading under a live channel is positive evidence that the bot is dead, so it
 * can be acted on quickly.
 *
 * A stale channel is the opposite: it is absence of evidence, and it is the only condition that
 * can produce a genuine split brain (healthy PC, broken link). It gets the long threshold, and it
 * SUPERSEDES the other two - otherwise a PC that is simply powered off would trip `procStaleMs`
 * at 5 minutes and the 12-minute channel threshold could never be reached, which would collapse
 * the two cases the design exists to keep apart.
 */

/**
 * @typedef {'HOLD'|'STAND_BY'|'ALREADY_ACTIVE'|'TAKEOVER'} HaAction
 */

/** Defaults; every one is overridable per call so the tests state their own numbers. */
export const DEFAULT_THRESHOLDS = {
  /**
   * A bot-produced reading is positive evidence only while the transport carrying it is this
   * fresh. With the PC agent running every 60s, three minutes tolerates two missed uploads.
   * Between this and channelStaleMs the channel is UNCERTAIN: hold rather than applying the short
   * proc/scheduler clocks to old data and manufacturing split brain.
   */
  channelFreshMs: 3 * 60 * 1000,
  /**
   * S1 (bot event loop) unchanged this long, WITH a live channel, means the process is gone.
   * At the agent's 60s cadence this is 5 consecutive missed readings - sized above the
   * Windows-specific stalls that make a PC slow rather than dead (AV scan, disk stall,
   * resume-from-hibernate). Re-derive if AGENT_INTERVAL in sync-to-vps.ps1 changes.
   */
  procStaleMs: 5 * 60 * 1000,
  /**
   * S2 (scheduler pass) unchanged this long, WITH a live channel, means the scheduler wedged.
   *
   * 12 minutes, NOT 2, and this is the number a naive implementation gets wrong - too tight and
   * the VPS manufactures split brain out of a perfectly healthy PC. `lastSchedulerRunUtc` can
   * legitimately freeze for a long time: MonitorWorker.start() skips every tick while one is in
   * flight, a pass awaits processCase for up to MAX_BROWSER_CONCURRENCY (4) cases SEQUENTIALLY,
   * and a routine escalated probe falls back to CAPTURE_TIMEOUT_MS (120s) plus ~8s of settle.
   * Worst legitimate pass is therefore ~4 x 128s = ~8.5 min; 12 min leaves ~40% headroom.
   *
   * RE-DERIVE THIS NUMBER if MAX_BROWSER_CONCURRENCY, CAPTURE_TIMEOUT_MS, or the sequential
   * claim loop in runSchedulingPass changes.
   */
  schedStaleMs: 12 * 60 * 1000,
  /**
   * No heartbeat file touched for this long. Sits just above the PC scheduled task's own
   * 10-minute repeating trigger on purpose: do not take over an outage the PC will fix itself,
   * because every unnecessary handover carries duplicate-notification risk. Home-uplink blips
   * shorter than this are common and cost nothing - a recovery is a STATE, not an event, so the
   * window costs latency, not loss.
   */
  channelStaleMs: 12 * 60 * 1000,
  /**
   * How long the PC's takeback lock is honoured before it is assumed abandoned. Longer than the
   * whole takeback transaction (stop 120s + checkpoint + transfer + start 180s) with room to
   * spare, so a slow-but-working takeback is never interrupted by the watchdog.
   */
  handoverLockTtlMs: 10 * 60 * 1000,
};

/** Roles a host may claim. Anything else is treated as "not active". */
const ROLE_ACTIVE = 'ACTIVE';
/** The PC agent's explicit "my bot died, take over now" signal (spec section 2.5). */
const ROLE_STANDDOWN = 'STANDDOWN';

function isNonEmptyString(v) {
  return typeof v === 'string' && v.length > 0;
}

function num(v, fallback) {
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback;
}

/**
 * Pull the two bot-produced timestamps out of a heartbeat, or null when the heartbeat is absent,
 * torn or malformed.
 *
 * Malformed deliberately reads as "no signal this cycle" rather than as a fresh signal: the change
 * clocks then keep running and we eventually take over. That fails towards overlap (rank 2) rather
 * than towards a blackout (rank 1), which is the correct direction for the fallback host.
 */
function readLiveness(heartbeat) {
  if (heartbeat === null || typeof heartbeat !== 'object') return { procUtc: null, schedUtc: null };
  const liveness = heartbeat.liveness;
  if (liveness === null || typeof liveness !== 'object') return { procUtc: null, schedUtc: null };
  return {
    procUtc: isNonEmptyString(liveness.procUtc) ? liveness.procUtc : null,
    schedUtc: isNonEmptyString(liveness.schedUtc) ? liveness.schedUtc : null,
  };
}

/**
 * Advance one change clock.
 *
 * The clock moves ONLY when the value differs from the one previously seen. A repeated value -
 * which is exactly what a live agent pushing for a dead bot produces - leaves it where it was.
 * A first-ever sighting starts the clock now, so a brand new VPS does not inherit an infinitely
 * old age from a missing state file.
 */
function advance(seenValue, prevValue, prevChangedAtMs, nowMs) {
  if (seenValue === null) {
    // No reading this cycle: keep the previous value AND the previous clock. Nothing observed
    // cannot be evidence of life, and it must not be evidence of death either - the channel
    // threshold is what covers a silent agent.
    return { value: prevValue, changedAtMs: prevChangedAtMs };
  }
  if (prevValue === null || seenValue !== prevValue) {
    return { value: seenValue, changedAtMs: nowMs };
  }
  return { value: prevValue, changedAtMs: prevChangedAtMs };
}

/**
 * Decide what the VPS should do this cycle.
 *
 * @param {object} input
 * @param {number} input.nowMs                  VPS-local epoch ms. The ONLY clock this uses.
 * @param {object} [input.thresholds]           Partial override of DEFAULT_THRESHOLDS.
 * @param {object|null} input.heartbeat         Parsed pc-heartbeat.json, or null.
 * @param {number|null} input.heartbeatMtimeMs  mtime of pc-heartbeat.json, or null when absent.
 * @param {object|null} input.state             Parsed watchdog-state.json, or null on first run.
 * @param {string|null} input.vpsRole           role from the VPS's own role.json, or null.
 * @param {boolean} input.serviceActive         `systemctl is-active monitor-bot` == active.
 * @param {number|null} input.handoverLockAgeMs Age of handover.lock, or null when absent.
 * @returns {{action: HaAction, reason: string, detail: string, installSnapshot: boolean,
 *            state: object, ages: {channelMs: number|null, procMs: number|null, schedMs: number|null}}}
 */
export function decide(input) {
  const t = { ...DEFAULT_THRESHOLDS, ...(input.thresholds ?? {}) };
  const nowMs = input.nowMs;
  const prev = input.state ?? {};

  // The change clocks are updated on EVERY cycle, including cycles that exit early because the
  // VPS is already active. Keeping them current while active costs nothing and means the first
  // cycle after a PC takeback is judged on fresh observations rather than on months-old ones.
  // Reject a duplicate/out-of-order upload from the SAME agent process. Without this, a delayed
  // scp could
  // replace a newer heartbeat, make an old timestamp look like a VALUE CHANGE, and reset the
  // liveness clock for a dead bot. A new agentBootId is accepted even if its sequence restarts;
  // advance() still compares the BOT timestamps themselves, so restarting only the helper cannot
  // manufacture life.
  const incomingAgentBootId = isNonEmptyString(input.heartbeat?.agentBootId)
    ? input.heartbeat.agentBootId
    : null;
  const previousAgentBootId = isNonEmptyString(prev.lastAgentBootId) ? prev.lastAgentBootId : null;
  const incomingSeq = num(input.heartbeat?.seq, 0);
  const previousSeq = num(prev.lastHeartbeatSeq, 0);
  const staleReplay =
    incomingAgentBootId !== null &&
    incomingAgentBootId === previousAgentBootId &&
    incomingSeq <= previousSeq;
  const seen = staleReplay ? { procUtc: null, schedUtc: null } : readLiveness(input.heartbeat);
  const incomingPcRole = isNonEmptyString(input.heartbeat?.pcRole) ? input.heartbeat.pcRole : null;
  // A duplicate file is normal when the watchdog ticks just before the next PC upload. Reuse its
  // last accepted role, but do not let the same sequence mutate ACTIVE into STANDDOWN. A missing
  // or malformed heartbeat likewise must not erase the replay guard's accepted identity.
  const acceptedIdentity = !staleReplay && incomingAgentBootId !== null;
  const acceptedPcRole = acceptedIdentity
    ? incomingPcRole
    : isNonEmptyString(prev.lastPcRole)
      ? prev.lastPcRole
      : null;
  const proc = advance(
    seen.procUtc,
    isNonEmptyString(prev.lastSeenProcUtc) ? prev.lastSeenProcUtc : null,
    Math.min(num(prev.lastProcChangedAtMs, nowMs), nowMs),
    nowMs,
  );
  const sched = advance(
    seen.schedUtc,
    isNonEmptyString(prev.lastSeenSchedUtc) ? prev.lastSeenSchedUtc : null,
    Math.min(num(prev.lastSchedChangedAtMs, nowMs), nowMs),
    nowMs,
  );

  const everSeenHeartbeat =
    isNonEmptyString(prev.lastSeenProcUtc) ||
    isNonEmptyString(prev.lastSeenSchedUtc) ||
    seen.procUtc !== null ||
    seen.schedUtc !== null;

  const state = {
    // Set once, then carried forward. It is what bounds the grace window below.
    // A corrupt/future state file must not stretch the fresh-install grace window forever.
    firstRunAtMs: Math.min(num(prev.firstRunAtMs, nowMs), nowMs),
    lastSeenProcUtc: proc.value,
    lastSeenSchedUtc: sched.value,
    lastProcChangedAtMs: proc.changedAtMs,
    lastSchedChangedAtMs: sched.changedAtMs,
    lastAgentBootId: acceptedIdentity ? incomingAgentBootId : previousAgentBootId,
    lastHeartbeatSeq: acceptedIdentity ? incomingSeq : previousSeq,
    lastPcRole: acceptedPcRole,
    lastHeartbeatMtimeMs: num(input.heartbeatMtimeMs, num(prev.lastHeartbeatMtimeMs, 0)),
    lastDecisionAtMs: nowMs,
  };

  const channelMs =
    input.heartbeatMtimeMs === null ? null : Math.max(0, nowMs - input.heartbeatMtimeMs);
  const procMs = Math.max(0, nowMs - proc.changedAtMs);
  const schedMs = Math.max(0, nowMs - sched.changedAtMs);
  const ages = { channelMs, procMs, schedMs };

  const verdict = (action, reason, detail, installSnapshot = false) => ({
    action,
    reason,
    detail,
    installSnapshot,
    state,
    ages,
  });

  // A1. A PC takeback transaction is in flight. It stops this service on purpose; racing it would
  // restart the bot underneath a host that is about to install a DB pulled from it.
  if (input.handoverLockAgeMs !== null && input.handoverLockAgeMs < t.handoverLockTtlMs) {
    return verdict('HOLD', 'takeback-in-progress', 'PC holds handover.lock; standing aside.');
  }

  // A2. Already ours. Nothing to do - except that "role says ACTIVE" is a claim, and
  // `systemctl is-active` is the fact. If the unit died under an ACTIVE role, NOBODY is
  // monitoring (rank 1) and the fix is to start it again on the DB we already own. Reinstalling
  // the PC's snapshot here would be wrong: our own DB has moved on since we took over.
  if (input.vpsRole === ROLE_ACTIVE) {
    if (input.serviceActive) {
      return verdict('ALREADY_ACTIVE', 'vps-active', 'VPS holds the active role and is running.');
    }
    return verdict(
      'TAKEOVER',
      'service-down',
      'VPS holds the active role but monitor-bot is NOT running; restarting on the local DB.',
      false,
    );
  }

  // A fresh install (or a VPS whose data/ha was wiped) has no idea what the PC is doing. Going
  // greedy immediately would start a second writer next to a perfectly healthy PC - the classic
  // "install the failover and cause the outage" move. Give the PC agent one full channel window
  // to introduce itself first. After that the greedy default applies: never having heard from the
  // PC at all is indistinguishable from the PC being gone, and the fallback host must cover.
  if (!everSeenHeartbeat && nowMs - state.firstRunAtMs < t.channelStaleMs) {
    return verdict(
      'HOLD',
      'grace-window',
      'No PC heartbeat seen yet and the post-install grace window has not expired.',
    );
  }

  // A4a. Absence of evidence. This is checked BEFORE the two positive-evidence thresholds and
  // supersedes them: a powered-off PC freezes proc/sched too, and if those could fire first the
  // channel threshold would be dead code and every hibernation would be judged at 5 minutes.
  if (channelMs === null || channelMs > t.channelStaleMs) {
    const how =
      channelMs === null
        ? 'no PC heartbeat file has ever arrived'
        : `PC heartbeat is ${Math.round(channelMs / 1000)}s old`;
    return verdict('TAKEOVER', 'channel-stale', `Channel to the PC is down (${how}).`, true);
  }

  // The file has stopped arriving, but not for long enough to justify a link-only takeover. The
  // old implementation fell through here and applied procStaleMs to the frozen reading at 5m,
  // making the documented 12m channel threshold unreachable. This explicit uncertainty band is
  // the split-brain guard: neither old positive evidence nor early absence is allowed to decide.
  if (channelMs > t.channelFreshMs) {
    return verdict(
      'HOLD',
      'channel-uncertain',
      `PC heartbeat has not arrived for ${Math.round(channelMs / 1000)}s; waiting for the channel threshold.`,
    );
  }

  // The channel is live from here down, so every reading below is current and trustworthy.

  const pcRole = acceptedPcRole;

  // The PC agent watched its own bot die and said so. No threshold needs to expire for a host
  // that has explicitly given up the role; acting now turns a 7.5-minute detection into ~60s.
  if (pcRole === ROLE_STANDDOWN) {
    return verdict('TAKEOVER', 'pc-stood-down', 'PC agent reports its bot is dead.', true);
  }

  // The PC is reachable and says it is not the active host - it stood down cleanly, or it never
  // took the role. Either way nobody is monitoring unless we do.
  if (pcRole !== ROLE_ACTIVE) {
    return verdict(
      'TAKEOVER',
      'pc-not-active',
      `PC is reachable but its role is ${pcRole ?? 'unknown'}.`,
      true,
    );
  }

  // A4b. Positive evidence of death: the agent is fine, the bot is not.
  if (procMs > t.procStaleMs) {
    return verdict(
      'TAKEOVER',
      'proc-stale',
      `PC bot event loop has not answered for ${Math.round(procMs / 1000)}s.`,
      true,
    );
  }
  if (schedMs > t.schedStaleMs) {
    return verdict(
      'TAKEOVER',
      'sched-stale',
      `PC scheduler has not advanced for ${Math.round(schedMs / 1000)}s.`,
      true,
    );
  }

  return verdict('STAND_BY', 'pc-healthy', 'PC is active and healthy; VPS stays on standby.');
}

/* ------------------------------------------------------------------------------------------- */
/* CLI shim: JSON in on stdin, JSON out on stdout, exit 0. Any parse failure exits 2 LOUDLY -    */
/* the caller must be able to tell "decided to stand by" from "could not decide".                */
/* ------------------------------------------------------------------------------------------- */

function readStdin() {
  return new Promise((resolve, reject) => {
    let buf = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', (d) => {
      buf += d;
    });
    process.stdin.on('end', () => resolve(buf));
    process.stdin.on('error', reject);
  });
}

// Run as a CLI only when executed directly, never when imported.
const invokedDirectly =
  process.argv[1] !== undefined && process.argv[1].replace(/\\/g, '/').endsWith('/ha-decide.mjs');

if (invokedDirectly) {
  readStdin()
    .then((raw) => {
      const input = JSON.parse(raw);
      if (typeof input !== 'object' || input === null) throw new Error('input is not an object');
      if (typeof input.nowMs !== 'number') throw new Error('input.nowMs is required');
      process.stdout.write(JSON.stringify(decide(input)) + '\n');
    })
    .catch((err) => {
      process.stderr.write(`ha-decide: ${err instanceof Error ? err.message : String(err)}\n`);
      process.exit(2);
    });
}
