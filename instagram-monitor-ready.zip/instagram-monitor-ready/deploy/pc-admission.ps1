# Admission check used before the Windows primary supervisor starts.
# Exit 0: the PC may start. Exit 10: the PC is fenced. Exit 20: invalid local setup.

[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [ValidatePattern('^[A-Za-z0-9.:[\]-]+$')]
  [string]$VpsHost,

  [ValidatePattern('^[a-z_][a-z0-9_-]*$')]
  [string]$VpsUser = 'monitorbot',

  [Parameter(Mandatory = $true)]
  [string]$SshKeyPath,

  [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot),

  [ValidatePattern('^/[A-Za-z0-9._/-]+$')]
  [string]$RemoteHaDir = '/opt/monitor-bot/data/ha'
)

$ErrorActionPreference = 'Stop'

function Write-Utf8NoBomAtomic {
  param([string]$Path, [string]$Text)
  $parent = Split-Path -Parent $Path
  New-Item -ItemType Directory -Force -Path $parent | Out-Null
  $temp = "$Path.partial-$PID-$([guid]::NewGuid().ToString('N'))"
  $encoding = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($temp, $Text, $encoding)
  Move-Item -Force -LiteralPath $temp -Destination $Path
}

function Read-JsonOrNull {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { return $null }
  try { return (Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json) } catch { return $null }
}

try {
  $resolvedRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
  $resolvedKey = (Resolve-Path -LiteralPath $SshKeyPath).Path
  $rolePath = Join-Path $resolvedRoot 'data\ha\role.json'
  $localRole = Read-JsonOrNull $rolePath

  # Once a takeback/failover has fenced this PC, an SSH outage must not silently grant its role
  # back. Only the explicit takeback procedure changes STANDBY to ACTIVE.
  if ($null -ne $localRole -and $localRole.role -ne 'ACTIVE') { exit 10 }

  $ssh = (Get-Command ssh.exe).Source
  $target = "$VpsUser@$VpsHost"
  # Keepalives, for the same reason as the sync agent: ConnectTimeout bounds only the handshake, so
  # an established-then-stalled session would hang the admission check indefinitely — and this one
  # gates whether the PC bot is allowed to run at all.
  $options = @(
    '-i', $resolvedKey,
    '-o', 'BatchMode=yes',
    '-o', 'StrictHostKeyChecking=yes',
    '-o', 'ConnectTimeout=10',
    '-o', 'ServerAliveInterval=5',
    '-o', 'ServerAliveCountMax=3'
  )
  $raw = & $ssh @options $target "test -f '$RemoteHaDir/role.json' && cat '$RemoteHaDir/role.json' || true"
  if ($LASTEXITCODE -ne 0) {
    # Availability-biased two-node policy: a host that already owns ACTIVE remains active during
    # a link outage. The 12-minute VPS channel guard and its split-brain trade-off are documented.
    Write-Warning 'VPS role is unreachable; retaining the PC ACTIVE role.'
    exit 0
  }
  $text = ($raw -join "`n").Trim()
  if ($text -eq '') { exit 0 }
  $remoteRole = $null
  try {
    $remoteRole = $text | ConvertFrom-Json
  } catch {
    # An UNREADABLE remote role file must not fence this PC. The VPS watchdog independently fences
    # its OWN service the moment its role file stops parsing as ACTIVE, so if both sides treat the
    # same corrupt file as "someone else owns it", one bad write turns into a zero-host outage —
    # which is precisely what the 2026-08-03 takeback incident produced. The availability-biased
    # answer matches the unreachable-VPS case above: the current ACTIVE holder keeps its role.
    Write-Warning 'VPS role.json exists but cannot be parsed; retaining the PC ACTIVE role.'
    exit 0
  }
  if ($remoteRole.role -eq 'ACTIVE') {
    Write-Utf8NoBomAtomic $rolePath (([ordered]@{
      version = 1
      role = 'STANDBY'
      reason = 'vps-active-at-pc-admission'
      updatedAtUtc = [DateTime]::UtcNow.ToString('o')
    } | ConvertTo-Json -Compress) + "`n")
    exit 10
  }
  exit 0
} catch {
  # Write-Warning, deliberately NOT Write-Error: with $ErrorActionPreference = 'Stop' in force,
  # Write-Error is itself terminating, so the `exit 20` after it never ran and every failure in
  # this script surfaced as a generic exit 1 — indistinguishable from a crash, and exactly what
  # made the takeback incident hard to read from the wrapper's log.
  Write-Warning "PC admission configuration failed: $($_.Exception.Message)"
  exit 20
}
