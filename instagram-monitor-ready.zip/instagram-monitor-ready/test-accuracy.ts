/**
 * Accuracy harness: run the fast probe and the browser probe over a set of accounts and
 * report where they agree. The fast path is only safe to ship if "identity present" tracks
 * the browser's ACTIVE, and "no identity" tracks the browser's GONE.
 *
 *   npx tsx --env-file=.env test-accuracy.ts user1 user2 ...
 */

import { loadConfig } from './src/config';
import { BrowserManager, PlaywrightDetector, httpProbe, proxyDispatcher } from './src/instagram';
import { createLogger } from './src/logging/logger';

const users = process.argv.slice(2);
if (users.length === 0) {
  console.log('usage: test-accuracy.ts <user> [user...]');
  process.exit(1);
}

const config = loadConfig(process.env);
const logger = createLogger({ level: 'error', secrets: [] });
const dispatcher = proxyDispatcher(config);
const browser = new BrowserManager({ config, logger });
const detector = new PlaywrightDetector({ browser, config, logger });

console.log(
  'user'.padEnd(24),
  'fast'.padEnd(10),
  'identity'.padEnd(10),
  'browser'.padEnd(9),
  'fastMs  browserMs',
);
console.log('-'.repeat(78));

let usable = 0;
for (const u of users) {
  const t0 = Date.now();
  const f = await httpProbe(u, { config, dispatcher }, 20000);
  const fMs = Date.now() - t0;
  const t1 = Date.now();
  const b = await detector.probe(u);
  const bMs = Date.now() - t1;

  const ident = f.result.evidence.identitySignalMatched;
  // The rule we intend to ship: identity => possible recovery (escalate); no identity => still gone.
  const fastVerdict = ident ? 'ACTIVE' : 'GONE';
  const ok = fastVerdict === b.result.classification;
  if (ok) usable += 1;
  console.log(
    u.padEnd(24),
    (f.result.classification as string).padEnd(10),
    (ident ? 'YES' : 'no').padEnd(10),
    (b.result.classification as string).padEnd(9),
    String(fMs).padStart(5),
    String(bMs).padStart(9),
    ok ? '' : '  <-- MISMATCH',
  );
}

console.log('-'.repeat(78));
console.log(`agreement (identity-rule vs browser): ${usable}/${users.length}`);
await browser.close().catch(() => undefined);
