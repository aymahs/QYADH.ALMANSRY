/** Prove /proxy switches egress: build the real ProxySwitch from .env and exercise both modes. */
import { loadConfig } from './src/config';
import { ProxySwitch } from './src/instagram';

const config = loadConfig(process.env);
const sw = new ProxySwitch(config);

console.log('PROXY_MODE from .env :', config.proxyMode);
console.log('proxy configured     :', config.browserProxy !== null ? 'yes' : 'NO');
console.log('');
console.log('start   ->', sw.describe(), '| gen', sw.gen());

const toMobile = sw.set('proxy');
console.log('/proxy mobile ->', toMobile ? 'OK' : 'REFUSED', '|', sw.describe(), '| gen', sw.gen());

const toHome = sw.set('direct');
console.log('/proxy home   ->', toHome ? 'OK' : 'REFUSED', '|', sw.describe(), '| gen', sw.gen());

// Switching to the mode already in use is intentionally a no-op (it must not force a needless
// browser relaunch), so the generation advances once per REAL change — which is 1 on a host that
// starts on the proxy, and 2 on one that starts direct.
const expectedGen = config.proxyMode === 'proxy' ? 1 : 2;
const ok = toMobile && toHome && sw.gen() === expectedGen;
console.log('');
console.log(
  ok
    ? `PASS - both routes selectable; generation advanced ${sw.gen()}x (real changes only)`
    : `FAIL - expected generation ${expectedGen}, got ${sw.gen()}`,
);
process.exit(ok ? 0 : 1);
