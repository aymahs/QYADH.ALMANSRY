/**
 * Live A/B of the fast HTTP probe against the browser probe.
 *
 *   npx tsx --env-file=.env test-fast.ts [username]
 *
 * Proves the cheap path returns the SAME classification as Chromium, and shows the real
 * speed difference through whatever proxy is configured.
 */

import { loadConfig } from './src/config';
import { BrowserManager, PlaywrightDetector, httpProbe, proxyDispatcher } from './src/instagram';
import { createLogger } from './src/logging/logger';

const USER = process.argv[2] ?? 'instagram';
const config = loadConfig(process.env);
const logger = createLogger({ level: 'error', secrets: [] });

console.log('-'.repeat(64));
console.log('  FAST PROBE vs BROWSER PROBE');
console.log('-'.repeat(64));
console.log(`Target : @${USER}`);
console.log(`Proxy  : ${config.browserProxy ? config.browserProxy.server : 'none (direct)'}`);
console.log('-'.repeat(64));

const dispatcher = proxyDispatcher(config);

const t0 = Date.now();
const fast = await httpProbe(USER, { config, dispatcher }, 20000);
const fastMs = Date.now() - t0;
console.log('FAST (1 HTTP GET)');
console.log(`  Result    : ${fast.result.classification}`);
console.log(`  Error     : ${fast.result.evidence.errorCode ?? 'none'}`);
console.log(`  Identity  : ${fast.result.evidence.identitySignalMatched ? 'matched' : 'no'}`);
console.log(`  Time      : ${fastMs} ms`);

const browser = new BrowserManager({ config, logger });
const detector = new PlaywrightDetector({ browser, config, logger });
const t1 = Date.now();
const slow = await detector.probe(USER, { captureScreenshot: true });
const slowMs = Date.now() - t1;
console.log('\nBROWSER (full Chromium page load)');
console.log(`  Result    : ${slow.result.classification}`);
console.log(`  Error     : ${slow.result.evidence.errorCode ?? 'none'}`);
console.log(`  Screenshot: ${slow.screenshot ? `${slow.screenshot.buffer.length} bytes` : 'none'}`);
console.log(`  Time      : ${slowMs} ms`);
await browser.close().catch(() => undefined);

console.log('\n' + '-'.repeat(64));
const agree = fast.result.classification === slow.result.classification;
console.log(`  Agreement : ${agree ? 'YES — same verdict' : 'NO — DIFFERENT VERDICTS'}`);
if (fastMs > 0) console.log(`  Speedup   : ${(slowMs / fastMs).toFixed(1)}x faster`);
console.log('-'.repeat(64));
process.exit(agree ? 0 : 1);
