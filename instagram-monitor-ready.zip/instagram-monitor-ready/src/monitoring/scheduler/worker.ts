/**
 * The scheduler worker: one tick claims due cases under a job lease, probes each
 * profile, threads the result through the pure state machine, and — on the
 * exactly-once `confirmed` edge — runs the screenshot + outbox pipeline.
 *
 * Reliability invariants enforced here:
 *  - a case is processed by at most one worker at a time (repo lease semantics);
 *  - a /clear that lands mid-check always wins: the transition is dropped via a
 *    compare-and-save re-read right before every save;
 *  - a confirmed case is never left stuck — any failure in the screenshot
 *    pipeline reverts it to MONITORING with a fresh baseline check.
 */

import { mkdir, unlink, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import type {
  Clock,
  Detector,
  MonitoringCase,
  OutboxItem,
  ProbeResult,
  Repositories,
  SchedulerHealth,
  Screenshot,
} from '../../domain';
import { ACTIVE_STATUSES, SIGNALS_VERSION } from '../../domain';
import type { AppConfig } from '../../config';
import { isThrottleSignal } from '../../instagram/circuit-breaker';
import { detectorDiagnostics } from '../../instagram/detector/tiered-detector';
import type { TieredProbeOptions } from '../../instagram/detector/tiered-detector';
import type { Logger } from '../../logging';
import type { SchedulingParams } from '../scheduling';
import { nextBaselineCheckAt } from '../scheduling';
import { applyCheckResult } from '../state-machine';

/** Consecutive UNKNOWN results that trip a case into ERROR_BACKOFF. */
const UNKNOWN_THRESHOLD = 3;
/** Exponential-moving-average weight for the rolling unknown rate. */
const UNKNOWN_RATE_WEIGHT = 0.2;
/**
 * Screenshot capture attempts on the critical path of the recovery alert.
 *
 * Kept small on purpose: a browser capture through a slow egress (a mobile proxy: measured
 * 15-115s) is the single largest source of notification latency, and every attempt here is
 * silence after the recovery was already confirmed. A miss is not final — the case is recorded
 * `screenshotStatus: 'FAILED'` and {@link MonitorWorker.reapMissingScreenshots} re-takes the
 * picture off the critical path. Speed of the ALERT beats having the picture in the first
 * message.
 */
const SCREENSHOT_ATTEMPTS = 3;
/** Bounded delay between screenshot capture attempts (injected sleep in tests). */
const SCREENSHOT_RETRY_DELAY_MS = 750;
/**
 * Hard ceiling across ALL capture attempts combined — not per attempt. Retrying without a budget
 * put up to ~5 minutes of browser captures in front of the alert on a slow egress. One shared
 * budget gives several chances on a fast link and still guarantees the alert goes out on a slow
 * one.
 *
 * RAISED FROM 30s, and the reasoning matters. Measured on the production host, the profile
 * header does not finish PAINTING until 9.9s / 85.4s / 96.4s after navigation start depending on
 * the account, so a 30s ceiling did not merely make a capture unlikely on a slow profile — it
 * GUARANTEED a miss, and the recovery alert always went out without the proof the client pays
 * for. 150s covers the slowest measured case end to end (41.3s to domcontentloaded + ~10.5s of
 * load settling + 96.4s to paint ≈ 148s) with the capture's own 120s paint poll nested inside.
 *
 * The trade, stated plainly: this can delay the alert by up to ~2.5 minutes. That is the right
 * call here because these recoveries take DAYS to arrive (the incident case had been monitored
 * for 1 day 22 hours) — two extra minutes to include real proof is invisible next to that,
 * whereas a proofless alert is the product failing. It is a CEILING, not a cost: a fast profile
 * paints in ~10s and the alert is no slower than before. And it is bounded on purpose — when
 * even this is exceeded the alert goes out text-first and {@link MonitorWorker.reapMissingScreenshots}
 * takes the picture off the critical path.
 *
 * WHO PAYS IT. That trade is defensible only because the wait is charged to the ONE client whose
 * recovery is being captured. It used to be charged to the whole fleet: the capture ran inline
 * inside a tick and `start()` skips every tick while one is in flight, so a single 150s capture
 * froze the scheduler — no case claimed, no check performed, and any OTHER account that recovered
 * during it was not even looked at. See {@link MonitorWorker.startConfirmedCapture}.
 */
const SCREENSHOT_BUDGET_MS = 150_000;
/**
 * How long a capture on the CONFIRMED edge may wait for the profile to finish painting.
 *
 * The detector's own default is deliberately short (it also serves `/check` and `/ping` inline on
 * the bot's serial ingress loop). This path is the opposite case: it is the client's proof, it is
 * already off the interactive path, and paint was measured as late as 96.4s. Sized to fit inside
 * {@link SCREENSHOT_BUDGET_MS} with the page load in front of it, so the outer deadline stays the
 * thing that actually ends the attempt.
 */
const CONFIRMED_PAINT_BUDGET_MS = 120_000;
/**
 * Navigation ceiling for a re-capture page load, passed INTO the probe rather than left to the
 * global `CAPTURE_TIMEOUT_MS`.
 *
 * This is the coupling whose absence broke the sweep. `CAPTURE_TIMEOUT_MS` is a global 120s sized
 * for the slowest measured cold load; the sweep independently wrapped the same probe in a 90s
 * {@link RECAPTURE_BUDGET_MS}. Two budgets, chosen apart, and the inner one won: 120s goto + 8s
 * settle = 128s of page load nested inside a 90s deadline, so the deadline fired mid-`goto` on
 * every profile slower than ~82s — precisely the profiles the sweep exists for. Sizing this from
 * the outer budget is what makes that wrapper a BACKSTOP again instead of a cliff.
 *
 * 85s clears @trymaven's measured 76.6s cold domcontentloaded through the mobile proxy with
 * headroom, and everything faster is unaffected.
 */
const RECAPTURE_NAV_BUDGET_MS = 85_000;
/**
 * How long a re-capture may wait for the profile to finish PAINTING.
 *
 * Sized from the measurement, not from fear of blocking the scheduler: text paint lands at
 * 114.7s cold / 95.7s warm on @trymaven, i.e. ~30s after its own domcontentloaded + settle. 45s
 * covers that with room and still leaves the sweep's total inside {@link RECAPTURE_BUDGET_MS}.
 *
 * It used to be 25s, justified by the sweep being `await`ed INLINE inside the tick — which made
 * every second here a fleet-wide detection blackout. That justification is gone: the sweep now
 * runs OFF the tick (see {@link MonitorWorker.startRecaptureSweep}), exactly like the
 * confirmed-edge capture, so its wait is charged to one browser slot rather than to every other
 * client's recovery detection. Suppressing the sweep to protect the fleet was buying rank-3 safety
 * with rank-2 harm: the sweep is the ONLY mechanism that recovers a client's proof after a
 * critical-path miss, and a budget below the measured paint time made it structurally incapable
 * of ever doing so.
 *
 * It also sizes the header-image wait, which the capture path caps at a quarter of the paint
 * budget: 11.25s here. @trymaven's avatar settles 16.0s after text paint, so a re-captured card
 * may still carry a grey avatar. That is the accepted trade — image quality is the lowest-ranked
 * invariant, and a correct card with a grey circle beats no proof at all.
 */
const RECAPTURE_PAINT_BUDGET_MS = 45_000;
/**
 * Hard ceiling on one re-capture attempt, covering the page load in front of the paint poll.
 *
 * Needed on top of the paint budget because not every step is bounded by it: `page.evaluate` is
 * not covered by `context.setDefaultTimeout` (Playwright applies that only to methods taking a
 * `timeout` option), so a wedged renderer can block a poll past its own ceiling. As with the
 * confirmed path, exceeding this abandons the wait rather than cancelling the probe — which is
 * exactly why it must sit ABOVE everything the inner budgets allow: a deadline that fires while
 * the probe is still making progress does not save anything, it just discards a page load the
 * residential IP has already been charged for and leaves the abandoned probe holding a capture
 * lane on the way out.
 *
 * Re-derived, every term of it, from the budgets the probe is actually handed:
 *
 *   goto                    <=  85,000   RECAPTURE_NAV_BUDGET_MS (passed as captureNavBudgetMs)
 *   settle selector         <=   8,000   SETTLE_TIMEOUT_MS in BrowserManager.loadProfile
 *   paint poll              <=  45,000   RECAPTURE_PAINT_BUDGET_MS
 *   dismiss + occlusion     ~=   5,000   overlay dismissal and the header visibility probe
 *   paint re-check          <=   5,000   PAINT_RECHECK_BUDGET_MS in the detector
 *   header-image wait       <=  11,250   a quarter of the paint budget
 *                              -------
 *                              159,250
 *
 * 165s sits above that sum, so a capture the inner budgets were willing to make can never be cut
 * off here; only a genuinely stuck one is. Whenever any term above changes, this number changes
 * with it — that arithmetic drifting apart is the entire defect this comment now guards.
 */
const RECAPTURE_BUDGET_MS = 165_000;
/** How often to sweep for notifications stranded by a crash or an exhausted outbox item. */
const REAP_INTERVAL_MS = 60_000;
/**
 * Cadence of the screenshot re-capture sweep, and therefore the HARD CEILING on the page loads it
 * can add: at most one capture per sweep, so at most 12 per hour no matter how many recoveries
 * are owed a picture. The single residential IP tolerates ~200 loads/hour in total, and burning
 * it blinds the whole fleet — a slow sweep is the price of a bounded one.
 */
const RECAPTURE_SWEEP_INTERVAL_MS = 5 * 60_000;
/**
 * Minimum gap between re-capture attempts for ONE case. Derived from the case's own
 * `updatedAtUtc`, which every attempt bumps before it probes, so the spacing is durable — an
 * in-memory counter would let a crash loop hammer the egress with a fresh budget each restart.
 */
const RECAPTURE_SPACING_MS = 5 * 60_000;
/**
 * How long after the recovery alert a missing screenshot is still worth re-taking.
 *
 * Deliberately generous. The dominant reason a capture misses is a throttled egress, and the
 * fleet-wide circuit breaker's cooldown doubles up to an hour — a tighter window would expire
 * precisely in the case this sweep exists for. The proof does not go stale either: the profile is
 * still live, so a picture taken later is just as good.
 */
const RECAPTURE_WINDOW_MS = 2 * 60 * 60 * 1000;
/** Default directory for captured screenshots awaiting delivery. */
const DEFAULT_SCREENSHOT_DIR = 'data/screenshots';
/** Health row name maintained by this worker. */
const HEALTH_NAME = 'scheduler';

/** Extract the pure {@link SchedulingParams} slice from the app config. */
export function schedulingParamsFrom(config: AppConfig): SchedulingParams {
  const s = config.scheduling;
  return {
    baselineIntervalSeconds: s.baselineIntervalSeconds,
    // Full speed unless a caller overrides it. Only the monitor worker does, from the governor.
    baselineIntervalMultiplier: 1,
    confirmationIntervalSeconds: s.confirmationIntervalSeconds,
    confirmationRequiredCount: s.confirmationRequiredCount,
    confirmationDeadlineSeconds: s.confirmationDeadlineSeconds,
    baselineJitterMaxSeconds: s.baselineJitterMaxSeconds,
    retryDelaysSeconds: s.retryDelaysSeconds,
    unknownBackoffBaseSeconds: s.unknownBackoffBaseSeconds,
    unknownBackoffMaxSeconds: s.unknownBackoffMaxSeconds,
    errorBackoffInitialSeconds: s.errorBackoffInitialSeconds,
    errorBackoffMaxSeconds: s.errorBackoffMaxSeconds,
  };
}

export interface MonitorWorkerDeps {
  repos: Repositories;
  detector: Detector;
  config: AppConfig;
  clock: Clock;
  logger: Logger;
  /** Injected randomness for jitter; defaults to Math.random. */
  rand?: () => number;
  /** Lease owner id recorded on claimed cases. */
  workerId?: string;
  /** Directory for captured screenshots (default `data/screenshots`). */
  screenshotDir?: string;
  /** Injected delay between screenshot attempts; tests inject an instant sleep. */
  sleep?: (ms: number) => Promise<void>;
}

export class MonitorWorker {
  private readonly repos: Repositories;
  private readonly detector: Detector;
  private readonly config: AppConfig;
  private readonly clock: Clock;
  private readonly logger: Logger;
  private readonly rand: () => number;
  private readonly workerId: string;
  private readonly screenshotDir: string;
  private readonly sleep: (ms: number) => Promise<void>;

  private timer: ReturnType<typeof setInterval> | null = null;
  private inFlight: Promise<void> | null = null;
  /** Epoch ms of the last stranded-notification sweep (0 = never, so the first tick runs one). */
  private lastReapMs = 0;
  /** Epoch ms of the last screenshot re-capture sweep (0 = never, so the first tick runs one). */
  private lastRecaptureMs = 0;
  /**
   * Epoch ms at which each case's CURRENT confirmation burst began. See
   * {@link MonitorWorker.burstElapsedMs} for why the deadline is scoped to the burst rather than
   * to the gap between two checks. Entries are removed the moment a case leaves CONFIRMING, so
   * this cannot grow without bound.
   */
  private readonly confirmationBurstStartMs = new Map<string, number>();
  /**
   * Confirmed-edge captures currently running OFF the tick, keyed by case id. Two jobs:
   * {@link MonitorWorker.drainConfirmedCaptures} awaits them, and
   * {@link MonitorWorker.reapStrandedNotifications} must not mistake one for a stranded case.
   */
  private readonly confirmedCaptures = new Map<string, Promise<void>>();
  /**
   * Last browser-load pressure the fleet reported, logged only when it CHANGES.
   *
   * Self-throttling must never be silent — but it is evaluated once per tick, so logging it every
   * time would bury the transition that actually matters in a second-by-second stream.
   */
  private lastLoggedMultiplier = 1;
  /**
   * The screenshot re-capture sweep currently running OFF the tick, or null. At most one at a
   * time: the sweep takes ONE case per run and spends that case's durable spacer before probing,
   * so two overlapping runs could otherwise both be in flight against the same slow profile.
   */
  private recaptureSweep: Promise<void> | null = null;

  constructor(deps: MonitorWorkerDeps) {
    this.repos = deps.repos;
    this.detector = deps.detector;
    this.config = deps.config;
    this.clock = deps.clock;
    this.logger = deps.logger;
    this.rand = deps.rand ?? Math.random;
    this.workerId = deps.workerId ?? 'monitor-worker';
    this.screenshotDir = deps.screenshotDir ?? DEFAULT_SCREENSHOT_DIR;
    this.sleep =
      deps.sleep ??
      ((ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms)));
  }

  /**
   * One scheduler pass, awaited to completion INCLUDING any browser work it started off-tick —
   * the confirmed-edge capture and the screenshot re-capture sweep.
   *
   * The tick loop deliberately does NOT wait for either (see
   * {@link MonitorWorker.startConfirmedCapture} and {@link MonitorWorker.startRecaptureSweep});
   * this entry point does, so a single manual pass stays self-contained and every caller that
   * inspects the outbox afterwards sees a finished pipeline rather than a race.
   */
  async runOnce(): Promise<void> {
    await this.runSchedulingPass();
    await this.drainConfirmedCaptures();
    await this.drainRecaptureSweep();
  }

  /** The scheduling half of a tick: heartbeat, sweeps, claim due cases, process each under its lease. */
  private async runSchedulingPass(): Promise<void> {
    const now = this.clock.now();
    const nowIso = now.toISOString();

    await this.recordSchedulerRun(nowIso);

    // Periodic rescue of notifications stranded by a crash or an exhausted outbox item. Runs on
    // a slow cadence — it scans, so it must not run on every 1s tick.
    if (now.getTime() - this.lastReapMs >= REAP_INTERVAL_MS) {
      this.lastReapMs = now.getTime();
      await this.reapStrandedNotifications().catch((err: unknown) => {
        this.logger.error('monitor worker: stranded-notification sweep failed', { err });
      });
    }

    // Re-take a recovery proof the critical-path capture could not get. Deliberately NOT awaited:
    // it costs a real browser page load on a profile already known to be slow, and this pass gates
    // the next tick. See {@link MonitorWorker.startRecaptureSweep}.
    if (
      this.recaptureSweep === null &&
      now.getTime() - this.lastRecaptureMs >= RECAPTURE_SWEEP_INTERVAL_MS
    ) {
      this.lastRecaptureMs = now.getTime();
      this.startRecaptureSweep();
    }

    const leaseExpiresUtc = new Date(
      now.getTime() + this.config.scheduling.jobLeaseSeconds * 1000,
    ).toISOString();
    const claimed = await this.repos.cases.claimDueCases({
      nowUtc: nowIso,
      leaseOwner: this.workerId,
      leaseExpiresUtc,
      limit: this.config.scheduling.maxBrowserConcurrency,
    });

    for (const c of claimed) {
      try {
        await this.processCase(c);
      } catch (err) {
        this.logger.error('monitor worker: case processing failed', { caseId: c.id, err });
      } finally {
        await this.repos.cases.releaseLease(c.id, this.clock.now().toISOString());
      }
    }
  }

  /**
   * Start the tick loop. A tick is skipped while the previous one is still running.
   *
   * Only the SCHEDULING half gates the next tick. Both browser-heavy jobs run off it — a
   * confirmed-edge capture may legitimately run for {@link SCREENSHOT_BUDGET_MS} and a re-capture
   * sweep for {@link RECAPTURE_BUDGET_MS} — because waiting for either here is what turned one
   * client's proof into a fleet-wide blackout.
   */
  start(intervalMs = 1000): void {
    if (this.timer !== null) return;
    this.timer = setInterval(() => {
      if (this.inFlight !== null) return; // long browser work must not stack
      this.inFlight = this.runSchedulingPass()
        .catch((err: unknown) => {
          this.logger.error('monitor worker: tick failed', { err });
        })
        .finally(() => {
          this.inFlight = null;
        });
    }, intervalMs);
  }

  /**
   * Stop the tick loop and wait for any in-flight tick to complete.
   *
   * Deliberately does NOT wait for a confirmed-edge capture: it may legitimately still have
   * minutes of {@link SCREENSHOT_BUDGET_MS} left, and holding shutdown for it would turn a
   * SIGTERM into a SIGKILL. Losing one costs no alert — the case is CONFIRMED with no outbox row,
   * which is precisely the shape {@link MonitorWorker.reapStrandedNotifications} rescues on the
   * next boot, exactly as when the capture ran inline and the process died mid-capture.
   */
  async stop(): Promise<void> {
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.inFlight !== null) {
      await this.inFlight;
    }
  }

  /** Process one claimed case: probe, record, transition, and maybe notify. */
  private async processCase(claimed: MonitoringCase): Promise<void> {
    // Re-read first: a /clear (or a completed notification) may have won the race
    // between the lease claim and now.
    const current = await this.repos.cases.findById(claimed.id);
    if (current === null || current.status === 'CLEARED' || current.status === 'NOTIFIED') {
      this.confirmationBurstStartMs.delete(claimed.id);
      return;
    }

    // Read the burst clock BEFORE the probe, not after. A confirmation leg through the mobile
    // proxy was measured at 85-96s, and the old gap-scoped test compared post-probe `now` against
    // the PREVIOUS check's timestamp — so a slow check discarded its OWN ACTIVE result and the
    // burst with it. Measuring here means only a burst that was already over budget when this
    // check started is abandoned; the result this check is about to produce always counts.
    const burstElapsedMs =
      current.status === 'CONFIRMING' ? this.burstElapsedMs(current.id, this.clock.nowMs()) : 0;
    const confirmationDeadlineExceeded =
      current.status === 'CONFIRMING' &&
      burstElapsedMs > this.config.scheduling.confirmationDeadlineSeconds * 1000;

    const probe = await this.safeProbe(current.normalizedUsername, this.probeOptionsFor(current));
    const { result } = probe;

    const now = this.clock.now();
    const nowIso = now.toISOString();

    await this.repos.checks.insert({
      caseId: current.id,
      checkedAtUtc: nowIso,
      classification: result.classification,
      finalUrl: result.evidence.finalUrl,
      responseStatus: result.evidence.responseStatus,
      durationMs: result.durationMs,
      activeSignals: result.evidence.activeSignals,
      goneSignals: result.evidence.goneSignals,
      errorCode: result.evidence.errorCode,
      confirmationSeq: current.status === 'CONFIRMING' ? current.confirmationCount + 1 : null,
    });

    const activeCount = await this.repos.cases.countByStatuses(ACTIVE_STATUSES);

    const { next, confirmed } = applyCheckResult({
      current,
      classification: result.classification,
      now,
      params: {
        ...this.schedulingParams(),
        activeCount,
        unknownThreshold: UNKNOWN_THRESHOLD,
      },
      rand: this.rand,
      confirmationDeadlineExceeded,
      operationalFailure: isRetryableOperationalFailure(result.evidence.errorCode),
    });

    // CRITICAL /clear race guard: compare-and-save. If the stored case became
    // CLEARED while we were probing, drop the transition entirely.
    const stored = await this.repos.cases.findById(current.id);
    if (stored === null || stored.status === 'CLEARED' || stored.clearedAtUtc !== null) {
      this.logger.info('monitor worker: transition dropped; case cleared mid-check', {
        caseId: current.id,
      });
      this.confirmationBurstStartMs.delete(current.id);
      return;
    }
    await this.repos.cases.save(next);
    this.trackConfirmationBurst(next, now.getTime());

    await this.updateCheckHealth(result.classification, nowIso, probe.notObserved === true);

    if (confirmed) {
      this.startConfirmedCapture(next, activeCount);
    }
  }

  /**
   * Run the screenshot + outbox pipeline for a freshly confirmed case OFF the tick.
   *
   * Why it may not be awaited by the tick: {@link SCREENSHOT_BUDGET_MS} deliberately allows up to
   * 150s so the client's proof survives a profile that paints at 96.4s. Awaited inline that cost
   * was paid by every other client — `start()` skips every tick while one is in flight, so the
   * whole scheduler stopped claiming and checking for the entire capture.
   *
   * Why this cannot double-alert, which is the hazard it would otherwise introduce:
   *  - the case is already saved CONFIRMED, and `claimDueCases` selects only the four ACTIVE
   *    statuses in BOTH backends, so no later tick can re-probe or re-confirm it;
   *  - {@link MonitorWorker.reapStrandedNotifications} is the only other producer of a recovery
   *    outbox row, and it now skips a case whose capture is still registered here. Without that
   *    skip its 60s sweep would enqueue RECOVERY_TEXT under a capture still heading for
   *    RECOVERY_PHOTO — two different kinds, so `ON CONFLICT (case_id, kind) DO NOTHING` would
   *    NOT have caught it and the client would be told twice.
   *
   * Registration happens in the same synchronous turn as the start, before `handleConfirmed` can
   * reach its first await, so there is no window in which a running capture looks stranded. A
   * capture lost to a crash or shutdown deregisters with the process, which is correct: then the
   * case IS stranded and the sweep is exactly what should rescue it on the next boot.
   *
   * The lease fields are neutralised because the ORDER changed with the detach: the pass now
   * releases the lease in its `finally` BEFORE this capture saves, so the snapshot taken while the
   * lease was held would write it straight back. That matters most on the cancellation path —
   * `cancelConfirmation` returns the case to MONITORING, and `claimDueCases` skips any row whose
   * lease has not expired, so a resurrected lease would suppress the case's next scheduled check.
   */
  private startConfirmedCapture(c: MonitoringCase, activeCount: number): void {
    const released: MonitoringCase = { ...c, leaseOwner: null, leaseExpiresAtUtc: null };
    const running = (async (): Promise<void> => {
      try {
        await this.handleConfirmed(released, activeCount);
      } catch (err) {
        // handleConfirmed already reverts a failed case itself; this is the last-resort net so an
        // off-tick rejection can never become an unhandled promise and kill the process.
        this.logger.error('monitor worker: confirmed-edge capture failed', { caseId: c.id, err });
      } finally {
        this.confirmedCaptures.delete(c.id);
      }
    })();
    this.confirmedCaptures.set(c.id, running);
  }

  /** Await every confirmed-edge capture currently running off-tick. */
  private async drainConfirmedCaptures(): Promise<void> {
    if (this.confirmedCaptures.size === 0) return;
    await Promise.all([...this.confirmedCaptures.values()]);
  }

  /**
   * Run the screenshot re-capture sweep OFF the tick, for the same reason the confirmed-edge
   * capture moved off it.
   *
   * The sweep chases the proof for a recovery that was already alerted text-only, which means the
   * profile it re-loads is, by selection, one whose capture ALREADY missed — measured 76.6s to
   * domcontentloaded and 114.7s to text paint through the mobile proxy. Awaited inline that cost
   * was charged to everyone: `runSchedulingPass` awaited it BEFORE `claimDueCases`, and `start()`
   * skips every tick while a pass is in flight, so one slow re-capture stopped the whole scheduler
   * — no case claimed, no check performed — every {@link RECAPTURE_SWEEP_INTERVAL_MS} for the full
   * {@link RECAPTURE_WINDOW_MS}. That is harm rank 1 at fleet scale, spent chasing one picture.
   *
   * Detaching it is safe in a way the confirmed edge had to work for: this sweep only ever touches
   * a case in NOTIFIED, and NOTIFIED is in neither `ACTIVE_STATUSES` (so `claimDueCases` cannot
   * hand the same case to `processCase`) nor the `['CONFIRMED','NOTIFYING']` set
   * {@link MonitorWorker.reapStrandedNotifications} reads. There is no case a tick and a running
   * sweep can both be inside. Overlapping sweeps are prevented by the handle itself, since the
   * sweep spends a case's durable spacer before it probes.
   *
   * Losing one to shutdown costs no alert: the case stays NOTIFIED/FAILED, which is precisely the
   * state this sweep rescues, so the next boot picks it up inside the same window.
   */
  private startRecaptureSweep(): void {
    // Assigned in the SAME synchronous turn as the start, so the `finally` below (a microtask at
    // the earliest) can never null out a handle that was not yet stored.
    this.recaptureSweep = this.reapMissingScreenshots()
      .catch((err: unknown) => {
        this.logger.error('monitor worker: screenshot re-capture sweep failed', { err });
      })
      .finally(() => {
        this.recaptureSweep = null;
      });
  }

  /** Await the re-capture sweep currently running off-tick, if any. */
  private async drainRecaptureSweep(): Promise<void> {
    const running = this.recaptureSweep;
    if (running !== null) await running;
  }

  /**
   * Which checks may stand on the fast tier, and which must buy a full browser verdict — and, of
   * the ones that do, which may be deferred when the fleet's browser-load budget is spent.
   *
   * A recovery needs `confirmationRequiredCount` consecutive ACTIVE results. Every one of them
   * used to escalate to a Chromium page load on an identity match — three loads and ~24s per
   * recovery, for three re-reads of the same evidence. Only the LAST one can actually confirm,
   * so only the last one needs the browser: that verdict still gates the alert, and the
   * screenshot probe in {@link handleConfirmed} is a second browser verdict on top of it.
   *
   * PRIORITY is keyed off the case's STATUS, not off whether the check happens to be the deciding
   * one. A case already inside a confirmation burst is chasing a recovery that has probably
   * already happened, so none of its checks may be starved; a MONITORING case is routine polling
   * and is exactly what the budget exists to bound. Keying it off `isDecidingConfirmation` would
   * have left a config-shaped hole — with `CONFIRMATION_REQUIRED_COUNT=1` every baseline check is
   * "deciding", and the entire fleet would have escaped the governor.
   *
   * The MONITORING -> CONFIRMING edge is safe despite being labelled ROUTINE: when the fast tier
   * sees the profile's identity metadata come back, the detector itself upgrades that escalation
   * to CONFIRMATION regardless of this label. The leading edge of a recovery is never deferred.
   */
  private probeOptionsFor(c: MonitoringCase): TieredProbeOptions {
    const loadPriority = c.status === 'CONFIRMING' ? 'CONFIRMATION' : 'ROUTINE';
    // exactOptionalPropertyTypes: omit the key entirely rather than pass `undefined`, so the
    // default (always escalate) is expressed by absence.
    return isDecidingConfirmation(c, this.config.scheduling.confirmationRequiredCount)
      ? { loadPriority }
      : { allowFastActive: true, loadPriority };
  }

  /**
   * Scheduling params for this pass, carrying the fleet's CURRENT browser-load pressure.
   *
   * Read once per use rather than cached: the governor's window rolls continuously, and a stale
   * multiplier would either keep the fleet slow after the pressure lifted or keep it fast into a
   * budget that has already run out.
   */
  private schedulingParams(): SchedulingParams {
    const budget = detectorDiagnostics(this.detector)?.browserBudget?.() ?? null;
    if (budget === null) return schedulingParamsFrom(this.config);
    if (budget.intervalMultiplier !== this.lastLoggedMultiplier) {
      this.lastLoggedMultiplier = budget.intervalMultiplier;
      // Self-throttling is a fact the owner needs, not an internal detail.
      this.logger.warn('monitor worker: baseline cadence changed by the browser-load budget', {
        multiplier: budget.intervalMultiplier,
        effectiveBaselineSeconds:
          this.config.scheduling.baselineIntervalSeconds * budget.intervalMultiplier,
        reason: budget.reason,
      });
    }
    return {
      ...schedulingParamsFrom(this.config),
      baselineIntervalMultiplier: budget.intervalMultiplier,
    };
  }

  /**
   * Milliseconds since this case's confirmation burst began, seeding the start when it is not
   * yet known (a burst inherited across a process restart, which gets a fresh full window —
   * strictly the permissive direction, so it can never discard a genuine recovery).
   *
   * The deadline is BURST-scoped rather than gap-scoped on purpose. Gap-scoped, it measured the
   * time between two checks, which on a slow egress is dominated by the second check's own probe
   * — so a genuine recovery was thrown away and the case re-armed at a fresh baseline, over and
   * over. Burst-scoped it means what it says: how long this confirmation attempt has been going.
   */
  private burstElapsedMs(caseId: string, nowMs: number): number {
    const startedMs = this.confirmationBurstStartMs.get(caseId);
    if (startedMs === undefined) {
      this.confirmationBurstStartMs.set(caseId, nowMs);
      return 0;
    }
    return nowMs - startedMs;
  }

  /**
   * Keep the burst clock in step with the transition just saved: a case entering CONFIRMING
   * starts a window, one leaving it (confirmed, reset, or abandoned) drops it. Without the drop,
   * the NEXT burst for the same case would inherit an already-spent deadline and be abandoned on
   * its first check.
   */
  private trackConfirmationBurst(next: MonitoringCase, nowMs: number): void {
    if (next.status !== 'CONFIRMING') {
      this.confirmationBurstStartMs.delete(next.id);
      return;
    }
    if (!this.confirmationBurstStartMs.has(next.id)) {
      this.confirmationBurstStartMs.set(next.id, nowMs);
    }
  }

  /**
   * Rescue cases stranded mid-notification.
   *
   * A case is saved as CONFIRMED/NOTIFYING BEFORE its outbox row exists, and nothing re-checks a
   * case in those states — they are deliberately skipped by the scheduler so the outbox can
   * finish. Two gaps followed: an ungraceful death between the save and the enqueue left a case
   * with no outbox row at all, and an outbox item that exhausted its attempts (markFailed) left
   * one whose row can never be picked up again. Either way the recovery was never delivered, the
   * case vanished from /list, and nothing ever retried — a silently lost client recovery.
   *
   * This sweep finds those cases and revives the right delivery. `enqueue` alone cannot do it:
   * it is `ON CONFLICT (case_id, kind) DO NOTHING`, so against an exhausted row it silently did
   * nothing while the sweep logged a "re-enqueued" rescue every 60 seconds forever. An exhausted
   * row is therefore re-opened explicitly via `reopenFailed`, and only a real change is logged.
   */
  private async reapStrandedNotifications(): Promise<void> {
    const stranded = await this.repos.cases.listByStatuses(['CONFIRMED', 'NOTIFYING']);
    for (const c of stranded) {
      if (c.notificationSentAtUtc !== null) continue; // already delivered
      if (c.clearedAtUtc !== null) continue; // defense in depth: a cleared case never notifies
      // NOT stranded — its capture is still running off-tick and owns the enqueue. Rescuing it
      // here would queue RECOVERY_TEXT beside the RECOVERY_PHOTO the capture is about to queue,
      // and the outbox's (case_id, kind) uniqueness does not span kinds: the client would be told
      // twice. A capture lost to a crash is not in this map, so a genuinely stranded case still
      // gets rescued.
      if (this.confirmedCaptures.has(c.id)) continue;
      const items = await this.repos.outbox.findByCase(c.id);
      const recoveries = items.filter(
        (i) => i.kind === 'RECOVERY_PHOTO' || i.kind === 'RECOVERY_TEXT',
      );
      // In flight — the outbox still owns it.
      if (recoveries.some((i) => i.status === 'PENDING' || i.status === 'CLAIMED')) continue;
      // The alert DID go out; only the case close-out is missing (a crash between `markSent` and
      // the save). Reviving the row would re-send it, so repair the case from the row instead —
      // silently skipping left it parked in NOTIFYING forever: invisible to /list, never checked
      // again, and still holding the username's active-monitor slot.
      const sent = recoveries.find((i) => i.status === 'SENT');
      if (sent !== undefined) {
        await this.closeOutFromSentRow(c, sent);
        continue;
      }

      const kind = c.screenshotStatus === 'CAPTURED' ? 'RECOVERY_PHOTO' : 'RECOVERY_TEXT';
      const nowIso = this.clock.now().toISOString();
      if (items.some((i) => i.kind === kind)) {
        const revived = await this.repos.outbox.reopenFailed(c.id, kind, nowIso);
        if (!revived) continue; // nothing changed — never claim a rescue that did not happen
      } else {
        await this.repos.outbox.enqueue({ caseId: c.id, kind, createdAtUtc: nowIso });
      }
      this.logger.warn('monitor worker: re-enqueued a stranded notification', {
        caseId: c.id,
        status: c.status,
        kind,
      });
    }
  }

  /**
   * Finish the close-out the outbox never got to, using the delivered row as the record of what
   * the owner actually received. This only ever moves a case FORWARD to NOTIFIED — it sends
   * nothing, so it cannot duplicate an alert.
   */
  private async closeOutFromSentRow(c: MonitoringCase, sent: OutboxItem): Promise<void> {
    // Never clobber a /clear that landed since the sweep read the case.
    const stored = await this.repos.cases.findById(c.id);
    if (stored === null || stored.status === 'CLEARED' || stored.clearedAtUtc !== null) return;
    const nowIso = this.clock.now().toISOString();
    await this.repos.cases.save({
      ...stored,
      status: 'NOTIFIED',
      notificationSentAtUtc: sent.sentAtUtc ?? nowIso,
      telegramMessageId: sent.telegramMessageId,
      screenshotStatus: sent.kind === 'RECOVERY_PHOTO' ? 'SENT' : stored.screenshotStatus,
      updatedAtUtc: nowIso,
    });
    this.logger.warn('monitor worker: closed out a case whose alert had already been delivered', {
      caseId: c.id,
      kind: sent.kind,
    });
  }

  /**
   * Re-take the recovery screenshot for a case that was alerted text-only.
   *
   * The screenshot is the proof the client is paying for, and until now nothing in the system
   * ever re-took one. SCREENSHOT_FOLLOWUP only READ a file from disk, and the sole writer was the
   * one-shot `confirmed` edge — so in production the follow-up found nothing, deferred, and was
   * failed after a few attempts. Every recovery whose capture missed stayed text-only forever,
   * and a throttled egress (circuit breaker OPEN) turned every capture in the window into a miss.
   * That is why the re-capture lives HERE: the outbox owns neither the detector nor the browser.
   *
   * `screenshotStatus === 'FAILED'` on a NOTIFIED case is the durable "still owed a picture"
   * marker, so the follow-up outbox row is now created only once a file genuinely exists — there
   * is no longer a queued item claiming a retry that cannot happen.
   *
   * Bounded three ways, because each attempt is a full browser page load against the single
   * residential IP: one case per sweep, {@link RECAPTURE_SPACING_MS} between attempts on the same
   * case, and nothing older than {@link RECAPTURE_WINDOW_MS}. That single slot is handed round
   * least-recently-attempted first, so no one case can consume the whole budget.
   */
  private async reapMissingScreenshots(): Promise<void> {
    // A probe the fleet-wide breaker will refuse never leaves the process, so no picture can be
    // taken right now — but taking the slot anyway would spend a case's durable spacer, and with
    // it one of the bounded window's attempts, on an attempt that never happened. Reading the
    // breaker is free: in-memory, no request, no page load.
    const diagnostics = detectorDiagnostics(this.detector);
    if (diagnostics !== null && diagnostics.breakerSnapshot().state === 'OPEN') return;
    // The SAME reasoning for the fleet-wide browser-load budget, which the guard above was never
    // extended to. This sweep probes as ROUTINE (see loadPriority below), and the governor refuses
    // a ROUTINE load once total consumption reaches the routine allowance — returning UNKNOWN with
    // no screenshot, having issued no page load at all. Spending the case's durable spacer in front
    // of that consumed one of the ~24 bounded attempts in RECAPTURE_WINDOW_MS on an attempt that
    // never happened; 24 of them fit inside the window, so the client's proof could be lost for
    // good without a single Chromium load ever being issued.
    //
    // The two conditions are POSITIVELY correlated, not independent: a degraded egress is both the
    // dominant cause of the capture miss that put this case here AND what drains the routine
    // allowance (every fast negative escalates to a browser load). The breaker cannot see it —
    // those escalated loads succeed — so this is the only guard that closes it.
    //
    // Free, like the breaker read: an in-memory count, no request, no page load.
    const budget = diagnostics?.browserBudget?.() ?? null;
    if (budget !== null && budget.used >= budget.routineAllowance) {
      this.logger.info('monitor worker: re-capture skipped; routine browser-load allowance spent', {
        used: budget.used,
        routineAllowance: budget.routineAllowance,
      });
      return;
    }

    const nowMs = this.clock.nowMs();
    // LEAST-RECENTLY-ATTEMPTED first, not oldest-created. Both backends return `listByStatuses`
    // in `created_at_utc ASC` order and RECAPTURE_SPACING_MS equals RECAPTURE_SWEEP_INTERVAL_MS,
    // so simply taking the first due candidate handed the same head case every single sweep: one
    // case that CANNOT be captured (a login-walled profile classifies ACTIVE but renders nothing)
    // monopolised all ~24 attempts of its window while every other client owed proof got zero.
    // A fleet-wide throttle downgrades several recoveries at once, so that is the normal shape
    // here rather than an edge case.
    const due = (await this.repos.cases.listByStatuses(['NOTIFIED']))
      .filter((candidate) => isRecaptureDue(candidate, nowMs))
      .sort((a, b) => a.updatedAtUtc.localeCompare(b.updatedAtUtc));
    const c = due[0];
    if (c === undefined) return;

    // Spend the attempt BEFORE probing. `updatedAtUtc` is the durable spacer, so a capture that
    // kills the process must still consume its slot rather than hand the next boot a free one.
    const attemptIso = this.clock.now().toISOString();
    const claimed = await this.repos.cases.findById(c.id);
    if (claimed === null || !isRecaptureDue(claimed, nowMs)) return; // another worker got there
    await this.repos.cases.save({ ...claimed, updatedAtUtc: attemptIso });

    // Every budget the probe gets is sized from RECAPTURE_BUDGET_MS, not chosen independently of
    // it. That is the whole point: the navigation ceiling used to come from the global
    // CAPTURE_TIMEOUT_MS (120s) while the wrapper below allowed 90s, so the wrapper fired
    // mid-`goto` on every profile slower than ~82s — the only profiles this sweep is ever handed,
    // since it takes the least-recently-attempted case and that is the one whose capture keeps
    // missing. Each of those attempts still cost a real Chromium page load against the single
    // residential IP, still spent the case's durable spacer, and still could not produce a file.
    const probe = await this.withDeadline(
      this.safeProbe(c.normalizedUsername, {
        captureScreenshot: true,
        captureNavBudgetMs: RECAPTURE_NAV_BUDGET_MS,
        paintBudgetMs: RECAPTURE_PAINT_BUDGET_MS,
        // ROUTINE, unlike the confirmed-edge capture. The alert has ALREADY been delivered; this
        // is chasing the picture that went with it (harm rank 2), so it must not be allowed to
        // spend the reserve that exists for recoveries nobody has been told about yet. It is
        // separately capped at one attempt per sweep, i.e. 12 loads/hour at most.
        loadPriority: 'ROUTINE',
      }),
      RECAPTURE_BUDGET_MS,
    );
    if (probe === null) {
      this.logger.info('monitor worker: screenshot re-capture exceeded its budget', {
        caseId: c.id,
      });
      return;
    }
    if (probe.screenshot === null) {
      this.logger.info('monitor worker: screenshot re-capture came back empty', {
        caseId: c.id,
        classification: probe.result.classification,
        errorCode: probe.result.evidence.errorCode,
      });
      return;
    }

    const filePath = this.screenshotPath(c.id);
    await mkdir(dirname(filePath), { recursive: true });
    await writeFile(filePath, probe.screenshot.buffer);

    // Re-read: the outbox may have moved the case on while the browser was working. Only a case
    // still owed a picture may be advanced, and only ever to CAPTURED.
    const stored = await this.repos.cases.findById(c.id);
    if (stored === null || stored.screenshotStatus !== 'FAILED') {
      await unlink(filePath).catch(() => undefined); // nothing will ever send this one
      return;
    }
    const nowIso = this.clock.now().toISOString();
    // Queue the delivery BEFORE flipping the case. Dying in between then leaves a claimable row
    // against a case still marked FAILED, so the follow-up still goes out and a repeat sweep
    // costs at most one wasted page load. The other order strands the proof for good: CAPTURED
    // is invisible to this sweep, so nothing would ever queue the row.
    //
    // `enqueue` is ON CONFLICT DO NOTHING, so it cannot revive a row that already spent its
    // attempts against an earlier (fileless) cycle; `reopenFailed` is what re-opens that one.
    await this.repos.outbox.enqueue({
      caseId: stored.id,
      kind: 'SCREENSHOT_FOLLOWUP',
      createdAtUtc: nowIso,
    });
    await this.repos.outbox.reopenFailed(stored.id, 'SCREENSHOT_FOLLOWUP', nowIso);
    await this.repos.cases.save({
      ...stored,
      screenshotStatus: 'CAPTURED',
      updatedAtUtc: nowIso,
    });
    this.logger.warn('monitor worker: re-captured a missing recovery screenshot', {
      caseId: stored.id,
    });
  }

  /**
   * Resolve `work`, or null if it exceeds `ms`. The underlying probe is NOT cancelled — it is
   * simply no longer waited on, so an in-flight browser page still closes normally.
   */
  private async withDeadline<T>(work: Promise<T>, ms: number): Promise<T | null> {
    let timer: ReturnType<typeof setTimeout> | undefined;
    const timeout = new Promise<null>((resolve) => {
      timer = setTimeout(() => resolve(null), ms);
      timer.unref?.();
    });
    try {
      return await Promise.race([work.catch(() => null), timeout]);
    } finally {
      if (timer !== undefined) clearTimeout(timer);
    }
  }

  /**
   * Screenshot + outbox pipeline for a freshly confirmed case. Verifies the
   * profile is still ACTIVE at capture time (cancels otherwise), then moves the
   * case to NOTIFYING and enqueues exactly one outbox item. Any unexpected
   * failure reverts the case to MONITORING so it can never be left stuck.
   */
  private async handleConfirmed(c: MonitoringCase, activeCount: number): Promise<void> {
    let committed = false;
    try {
      let screenshot: Screenshot | null = null;
      let restricted = false;
      const captureDeadline = this.clock.nowMs() + SCREENSHOT_BUDGET_MS;
      for (let attempt = 1; attempt <= SCREENSHOT_ATTEMPTS; attempt++) {
        const remaining = captureDeadline - this.clock.nowMs();
        if (remaining <= 0) {
          this.logger.info('monitor worker: screenshot budget spent; alerting text-first', {
            caseId: c.id,
          });
          break;
        }
        // `null` means the attempt outran the remaining budget. Treated exactly like a capture
        // miss — never as "no longer active", which would wrongly cancel a real recovery.
        // The page load is capped by what is LEFT of the shared budget, not by the global
        // CAPTURE_TIMEOUT_MS. Uncapped, a 120s goto could outlive the deadline that is racing it,
        // and `withDeadline` does not cancel — so the alert went out text-first while an abandoned
        // capture kept a Chromium page and one of the three capture lanes for another minute-plus,
        // and attempts 2 and 3 of SCREENSHOT_ATTEMPTS could never run.
        const probe = await this.withDeadline(
          this.safeProbe(c.normalizedUsername, {
            captureScreenshot: true,
            captureNavBudgetMs: remaining,
            paintBudgetMs: CONFIRMED_PAINT_BUDGET_MS,
            // The client's proof for a recovery nobody has been told about yet. Never deferred:
            // this is what the reserved headroom in the browser-load budget exists for.
            loadPriority: 'CONFIRMATION',
          }),
          remaining,
        );
        if (probe === null) {
          this.logger.info('monitor worker: screenshot exceeded budget; alerting text-first', {
            caseId: c.id,
          });
          break;
        }
        // Only a POSITIVE contradiction cancels the recovery. GONE here means the account really
        // did go away between confirmation and capture, so the alert must not be sent.
        //
        // UNKNOWN must NOT cancel: it means we could not see the page (throttled egress, browser
        // hiccup, timeout), which is no evidence about the account. Treating it as a cancellation
        // discarded three already-verified consecutive ACTIVE checks and restarted the whole
        // cycle — on a flaky proxy that could postpone a real recovery indefinitely.
        if (probe.result.classification === 'GONE') {
          await this.cancelConfirmation(c, activeCount, 'GONE at capture time');
          committed = true;
          return;
        }
        if (probe.result.classification !== 'ACTIVE') {
          // "The egress refused to let me try" is NOT "I tried and the capture failed". While the
          // fleet-wide circuit breaker is OPEN the detector returns UNKNOWN instantly without
          // touching the network, so the retry loop spent all three attempts and the entire 30s
          // budget in ~1.5s of sleeps and the recovery went out with no proof — permanently, and
          // exactly when a throttled IP makes it most likely. Nothing was attempted, so repeating
          // it gains nothing: stop here, alert immediately, and let the case's FAILED screenshot
          // status hand the picture to `reapMissingScreenshots` once the breaker closes.
          if (isThrottleSignal(probe.result.evidence.errorCode)) {
            this.logger.info('monitor worker: capture blocked by egress back-off; alerting now', {
              caseId: c.id,
              errorCode: probe.result.evidence.errorCode,
            });
            break;
          }
          this.logger.info('monitor worker: capture probe inconclusive; keeping confirmation', {
            caseId: c.id,
            errorCode: probe.result.evidence.errorCode,
          });
          if (attempt < SCREENSHOT_ATTEMPTS) {
            await this.sleep(SCREENSHOT_RETRY_DELAY_MS);
            continue;
          }
          break;
        }
        if (probe.screenshot !== null) {
          screenshot = probe.screenshot;
          break;
        }
        // A "Restricted profile" age-gate yields no screenshot BY DESIGN (not a failure):
        // record it so recovery is delivered as a clean text-only "restricted" alert, and
        // stop retrying — extra attempts would never produce a viewable capture.
        if (probe.restricted === true) {
          restricted = true;
          break;
        }
        if (attempt < SCREENSHOT_ATTEMPTS) {
          await this.sleep(SCREENSHOT_RETRY_DELAY_MS);
        }
      }

      // Defense in depth: never move a cleared case into NOTIFYING.
      const stored = await this.repos.cases.findById(c.id);
      if (stored === null || stored.status === 'CLEARED' || stored.clearedAtUtc !== null) {
        this.logger.info('monitor worker: notification dropped; case cleared mid-capture', {
          caseId: c.id,
        });
        committed = true;
        return;
      }

      const nowIso = this.clock.now().toISOString();
      if (screenshot !== null) {
        const filePath = this.screenshotPath(c.id);
        await mkdir(dirname(filePath), { recursive: true });
        await writeFile(filePath, screenshot.buffer);
        const next: MonitoringCase = {
          ...c,
          status: 'NOTIFYING',
          screenshotStatus: 'CAPTURED',
          updatedAtUtc: nowIso,
        };
        await this.repos.cases.save(next);
        await this.repos.outbox.enqueue({
          caseId: c.id,
          kind: 'RECOVERY_PHOTO',
          createdAtUtc: nowIso,
        });
      } else {
        // No screenshot. Either a technical failure — FAILED is the durable marker that
        // {@link reapMissingScreenshots} re-takes the picture from — or a "Restricted profile"
        // age-gate (clean text-only recovery, never re-captured: there is nothing viewable).
        const next: MonitoringCase = {
          ...c,
          status: 'NOTIFYING',
          screenshotStatus: restricted ? 'RESTRICTED' : 'FAILED',
          updatedAtUtc: nowIso,
        };
        await this.repos.cases.save(next);
        await this.repos.outbox.enqueue({
          caseId: c.id,
          kind: 'RECOVERY_TEXT',
          createdAtUtc: nowIso,
        });
      }
      committed = true;
    } catch (err) {
      this.logger.error('monitor worker: screenshot pipeline failed', { caseId: c.id, err });
      if (!committed) {
        try {
          await this.cancelConfirmation(c, activeCount, 'unexpected screenshot pipeline failure');
        } catch (revertErr) {
          this.logger.error('monitor worker: failed to revert confirmed case', {
            caseId: c.id,
            err: revertErr,
          });
        }
      }
    }
  }

  /** Revert a confirmed case back to MONITORING with a fresh baseline check. */
  private async cancelConfirmation(
    c: MonitoringCase,
    activeCount: number,
    reason: string,
  ): Promise<void> {
    // Never clobber a /clear that landed while capturing.
    const stored = await this.repos.cases.findById(c.id);
    if (stored === null || stored.status === 'CLEARED' || stored.clearedAtUtc !== null) {
      return;
    }
    const now = this.clock.now();
    const reverted: MonitoringCase = {
      ...c,
      status: 'MONITORING',
      confirmationCount: 0,
      confirmedAtUtc: null,
      screenshotStatus: 'NONE',
      nextCheckAtUtc: nextBaselineCheckAt(now, activeCount, this.schedulingParams(), this.rand),
      updatedAtUtc: now.toISOString(),
    };
    await this.repos.cases.save(reverted);
    // The burst is over, so its window must not be inherited by the next one.
    this.confirmationBurstStartMs.delete(c.id);
    this.logger.info('monitor worker: confirmation cancelled', { caseId: c.id, reason });
  }

  /** Merge-update the scheduler heartbeat into the health row. */
  private async recordSchedulerRun(nowIso: string): Promise<void> {
    const existing = await this.repos.health.get(HEALTH_NAME);
    const base = existing ?? emptyHealth(nowIso);
    await this.repos.health.upsert({
      ...base,
      lastSchedulerRunUtc: nowIso,
      updatedAtUtc: nowIso,
    });
  }

  /**
   * Roll the unknown-rate EMA and (on non-UNKNOWN) the last successful check.
   *
   * A check that NEVER TOUCHED THE NETWORK moves NOTHING. The rate answers exactly one question —
   * "are the checks we actually make coming back unreadable?" — and a probe the circuit breaker
   * refused or the governor deferred was never made, so it is evidence about our own back-off, not
   * about Instagram. Feeding it in inverted the meaning: the harder the fleet protected the IP, the
   * more "degraded" it declared itself, which is what produced WARNING/RESTORED cycles all night
   * over a fleet whose real checks were almost entirely clean.
   *
   * Leaving the EMA untouched is deliberately different from recording a success. Back-off says
   * nothing either way, and inventing a success would mask a genuine outage that begins during a
   * cooldown. The rate simply holds its last real value until real evidence arrives.
   */
  private async updateCheckHealth(
    classification: 'ACTIVE' | 'GONE' | 'UNKNOWN',
    nowIso: string,
    notObserved = false,
  ): Promise<void> {
    if (notObserved) return;
    const existing = (await this.repos.health.get(HEALTH_NAME)) ?? emptyHealth(nowIso);
    const isUnknown = classification === 'UNKNOWN' ? 1 : 0;
    await this.repos.health.upsert({
      ...existing,
      recentUnknownRate:
        (1 - UNKNOWN_RATE_WEIGHT) * existing.recentUnknownRate + UNKNOWN_RATE_WEIGHT * isUnknown,
      lastSuccessfulCheckUtc:
        classification !== 'UNKNOWN' ? nowIso : existing.lastSuccessfulCheckUtc,
      updatedAtUtc: nowIso,
    });
  }

  /** Probe that never throws: any detector crash is recorded as UNKNOWN. */
  private async safeProbe(username: string, options?: TieredProbeOptions): Promise<ProbeResult> {
    try {
      return options !== undefined
        ? await this.detector.probe(username, options)
        : await this.detector.probe(username);
    } catch (err) {
      this.logger.warn('monitor worker: detector probe threw', { username, err });
      return {
        result: {
          classification: 'UNKNOWN',
          evidence: {
            signalsVersion: SIGNALS_VERSION,
            activeSignals: [],
            goneSignals: [],
            identitySignalMatched: false,
            finalUrl: null,
            responseStatus: null,
            errorCode: 'UNKNOWN_ERROR',
          },
          durationMs: 0,
        },
        screenshot: null,
      };
    }
  }

  private screenshotPath(caseId: string): string {
    return join(this.screenshotDir, `${caseId}.png`);
  }
}

/**
 * Would an ACTIVE result on the NEXT check of this case confirm the recovery?
 *
 * Mirrors `applyCheckResult` exactly, and must keep mirroring it: a CONFIRMING case advances to
 * `confirmationCount + 1`, anything else (MONITORING or a bounded-backoff state) restarts the
 * burst at 1 — which already confirms when only one ACTIVE is required. Getting this wrong in the
 * permissive direction would let a recovery be confirmed on fast-tier evidence alone, so it errs
 * the other way: an unexpected status is treated as deciding, and simply pays for a browser load.
 */
function isDecidingConfirmation(c: MonitoringCase, requiredCount: number): boolean {
  const countAfterActive = c.status === 'CONFIRMING' ? c.confirmationCount + 1 : 1;
  return countAfterActive >= requiredCount;
}

/**
 * Is this case still owed its recovery screenshot, and due another (page-load-costing) attempt?
 *
 * A delivered alert is required: while the outbox still owns the case the picture may yet go out
 * with the alert itself, and re-capturing underneath it would spend the IP budget for nothing.
 */
function isRecaptureDue(c: MonitoringCase, nowMs: number): boolean {
  if (c.screenshotStatus !== 'FAILED') return false;
  if (c.clearedAtUtc !== null) return false;
  if (c.notificationSentAtUtc === null) return false;
  if (nowMs - new Date(c.notificationSentAtUtc).getTime() > RECAPTURE_WINDOW_MS) return false;
  return nowMs - new Date(c.updatedAtUtc).getTime() >= RECAPTURE_SPACING_MS;
}

/** Routine Instagram ambiguity is UNKNOWN, not an application error. */
function isRetryableOperationalFailure(errorCode: string | null): boolean {
  return (
    errorCode === 'TIMEOUT' ||
    errorCode === 'DNS' ||
    errorCode === 'NAVIGATION' ||
    errorCode === 'BROWSER_CRASH' ||
    errorCode === 'HTTP_5XX'
  );
}

/** A fresh, empty health row for first-run upserts. */
function emptyHealth(nowIso: string): SchedulerHealth {
  return {
    name: HEALTH_NAME,
    lastSchedulerRunUtc: null,
    lastSuccessfulCheckUtc: null,
    lastControlOkUtc: null,
    recentUnknownRate: 0,
    browserRestarts: 0,
    detectorUnhealthy: false,
    lastWarningSentUtc: null,
    updatedAtUtc: nowIso,
  };
}
