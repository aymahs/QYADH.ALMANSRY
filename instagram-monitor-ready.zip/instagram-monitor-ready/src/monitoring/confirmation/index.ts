/** Small presentation/timeout helpers for the confirmation burst. */

/** Human-readable progress label, e.g. `Confirming 2/3`. */
export function confirmationLabel(count: number, required: number): string {
  return `Confirming ${count}/${required}`;
}

/**
 * True once a confirmation burst has been running for at least `deadlineSeconds`.
 * `confirmationStartMs` is epoch milliseconds; comparison is inclusive of the
 * exact deadline.
 */
export function isConfirmationExpired(
  confirmationStartMs: number,
  now: Date,
  deadlineSeconds: number,
): boolean {
  const elapsedMs = now.getTime() - confirmationStartMs;
  return elapsedMs >= deadlineSeconds * 1000;
}
