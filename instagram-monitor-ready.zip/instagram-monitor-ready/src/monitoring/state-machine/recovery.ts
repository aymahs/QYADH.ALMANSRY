/**
 * Restart safety. On process startup every persisted case is passed through
 * {@link recoverOnStartup} to release stale job leases and to discard any
 * in-flight confirmation burst whose ACTIVE results cannot be trusted across a
 * restart. CONFIRMED/NOTIFYING cases are kept so the outbox can finish sending.
 */

import type { MonitoringCase } from '../../domain';

/**
 * Return a new case that is safe to resume after a crash/restart:
 *  - the job lease is always released (leaseOwner / leaseExpiresAtUtc = null);
 *  - CONFIRMING -> MONITORING with confirmationCount 0 and an immediate re-check
 *    (old ACTIVE results in a partial burst cannot be reused);
 *  - CONFIRMED / NOTIFYING are preserved untouched (aside from the lease) so the
 *    notification outbox can complete;
 *  - MONITORING / ERROR_BACKOFF / terminal states are left as-is (lease aside).
 */
export function recoverOnStartup(c: MonitoringCase, now: Date): MonitoringCase {
  const nowIso = now.toISOString();
  const recovered: MonitoringCase = {
    ...c,
    leaseOwner: null,
    leaseExpiresAtUtc: null,
    updatedAtUtc: nowIso,
  };

  if (c.status === 'CONFIRMING') {
    recovered.status = 'MONITORING';
    recovered.confirmationCount = 0;
    recovered.nextCheckAtUtc = nowIso;
  }

  // A historical crash or a bad legacy transition must not strand a backoff case.
  if (
    (c.status === 'ERROR_BACKOFF' || c.status === 'UNKNOWN_BACKOFF') &&
    c.nextCheckAtUtc === null
  ) {
    recovered.nextCheckAtUtc = nowIso;
    recovered.errorBackoffUntilUtc = nowIso;
  }

  // Clock-discontinuity guard: if a host clock was skewed when this case was written and
  // has since been corrected, its timestamps can be in the future. A start time can never
  // be in the future — clamp it (prevents a zero/negative /list timer). And an active
  // monitor whose next check is implausibly far out (a stale fast-clock value) is pulled to
  // now so a corrected clock can never leave it silently unmonitored.
  const isActive =
    recovered.status === 'MONITORING' ||
    recovered.status === 'CONFIRMING' ||
    recovered.status === 'ERROR_BACKOFF' ||
    recovered.status === 'UNKNOWN_BACKOFF';

  if (Date.parse(c.startedAtUtc) > now.getTime()) {
    recovered.startedAtUtc = nowIso;
  }
  if (isActive) {
    const next = recovered.nextCheckAtUtc;
    if (next === null || Date.parse(next) > now.getTime() + STRANDED_NEXT_CHECK_MS) {
      recovered.nextCheckAtUtc = nowIso;
    }
  }

  return recovered;
}

/** An active monitor's next check should never be more than a few minutes out. */
const STRANDED_NEXT_CHECK_MS = 5 * 60 * 1000;
