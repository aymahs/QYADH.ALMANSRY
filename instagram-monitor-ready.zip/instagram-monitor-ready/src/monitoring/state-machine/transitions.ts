/**
 * The pure monitoring state transition. Given a case, a fresh classification,
 * and the current time, it computes the next case — including the exactly-once
 * `confirmed` edge that tells the caller to capture a screenshot and notify.
 *
 * This function is total, side-effect free, and never mutates `current`.
 */

import type { Classification, MonitoringCase } from '../../domain';
import type { SchedulingParams } from '../scheduling';
import { nextBaselineCheckAt, nextConfirmationCheckAt, nextRetryCheckAt } from '../scheduling';

/** Scheduling params plus the runtime context needed to decide a transition. */
export interface TransitionParams extends SchedulingParams {
  /** Number of active cases, used to scale the baseline interval. */
  activeCount: number;
  /** Consecutive UNKNOWN results that trip a case into ERROR_BACKOFF (default 3). */
  unknownThreshold: number;
}

export interface TransitionInput {
  current: MonitoringCase;
  classification: Classification;
  now: Date;
  params: TransitionParams;
  /** Injected randomness for jitter; defaults to Math.random at runtime. */
  rand?: () => number;
  /** Caller-detected: the confirmation burst outlived its deadline. */
  confirmationDeadlineExceeded?: boolean;
  /** True only for retryable browser/transport failures, never for a routine ambiguous page. */
  operationalFailure?: boolean;
}

export interface TransitionOutput {
  next: MonitoringCase;
  /**
   * True EXACTLY on the transition that reaches the required consecutive ACTIVE
   * count. Never true more than once for a case's lifetime.
   */
  confirmed: boolean;
}

/**
 * Advance a monitoring case by one check result. See the module doc for the
 * full state table; the short version:
 *  - terminal (NOTIFIED/CLEARED) is a no-op — a late result never revives a case;
 *  - CONFIRMED/NOTIFYING re-checks never re-confirm;
 *  - MONITORING/ERROR_BACKOFF: ACTIVE starts confirmation, GONE re-arms baseline,
 *    UNKNOWN accrues toward backoff;
 *  - CONFIRMING: consecutive ACTIVE reaches CONFIRMED; GONE/UNKNOWN/deadline reset.
 */
export function applyCheckResult(input: TransitionInput): TransitionOutput {
  const { current, classification, now, params } = input;
  const rand = input.rand ?? Math.random;
  const nowIso = now.toISOString();

  // Terminal states are frozen: a late-arriving result must never revive them.
  if (current.status === 'NOTIFIED' || current.status === 'CLEARED') {
    return { next: current, confirmed: false };
  }

  // Every non-terminal path produces a fresh object with refreshed timestamps.
  const next: MonitoringCase = {
    ...current,
    lastCheckedAtUtc: nowIso,
    updatedAtUtc: nowIso,
  };

  // A re-check while the case is confirmed / being notified: keep status, never
  // re-confirm. Screenshot-failure cancellation is the caller's concern.
  if (current.status === 'CONFIRMED' || current.status === 'NOTIFYING') {
    return { next, confirmed: false };
  }

  if (current.status === 'CONFIRMING') {
    // A confirmation burst that outran its deadline is abandoned back to baseline.
    if (input.confirmationDeadlineExceeded === true) {
      next.status = 'MONITORING';
      next.confirmationCount = 0;
      next.nextCheckAtUtc = nextBaselineCheckAt(now, params.activeCount, params, rand);
      return { next, confirmed: false };
    }

    switch (classification) {
      case 'ACTIVE': {
        const count = current.confirmationCount + 1;
        next.confirmationCount = count;
        next.consecutiveUnknownCount = 0;
        next.lastResult = 'ACTIVE';
        if (count >= params.confirmationRequiredCount) {
          next.status = 'CONFIRMED';
          next.confirmedAtUtc = nowIso;
          next.nextCheckAtUtc = null;
          return { next, confirmed: true };
        }
        next.status = 'CONFIRMING';
        next.nextCheckAtUtc = nextConfirmationCheckAt(now, params);
        return { next, confirmed: false };
      }
      case 'GONE': {
        next.status = 'MONITORING';
        next.confirmationCount = 0;
        next.lastResult = 'GONE';
        next.nextCheckAtUtc = nextBaselineCheckAt(now, params.activeCount, params, rand);
        return { next, confirmed: false };
      }
      case 'UNKNOWN': {
        // UNKNOWN breaks the consecutive-ACTIVE streak; a fresh burst is required.
        next.status = 'MONITORING';
        next.confirmationCount = 0;
        next.lastResult = 'UNKNOWN';
        next.nextCheckAtUtc = nextBaselineCheckAt(now, params.activeCount, params, rand);
        return { next, confirmed: false };
      }
      default:
        return { next, confirmed: false };
    }
  }

  // Bound a run of backoffs. An account must periodically return to ordinary
  // monitoring rather than looking permanently stranded in a backoff state.
  const BACKOFF_CYCLE_LIMIT = 8;

  // current.status is MONITORING or either bounded-backoff state.
  switch (classification) {
    case 'ACTIVE': {
      next.consecutiveUnknownCount = 0;
      next.confirmationCount = 1;
      next.lastResult = 'ACTIVE';
      next.errorBackoffUntilUtc = null;
      if (params.confirmationRequiredCount <= 1) {
        next.status = 'CONFIRMED';
        next.confirmedAtUtc = nowIso;
        next.nextCheckAtUtc = null;
        return { next, confirmed: true };
      }
      next.status = 'CONFIRMING';
      next.nextCheckAtUtc = nextConfirmationCheckAt(now, params);
      return { next, confirmed: false };
    }
    case 'GONE': {
      next.status = 'MONITORING';
      next.confirmationCount = 0;
      next.consecutiveUnknownCount = 0;
      next.lastResult = 'GONE';
      next.errorBackoffUntilUtc = null;
      next.nextCheckAtUtc = nextBaselineCheckAt(now, params.activeCount, params, rand);
      return { next, confirmed: false };
    }
    case 'UNKNOWN': {
      const unknownCount = current.consecutiveUnknownCount + 1;
      next.consecutiveUnknownCount = unknownCount;
      next.confirmationCount = 0;
      next.lastResult = 'UNKNOWN';
      // Every UNKNOWN (login wall, rate limit, timeout, ...) stays actively scheduled on
      // the SHORT retry ladder (5/10/15/30s cap) — never a long backoff that could miss a
      // recovery. Operational failures are labelled ERROR_BACKOFF, routine ambiguity
      // UNKNOWN_BACKOFF, but both retry equally fast. After BACKOFF_CYCLE_LIMIT the label
      // folds back to plain MONITORING so it never looks permanently stranded.
      if (unknownCount >= BACKOFF_CYCLE_LIMIT) {
        next.status = 'MONITORING';
        next.consecutiveUnknownCount = 0;
        next.errorBackoffUntilUtc = null;
        next.nextCheckAtUtc = nextBaselineCheckAt(now, params.activeCount, params, rand);
        return { next, confirmed: false };
      }
      const at = nextRetryCheckAt(now, unknownCount, params, rand);
      next.status = input.operationalFailure ? 'ERROR_BACKOFF' : 'UNKNOWN_BACKOFF';
      next.errorBackoffUntilUtc = at;
      next.nextCheckAtUtc = at;
      return { next, confirmed: false };
    }
    default:
      return { next, confirmed: false };
  }
}
