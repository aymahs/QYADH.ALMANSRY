/**
 * Pure scheduling math for the monitoring loop: a flat fast baseline interval,
 * small absolute jitter, confirmation cadence, and a short bounded retry ladder.
 * No I/O, no clock — every function is deterministic given its inputs.
 *
 * Design goal: notify as soon as a page returns. The baseline interval is a flat,
 * fleet-independent value (default 15s) and every inconclusive result (UNKNOWN or a
 * retryable operational error) reschedules within a few seconds via the retry ladder,
 * capped short — a monitor is NEVER parked in a long backoff where a recovery is missed.
 */

/** Tunable timing parameters, sourced from {@link AppConfig.scheduling}. */
export interface SchedulingParams {
  baselineIntervalSeconds: number;
  baselineJitterMaxSeconds: number;
  confirmationIntervalSeconds: number;
  confirmationRequiredCount: number;
  confirmationDeadlineSeconds: number;
  /** Retry delays by consecutive-failure count, e.g. [5, 10, 15, 30]; last value repeats. */
  retryDelaysSeconds: number[];
  /** Hard cap on any retry delay (default 30s). */
  errorBackoffMaxSeconds: number;
  // Retained for config/back-compat; superseded by the retry ladder above.
  unknownBackoffBaseSeconds: number;
  unknownBackoffMaxSeconds: number;
  errorBackoffInitialSeconds: number;
  /**
   * Fleet-wide stretch applied to the BASELINE interval only (1 = full speed). Omit for 1.
   *
   * This is how the browser-load governor's back-pressure reaches the state machine without the
   * state machine having to know the governor exists: the monitor worker recomputes it once per
   * tick from {@link BrowserLoadGovernor.intervalMultiplier} and hands it down with the rest of
   * the params. Everything downstream — including `applyCheckResult` — picks it up for free.
   *
   * Deliberately NOT applied to the confirmation cadence or the retry ladder. Those are spent
   * inside a recovery that has already happened, or chasing a check that failed; slowing them
   * costs the client latency on the one path that matters, and neither is a volume driver.
   */
  baselineIntervalMultiplier?: number;
}

/** Hardest the governor is ever allowed to stretch the baseline, mirrored from the governor. */
const MAX_BASELINE_MULTIPLIER = 8;

/**
 * Clamp a caller-supplied multiplier into a sane range. A garbage value (NaN, 0, negative, or an
 * absurd number) must never be able to either hammer the egress or park the fleet for hours.
 */
function safeMultiplier(value: number | undefined): number {
  if (value === undefined || !Number.isFinite(value)) return 1;
  return Math.min(MAX_BASELINE_MULTIPLIER, Math.max(1, value));
}

/** Never schedule a check less than this many seconds out. */
const MIN_DELAY_SECONDS = 1;

function addSeconds(now: Date, seconds: number): Date {
  return new Date(now.getTime() + seconds * 1000);
}

/**
 * Baseline poll interval. FLAT and fleet-independent — monitoring four accounts must
 * not be four times slower than monitoring one. Concurrency is bounded by the browser
 * worker pool, not by stretching each account's interval.
 *
 * The ONE thing that does stretch it is {@link SchedulingParams.baselineIntervalMultiplier}: the
 * fleet-wide browser-load budget, which is a property of the shared egress IP rather than of the
 * fleet size. That is not the "N accounts means N times slower" mistake this function exists to
 * avoid — it is the same interval for every account, sized to what the single residential IP can
 * actually carry this hour.
 */
export function baselineIntervalSeconds(_activeCount: number, p: SchedulingParams): number {
  return p.baselineIntervalSeconds * safeMultiplier(p.baselineIntervalMultiplier);
}

/**
 * Add absolute jitter in `[0, maxJitter]` seconds using an injected `rand` in [0, 1).
 * `rand() === 0` yields zero jitter, which keeps timing tests deterministic. Result is
 * clamped to never fall below {@link MIN_DELAY_SECONDS}.
 */
export function applyJitter(
  seconds: number,
  maxJitter: number,
  rand: () => number = Math.random,
): number {
  const jitter = rand() * Math.max(0, maxJitter);
  return Math.max(MIN_DELAY_SECONDS, seconds + jitter);
}

/** ISO-8601 UTC of the next baseline check: `now + baseline + jitter(0..baselineJitterMax)`. */
export function nextBaselineCheckAt(
  now: Date,
  activeCount: number,
  p: SchedulingParams,
  rand: () => number = Math.random,
): string {
  const seconds = applyJitter(
    baselineIntervalSeconds(activeCount, p),
    p.baselineJitterMaxSeconds,
    rand,
  );
  return addSeconds(now, seconds).toISOString();
}

/** ISO-8601 UTC of the next confirmation check: exact `now + confirmationInterval` (no jitter). */
export function nextConfirmationCheckAt(now: Date, p: SchedulingParams): string {
  return addSeconds(now, p.confirmationIntervalSeconds).toISOString();
}

/**
 * Short bounded retry delay for the Nth consecutive inconclusive result (failureCount >= 1):
 * the Nth entry of the ladder, the last entry repeating, hard-capped at errorBackoffMaxSeconds.
 * e.g. ladder [5,10,15,30] -> 5, 10, 15, 30, 30, 30, ...
 */
export function retryDelaySeconds(failureCount: number, p: SchedulingParams): number {
  const ladder =
    p.retryDelaysSeconds.length > 0 ? p.retryDelaysSeconds : [p.errorBackoffMaxSeconds];
  const idx = Math.min(Math.max(failureCount, 1) - 1, ladder.length - 1);
  const delay = ladder[idx] ?? p.errorBackoffMaxSeconds;
  return Math.min(delay, p.errorBackoffMaxSeconds);
}

/** ISO-8601 UTC of the next retry: `now + retryDelay + small jitter`. */
export function nextRetryCheckAt(
  now: Date,
  failureCount: number,
  p: SchedulingParams,
  rand: () => number = Math.random,
): string {
  const seconds = applyJitter(retryDelaySeconds(failureCount, p), p.baselineJitterMaxSeconds, rand);
  return addSeconds(now, seconds).toISOString();
}
