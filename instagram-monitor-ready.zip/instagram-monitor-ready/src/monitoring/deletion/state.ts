/**
 * Pure deletion-watch transition — the mirror of the recovery state machine, but the target
 * is GONE instead of ACTIVE. Given a watch, a fresh classification, and the time, it returns
 * the next watch and an exactly-once `confirmed` edge (reached required consecutive GONE).
 *
 * Total, side-effect free, never mutates `current`. Fully independent of the recovery
 * transition — the two features share only the (pure) scheduling helpers.
 */

import type { Classification, DeletionWatch } from '../../domain';
import { DELETION_DECIDED_STATUSES } from '../../domain/deletion';
import type { SchedulingParams } from '../scheduling';
import { nextBaselineCheckAt, nextConfirmationCheckAt, nextRetryCheckAt } from '../scheduling';

export interface DeletionTransitionParams extends SchedulingParams {
  /** Active watch count, used to scale the baseline interval. */
  activeCount: number;
}

export interface DeletionTransitionInput {
  current: DeletionWatch;
  classification: Classification;
  now: Date;
  params: DeletionTransitionParams;
  /** Injected randomness for jitter; defaults to Math.random. */
  rand?: () => number;
}

export interface DeletionTransitionOutput {
  next: DeletionWatch;
  /** True EXACTLY on the transition that reaches the required consecutive GONE count. */
  confirmed: boolean;
}

/** A run of UNKNOWNs eventually folds back to WATCHING so a watch never looks stranded. */
const BACKOFF_CYCLE_LIMIT = 8;

/**
 * Seal the confirmed edge into `next`. The CONFIRMED status is part of the transition rather
 * than something the worker bolts on afterwards, so the decision reaches the database in one
 * write, before any alert leaves the process. The watch is left due *now* on purpose: the only
 * work remaining is the alert fan-out, and a crash before it must leave a claimable row rather
 * than a stranded one with no next check.
 */
function sealConfirmed(next: DeletionWatch, nowIso: string): DeletionTransitionOutput {
  next.status = 'CONFIRMED';
  next.confirmedAtUtc = nowIso;
  next.nextCheckAtUtc = nowIso;
  return { next, confirmed: true };
}

/**
 * Advance a deletion watch by one check result:
 *  - decided (CONFIRMED/ALERTING/NOTIFIED) and CLEARED are no-ops — a late result never
 *    revives a cleared watch, and never un-decides one whose alerts have gone out;
 *  - WATCHING/BACKOFF: GONE starts confirmation, ACTIVE re-arms baseline, UNKNOWN backs off;
 *  - CONFIRMING: consecutive GONE reaches the confirmed edge; ACTIVE/UNKNOWN reset it.
 */
export function applyDeletionCheck(input: DeletionTransitionInput): DeletionTransitionOutput {
  const { current, classification, now, params } = input;
  const rand = input.rand ?? Math.random;
  const nowIso = now.toISOString();

  if (current.status === 'CLEARED' || DELETION_DECIDED_STATUSES.includes(current.status)) {
    return { next: current, confirmed: false };
  }

  const next: DeletionWatch = { ...current, lastCheckedAtUtc: nowIso, updatedAtUtc: nowIso };

  if (current.status === 'CONFIRMING') {
    switch (classification) {
      case 'GONE': {
        const count = current.confirmationCount + 1;
        next.confirmationCount = count;
        next.consecutiveUnknownCount = 0;
        next.lastResult = 'GONE';
        if (count >= params.confirmationRequiredCount) {
          return sealConfirmed(next, nowIso);
        }
        next.status = 'CONFIRMING';
        next.nextCheckAtUtc = nextConfirmationCheckAt(now, params);
        return { next, confirmed: false };
      }
      // ACTIVE (came back) or UNKNOWN (streak broken) both reset the burst to baseline.
      case 'ACTIVE':
      case 'UNKNOWN':
      default: {
        next.status = 'WATCHING';
        next.confirmationCount = 0;
        next.lastResult = classification;
        next.nextCheckAtUtc = nextBaselineCheckAt(now, params.activeCount, params, rand);
        return { next, confirmed: false };
      }
    }
  }

  // current.status is WATCHING or BACKOFF.
  switch (classification) {
    case 'GONE': {
      next.consecutiveUnknownCount = 0;
      next.confirmationCount = 1;
      next.lastResult = 'GONE';
      if (params.confirmationRequiredCount <= 1) {
        return sealConfirmed(next, nowIso);
      }
      next.status = 'CONFIRMING';
      next.nextCheckAtUtc = nextConfirmationCheckAt(now, params);
      return { next, confirmed: false };
    }
    case 'ACTIVE': {
      next.status = 'WATCHING';
      next.confirmationCount = 0;
      next.consecutiveUnknownCount = 0;
      next.lastResult = 'ACTIVE';
      next.nextCheckAtUtc = nextBaselineCheckAt(now, params.activeCount, params, rand);
      return { next, confirmed: false };
    }
    case 'UNKNOWN': {
      const unknownCount = current.consecutiveUnknownCount + 1;
      next.consecutiveUnknownCount = unknownCount;
      next.confirmationCount = 0;
      next.lastResult = 'UNKNOWN';
      if (unknownCount >= BACKOFF_CYCLE_LIMIT) {
        next.status = 'WATCHING';
        next.consecutiveUnknownCount = 0;
        next.nextCheckAtUtc = nextBaselineCheckAt(now, params.activeCount, params, rand);
        return { next, confirmed: false };
      }
      next.status = 'BACKOFF';
      next.nextCheckAtUtc = nextRetryCheckAt(now, unknownCount, params, rand);
      return { next, confirmed: false };
    }
    default:
      return { next, confirmed: false };
  }
}
