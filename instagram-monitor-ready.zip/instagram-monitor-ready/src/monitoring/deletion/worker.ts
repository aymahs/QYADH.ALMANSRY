/**
 * The deletion-watch worker: one tick claims due watches under a lease, probes each profile
 * (NO screenshot — deletions are text-only), threads the result through {@link applyDeletionCheck},
 * and on the exactly-once `confirmed` edge fans the deletion out to the owner, to Discord, and
 * into the linked client chat.
 *
 * Fully separate from {@link MonitorWorker}: it only ever touches `deletion_watches` via
 * `repos.deletionWatches`, and it sends notifications directly (no outbox). Reliability:
 *  - a watch is processed by at most one worker at a time (repo lease semantics);
 *  - an /unwatch that lands mid-check always wins (compare-and-save re-read before save);
 *  - the confirmation is written down BEFORE the first alert is sent and is never taken back,
 *    so a client is never told about a deletion the bot later un-decides;
 *  - a confirmed watch retries only what is still outstanding (the owner alert, the client
 *    delivery, or both) — every channel carries a durable exactly-once marker, so nothing
 *    replays on a retry;
 *  - a watch left decided-but-unalerted (crash mid-fan-out, a failed owner send, or a client
 *    delivery that could not even record its outcome) is picked back up by a periodic sweep,
 *    because `claimDue` never returns one.
 */

import type {
  BusinessDeliveryStatus,
  Clock,
  DeletionWatch,
  Detector,
  Repositories,
  TelegramClient,
} from '../../domain';
import type { AppConfig } from '../../config';
import { DELETION_PENDING_ALERT_STATUSES } from '../../domain/deletion';
import type { ClientSendOutcome } from '../../domain/clients';
import {
  CLIENT_DELIVERY_DONE_STATUSES,
  CLIENT_DELIVERY_IN_FLIGHT_STATUS,
  CLIENT_DELIVERY_OWED_STATUS,
  classifyClientSendFailure,
  clientRetryExhausted,
  ownerPingRetryExhausted,
} from '../../domain/clients';
import type { Logger } from '../../logging';
import type { LoadPriority } from '../../instagram/load-governor';
// Deep import (not the detector barrel) so this worker never pulls Playwright into scope.
import type { TieredProbeOptions } from '../../instagram/detector/tiered-detector';
import type { DiscordNotifier } from '../../bot/discord/discord-notifier';
import {
  deletionConfirmed,
  clientDeletionConfirmed,
  ownerActionRequiredDeletion,
  recoveryButton,
} from '../../notifications/formatter';
import type { SchedulingParams } from '../scheduling';
import { nextBaselineCheckAt } from '../scheduling';
import { schedulingParamsFrom } from '../scheduler';
import { applyDeletionCheck } from './state';

/**
 * The single Discord capability this worker needs. Narrowed from {@link DiscordNotifier} so the
 * mirror can be stood in for without a Discord client.
 */
export type DeletionMirror = Pick<DiscordNotifier, 'deletion'>;

/**
 * Link states that already produced the owner "deliver this by hand" ping. A link parked in one
 * of these means the ping went out on the pass that put it there, so a later retry pass must
 * stay silent instead of re-pinging the owner on every re-arm.
 */
const OWNER_PINGED_DELIVERY_STATUSES: readonly BusinessDeliveryStatus[] = [
  'BUSINESS_CONNECTION_DISABLED',
  'BUSINESS_PERMISSION_MISSING',
  'OWNER_ACTION_REQUIRED',
];

/** How often to sweep for watches stranded mid-fan-out; it scans, so not on every 1s tick. */
const ALERT_REAP_INTERVAL_MS = 60_000;

/**
 * What one client-delivery attempt settled.
 *  - `RECORDED`: the client's fate is written down (delivered, escalated to the owner, or there
 *    is no link at all), so the link itself will stop a later pass repeating anything.
 *  - `TOLD_UNRECORDED`: the client HAS been told, but the link could not be updated to say so.
 *    That marker is the ONLY exactly-once guard the client channel has, so nothing may run this
 *    delivery again.
 *  - `RETRY_OWED`: the send provably did not land and the retry budget is not spent. The client's
 *    fate is NOT settled, so the watch must stay retryable — collapsing this into `RECORDED` is
 *    what used to turn one transient Telegram failure into a permanent silent miss.
 */
type ClientDeliveryOutcome = 'RECORDED' | 'TOLD_UNRECORDED' | 'RETRY_OWED';

export interface DeletionWorkerDeps {
  repos: Repositories;
  detector: Detector;
  client: TelegramClient;
  config: AppConfig;
  clock: Clock;
  logger: Logger;
  /** Resolves the paired owner's chat id, or null while unpaired. */
  ownerChatId: () => Promise<number | null>;
  /** Optional best-effort Discord mirror (#deletions); fires once per confirmed deletion. */
  discord?: DeletionMirror;
  rand?: () => number;
  workerId?: string;
}

export class DeletionWorker {
  private readonly repos: Repositories;
  private readonly detector: Detector;
  private readonly client: TelegramClient;
  private readonly config: AppConfig;
  private readonly clock: Clock;
  private readonly logger: Logger;
  private readonly ownerChatId: () => Promise<number | null>;
  private readonly discord: DeletionMirror | null;
  private readonly rand: () => number;
  private readonly workerId: string;

  private timer: ReturnType<typeof setInterval> | null = null;
  private inFlight: Promise<void> | null = null;
  /** Epoch ms of the last stranded-alert sweep (0 = never, so the first tick runs one). */
  private lastReapMs = 0;

  constructor(deps: DeletionWorkerDeps) {
    this.repos = deps.repos;
    this.detector = deps.detector;
    this.client = deps.client;
    this.config = deps.config;
    this.clock = deps.clock;
    this.logger = deps.logger;
    this.ownerChatId = deps.ownerChatId;
    this.discord = deps.discord ?? null;
    this.rand = deps.rand ?? Math.random;
    this.workerId = deps.workerId ?? 'deletion-worker';
  }

  /** One tick: claim due watches, process each under its lease, then rescue stranded alerts. */
  async runOnce(): Promise<void> {
    const now = this.clock.now();
    const nowIso = now.toISOString();
    const leaseExpiresUtc = new Date(
      now.getTime() + this.config.scheduling.jobLeaseSeconds * 1000,
    ).toISOString();

    const claimed = await this.repos.deletionWatches.claimDue({
      nowUtc: nowIso,
      leaseOwner: this.workerId,
      leaseExpiresUtc,
      limit: this.config.scheduling.maxBrowserConcurrency,
    });

    for (const w of claimed) {
      try {
        await this.processWatch(w);
      } catch (err) {
        this.logger.error('deletion worker: watch processing failed', { watchId: w.id, err });
      } finally {
        await this.repos.deletionWatches.releaseLease(w.id, this.clock.now().toISOString());
      }
    }

    if (now.getTime() - this.lastReapMs >= ALERT_REAP_INTERVAL_MS) {
      this.lastReapMs = now.getTime();
      await this.reapStrandedAlerts(new Set(claimed.map((w) => w.id))).catch((err: unknown) => {
        this.logger.error('deletion worker: stranded-alert sweep failed', { err });
      });
    }
  }

  /**
   * Rescue watches stranded mid-fan-out.
   *
   * Both halves of the exactly-once design park a watch in a decided status and rely on a later
   * pass to finish the job: the confirmation is saved as CONFIRMED before any alert is sent, and
   * a failed owner send re-arms the row while leaving it ALERTING. `claimDue` cannot be that
   * pass — its due-check queue only serves the statuses that still need a probe, and a decided
   * watch never needs one again. Without this sweep a crash between the CONFIRMED write and the
   * fan-out, or a single unreachable-owner send, stranded the watch for good: no Discord mirror,
   * no owner alert, no client delivery, and a row stuck active in /banlist that also blocked
   * re-running /ban on the username. That is the missed client notification this module exists
   * to prevent.
   *
   * `listActive` is the read that reaches them, since it excludes only the terminal statuses.
   * Nothing replays: every channel but the owner's Telegram alert carries its own durable
   * marker, the row's own `nextCheckAtUtc` paces the retries, and anything this tick's claim
   * loop already handled is skipped.
   */
  private async reapStrandedAlerts(handled: ReadonlySet<string>): Promise<void> {
    const nowIso = this.clock.now().toISOString();
    for (const w of await this.repos.deletionWatches.listActive()) {
      if (!DELETION_PENDING_ALERT_STATUSES.includes(w.status)) continue;
      if (handled.has(w.id)) continue;
      // A decided watch has no work left but the fan-out, so a missing next check means "due
      // now" rather than "never again" — the alternative is stranding it permanently.
      if (w.nextCheckAtUtc !== null && w.nextCheckAtUtc > nowIso) continue;
      // Another worker holds a live lease on it; leave the mirror claim to them.
      if (
        w.leaseOwner !== null &&
        w.leaseOwner !== this.workerId &&
        (w.leaseExpiresAtUtc === null || w.leaseExpiresAtUtc > nowIso)
      ) {
        continue;
      }
      try {
        await this.dispatchConfirmed(w);
        this.logger.warn('deletion worker: resumed a stranded deletion alert', {
          watchId: w.id,
          status: w.status,
        });
      } catch (err) {
        this.logger.error('deletion worker: stranded alert dispatch failed', {
          watchId: w.id,
          err,
        });
      }
    }
  }

  /** Start the tick loop. A tick is skipped while the previous one is still running. */
  start(intervalMs = 1000): void {
    if (this.timer !== null) return;
    this.timer = setInterval(() => {
      if (this.inFlight !== null) return;
      this.inFlight = this.runOnce()
        .catch((err: unknown) => {
          this.logger.error('deletion worker: tick failed', { err });
        })
        .finally(() => {
          this.inFlight = null;
        });
    }, intervalMs);
  }

  /** Stop the tick loop and wait for any in-flight tick to complete. */
  async stop(): Promise<void> {
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.inFlight !== null) {
      await this.inFlight;
    }
  }

  private async processWatch(claimed: DeletionWatch): Promise<void> {
    // Re-read: an /unwatch may have won the race between the lease claim and now.
    const current = await this.repos.deletionWatches.findById(claimed.id);
    if (current === null || current.status === 'CLEARED' || current.status === 'NOTIFIED') return;

    // A watch whose deletion is already decided never probes again — the decision is final.
    // This pass exists only to finish the alert fan-out an earlier pass could not complete.
    if (current.status === 'CONFIRMED' || current.status === 'ALERTING') {
      await this.dispatchConfirmed(current);
      return;
    }

    // A watch already inside its confirmation burst is deciding a client-facing alert, so its
    // checks are never deferred by the browser-load budget; routine watching is.
    const classification = await this.safeProbe(
      current.normalizedUsername,
      current.status === 'CONFIRMING' ? 'CONFIRMATION' : 'ROUTINE',
    );
    const now = this.clock.now();
    const activeCount = await this.repos.deletionWatches.countActive();
    const params = { ...this.watchSchedulingParams(), activeCount };
    const { next, confirmed } = applyDeletionCheck({
      current,
      classification,
      now,
      params,
      rand: this.rand,
    });

    // Compare-and-save guard: drop the write if /unwatch cleared the watch mid-check.
    const stored = await this.repos.deletionWatches.findById(current.id);
    if (stored === null || stored.status === 'CLEARED' || stored.status === 'NOTIFIED') return;

    // Write-ahead: `next` already carries the CONFIRMED verdict on the confirmed edge, so the
    // decision reaches the database BEFORE a single alert leaves the process. Nothing after this
    // point may retract it — a client that is about to be told "your account was deleted" must
    // never be silently un-told, and a crash mid-fan-out must resume rather than re-decide.
    await this.repos.deletionWatches.save(next);
    if (confirmed) await this.dispatchConfirmed(next);
  }

  /**
   * Fan a confirmed deletion out to every channel. Runs on the confirming pass and again on
   * each retry pass until BOTH the owner's Telegram alert and the client delivery are resolved,
   * so every channel that must fire exactly once carries its own durable marker:
   *  - the Discord mirror is claimed by the CONFIRMED -> ALERTING status write BEFORE it is
   *    posted, the same claim-then-send rule as {@link CaseRepository.claimNotification}. A
   *    mirror lost to a crash is still covered by the owner's Telegram alert; an unbounded
   *    stream of duplicate deletion alerts is not recoverable;
   *  - client delivery and the owner "action required" ping are claimed by the link's
   *    `clientDeliveryStatus`;
   *  - the owner's Telegram alert is claimed by `telegramMessageId`, written down the instant it
   *    lands. That claim is what makes a CLIENT retry pass safe: without it every such pass would
   *    send the owner a deletion alert they already have.
   *
   * The watch only reaches the terminal NOTIFIED once nothing is outstanding, because NOTIFIED is
   * excluded from `listActive()` — advancing early put the row beyond the reach of both
   * `claimDue` and the stranded-alert sweep, permanently. The one exception is a client who was
   * told but whose link could not record it: there the retry path IS the hazard, so the watch is
   * settled and the owner's alert is what gets sacrificed.
   */
  private async dispatchConfirmed(w: DeletionWatch): Promise<void> {
    let watch = w;
    if (watch.status === 'CONFIRMED') {
      const claimIso = this.clock.now().toISOString();
      watch = { ...watch, status: 'ALERTING', updatedAtUtc: claimIso };
      await this.repos.deletionWatches.save(watch);
      await this.discord?.deletion(
        deletionConfirmed(
          watch.normalizedUsername,
          watch.startedAtUtc,
          watch.confirmedAtUtc ?? claimIso,
          this.config.displayTimezone,
        ),
      );
    }

    if (watch.telegramMessageId === null) {
      const sent = await this.notifyOwner(watch);
      // Re-check AFTER the (async) send: an /unwatch may have cleared the watch during it.
      // Respect that CLEARED terminal rather than resurrecting the row.
      if (!(await this.stillDeliverable(watch.id))) return;
      if (sent !== 'failed') {
        // Persist the claim IMMEDIATELY, before anything that can fail below.
        watch = {
          ...watch,
          telegramMessageId: sent,
          updatedAtUtc: this.clock.now().toISOString(),
        };
        await this.repos.deletionWatches.save(watch);
      }
    }

    const nowIso = this.clock.now().toISOString();
    if (!(await this.stillDeliverable(watch.id))) return;
    // Client delivery is INDEPENDENT of the owner send. Gating it behind owner success meant an
    // unpaired or unreachable owner left the linked client permanently uninformed, even though
    // the deletion was fully confirmed. It is idempotent via the link's delivery status, so it is
    // safe to attempt on a retry pass too.
    //
    // A THROWN failure means the attempt never got as far as recording an outcome — a busy
    // database reading the link or the business connection, or writing the delivery status. That
    // used to be swallowed while the watch marched on to NOTIFIED, which put the row beyond
    // `listActive()` and so beyond every retry path there is: the link sat at
    // BUSINESS_DELIVERY_PENDING forever and a paying client was never told. Keep the watch
    // retryable instead.
    let clientOutcome: ClientDeliveryOutcome | 'THREW';
    try {
      clientOutcome = await this.deliverToClient(watch, nowIso);
    } catch (err) {
      clientOutcome = 'THREW';
      this.logger.error('deletion worker: client delivery attempt failed; watch stays retryable', {
        watchId: watch.id,
        error: err instanceof Error ? err.message : String(err),
      });
    }
    // Settled = the client's fate is written down. A RETRY_OWED (a transient send failure inside
    // the retry budget) is deliberately NOT settled: it must keep the watch coming back, exactly
    // like a throw does.
    const clientMarkerLost = clientOutcome === 'TOLD_UNRECORDED';
    const clientResolved = clientOutcome === 'RECORDED' || clientMarkerLost;

    // Both writes below spread the in-memory `watch`, which is now stale: an /unwatch may have
    // landed while the client send was on the wire. Saving it back would resurrect a CLEARED row
    // as ALERTING/NOTIFIED with `clearedAtUtc` reset to null, leaving it in /banlist and blocking
    // a fresh /ban on the username — the opposite of "an /unwatch mid-check always wins".
    if (!(await this.stillDeliverable(watch.id))) return;

    // Terminal once the client half is settled AND coming back here can only do harm. The second
    // disjunct is the one that is easy to miss: `clientMarkerLost` means the client HAS been told
    // but the link could not record it, so its idempotency guard is gone and the ONLY thing left
    // between them and a second "your account was deleted" is never re-entering deliverToClient.
    // Gating solely on the owner alert defeated that — an unreachable owner re-armed the watch
    // regardless, and the next pass read the still-pending link and told the client again. An
    // owner alert lost this way is the cheaper failure: the Discord mirror already carried it.
    if (clientResolved && (watch.telegramMessageId !== null || clientMarkerLost)) {
      await this.repos.deletionWatches.save({
        ...watch,
        status: 'NOTIFIED',
        notifiedAtUtc: nowIso,
        nextCheckAtUtc: null,
        updatedAtUtc: nowIso,
      });
      return;
    }

    // Something is still outstanding — the owner alert, the client delivery, or both. Re-arm so
    // the stranded-alert sweep comes back for it. Nothing already done replays: the mirror is
    // claimed by ALERTING, the owner alert by `telegramMessageId`, the client by the link.
    const activeCount = await this.repos.deletionWatches.countActive();
    const params = { ...schedulingParamsFrom(this.config), activeCount };
    await this.repos.deletionWatches.save({
      ...watch,
      nextCheckAtUtc: nextBaselineCheckAt(this.clock.now(), activeCount, params, this.rand),
      updatedAtUtc: nowIso,
    });
  }

  /** False once an /unwatch has cleared the watch (or it vanished): nothing more may be written. */
  private async stillDeliverable(watchId: string): Promise<boolean> {
    const stored = await this.repos.deletionWatches.findById(watchId);
    return stored !== null && stored.status !== 'CLEARED';
  }

  /**
   * Scheduling params for a WATCH, which needs its own baseline cadence.
   *
   * A deletion alert may never rest on an INFERRED gone, so this worker runs the detector with the
   * fast path OFF and every probe it makes is a full Chromium page load. Sharing the recovery
   * fleet's 15s baseline therefore cost ~225 page loads/hour PER WATCH — two watches on their own
   * exceeded the ~200/hour the single residential IP tolerates, before the recovery fleet had run
   * a single check. See DELETION_INTERVAL_SECONDS for the number and the latency trade.
   *
   * Only the BASELINE is stretched. The confirmation cadence stays as it is: a burst is three
   * loads spent once, inside an event that has already happened.
   */
  private watchSchedulingParams(): SchedulingParams {
    return {
      ...schedulingParamsFrom(this.config),
      baselineIntervalSeconds: this.config.scheduling.deletionIntervalSeconds,
    };
  }

  /**
   * Probe for the classification only (no screenshot). Never throws — errors map to UNKNOWN.
   *
   * A probe the browser-load governor DEFERS also comes back UNKNOWN, which is exactly right: the
   * watch backs off and is retried, and nothing is ever inferred from a check that never happened.
   */
  private async safeProbe(
    username: string,
    loadPriority: LoadPriority,
  ): Promise<'ACTIVE' | 'GONE' | 'UNKNOWN'> {
    try {
      const options: TieredProbeOptions = { loadPriority };
      const probe = await this.detector.probe(username, options);
      return probe.result.classification;
    } catch (err) {
      this.logger.warn('deletion worker: probe threw', {
        username,
        error: err instanceof Error ? err.message : String(err),
      });
      return 'UNKNOWN';
    }
  }

  /**
   * Deliver the deletion into the linked client conversation, when the watch was started with
   * `/ban` inside one. Mirrors the recovery path in {@link OutboxWorker}: independent of the
   * owner alert, idempotent via the link's delivery status, and honest about Telegram's 24h
   * business reply window — a refused send becomes OWNER_ACTION_REQUIRED plus an owner ping,
   * never a silent "delivered". Both the client message and the owner ping are claimed by that
   * same link status, so a retry pass repeats neither.
   *
   * A transient send failure is RETRIED rather than escalated. Treating every exception as
   * terminal meant one 429 or one network blip permanently ended a paying client's deletion
   * notice; the retry is bounded by {@link clientRetryExhausted} and ends in the owner ping.
   *
   * CONTRACT: returning `RECORDED` means the client's fate is written down — delivered, escalated
   * to the owner, or no link at all. `TOLD_UNRECORDED` means they were told but the record failed,
   * which the caller must treat as "never run this again". `RETRY_OWED` means nothing was sent and
   * the caller must come back. It throws only when it could not get as far as an outcome, which
   * the caller also reads as "not finished with this watch yet".
   */
  private async deliverToClient(w: DeletionWatch, nowIso: string): Promise<ClientDeliveryOutcome> {
    const link = await this.repos.clientLinks.findByMonitorId(w.id);
    if (link === null) return 'RECORDED'; // owner-only watch
    if (CLIENT_DELIVERY_DONE_STATUSES.includes(link.clientDeliveryStatus)) {
      return 'RECORDED'; // already delivered — idempotent
    }

    // The owner is pinged once per deletion, not once per retry pass: a link already parked in
    // a failure state was pinged on the pass that put it there.
    const alreadyPinged = OWNER_PINGED_DELIVERY_STATUSES.includes(link.clientDeliveryStatus);
    const ownerId = await this.ownerChatId();

    // An earlier pass put a message on the wire and never recorded what came back. The client may
    // already be holding it, so this must escalate, never re-send.
    if (link.clientDeliveryStatus === CLIENT_DELIVERY_IN_FLIGHT_STATUS) {
      return this.escalateClientDelivery(
        w,
        ownerId,
        alreadyPinged,
        'send outcome never recorded',
        nowIso,
      );
    }

    const connection = await this.repos.businessConnections.findById(link.businessConnectionId);
    if (connection === null || !connection.isEnabled || !connection.rights.canReply) {
      const status =
        connection === null || !connection.isEnabled
          ? 'BUSINESS_CONNECTION_DISABLED'
          : 'BUSINESS_PERMISSION_MISSING';
      // Both of these statuses settle the watch, so committing one on the strength of a ping that
      // never landed buries the client exactly as escalateClientDelivery used to. Only a landed
      // ping (or a spent ping budget) may commit; otherwise park the link in the escalation-pending
      // state and keep the watch retryable so the sweep re-attempts the PING.
      const told =
        alreadyPinged ||
        (ownerId !== null && (await this.pingOwnerActionRequired(ownerId, w.normalizedUsername)));
      if (!told && !ownerPingRetryExhausted(w.confirmedAtUtc ?? w.startedAtUtc, new Date(nowIso))) {
        await this.repos.clientLinks.updateDeliveryStatus(
          w.id,
          CLIENT_DELIVERY_IN_FLIGHT_STATUS,
          nowIso,
        );
        return 'RETRY_OWED';
      }
      await this.repos.clientLinks.updateDeliveryStatus(w.id, status, nowIso);
      return 'RECORDED';
    }

    const msg = clientDeletionConfirmed(
      w.normalizedUsername,
      w.startedAtUtc,
      w.confirmedAtUtc ?? nowIso,
      this.config.displayTimezone,
    );
    // Claim, THEN send — see CLIENT_DELIVERY_IN_FLIGHT_STATUS. A failure of this write means
    // nothing was sent; it propagates, and the caller keeps the watch retryable.
    await this.repos.clientLinks.updateDeliveryStatus(
      w.id,
      CLIENT_DELIVERY_IN_FLIGHT_STATUS,
      nowIso,
    );

    // Nothing but the send belongs in this try.
    let outcome: ClientSendOutcome;
    try {
      const params: Parameters<TelegramClient['sendMessage']>[0] = {
        chat_id: link.clientChatId,
        text: msg.text,
        business_connection_id: link.businessConnectionId,
      };
      if (msg.replyMarkup) params.reply_markup = msg.replyMarkup;
      await this.client.sendMessage(params);
      outcome = 'DELIVERED';
    } catch (err) {
      outcome = classifyClientSendFailure(err);
      this.logger.warn('client deletion delivery failed', {
        watchId: w.id,
        outcome,
        error: err instanceof Error ? err.message : String(err),
      });
    }

    if (outcome !== 'DELIVERED') {
      // "Possibly landed" resolves toward NOT re-sending; a definite failure retries until the
      // budget anchored on the confirmation instant runs out.
      const reason =
        outcome === 'POSSIBLY_DELIVERED' ? 'send outcome unknowable' : 'retry budget exhausted';
      if (
        outcome === 'POSSIBLY_DELIVERED' ||
        clientRetryExhausted(w.confirmedAtUtc ?? w.startedAtUtc, new Date(nowIso))
      ) {
        return this.escalateClientDelivery(w, ownerId, alreadyPinged, reason, nowIso);
      }
      await this.repos.clientLinks.updateDeliveryStatus(w.id, CLIENT_DELIVERY_OWED_STATUS, nowIso);
      return 'RETRY_OWED';
    }

    // The client HAS been told. Recording that is what stops a retry pass repeating it, so a
    // failure here must NOT escape as a throw (the caller would keep the watch retryable and the
    // next pass would tell them a second time) — it is reported instead, and the caller closes
    // the watch out rather than re-entering this.
    try {
      await this.repos.clientLinks.updateDeliveryStatus(w.id, 'BUSINESS_DELIVERED', nowIso);
    } catch (err) {
      this.logger.error('deletion worker: client was told but the delivery was not recorded', {
        watchId: w.id,
        error: err instanceof Error ? err.message : String(err),
      });
      return 'TOLD_UNRECORDED';
    }
    this.logger.info('client deletion delivery ok', { watchId: w.id });
    return 'RECORDED';
  }

  /**
   * End the retry loop by handing the delivery to the owner.
   *
   * CLAIM-THEN-PING. This used to write OWNER_ACTION_REQUIRED first and then make ONE unretried
   * ping whose failure was swallowed, and that status settles the watch as NOTIFIED — which puts
   * the row beyond `listActive()` and so beyond every retry path there is. A ping lost to a
   * network blip therefore left the client permanently untold AND the owner permanently unaware
   * they had to finish it by hand. The drop is CORRELATED with the escalation: we are here because
   * Telegram has been failing.
   *
   * So the link is parked in {@link CLIENT_DELIVERY_IN_FLIGHT_STATUS} first — the durable "never
   * send this client anything again" marker — and OWNER_ACTION_REQUIRED is committed only once the
   * ping PROVABLY landed. Until then this returns `RETRY_OWED`, which keeps the watch active so
   * the stranded-alert sweep comes back for the PING alone: an in-flight link routes straight back
   * here and can never re-enter the send path.
   *
   * Bounded by {@link ownerPingRetryExhausted} against the confirmation instant (a timestamp
   * written once), so an unreachable owner settles instead of pinging Telegram forever.
   */
  private async escalateClientDelivery(
    w: DeletionWatch,
    ownerChatId: number | null,
    alreadyPinged: boolean,
    reason: string,
    nowIso: string,
  ): Promise<ClientDeliveryOutcome> {
    // Claim first: whatever happens to the ping, the client must never be sent to again.
    await this.repos.clientLinks.updateDeliveryStatus(
      w.id,
      CLIENT_DELIVERY_IN_FLIGHT_STATUS,
      nowIso,
    );
    this.logger.error('deletion worker: client delivery handed to the owner', {
      watchId: w.id,
      reason,
    });

    const told =
      alreadyPinged ||
      (ownerChatId !== null &&
        (await this.pingOwnerActionRequired(ownerChatId, w.normalizedUsername)));
    if (!told && !ownerPingRetryExhausted(w.confirmedAtUtc ?? w.startedAtUtc, new Date(nowIso))) {
      this.logger.error('deletion worker: owner escalation ping did not land; will retry', {
        watchId: w.id,
        unpaired: ownerChatId === null,
      });
      return 'RETRY_OWED'; // keeps the watch active so the sweep retries the PING, not the send
    }
    await this.repos.clientLinks.updateDeliveryStatus(w.id, 'OWNER_ACTION_REQUIRED', nowIso);
    if (!told) {
      this.logger.error(
        'deletion worker: owner could not be reached about a stranded client delivery',
        { watchId: w.id, username: w.normalizedUsername },
      );
    }
    return 'RECORDED';
  }

  /**
   * Tell the owner a client delivery needs finishing by hand. Returns whether it PROVABLY reached
   * Telegram — swallowing that into `undefined` is what let a terminal status be committed on the
   * strength of a send that never happened.
   *
   * The DELETION variant, never the recovery one: the owner hand-delivers whatever this ping
   * describes, and recovery copy would have them tell the client their account is back.
   */
  private async pingOwnerActionRequired(ownerChatId: number, username: string): Promise<boolean> {
    const msg = ownerActionRequiredDeletion(username);
    const params: Parameters<TelegramClient['sendMessage']>[0] = {
      chat_id: ownerChatId,
      text: msg.text,
    };
    if (msg.replyMarkup) params.reply_markup = msg.replyMarkup;
    try {
      await this.client.sendMessage(params);
      return true;
    } catch (err) {
      this.logger.error('deletion worker: owner action-required ping failed', {
        username,
        error: err instanceof Error ? err.message : String(err),
      });
      return false;
    }
  }

  /**
   * Send the deletion notification to the owner. Returns the message id, or 'failed'.
   *
   * Never null: the id is the durable claim that stops a retry pass re-alerting the owner, so a
   * successful send MUST yield something to write down.
   */
  private async notifyOwner(w: DeletionWatch): Promise<number | 'failed'> {
    const chatId = await this.ownerChatId();
    if (chatId === null) return 'failed'; // unpaired — retry later
    try {
      const sent = await this.client.sendMessage({
        chat_id: chatId,
        text: deletionConfirmed(
          w.normalizedUsername,
          w.startedAtUtc,
          w.confirmedAtUtc ?? this.clock.now().toISOString(),
          this.config.displayTimezone,
        ),
        reply_markup: recoveryButton(w.normalizedUsername),
      });
      return sent.message_id;
    } catch (err) {
      this.logger.error('deletion worker: owner notification failed', {
        watchId: w.id,
        error: err instanceof Error ? err.message : String(err),
      });
      return 'failed';
    }
  }
}
