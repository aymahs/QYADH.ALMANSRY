/** Public surface of the SEPARATE deletion-watch feature (/ban). */

export { DeletionWorker } from './worker';
export type { DeletionWorkerDeps, DeletionMirror } from './worker';
export { applyDeletionCheck } from './state';
export type {
  DeletionTransitionInput,
  DeletionTransitionOutput,
  DeletionTransitionParams,
} from './state';
