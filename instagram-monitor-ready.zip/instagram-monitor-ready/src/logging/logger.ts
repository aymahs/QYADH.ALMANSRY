/**
 * Structured JSON logger with aggressive secret redaction.
 *
 * Redacts (a) any exact secret value registered at construction and (b) anything that
 * looks like a Telegram bot token, so secrets can never leak into logs — the property
 * verified by the "no secrets in logs" test.
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

const LEVEL_ORDER: Record<LogLevel, number> = { debug: 10, info: 20, warn: 30, error: 40 };

export interface Logger {
  debug(msg: string, fields?: Record<string, unknown>): void;
  info(msg: string, fields?: Record<string, unknown>): void;
  warn(msg: string, fields?: Record<string, unknown>): void;
  error(msg: string, fields?: Record<string, unknown>): void;
  child(bindings: Record<string, unknown>): Logger;
}

export interface LoggerOptions {
  level?: LogLevel;
  /** Exact secret strings to scrub wherever they appear. */
  secrets?: readonly string[];
  /** Sink for lines (defaults to process.stdout). Injectable for tests. */
  write?: (line: string) => void;
  /** Fixed timestamp source for deterministic tests. */
  now?: () => Date;
}

/** Telegram bot tokens: `<digits>:<35+ url-safe chars>`. */
const BOT_TOKEN_RE = /\b\d{6,}:[A-Za-z0-9_-]{30,}\b/g;
const REDACTED = '[REDACTED]';

function buildRedactor(secrets: readonly string[]): (value: string) => string {
  const meaningful = secrets.filter((s) => typeof s === 'string' && s.length >= 6);
  return (value: string): string => {
    let out = value;
    for (const secret of meaningful) {
      if (out.includes(secret)) {
        out = out.split(secret).join(REDACTED);
      }
    }
    out = out.replace(BOT_TOKEN_RE, REDACTED);
    return out;
  };
}

function redactDeep(value: unknown, redact: (s: string) => string): unknown {
  if (typeof value === 'string') return redact(value);
  if (value === null || value === undefined) return value;
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (value instanceof Error) {
    return { name: value.name, message: redact(value.message) };
  }
  if (Array.isArray(value)) return value.map((v) => redactDeep(v, redact));
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = redactDeep(v, redact);
    }
    return out;
  }
  return redact(String(value));
}

class JsonLogger implements Logger {
  constructor(
    private readonly level: LogLevel,
    private readonly redact: (s: string) => string,
    private readonly write: (line: string) => void,
    private readonly now: () => Date,
    private readonly bindings: Record<string, unknown>,
  ) {}

  private emit(level: LogLevel, msg: string, fields?: Record<string, unknown>): void {
    if (LEVEL_ORDER[level] < LEVEL_ORDER[this.level]) return;
    const record: Record<string, unknown> = {
      ts: this.now().toISOString(),
      level,
      msg: this.redact(msg),
      ...this.bindings,
      ...(fields ? (redactDeep(fields, this.redact) as Record<string, unknown>) : {}),
    };
    // Final safety net: scrub the serialized line too.
    this.write(this.redact(JSON.stringify(record)));
  }

  debug(msg: string, fields?: Record<string, unknown>): void {
    this.emit('debug', msg, fields);
  }
  info(msg: string, fields?: Record<string, unknown>): void {
    this.emit('info', msg, fields);
  }
  warn(msg: string, fields?: Record<string, unknown>): void {
    this.emit('warn', msg, fields);
  }
  error(msg: string, fields?: Record<string, unknown>): void {
    this.emit('error', msg, fields);
  }
  child(bindings: Record<string, unknown>): Logger {
    return new JsonLogger(this.level, this.redact, this.write, this.now, {
      ...this.bindings,
      ...(redactDeep(bindings, this.redact) as Record<string, unknown>),
    });
  }
}

export function createLogger(options: LoggerOptions = {}): Logger {
  const level = options.level ?? 'info';
  const redact = buildRedactor(options.secrets ?? []);
  const write =
    options.write ??
    ((line: string): void => {
      process.stdout.write(line + '\n');
    });
  const now = options.now ?? ((): Date => new Date());
  return new JsonLogger(level, redact, write, now, {});
}

/** No-op logger for tests that don't assert on logging. */
export function nullLogger(): Logger {
  const noop = (): void => undefined;
  const logger: Logger = {
    debug: noop,
    info: noop,
    warn: noop,
    error: noop,
    child: () => logger,
  };
  return logger;
}
