/**
 * Screenshot capture for a VERIFIED-ACTIVE profile.
 *
 * ONE INVARIANT: a client must never receive an image that is not a rendered profile —
 * neither Instagram's logged-out signup/login interstitial NOR a blank white rectangle taken
 * before the page painted. A text-only recovery alert is an acceptable outcome; a misleading
 * picture is not. The VPS runs behind a mobile residential proxy, so both are normal cases.
 *
 * PAINT READINESS (the second incident: blank images shipped as proof).
 * Measured on the production host, time from navigation start until each signal first
 * became true, polled once per second:
 *
 *   account            domcontentloaded   header+username+counters   avatar img   networkidle
 *   instagram               7.1s                  85.4s                104.5s        NEVER
 *   trymaven               41.3s                  96.4s                 NEVER        NEVER
 *   odpcompetitions         6.9s                   9.9s                 14.9s        NEVER
 *
 * Three conclusions drive the code below:
 *  - `networkidle` NEVER fires on Instagram, so the old `waitForLoadState('networkidle')`
 *    ALWAYS timed out and the shutter fired ~5s in. On a fast profile that yielded a picture;
 *    on a slow one, a white rectangle sold to a paying client as proof. It is replaced by
 *    POLLING {@link probeRenderReady} — a fixed sleep cannot work when paint varies 10s..100s.
 *  - The four signals in column 3 flipped in the SAME poll on all three accounts, so they
 *    form one reliable predicate: a big-enough `<header>` whose rendered text names the
 *    account and carries posts/followers/following.
 *  - The avatar `<img>` is NEVER gated on: it did not load within 120s for trymaven, so
 *    requiring it would hang every capture on some profiles. (A later measurement showed it is
 *    not unloadable — that diagnostic simply gave up at 120s; it settles at 18.5-130.7s. It is
 *    still not a gate, but {@link waitForHeaderImages} now gives it a BOUNDED window so the
 *    delivered card usually carries a real profile picture instead of a grey circle.)
 *
 * How the invariant is held:
 *  - Nothing is photographed until the paint predicate holds. If it never holds, no image is
 *    produced at all — the caller falls back to the text-only recovery.
 *  - The captured BYTES are checked for information density as defence in depth, for the case
 *    where the DOM claims ready but the pixels disagree. See {@link MIN_IMAGE_BYTES_PER_PIXEL}.
 *  - The probe proves the EXACT region that will be photographed — the padded clip, not
 *    just the header box. A grid of points over the header interior must each resolve to
 *    the header itself (walking through transparent hit-testable layers such as empty
 *    portal roots), and the padding bands around it are checked separately: in-flow page
 *    content there is the profile's genuine surroundings, while out-of-flow chrome (a
 *    fixed banner, a viewport-anchored sheet) RETRACTS that side's padding so those pixels
 *    are simply never delivered. Retraction never suppresses a clean header.
 *  - Painted click-through layers (pointer-events: none, ANY position value) are found by
 *    a geometric sweep that decides "above or below the header" by asking the page itself:
 *    the candidate is made hit-testable for a moment and elementFromPoint reports what is
 *    actually on top. No role, class, position or z-index heuristics — those are the
 *    mistakes that let the incident modal through and, later, made Instagram's own painted
 *    background layer (fixed, z-index -9999, BEHIND all content) look like an occluder.
 *  - Every uncertain outcome fails CLOSED. A probe that could not run, or a DOM too large
 *    to sweep completely, is not evidence of a clean page, so it suppresses the capture.
 *  - The probe runs again AFTER the shutter and must reproduce the SAME clip: an
 *    interstitial that swaps the page (even one carrying its own clean header) changes the
 *    geometry and the image is discarded.
 *
 * Overlays are dismissed non-destructively first (real dismiss controls, then Escape), and
 * only elements demonstrably painted over the header are removed from the DOM. Profile
 * content is never touched, altered or fabricated. Output is validated by magic bytes.
 */

import type { Page } from 'playwright';
import { AppError, type Screenshot } from '../../domain';

// --- Minimal browser globals for page.evaluate() -----------------------------
// The project's tsconfig intentionally omits the DOM lib. These module-scoped ambient
// declarations type ONLY what the evaluate callbacks below touch; they emit no runtime
// code and never leak outside this module.
interface DomStyle {
  overflow: string;
  pointerEvents: string;
}
interface DomComputedStyle {
  position: string;
  display: string;
  visibility: string;
  opacity: string;
  backgroundColor: string;
  backgroundImage: string;
  boxShadow: string;
  borderTopWidth: string;
  borderRightWidth: string;
  borderBottomWidth: string;
  borderLeftWidth: string;
}
interface DomGeometry {
  x: number;
  y: number;
  width: number;
  height: number;
  top: number;
  right: number;
  bottom: number;
  left: number;
}
interface DomNode {
  nodeType: number;
  textContent: string | null;
}
interface DomElement {
  tagName: string;
  style: DomStyle;
  clientWidth: number;
  clientHeight: number;
  /**
   * `HTMLImageElement.complete` — true once the image has loaded, errored, or has no src.
   * `undefined` on every other element and on hosts that do not expose it, which is why the
   * header-image wait treats "not a judgeable image" as nothing to wait for.
   */
  complete?: boolean;
  /**
   * Rendered text. `innerText` reflects what is actually LAID OUT (it is the readiness
   * signal); `textContent` is the flat fallback for the elements that do not expose it.
   */
  innerText: string | null;
  textContent: string | null;
  parentElement: DomElement | null;
  parentNode: { removeChild(child: DomElement): void } | null;
  offsetParent: DomElement | null;
  childNodes: DomNode[];
  getAttribute(name: string): string | null;
  getBoundingClientRect(): DomGeometry;
  contains(other: DomElement | null): boolean;
}
interface DomDocument {
  body: DomElement;
  documentElement: DomElement;
  querySelectorAll(selectors: string): DomElement[];
  elementFromPoint(x: number, y: number): DomElement | null;
  elementsFromPoint(x: number, y: number): DomElement[];
}
declare const document: DomDocument;
declare function getComputedStyle(element: DomElement): DomComputedStyle;

/** Breathing room around the header so the crop reads as a card, not an edge-to-edge cut. */
const HEADER_PADDING = 28;
/** A real profile header is large; anything smaller is a stray `<header>`, not the profile. */
const MIN_HEADER_WIDTH = 200;
const MIN_HEADER_HEIGHT = 80;
/**
 * Sample fractions on both axes for the interior grid (and along each padding band). The
 * near-edge values matter: the old 0.15 inset left the outer 15% of the header — and the
 * whole padding band — unprobed, which is exactly where a bottom login sheet clipped into
 * the delivered image while every sample point stayed clean.
 */
const SAMPLE_FRACTIONS = [0.02, 0.15, 0.5, 0.85, 0.98];
/**
 * Hard cap on the DOM sweep. Exceeding it FAILS CLOSED ('scan-truncated'): a sweep that
 * examined only a prefix of the DOM proves nothing, and portal-mounted overlays live at the
 * END of <body> — precisely the slice a silent truncation would skip.
 */
const MAX_SCAN_ELEMENTS = 40_000;
/** Removal passes per dismissal round: enough to peel a modal + its backdrop. */
const MAX_REMOVAL_PASSES = 4;
/**
 * How far (px, per edge) the after-shutter probe's clip may drift from the clip actually
 * photographed before the image is considered unproven and discarded. Fonts/images settling
 * can nudge layout a pixel or two; a remounted interstitial moves it far more.
 */
const AFTER_CLIP_TOLERANCE_PX = 8;
/**
 * Minimum side (px) the header box must EXCEED before its text is trusted as painted. From the
 * production measurement: the readiness predicate held once the header was "bigger than about
 * 100x100". Deliberately separate from MIN_HEADER_WIDTH/HEIGHT, which pick WHICH header is the
 * profile's; this one asks whether that header has laid out yet.
 */
const MIN_PAINTED_HEADER_SIDE = 100;
/**
 * The counters that accompany a laid-out profile header; absent while it is still a shell.
 * Lower-case tokens, matched against lower-cased text — an actual RegExp cannot be used here
 * because `page.evaluate` arguments are JSON-serialized and a RegExp would arrive as `{}`.
 */
const PROFILE_COUNTER_TOKENS = ['posts', 'followers', 'following'] as const;
/**
 * Overall budget for the paint poll. Paint was observed as late as 96.4s from navigation start
 * (~68s into this wait, since `loadProfile` already spends up to ~10.5s settling), so anything
 * shorter guarantees a miss on slow profiles. It is a CEILING, not a delay: a fast profile
 * (measured 9.9s) satisfies the predicate on an early poll and proceeds immediately.
 */
const DEFAULT_PAINT_TIMEOUT_MS = 120_000;
/** Poll cadence. Matches the once-per-second sampling the measurements were taken with. */
const DEFAULT_PAINT_POLL_INTERVAL_MS = 1000;
/**
 * Poll cadence for the header-image wait. Faster than the paint poll because the whole point is
 * to leave as soon as the last image lands: every poll skipped after that is dead time inside
 * the client's alert, and the probe is a cheap DOM walk over the header's own subtree.
 */
const DEFAULT_HEADER_IMAGE_POLL_INTERVAL_MS = 500;
/**
 * Blankness backstop, in bytes of PNG per CSS pixel of the delivered clip (the same units as
 * {@link Screenshot.width}/`height`, which is how the incident captures were measured).
 *
 * Measured on the production host:
 *   full-viewport captures taken AFTER the predicate held  1.16 / 1.42 / 1.96 B/px
 *   a good TIGHT HEADER CROP                               0.48 B/px
 *   the two blank captures taken under the old code        0.016 / 0.026 B/px
 *
 * Roughly two orders of magnitude separate a blank from a real crop, so the floor sits inside
 * that gap: 3x above the densest blank ever measured, 6x below the sparsest good crop. Biased
 * to the low side on purpose — a rejected good capture costs one text-only alert plus a
 * re-capture sweep, while an accepted blank is the incident itself.
 *
 * CALIBRATION DEPENDENCY: the numerator is real PNG bytes and the denominator is CSS pixels, so
 * this ratio scales with `deviceScaleFactor` (2 in `BrowserManager`, which is what every figure
 * above was measured under). Dropping back to 1x would shrink every density by roughly 3-4x and
 * eat most of the headroom — re-measure before changing it.
 */
export const MIN_IMAGE_BYTES_PER_PIXEL = 0.08;

/**
 * Validate an in-memory image by magic bytes. Accepts PNG (`89 50 4E 47`) and
 * JPEG (`FF D8 FF`); rejects anything empty or unrecognized.
 */
export function validateImage(
  buffer: Buffer,
): { ok: true; format: 'png' | 'jpeg' } | { ok: false; reason: string } {
  if (!buffer || buffer.length === 0) {
    return { ok: false, reason: 'empty buffer' };
  }
  if (
    buffer.length >= 4 &&
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47
  ) {
    return { ok: true, format: 'png' };
  }
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return { ok: true, format: 'jpeg' };
  }
  return { ok: false, reason: 'unrecognized image format (expected PNG or JPEG magic bytes)' };
}

/**
 * Information density of a captured image, as a blankness backstop. A PNG of a near-uniform
 * region compresses to almost nothing, so bytes-per-pixel separates "blank white rectangle"
 * from "rendered profile card" by two orders of magnitude — no pixel decoding required.
 *
 * This is DEFENCE IN DEPTH behind the DOM predicate, not a replacement for it: it catches the
 * case where the DOM reports a painted header but the compositor had not produced the pixels.
 * A zero/NaN area fails closed — an image whose size we cannot reason about is not proof.
 */
export function assessImageDensity(
  byteLength: number,
  width: number,
  height: number,
): { ok: boolean; bytesPerPixel: number } {
  const area = width * height;
  if (!Number.isFinite(area) || area <= 0) return { ok: false, bytesPerPixel: 0 };
  const bytesPerPixel = byteLength / area;
  return { ok: bytesPerPixel >= MIN_IMAGE_BYTES_PER_PIXEL, bytesPerPixel };
}

/** Why the profile is (not) considered painted yet. */
export type RenderReadyReason =
  | 'ok'
  | 'no-header'
  | 'header-too-small'
  | 'identity-missing'
  | 'counters-missing'
  | 'probe-failed';

/** Verdict of the in-page paint check. Plain JSON — it crosses the page boundary. */
export interface RenderReady {
  /** True ONLY when the profile header has demonstrably laid out with its real content. */
  ready: boolean;
  reason: RenderReadyReason;
  /** Viewport-space header box, for logs. Null when no usable header exists yet. */
  box: { x: number; y: number; width: number; height: number } | null;
}

interface ReadyArg {
  minWidth: number;
  minHeight: number;
  minPaintedSide: number;
  username: string;
  counterTokens: readonly string[];
}

/** Why the header is (not) safe to photograph. */
export type HeaderProbeReason =
  | 'ok'
  | 'no-header'
  | 'header-too-small'
  | 'header-off-screen'
  | 'occluded'
  | 'scan-truncated'
  | 'probe-failed';

/** Verdict of the in-page occlusion probe. Plain JSON — it crosses the page boundary. */
export interface HeaderProbe {
  /** True ONLY when a real header exists and nothing is painted over it. */
  visible: boolean;
  reason: HeaderProbeReason;
  /** Viewport-space header box; informational — the photographed region is `clip`. */
  box: { x: number; y: number; width: number; height: number } | null;
  viewport: { width: number; height: number } | null;
  /**
   * The proven-clean capture region: the header box plus padding on each side WHERE that
   * padding was itself verified. A side whose band contains out-of-flow chrome is retracted
   * to the header's edge, so the delivered image never contains unproven pixels. Non-null
   * only when `visible` is true.
   */
  clip: { x: number; y: number; width: number; height: number } | null;
  /** Shape/size of the topmost occluder, for logs only. Never shown to a client. */
  occluder: string | null;
}

/** Why the header's images are (not) considered finished. */
export type HeaderImagesReason = 'ok' | 'pending' | 'no-header' | 'scan-truncated' | 'probe-failed';

/** Verdict of the in-page header-image check. Plain JSON — it crosses the page boundary. */
export interface HeaderImages {
  /** `<img>` elements inside the profile header. */
  total: number;
  /** How many of those have finished (loaded OR failed — see {@link probeHeaderImagesInPage}). */
  settled: number;
  /** True when there is nothing left worth waiting for. FAILS OPEN — see the probe's docstring. */
  ready: boolean;
  reason: HeaderImagesReason;
}

interface HeaderImagesArg {
  minWidth: number;
  minHeight: number;
  maxScan: number;
}

interface ProbeArg {
  minWidth: number;
  minHeight: number;
  samples: number[];
  pad: number;
  maxScan: number;
}

interface ClearArg {
  minWidth: number;
  minHeight: number;
  maxScan: number;
  maxPasses: number;
}

/*
 * ===========================================================================================
 * THE THREE FUNCTIONS BELOW RUN INSIDE THE PAGE. Two rules, both load-bearing:
 *
 *  1. They close over NOTHING from this module — Playwright ships them to the browser as
 *     source text, so every threshold arrives as an argument.
 *  2. They contain NO nested function of any kind (no helper arrow, no inner declaration, no
 *     `.map()`/`.forEach()` callback). tsx transpiles with esbuild's `keepNames`, which
 *     rewrites a nested function into a call to a module-scope `__name` helper that does not
 *     exist in the page, so a single nested function turns every probe into a
 *     ReferenceError. Since the callers swallow probe errors and fail closed, the visible
 *     symptom would not be a crash — it would be screenshots silently disappearing from
 *     every recovery alert forever. Hence the flat loops and the (deliberately) repeated
 *     inline paint-detection blocks.
 * ===========================================================================================
 */

/**
 * Report whether the profile has PAINTED — the predicate the production measurements
 * identified, and the thing that separates a real profile card from a white rectangle.
 *
 * All four measured signals flipped in the same one-second poll on every account tested, so
 * they are checked together: a `<header>` exists, its box exceeds ~100x100, its RENDERED text
 * names the account being monitored, and that text carries the post/follower/following
 * counters. The avatar `<img>` is deliberately NOT part of this: it never loaded at all for
 * one of the three accounts, so gating on it would hang those captures forever.
 *
 * Header selection matches {@link probeHeaderInPage} exactly (largest header at or above the
 * minimum profile-header size) so the two probes can never disagree about WHICH header they
 * are talking about.
 */
function probeRenderReadyInPage(arg: ReadyArg): RenderReady {
  const headers = document.querySelectorAll('header');
  let header: DomElement | null = null;
  let rect: DomGeometry | null = null;
  let bestArea = -1;
  let sawHeader = false;
  for (let i = 0; i < headers.length; i += 1) {
    const candidate = headers[i];
    if (candidate === undefined) continue;
    sawHeader = true;
    const r = candidate.getBoundingClientRect();
    if (r.width < arg.minWidth || r.height < arg.minHeight) continue;
    const area = r.width * r.height;
    if (area > bestArea) {
      bestArea = area;
      header = candidate;
      rect = r;
    }
  }
  if (header === null || rect === null) {
    return { ready: false, reason: sawHeader ? 'header-too-small' : 'no-header', box: null };
  }

  const box = { x: rect.left, y: rect.top, width: rect.width, height: rect.height };
  // A header element can be attached and still be an unlaid-out shell; the measured predicate
  // required it to have grown past roughly 100x100 first.
  if (rect.width <= arg.minPaintedSide || rect.height <= arg.minPaintedSide) {
    return { ready: false, reason: 'header-too-small', box };
  }

  // `innerText` is layout-aware (it reflects what is actually rendered), which is precisely
  // the property that makes it a paint signal — text inside an unrendered subtree is not
  // evidence of paint. `textContent` is ONLY the fallback for a host that does not expose
  // innerText at all, which is why the guard below is a bare `typeof` and nothing more.
  //
  // An EMPTY innerText must NEVER escalate to `textContent`. An extra `rendered !== ''` clause
  // here fired on exactly the dangerous state: a header that HAS laid out (so it clears the
  // size gate above) while its username and counters still sit in a not-yet-revealed skeleton
  // subtree (`display:none` / `visibility:hidden` / `content-visibility:hidden`). innerText
  // correctly reports '' for that; textContent reports the full "trymaven ... 412 posts ...",
  // so the predicate would be satisfied by MARKUP instead of PAINT — the one distinction it
  // exists to make. Nothing downstream recovers the guarantee: the occlusion probe checks only
  // geometry and never re-checks identity, and a laid-out grey skeleton carries far more
  // entropy than the near-uniform blanks the density backstop is calibrated against, so the
  // image would ship. A header with genuinely no text yields '' from both, and the identity
  // check below rejects it either way — so this costs nothing on the safe path.
  //
  // The `typeof` guards are not decoration. Every caller of this probe swallows a throw and
  // fails closed, so one unexpected non-string here would not crash visibly — it would
  // silently drop the screenshot from every recovery alert, forever.
  const rendered = header.innerText;
  const source = typeof rendered === 'string' ? rendered : header.textContent;
  const text = typeof source === 'string' ? source.toLowerCase() : '';

  // Identity: the header must name the account we are photographing. This is the check that a
  // half-painted shell — or a DIFFERENT profile the page navigated to — cannot pass.
  if (arg.username !== '' && text.indexOf(arg.username.toLowerCase()) < 0) {
    return { ready: false, reason: 'identity-missing', box };
  }

  let counters = false;
  for (let i = 0; i < arg.counterTokens.length && !counters; i += 1) {
    const token = arg.counterTokens[i];
    if (token === undefined) continue;
    if (text.indexOf(token) >= 0) counters = true;
  }
  if (!counters) return { ready: false, reason: 'counters-missing', box };

  return { ready: true, reason: 'ok', box };
}

/**
 * Report how many images inside the profile header have finished, so the caller can give the
 * avatar and the story highlights a BOUNDED chance to arrive before the shutter fires.
 *
 * This probe is the one that fails OPEN, and deliberately so: it decides only how long to WAIT,
 * never whether an image may ship. Every safety probe around it still fails closed. So a missing
 * header, a DOM too large to sweep, or an image the host will not describe all read as "nothing
 * left to wait for" — the alternative would be burning the whole window and then capturing
 * anyway, which is strictly worse for the same picture.
 *
 * `complete` (not `naturalWidth`) is the settle signal on purpose: it flips to true for a
 * successful load AND for a failed one, so a placeholder served by the capture image budget, a
 * 404 avatar, or a CDN error can never hold the wait open for its full duration.
 *
 * Header selection matches the other two probes exactly (largest header at or above the minimum
 * profile-header size) so all three can never disagree about WHICH header they mean.
 */
function probeHeaderImagesInPage(arg: HeaderImagesArg): HeaderImages {
  const headers = document.querySelectorAll('header');
  let header: DomElement | null = null;
  let bestArea = -1;
  for (let i = 0; i < headers.length; i += 1) {
    const candidate = headers[i];
    if (candidate === undefined) continue;
    const r = candidate.getBoundingClientRect();
    if (r.width < arg.minWidth || r.height < arg.minHeight) continue;
    const area = r.width * r.height;
    if (area > bestArea) {
      bestArea = area;
      header = candidate;
    }
  }
  if (header === null) return { total: 0, settled: 0, ready: true, reason: 'no-header' };

  const candidates = document.querySelectorAll('body *');
  if (candidates.length > arg.maxScan) {
    return { total: 0, settled: 0, ready: true, reason: 'scan-truncated' };
  }

  let total = 0;
  let settled = 0;
  for (let i = 0; i < candidates.length; i += 1) {
    const el = candidates[i];
    if (el === undefined) continue;
    if (el.tagName.toUpperCase() !== 'IMG') continue;
    if (!header.contains(el)) continue;
    total += 1;
    if (el.complete === true) settled += 1;
  }
  const ready = settled >= total;
  return { total, settled, ready, reason: ready ? 'ok' : 'pending' };
}

/**
 * Report whether the profile header is genuinely visible, by asking the page what is actually
 * painted across the ENTIRE region a capture would photograph. Chooses the LARGEST `<header>`
 * that is big enough to be a profile header, so a site-chrome `<header>` appearing earlier in
 * the document cannot hijack the crop.
 */
function probeHeaderInPage(arg: ProbeArg): HeaderProbe {
  const root = document.documentElement;
  const viewport = { width: root.clientWidth, height: root.clientHeight };

  const headers = document.querySelectorAll('header');
  let header: DomElement | null = null;
  let rect: DomGeometry | null = null;
  let bestArea = -1;
  let sawHeader = false;
  for (let i = 0; i < headers.length; i += 1) {
    const candidate = headers[i];
    if (candidate === undefined) continue;
    sawHeader = true;
    const r = candidate.getBoundingClientRect();
    if (r.width < arg.minWidth || r.height < arg.minHeight) continue;
    const area = r.width * r.height;
    if (area > bestArea) {
      bestArea = area;
      header = candidate;
      rect = r;
    }
  }
  if (header === null || rect === null) {
    return {
      visible: false,
      reason: sawHeader ? 'header-too-small' : 'no-header',
      box: null,
      viewport,
      clip: null,
      occluder: null,
    };
  }

  const box = { x: rect.left, y: rect.top, width: rect.width, height: rect.height };

  // The whole header must be on-screen: a clip running past the viewport photographs blank
  // pixels, and hit-testing cannot answer for a point it cannot see.
  if (
    rect.left < 0 ||
    rect.top < 0 ||
    rect.right > viewport.width ||
    rect.bottom > viewport.height
  ) {
    return {
      visible: false,
      reason: 'header-off-screen',
      box,
      viewport,
      clip: null,
      occluder: null,
    };
  }

  // Enumerate the DOM once, and refuse to certify a page we could not inspect completely:
  // a truncated sweep is not evidence of a clean page, so it fails CLOSED instead of open.
  const candidates = document.querySelectorAll('body *');
  if (candidates.length > arg.maxScan) {
    return {
      visible: false,
      reason: 'scan-truncated',
      box,
      viewport,
      clip: null,
      occluder: null,
    };
  }

  // Preliminary padded clip: the EXACT region a capture would photograph. Everything below
  // proves (or retracts) THIS region, never just the header box.
  const boxL = box.x;
  const boxT = box.y;
  const boxR = box.x + box.width;
  const boxB = box.y + box.height;
  const clipX = Math.max(0, Math.floor(boxL - arg.pad));
  const clipY = Math.max(0, Math.floor(boxT - arg.pad));
  const clipW = Math.max(1, Math.min(viewport.width - clipX, Math.ceil(box.width + arg.pad * 2)));
  const clipH = Math.max(1, Math.min(viewport.height - clipY, Math.ceil(box.height + arg.pad * 2)));
  const clipRight = clipX + clipW;
  const clipBottom = clipY + clipH;

  // Sample points. Region 0 is the header interior: whatever paints there must BE the
  // header (or the page background showing through, e.g. at a rounded corner). Regions
  // 1/2/3/4 are the top/bottom/left/right padding bands: in-flow content there is the
  // page's genuine surroundings and is fine, while out-of-flow chrome retracts that side.
  const px: number[] = [];
  const py: number[] = [];
  const pRegion: number[] = [];
  for (let i = 0; i < arg.samples.length; i += 1) {
    const fx = arg.samples[i];
    if (fx === undefined) continue;
    for (let j = 0; j < arg.samples.length; j += 1) {
      const fy = arg.samples[j];
      if (fy === undefined) continue;
      px.push(boxL + box.width * fx);
      py.push(boxT + box.height * fy);
      pRegion.push(0);
    }
  }
  if (clipY < Math.floor(boxT)) {
    for (let i = 0; i < arg.samples.length; i += 1) {
      const f = arg.samples[i];
      if (f === undefined) continue;
      px.push(clipX + clipW * f);
      py.push((clipY + boxT) / 2);
      pRegion.push(1);
    }
  }
  if (clipBottom > Math.ceil(boxB)) {
    for (let i = 0; i < arg.samples.length; i += 1) {
      const f = arg.samples[i];
      if (f === undefined) continue;
      px.push(clipX + clipW * f);
      py.push((boxB + clipBottom) / 2);
      pRegion.push(2);
    }
  }
  if (clipX < Math.floor(boxL)) {
    for (let i = 0; i < arg.samples.length; i += 1) {
      const f = arg.samples[i];
      if (f === undefined) continue;
      px.push((clipX + boxL) / 2);
      py.push(boxT + box.height * f);
      pRegion.push(3);
    }
  }
  if (clipRight > Math.ceil(boxR)) {
    for (let i = 0; i < arg.samples.length; i += 1) {
      const f = arg.samples[i];
      if (f === undefined) continue;
      px.push((boxR + clipRight) / 2);
      py.push(boxT + box.height * f);
      pRegion.push(4);
    }
  }

  let occluded = false;
  let occluder: DomElement | null = null;
  let dirtyTop = false;
  let dirtyBottom = false;
  let dirtyLeft = false;
  let dirtyRight = false;

  // PRIMARY: walk the full hit-test stack at each point, skipping layers that paint nothing
  // (an empty transparent portal root is hit-testable but visually absent, so it must not
  // count as an occluder). The first element that actually paints decides the point.
  for (let p = 0; p < px.length && !occluded; p += 1) {
    const x = px[p];
    const y = py[p];
    const region = pRegion[p];
    if (x === undefined || y === undefined || region === undefined) continue;
    if (x < 0 || y < 0 || x >= viewport.width || y >= viewport.height) continue;
    const stack = document.elementsFromPoint(x, y);
    let decided = false;
    for (let s = 0; s < stack.length && !decided; s += 1) {
      const el = stack[s];
      if (el === undefined || el === null) continue;
      // The header itself (or one of its descendants) is what paints here: clean.
      if (header.contains(el)) {
        decided = true;
        continue;
      }
      // An ancestor of the header is the page background showing through: clean.
      if (el.contains(header)) {
        decided = true;
        continue;
      }
      // Foreign element. Does it actually paint at this point, or is it a transparent
      // hit-testable layer we should look straight through?
      const style = getComputedStyle(el);
      const opacity = style.opacity === '' ? 1 : Number(style.opacity);
      let paints = false;
      const tag = el.tagName.toUpperCase();
      if (
        tag === 'IMG' ||
        tag === 'VIDEO' ||
        tag === 'CANVAS' ||
        tag === 'SVG' ||
        tag === 'PICTURE' ||
        tag === 'IFRAME'
      ) {
        paints = true;
      }
      if (!paints) {
        const bg = style.backgroundColor;
        if (bg !== '' && bg !== 'transparent' && bg !== 'rgba(0, 0, 0, 0)') paints = true;
      }
      if (!paints && style.backgroundImage !== '' && style.backgroundImage !== 'none') {
        paints = true;
      }
      if (!paints && style.boxShadow !== '' && style.boxShadow !== 'none') paints = true;
      if (
        !paints &&
        (parseFloat(style.borderTopWidth) > 0 ||
          parseFloat(style.borderRightWidth) > 0 ||
          parseFloat(style.borderBottomWidth) > 0 ||
          parseFloat(style.borderLeftWidth) > 0)
      ) {
        paints = true;
      }
      if (!paints) {
        const kids = el.childNodes;
        for (let k = 0; k < kids.length; k += 1) {
          const kid = kids[k];
          if (kid === undefined) continue;
          if (kid.nodeType !== 3) continue;
          const text = kid.textContent;
          if (text !== null && text.trim() !== '') {
            paints = true;
            break;
          }
        }
      }
      if (!Number.isNaN(opacity) && opacity <= 0.05) paints = false;
      if (!paints) continue;
      if (region === 0) {
        // Anything foreign painted over the header interior is an occlusion. Full stop.
        occluded = true;
        occluder = el;
        decided = true;
        continue;
      }
      // Padding band. In-flow neighbours (the tab bar, the posts grid) are the page itself;
      // out-of-flow chrome must not be delivered, so that side's padding is retracted.
      let overlayish = false;
      let node: DomElement | null = el;
      for (let depth = 0; depth < 60 && node !== null; depth += 1) {
        if (node.contains(header)) break;
        const ns = getComputedStyle(node);
        if (ns.position === 'fixed' || ns.position === 'sticky') {
          overlayish = true;
          break;
        }
        if (ns.position === 'absolute') {
          const anchor = node.offsetParent;
          if (anchor === null || anchor === document.body || anchor === document.documentElement) {
            overlayish = true;
            break;
          }
        }
        node = node.parentElement;
      }
      if (overlayish) {
        if (region === 1) dirtyTop = true;
        else if (region === 2) dirtyBottom = true;
        else if (region === 3) dirtyLeft = true;
        else dirtyRight = true;
      }
      decided = true;
    }
    if (!decided) {
      // The stack never produced the header, its background, or painted content — no
      // evidence about this point at all. Interior: fail closed. Band: retract the side.
      if (region === 0) occluded = true;
      else if (region === 1) dirtyTop = true;
      else if (region === 2) dirtyBottom = true;
      else if (region === 3) dirtyLeft = true;
      else dirtyRight = true;
    }
  }

  // SECONDARY: hit-testing follows `pointer-events`, so a PAINTED click-through layer is
  // invisible to the walk above yet still lands in the picture. Sweep every element that
  // overlaps the clip and paints, then decide above/below by asking the page itself: force
  // the candidate hit-testable for a moment and see whether it is what a probe would land
  // on. That is real paint order — no position/z-index guessing, so a layer painted BEHIND
  // the page (Instagram ships a fixed, z-index -9999 background div on every logged-out
  // profile) is correctly ignored.
  for (let i = 0; i < candidates.length && !occluded; i += 1) {
    const el = candidates[i];
    if (el === undefined) continue;
    if (el === header || header.contains(el) || el.contains(header)) continue;
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) continue;
    const clipOverlapW = Math.min(r.right, clipRight) - Math.max(r.left, clipX);
    const clipOverlapH = Math.min(r.bottom, clipBottom) - Math.max(r.top, clipY);
    // A couple of px of bounding-box bleed from adjacent in-flow elements is not overlap.
    if (clipOverlapW <= 2 || clipOverlapH <= 2) continue;
    const style = getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') continue;
    const opacity = style.opacity === '' ? 1 : Number(style.opacity);
    if (!Number.isNaN(opacity) && opacity <= 0.05) continue;
    let paints = false;
    const tag = el.tagName.toUpperCase();
    if (
      tag === 'IMG' ||
      tag === 'VIDEO' ||
      tag === 'CANVAS' ||
      tag === 'SVG' ||
      tag === 'PICTURE' ||
      tag === 'IFRAME'
    ) {
      paints = true;
    }
    if (!paints) {
      const bg = style.backgroundColor;
      if (bg !== '' && bg !== 'transparent' && bg !== 'rgba(0, 0, 0, 0)') paints = true;
    }
    if (!paints && style.backgroundImage !== '' && style.backgroundImage !== 'none') {
      paints = true;
    }
    if (!paints && style.boxShadow !== '' && style.boxShadow !== 'none') paints = true;
    if (
      !paints &&
      (parseFloat(style.borderTopWidth) > 0 ||
        parseFloat(style.borderRightWidth) > 0 ||
        parseFloat(style.borderBottomWidth) > 0 ||
        parseFloat(style.borderLeftWidth) > 0)
    ) {
      paints = true;
    }
    if (!paints) {
      const kids = el.childNodes;
      for (let k = 0; k < kids.length; k += 1) {
        const kid = kids[k];
        if (kid === undefined) continue;
        if (kid.nodeType !== 3) continue;
        const text = kid.textContent;
        if (text !== null && text.trim() !== '') {
          paints = true;
          break;
        }
      }
    }
    if (!paints) continue;

    const headOverlapW = Math.min(r.right, boxR) - Math.max(r.left, boxL);
    const headOverlapH = Math.min(r.bottom, boxB) - Math.max(r.top, boxT);
    if (headOverlapW > 2 && headOverlapH > 2) {
      // Painted and overlapping the header. Above or below? Ask the page at up to five
      // points of the overlap; any hit landing on the candidate means it is on top.
      const ox1 = Math.max(r.left, boxL);
      const oy1 = Math.max(r.top, boxT);
      const ox2 = Math.min(r.right, boxR);
      const oy2 = Math.min(r.bottom, boxB);
      const qx: number[] = [];
      const qy: number[] = [];
      qx.push((ox1 + ox2) / 2);
      qy.push((oy1 + oy2) / 2);
      qx.push(ox1 + 2);
      qy.push(oy1 + 2);
      qx.push(ox2 - 2);
      qy.push(oy1 + 2);
      qx.push(ox1 + 2);
      qy.push(oy2 - 2);
      qx.push(ox2 - 2);
      qy.push(oy2 - 2);
      const savedPointerEvents = el.style.pointerEvents;
      el.style.pointerEvents = 'auto';
      let above = false;
      for (let q = 0; q < qx.length && !above; q += 1) {
        const hx = qx[q];
        const hy = qy[q];
        if (hx === undefined || hy === undefined) continue;
        if (hx < 0 || hy < 0 || hx >= viewport.width || hy >= viewport.height) continue;
        const hit = document.elementFromPoint(hx, hy);
        if (hit !== null && el.contains(hit)) above = true;
      }
      el.style.pointerEvents = savedPointerEvents;
      if (above) {
        occluded = true;
        occluder = el;
      }
      continue;
    }

    // Band-only overlap: retract the touched side(s) if this is out-of-flow chrome that is
    // actually on top there. In-flow neighbours stay — they are the page, not an overlay.
    let overlayish = false;
    let node: DomElement | null = el;
    for (let depth = 0; depth < 60 && node !== null; depth += 1) {
      if (node.contains(header)) break;
      const ns = getComputedStyle(node);
      if (ns.position === 'fixed' || ns.position === 'sticky') {
        overlayish = true;
        break;
      }
      if (ns.position === 'absolute') {
        const anchor = node.offsetParent;
        if (anchor === null || anchor === document.body || anchor === document.documentElement) {
          overlayish = true;
          break;
        }
      }
      node = node.parentElement;
    }
    if (!overlayish) continue;
    const bx1 = Math.max(r.left, clipX);
    const by1 = Math.max(r.top, clipY);
    const bx2 = Math.min(r.right, clipRight);
    const by2 = Math.min(r.bottom, clipBottom);
    const cx = (bx1 + bx2) / 2;
    const cy = (by1 + by2) / 2;
    if (cx < 0 || cy < 0 || cx >= viewport.width || cy >= viewport.height) continue;
    const savedBandPointerEvents = el.style.pointerEvents;
    el.style.pointerEvents = 'auto';
    const bandHit = document.elementFromPoint(cx, cy);
    el.style.pointerEvents = savedBandPointerEvents;
    if (bandHit === null || !el.contains(bandHit)) continue;
    // Attribute the dirt to the band strip(s) the CLIP-INTERSECTION actually touches: the
    // top/bottom strips run the clip's full width above/below the header, the left/right
    // strips cover the header's own rows. A full-width sheet below the header must retract
    // ONLY the bottom padding, not the sides it merely crosses at the corners.
    let strip = false;
    if (Math.min(by2, boxT) - by1 > 0 && Math.min(bx2, boxR) - Math.max(bx1, boxL) > 0) {
      dirtyTop = true;
      strip = true;
    }
    if (by2 - Math.max(by1, boxB) > 0 && Math.min(bx2, boxR) - Math.max(bx1, boxL) > 0) {
      dirtyBottom = true;
      strip = true;
    }
    if (Math.min(bx2, boxL) - bx1 > 0 && Math.min(by2, boxB) - Math.max(by1, boxT) > 0) {
      dirtyLeft = true;
      strip = true;
    }
    if (bx2 - Math.max(bx1, boxR) > 0 && Math.min(by2, boxB) - Math.max(by1, boxT) > 0) {
      dirtyRight = true;
      strip = true;
    }
    if (!strip) {
      // Corner-only content touches no strip; retract both adjacent sides (conservative).
      if (bx1 < boxL) dirtyLeft = true;
      if (bx2 > boxR) dirtyRight = true;
      if (by1 < boxT) dirtyTop = true;
      if (by2 > boxB) dirtyBottom = true;
    }
  }

  if (occluded) {
    let description = 'nothing-painted';
    if (occluder !== null) {
      const role = occluder.getAttribute('role');
      const r = occluder.getBoundingClientRect();
      description =
        occluder.tagName.toLowerCase() +
        (role !== null && role !== '' ? '[role=' + role + ']' : '') +
        ' ' +
        Math.round(r.width) +
        'x' +
        Math.round(r.height);
    }
    return { visible: false, reason: 'occluded', box, viewport, clip: null, occluder: description };
  }

  // Final clip: padding survives only on sides whose band was proven clean.
  const padTop = dirtyTop ? 0 : arg.pad;
  const padBottom = dirtyBottom ? 0 : arg.pad;
  const padLeft = dirtyLeft ? 0 : arg.pad;
  const padRight = dirtyRight ? 0 : arg.pad;
  const finalX = Math.max(0, Math.floor(boxL - padLeft));
  const finalY = Math.max(0, Math.floor(boxT - padTop));
  const finalW = Math.max(
    1,
    Math.min(viewport.width - finalX, Math.ceil(box.width + padLeft + padRight)),
  );
  const finalH = Math.max(
    1,
    Math.min(viewport.height - finalY, Math.ceil(box.height + padTop + padBottom)),
  );
  return {
    visible: true,
    reason: 'ok',
    box,
    viewport,
    clip: { x: finalX, y: finalY, width: finalW, height: finalH },
    occluder: null,
  };
}

/**
 * Remove ONLY the nodes that are demonstrably PAINTED OVER the profile header, then restore
 * scrolling. Geometry and real paint order decide what goes — never a role, class or caption.
 * Returns how many nodes were removed.
 *
 * The `contains(header)` guard is what makes this safe: an ancestor of the header can never
 * be removed, so the profile itself is never destroyed. The above/below decision is made by
 * hit-testing (with pointer-events forced on for a moment), which keeps two prior mistakes
 * out: a painted click-through layer that is not fixed/sticky used to be invisible to the
 * sweep, and Instagram's own full-viewport background layer (painted but BEHIND all content)
 * used to be wrongly deleted, changing how the delivered image looked.
 */
function clearHeaderOverlaysInPage(arg: ClearArg): number {
  const headers = document.querySelectorAll('header');
  let header: DomElement | null = null;
  let rect: DomGeometry | null = null;
  let bestArea = -1;
  for (let i = 0; i < headers.length; i += 1) {
    const candidate = headers[i];
    if (candidate === undefined) continue;
    const r = candidate.getBoundingClientRect();
    if (r.width < arg.minWidth || r.height < arg.minHeight) continue;
    const area = r.width * r.height;
    if (area > bestArea) {
      bestArea = area;
      header = candidate;
      rect = r;
    }
  }
  if (header === null || rect === null) return 0;

  let removed = 0;

  // 1. Peel whatever is painted over the middle of the header, outermost overlay first.
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  for (let pass = 0; pass < arg.maxPasses; pass += 1) {
    const hit = document.elementFromPoint(centerX, centerY);
    if (hit === null || header.contains(hit)) break;
    // Climb to the outermost node that still excludes the header — the overlay's own root.
    let node: DomElement = hit;
    let positioned: DomElement | null = null;
    for (let depth = 0; depth < 40; depth += 1) {
      const style = getComputedStyle(node);
      if (style.position === 'fixed' || style.position === 'sticky') positioned = node;
      const parent = node.parentElement;
      if (parent === null || parent === document.body || parent.contains(header)) break;
      node = parent;
    }
    const target = positioned ?? node;
    if (target.contains(header)) break;
    const targetParent = target.parentNode;
    if (targetParent === null) break;
    targetParent.removeChild(target);
    removed += 1;
  }

  // 2. Sweep any remaining PAINTED layer over the header — click-through ones included.
  //    Skipped entirely (rather than truncated) on a pathologically large DOM: the probe
  //    fails closed on the same cap, so nothing is captured in that state anyway.
  const candidates = document.querySelectorAll('body *');
  if (candidates.length <= arg.maxScan) {
    for (let i = 0; i < candidates.length; i += 1) {
      const el = candidates[i];
      if (el === undefined) continue;
      if (el === header || header.contains(el) || el.contains(header)) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) continue;
      const overlapWidth = Math.min(r.right, rect.right) - Math.max(r.left, rect.left);
      const overlapHeight = Math.min(r.bottom, rect.bottom) - Math.max(r.top, rect.top);
      if (overlapWidth <= 2 || overlapHeight <= 2) continue;
      const style = getComputedStyle(el);
      if (style.display === 'none' || style.visibility === 'hidden') continue;
      const opacity = style.opacity === '' ? 1 : Number(style.opacity);
      if (!Number.isNaN(opacity) && opacity <= 0.05) continue;
      let paints = false;
      const tag = el.tagName.toUpperCase();
      if (
        tag === 'IMG' ||
        tag === 'VIDEO' ||
        tag === 'CANVAS' ||
        tag === 'SVG' ||
        tag === 'PICTURE' ||
        tag === 'IFRAME'
      ) {
        paints = true;
      }
      if (!paints) {
        const bg = style.backgroundColor;
        if (bg !== '' && bg !== 'transparent' && bg !== 'rgba(0, 0, 0, 0)') paints = true;
      }
      if (!paints && style.backgroundImage !== '' && style.backgroundImage !== 'none') {
        paints = true;
      }
      if (!paints && style.boxShadow !== '' && style.boxShadow !== 'none') paints = true;
      if (
        !paints &&
        (parseFloat(style.borderTopWidth) > 0 ||
          parseFloat(style.borderRightWidth) > 0 ||
          parseFloat(style.borderBottomWidth) > 0 ||
          parseFloat(style.borderLeftWidth) > 0)
      ) {
        paints = true;
      }
      if (!paints) {
        const kids = el.childNodes;
        for (let k = 0; k < kids.length; k += 1) {
          const kid = kids[k];
          if (kid === undefined) continue;
          if (kid.nodeType !== 3) continue;
          const text = kid.textContent;
          if (text !== null && text.trim() !== '') {
            paints = true;
            break;
          }
        }
      }
      if (!paints) continue;
      // Painted and overlapping: remove only if it is actually ON TOP of the header.
      const ox1 = Math.max(r.left, rect.left);
      const oy1 = Math.max(r.top, rect.top);
      const ox2 = Math.min(r.right, rect.right);
      const oy2 = Math.min(r.bottom, rect.bottom);
      const qx: number[] = [];
      const qy: number[] = [];
      qx.push((ox1 + ox2) / 2);
      qy.push((oy1 + oy2) / 2);
      qx.push(ox1 + 2);
      qy.push(oy1 + 2);
      qx.push(ox2 - 2);
      qy.push(oy1 + 2);
      qx.push(ox1 + 2);
      qy.push(oy2 - 2);
      qx.push(ox2 - 2);
      qy.push(oy2 - 2);
      const savedPointerEvents = el.style.pointerEvents;
      el.style.pointerEvents = 'auto';
      let above = false;
      for (let q = 0; q < qx.length && !above; q += 1) {
        const hx = qx[q];
        const hy = qy[q];
        if (hx === undefined || hy === undefined) continue;
        const hit = document.elementFromPoint(hx, hy);
        if (hit !== null && el.contains(hit)) above = true;
      }
      el.style.pointerEvents = savedPointerEvents;
      if (!above) continue;
      const elParent = el.parentNode;
      if (elParent === null) continue;
      elParent.removeChild(el);
      removed += 1;
    }
  }

  // A modal locks the page; restore scrolling so the header lays out normally again.
  document.body.style.overflow = 'auto';
  document.documentElement.style.overflow = 'auto';
  return removed;
}

const CONSENT_BUTTON_LABELS = [
  'Only allow essential cookies',
  'Decline optional cookies',
  'Allow all cookies',
  'Allow the use of cookies',
  'Accept All',
] as const;

/**
 * Best-effort, non-destructive overlay dismissal, escalating to geometric removal.
 * Safe to call on any page: every step only acts on what is actually present.
 *
 * MUTATES THE PAGE. Any caller that also gates on `page.content()` (login form, consent,
 * error interstitial) must read that HTML BEFORE calling this — step 4 deletes overlay
 * nodes from the DOM, so markup evidence read afterwards has been stripped of exactly the
 * things the gate is looking for.
 *
 * Steps 1-3 are heuristics (labels, ARIA, keyboard) — useful, but never trusted on their
 * own. Step 4 is deterministic and driven purely by geometry and paint order. Nothing here
 * decides whether a capture may proceed: {@link probeHeaderVisibility} does that, afterwards.
 */
export async function dismissOverlays(page: Page): Promise<void> {
  // 1. Cookie / consent buttons (most privacy-preserving option first).
  for (const label of CONSENT_BUTTON_LABELS) {
    const button = page.getByRole('button', { name: label }).first();
    // Short probes on purpose: this runs inside the worker's screenshot budget, and every
    // label that is absent costs its full timeout before the deterministic step 4 is reached.
    const visible = await button.isVisible({ timeout: 250 }).catch(() => false);
    if (visible) {
      await button.click({ timeout: 1000 }).catch(() => undefined);
      break;
    }
  }

  // 2. Explicit close controls. Instagram varies the markup (svg vs button, different
  //    labels), so try each shape rather than relying on one selector.
  const closeSelectors = [
    'svg[aria-label="Close"]',
    'button[aria-label="Close"]',
    '[aria-label="Close"]',
    'div[role="dialog"] button:has(svg)',
  ];
  for (const selector of closeSelectors) {
    const control = page.locator(selector).first();
    const visible = await control.isVisible({ timeout: 200 }).catch(() => false);
    if (visible) {
      await control.click({ timeout: 800 }).catch(() => undefined);
      break;
    }
  }

  // 3. Escape as a general dismiss.
  await page.keyboard.press('Escape').catch(() => undefined);

  // 4. Remove whatever is still painted over the header. Profile content is never touched.
  await page
    .evaluate(clearHeaderOverlaysInPage, {
      minWidth: MIN_HEADER_WIDTH,
      minHeight: MIN_HEADER_HEIGHT,
      maxScan: MAX_SCAN_ELEMENTS,
      maxPasses: MAX_REMOVAL_PASSES,
    })
    .catch(() => 0);
}

function isHeaderProbe(value: unknown): value is HeaderProbe {
  if (typeof value !== 'object' || value === null) return false;
  const record = value as Record<string, unknown>;
  return typeof record['visible'] === 'boolean' && typeof record['reason'] === 'string';
}

const PROBE_FAILED: HeaderProbe = {
  visible: false,
  reason: 'probe-failed',
  box: null,
  viewport: null,
  clip: null,
  occluder: null,
};

/**
 * Ask the page whether the profile header is genuinely VISIBLE — present is not enough.
 *
 * Fails closed on every error path: if `evaluate` rejects (page navigating away, context
 * torn down, `elementFromPoint` throwing) we have no evidence the page is clean, and "no
 * evidence" must never authorize sending an image to a client.
 */
export async function probeHeaderVisibility(page: Page): Promise<HeaderProbe> {
  const raw = await page
    .evaluate(probeHeaderInPage, {
      minWidth: MIN_HEADER_WIDTH,
      minHeight: MIN_HEADER_HEIGHT,
      samples: SAMPLE_FRACTIONS,
      pad: HEADER_PADDING,
      maxScan: MAX_SCAN_ELEMENTS,
    })
    .catch(() => null);
  return isHeaderProbe(raw) ? raw : PROBE_FAILED;
}

function isRenderReady(value: unknown): value is RenderReady {
  if (typeof value !== 'object' || value === null) return false;
  const record = value as Record<string, unknown>;
  return typeof record['ready'] === 'boolean' && typeof record['reason'] === 'string';
}

const RENDER_PROBE_FAILED: RenderReady = { ready: false, reason: 'probe-failed', box: null };

/**
 * One paint check. Fails closed for the same reason {@link probeHeaderVisibility} does: an
 * `evaluate` that rejected (page navigating, context torn down, a DOM method throwing) is not
 * evidence that anything rendered. When polled, a failed check is simply retried until the
 * deadline, so a transient hydration error costs one poll rather than the whole capture.
 */
export async function probeRenderReady(page: Page, username: string): Promise<RenderReady> {
  const raw = await page
    .evaluate(probeRenderReadyInPage, {
      minWidth: MIN_HEADER_WIDTH,
      minHeight: MIN_HEADER_HEIGHT,
      minPaintedSide: MIN_PAINTED_HEADER_SIDE,
      username,
      counterTokens: PROFILE_COUNTER_TOKENS,
    })
    .catch(() => null);
  return isRenderReady(raw) ? raw : RENDER_PROBE_FAILED;
}

function isHeaderImages(value: unknown): value is HeaderImages {
  if (typeof value !== 'object' || value === null) return false;
  const record = value as Record<string, unknown>;
  return typeof record['ready'] === 'boolean' && typeof record['reason'] === 'string';
}

/** A probe that could not run tells us nothing to wait FOR, so it reads as done, not as pending. */
const HEADER_IMAGES_PROBE_FAILED: HeaderImages = {
  total: 0,
  settled: 0,
  ready: true,
  reason: 'probe-failed',
};

/** One header-image check. Unlike the safety probes, an error here fails OPEN (see the probe). */
export async function probeHeaderImages(page: Page): Promise<HeaderImages> {
  const raw = await page
    .evaluate(probeHeaderImagesInPage, {
      minWidth: MIN_HEADER_WIDTH,
      minHeight: MIN_HEADER_HEIGHT,
      maxScan: MAX_SCAN_ELEMENTS,
    })
    .catch(() => null);
  return isHeaderImages(raw) ? raw : HEADER_IMAGES_PROBE_FAILED;
}

/** Knobs for {@link waitForHeaderImages}. */
export interface HeaderImageWaitOptions {
  /** Hard ceiling. `<= 0` means do not wait at all — check nothing, capture now. */
  timeoutMs: number;
  /** Gap between polls (default {@link DEFAULT_HEADER_IMAGE_POLL_INTERVAL_MS}). */
  pollIntervalMs?: number;
}

/**
 * Give the header's images — the avatar and the story-highlight thumbnails, the only images
 * inside the crop — a BOUNDED window to finish, then return regardless.
 *
 * This is why the good capture in production still showed a grey circle: the text predicate held
 * at 13.5s and the shutter fired immediately, while header images were measured to settle 8-70s
 * after text paint depending on how warm the connections were. The wait closes that gap without
 * ever becoming a gate: when the window expires the caller captures anyway, because a correct
 * card with a grey avatar is FAR better than no proof at all.
 *
 * Returns the last verdict, for logging only. Nothing downstream may branch on it.
 */
export async function waitForHeaderImages(
  page: Page,
  options: HeaderImageWaitOptions,
): Promise<HeaderImages> {
  if (!Number.isFinite(options.timeoutMs) || options.timeoutMs <= 0) {
    return { total: 0, settled: 0, ready: true, reason: 'ok' };
  }
  const pollIntervalMs = options.pollIntervalMs ?? DEFAULT_HEADER_IMAGE_POLL_INTERVAL_MS;
  const deadline = Date.now() + options.timeoutMs;

  let verdict = await probeHeaderImages(page);
  while (!verdict.ready && Date.now() < deadline) {
    await sleep(pollIntervalMs);
    verdict = await probeHeaderImages(page);
  }
  return verdict;
}

/** Knobs for {@link waitForProfilePainted}. Tests pass zeroes to stay fast. */
export interface PaintWaitOptions {
  /** The account whose name must appear in the rendered header. */
  username: string;
  /** Overall ceiling for the poll (default {@link DEFAULT_PAINT_TIMEOUT_MS}). */
  timeoutMs?: number;
  /** Gap between polls (default {@link DEFAULT_PAINT_POLL_INTERVAL_MS}). */
  pollIntervalMs?: number;
}

/**
 * Poll until the profile has painted, or the budget runs out.
 *
 * POLLING, not a fixed sleep and not `networkidle`. Paint was measured at 9.9s, 85.4s and
 * 96.4s on three accounts through the production egress — an order of magnitude of spread, so
 * no constant delay can be both fast and correct — while `networkidle` never fired once in
 * 120s, which is exactly why the old `waitForLoadState('networkidle')` always timed out and
 * let the shutter fire on an unpainted page.
 *
 * Returns the LAST verdict. A caller must treat `ready === false` as "produce no image".
 */
export async function waitForProfilePainted(
  page: Page,
  options: PaintWaitOptions,
): Promise<RenderReady> {
  // A blank username makes the identity half of the predicate VACUOUS — `''` is a substring
  // of every string — leaving only "a big header exists", which a half-painted shell of the
  // wrong page satisfies. There is nothing to prove, so prove nothing: fail closed at once
  // rather than spend the whole budget polling towards an answer that cannot be trusted.
  if (options.username.trim() === '') {
    return { ready: false, reason: 'identity-missing', box: null };
  }

  const timeoutMs = options.timeoutMs ?? DEFAULT_PAINT_TIMEOUT_MS;
  const pollIntervalMs = options.pollIntervalMs ?? DEFAULT_PAINT_POLL_INTERVAL_MS;
  const deadline = Date.now() + timeoutMs;

  // Check first, sleep second: an already-painted page (the common case once the detector has
  // waited) proceeds with no added latency at all.
  let verdict = await probeRenderReady(page, options.username);
  while (!verdict.ready && Date.now() < deadline) {
    await sleep(pollIntervalMs);
    verdict = await probeRenderReady(page, options.username);
  }
  return verdict;
}

/**
 * Is something covering the profile? True means: do not screenshot, send the text-only
 * recovery instead.
 *
 * Now answered by occlusion testing rather than by selector matching. The previous
 * implementation asked only for `div[role="dialog"], div[role="presentation"]`; Instagram's
 * logged-out signup interstitial carries neither role, so the guard returned false on
 * precisely the case its own docstring named and a signup modal was sent to a client.
 */
export async function hasBlockingOverlay(page: Page): Promise<boolean> {
  const probe = await probeHeaderVisibility(page);
  return !probe.visible;
}

/** Timing knobs. Defaults are the production values; tests pass zeroes to stay fast. */
export interface CaptureTiming {
  /**
   * Wait before the FIRST probe. The signup interstitial typically lands a second or two
   * after load, so probing immediately yields a clean verdict that is about to go stale.
   */
  settleMs: number;
  /** Pause after a dismissal attempt: close animations finish, and a remount can show up. */
  retryDelayMs: number;
  /** Dismissal rounds before giving up and letting the caller fall back to text-only. */
  maxAttempts: number;
}

/**
 * Occlusion-only timings, and small on purpose: the dominant cost of a capture is now the
 * PAINT poll (see {@link DEFAULT_PAINT_TIMEOUT_MS}), which runs first and against which this
 * worst case — settle + 2 x (dismissal probing + retry delay) ~= 6.5s — is rounding error.
 */
const DEFAULT_TIMING: CaptureTiming = { settleMs: 1500, retryDelayMs: 600, maxAttempts: 2 };

function sleep(ms: number): Promise<void> {
  if (ms <= 0) return Promise.resolve();
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

/**
 * Settle, then dismiss-and-re-verify until the header is provably unobstructed or the
 * attempts run out. The returned probe is the ONLY authority on whether a capture may
 * proceed — a caller must check `visible` and fall back to text-only when it is false.
 */
export async function ensureHeaderVisible(
  page: Page,
  timing: Partial<CaptureTiming> = {},
): Promise<HeaderProbe> {
  const settleMs = timing.settleMs ?? DEFAULT_TIMING.settleMs;
  const retryDelayMs = timing.retryDelayMs ?? DEFAULT_TIMING.retryDelayMs;
  const maxAttempts = timing.maxAttempts ?? DEFAULT_TIMING.maxAttempts;

  await sleep(settleMs);
  let probe = await probeHeaderVisibility(page);
  for (let attempt = 0; attempt < maxAttempts && !probe.visible; attempt += 1) {
    // Dismissal uncovers things; it cannot conjure a header that was never rendered.
    if (probe.reason === 'no-header' || probe.reason === 'header-too-small') break;
    await dismissOverlays(page);
    await sleep(retryDelayMs);
    probe = await probeHeaderVisibility(page);
  }
  return probe;
}

function isUsableGeometry(probe: HeaderProbe): probe is HeaderProbe & {
  box: { x: number; y: number; width: number; height: number };
  viewport: { width: number; height: number };
  clip: { x: number; y: number; width: number; height: number };
} {
  const box = probe.box;
  const viewport = probe.viewport;
  const clip = probe.clip;
  if (box === null || viewport === null || clip === null) return false;
  const finite = [
    box.x,
    box.y,
    box.width,
    box.height,
    viewport.width,
    viewport.height,
    clip.x,
    clip.y,
    clip.width,
    clip.height,
  ];
  return finite.every((n) => typeof n === 'number' && Number.isFinite(n));
}

/** Everything {@link captureProfileScreenshot} needs. `username` is not optional by design. */
export interface CaptureOptions extends Partial<CaptureTiming> {
  /**
   * The account being photographed. REQUIRED: paint readiness is proven by the rendered
   * header NAMING this account, which is the only signal that distinguishes a laid-out
   * profile from an empty `<header>` shell. Without it there is nothing to prove.
   */
  username: string;
  /** Override the paint-poll ceiling (default {@link DEFAULT_PAINT_TIMEOUT_MS}). */
  paintTimeoutMs?: number;
  /** Override the paint-poll cadence (default {@link DEFAULT_PAINT_POLL_INTERVAL_MS}). */
  paintPollIntervalMs?: number;
  /**
   * Bounded window, after paint, for the header's images (avatar + story highlights) to finish.
   * DEFAULTS TO ZERO — no wait — so this module never spends a budget nobody granted it. The
   * production value is supplied by the detector, which is the layer that knows the caller's
   * remaining budget; see {@link waitForHeaderImages}.
   */
  headerImageWaitMs?: number;
  /** Override the header-image poll cadence (default 500ms). */
  headerImagePollIntervalMs?: number;
}

/**
 * Capture a TIGHT crop of the profile header — profile picture, name, @username,
 * post/follower/following counts and bio — and nothing that is not the profile.
 *
 * Three independent proofs must all hold, in order:
 *  1. the profile has PAINTED (polled; see {@link waitForProfilePainted});
 *  2. nothing is painted over the region about to be photographed, before AND after the
 *     shutter, and the after-probe certifies the SAME region (see {@link probeHeaderVisibility});
 *  3. the captured BYTES carry enough information to be a rendered card, not a blank
 *     rectangle (see {@link assessImageDensity}).
 *
 * The photographed clip comes from the probe itself, so the region delivered is exactly the
 * region that was proved clean (including per-side padding retraction). Throws
 * AppError('SCREENSHOT_INVALID') whenever any proof fails, which the caller turns into the
 * text-only recovery. There is deliberately NO fallback ladder (a fixed top-region clip, or
 * the full viewport): those photograph the composited viewport, so they cannot tell "no header
 * yet" from "header here" — on a logged-out page they produce the signup-modal image, and on
 * an unpainted one the white rectangle, that this function exists to prevent. A fallback that
 * cannot distinguish those manufactures a plausible-looking failure; no image is strictly
 * better than the wrong image.
 */
export async function captureProfileScreenshot(
  page: Page,
  options: CaptureOptions,
): Promise<Screenshot> {
  // PROOF 1. Replaces `waitForLoadState('networkidle', { timeout: 5000 })`, which never once
  // fired on Instagram in 120s of measurement and therefore always timed out — firing the
  // shutter ~5s in, which is the entire root cause of the blank images shipped to clients.
  const paintOptions: PaintWaitOptions = { username: options.username };
  if (options.paintTimeoutMs !== undefined) paintOptions.timeoutMs = options.paintTimeoutMs;
  if (options.paintPollIntervalMs !== undefined) {
    paintOptions.pollIntervalMs = options.paintPollIntervalMs;
  }
  const painted = await waitForProfilePainted(page, paintOptions);
  if (!painted.ready) {
    throw new AppError('SCREENSHOT_INVALID', `Profile never finished painting (${painted.reason})`);
  }

  // NOT a proof — a bounded courtesy. The text predicate holds before the avatar and the story
  // highlights have arrived (measured 8-70s earlier), which is exactly why the one capture that
  // did succeed in production shipped a card with a grey circle where the profile picture should
  // be. Wait for them, briefly, then carry on either way: this must never be able to suppress a
  // capture, so nothing below branches on the result.
  const headerImageWaitMs = options.headerImageWaitMs ?? 0;
  if (headerImageWaitMs > 0) {
    const waitOptions: HeaderImageWaitOptions = { timeoutMs: headerImageWaitMs };
    if (options.headerImagePollIntervalMs !== undefined) {
      waitOptions.pollIntervalMs = options.headerImagePollIntervalMs;
    }
    await waitForHeaderImages(page, waitOptions);
  }

  // PROOF 2.
  const probe = await ensureHeaderVisible(page, options);
  if (!probe.visible || !isUsableGeometry(probe)) {
    throw new AppError(
      'SCREENSHOT_INVALID',
      `No clean profile capture available (${probe.reason})`,
      probe.occluder ?? undefined,
    );
  }

  const clip = probe.clip;
  const buffer = await page.screenshot({ type: 'png', clip });

  // Re-verify AFTER the shutter. The interstitial can remount at any moment: an image taken
  // a frame before it appears is fine, one taken a frame after is a lie, and only this
  // second probe can tell them apart. Cheap insurance on the one invariant that matters.
  const after = await probeHeaderVisibility(page);
  if (!after.visible) {
    throw new AppError(
      'SCREENSHOT_INVALID',
      `An overlay appeared while capturing (${after.reason})`,
      after.occluder ?? undefined,
    );
  }
  // `visible` alone is not enough: the after-probe re-derives everything from the LIVE DOM,
  // so an interstitial that replaced the page with its own clean header would still report
  // visible. The image is only proven if the region we photographed is the region the
  // after-probe certifies — same clip, within a small layout-settling tolerance.
  const afterClip = after.clip;
  if (
    afterClip === null ||
    Math.abs(afterClip.x - clip.x) > AFTER_CLIP_TOLERANCE_PX ||
    Math.abs(afterClip.y - clip.y) > AFTER_CLIP_TOLERANCE_PX ||
    Math.abs(afterClip.width - clip.width) > AFTER_CLIP_TOLERANCE_PX ||
    Math.abs(afterClip.height - clip.height) > AFTER_CLIP_TOLERANCE_PX
  ) {
    throw new AppError(
      'SCREENSHOT_INVALID',
      'The header region changed while capturing (page replaced or moved)',
    );
  }

  const validation = validateImage(buffer);
  if (!validation.ok) {
    throw new AppError(
      'SCREENSHOT_INVALID',
      `Captured screenshot is invalid: ${validation.reason}`,
    );
  }

  // PROOF 3. The DOM said painted; do the pixels agree? A blank capture compresses to two
  // orders of magnitude less than a real header card, so this catches a compositor that had
  // not produced the frame yet — the one failure mode a DOM predicate cannot see.
  const density = assessImageDensity(buffer.length, clip.width, clip.height);
  if (!density.ok) {
    throw new AppError(
      'SCREENSHOT_INVALID',
      'Captured image looks blank (too little information for a rendered profile)',
      `${density.bytesPerPixel.toFixed(4)} B/px < ${MIN_IMAGE_BYTES_PER_PIXEL} B/px`,
    );
  }

  return { buffer, format: validation.format, width: clip.width, height: clip.height };
}
