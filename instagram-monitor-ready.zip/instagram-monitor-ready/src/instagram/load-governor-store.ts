/**
 * Durable backing for the browser-load window.
 *
 * Kept OUT of {@link BrowserLoadGovernor} so the governor itself stays pure and clock-injected
 * (no fs, no I/O, fully testable without a filesystem). This is the only piece that touches disk.
 *
 * A plain JSON file rather than a database table, deliberately:
 *  - it is written up to ~12 times a minute, which is churn no schema should have to carry;
 *  - it must be readable SYNCHRONOUSLY at startup, before repositories exist, because the very
 *    first probe must already be inside the budget the previous incarnation left behind;
 *  - and losing it is harmless — the governor falls back to a clean window, which is exactly the
 *    behaviour before this existed.
 *
 * Writes are chained (never fired in parallel) so two snapshots in quick succession cannot land
 * out of order and leave a stale, SMALLER window behind a newer one — the one corruption that
 * would matter here, because it hands the fleet budget it has already spent.
 */

import { mkdirSync, readFileSync } from 'node:fs';
import { rename, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';

import type { Logger } from '../logging';
import type { GovernorSnapshot, GovernorStore } from './load-governor';

/** File name used inside the app's data directory. */
export const GOVERNOR_STATE_FILE = 'browser-load-window.json';

/** Where the window lives: beside the SQLite database, in the app's own data directory. */
export function governorStatePath(sqlitePath: string): string {
  return join(dirname(sqlitePath), GOVERNOR_STATE_FILE);
}

/**
 * File-backed {@link GovernorStore}. Every failure is swallowed and logged at debug level: this
 * is durability, and durability must never be able to stop a check.
 */
export function fileGovernorStore(filePath: string, logger: Logger): GovernorStore {
  let writes: Promise<void> = Promise.resolve();
  let warnedOnce = false;

  const warn = (what: string, err: unknown): void => {
    if (warnedOnce) return;
    warnedOnce = true;
    // Once, not per write: a read-only or missing data directory would otherwise fill the log at
    // the exact moment the operator is trying to read it.
    logger.warn('browser-load window is not durable on this host; a restart will start clean', {
      step: what,
      error: err instanceof Error ? err.message : String(err),
    });
  };

  return {
    load(): GovernorSnapshot | null {
      try {
        const raw = readFileSync(filePath, 'utf8');
        const parsed: unknown = JSON.parse(raw);
        if (typeof parsed !== 'object' || parsed === null) return null;
        // Shape is validated by the governor's own defensive rehydrate(); this only has to make
        // sure a non-object never reaches it.
        return parsed as GovernorSnapshot;
      } catch {
        // Missing (first boot) or unreadable (corrupt/truncated) both mean "start clean".
        return null;
      }
    },

    save(snapshot: GovernorSnapshot): void {
      writes = writes
        .then(async () => {
          // Write-then-rename: a crash mid-write must leave the PREVIOUS window intact rather
          // than a truncated file that parses to a smaller budget than was actually spent.
          const tmp = `${filePath}.tmp`;
          await writeFile(tmp, JSON.stringify(snapshot), 'utf8');
          await rename(tmp, filePath);
        })
        .catch((err: unknown) => {
          warn('save', err);
        });
    },

    /**
     * Wait for the queued write chain to settle. Shutdown calls this; without it the last
     * snapshot — the one covering the minutes just spent — raced `process.exit` and was lost.
     * The chain already swallows its own errors, so this can only resolve.
     */
    async drain(): Promise<void> {
      await writes;
    },
  };
}

/**
 * Make sure the directory exists before the first write, and report honestly when it cannot be
 * created — a silently non-durable governor is a load amplifier waiting for a crash loop.
 */
export function ensureGovernorStateDir(filePath: string, logger: Logger): void {
  try {
    mkdirSync(dirname(filePath), { recursive: true });
  } catch (err) {
    logger.warn(
      'browser-load window directory is not writable; the budget will not survive a restart',
      { error: err instanceof Error ? err.message : String(err) },
    );
  }
}
