/**
 * The shared, live {@link Detector}. `/ping` and the monitor call this SAME implementation,
 * so classification never diverges. It only ever navigates to
 * `https://www.instagram.com/{validated username}/` — the sole SSRF guard.
 *
 * Navigation/timeout/browser failures become an UNKNOWN {@link DetectorResult} with a safe
 * structured error code; the probe never throws for a network problem. A screenshot failure
 * degrades to `screenshot: null` without failing the probe.
 */

import type { Page } from 'playwright';
import { captureSettings, type AppConfig } from '../../config';
import type { Logger } from '../../logging';
import {
  AppError,
  isAppError,
  SIGNALS_VERSION,
  type Detector,
  type DetectorErrorCode,
  type DetectorResult,
  type ProbeOptions,
  type ProbeResult,
  type Screenshot,
} from '../../domain';
import type { BrowserManager, PageOptions } from '../browser/browser-manager';
import { isProxySessionFailure } from '../proxy-session';
import {
  captureProfileScreenshot,
  dismissOverlays,
  ensureHeaderVisible,
  waitForProfilePainted,
  type CaptureOptions,
} from '../screenshot/capture';
import { classify } from './classify';
import { extractSnapshot } from './signals';

/** Instagram username charset guard (replicates core/username while it does not yet exist). */
const USERNAME_RE = /^[a-z0-9._]{1,30}$/i;

/**
 * Ceiling for the paint poll when the CALLER did not choose one ({@link ProbeOptions.paintBudgetMs}).
 *
 * Deliberately short, and NOT the capture module's own 120s default. `/check` and `/ping` reach
 * this same detector from the bot's ingress loop, which dispatches updates strictly serially —
 * one slow capture freezes every other command, including the `/ping` the owner would use to
 * find out why. The repo already paid for that lesson with `/bulkunban`. Since paint was measured
 * at 85.4s and 96.4s on two of three production accounts, inheriting a 120s default would make a
 * ~100s ingress freeze the NORMAL outcome of a single `/check`, not an edge case.
 *
 * What this ceiling costs is bounded and cheap: an interactive command answers text-only on a
 * slow-painting profile. It cannot cost a client their proof, because the client-facing capture
 * is never taken here — the monitor worker passes its own, far larger budget.
 */
const DEFAULT_PAINT_BUDGET_MS = 20_000;

/**
 * Ceiling for capture's SECOND paint poll.
 *
 * {@link PlaywrightDetector.tryScreenshot} proves paint before it touches the page, and
 * `captureProfileScreenshot` proves it again because it owns the bytes it hands back. On an
 * already-painted page that re-proof costs a single probe. This bounds the other case — paint
 * REGRESSED between the two (a remount mid-dismissal) — so the re-proof can never silently spend
 * a second full budget on top of the first. Un-parameterised, the two polls stacked to ~240s.
 */
const PAINT_RECHECK_BUDGET_MS = 5_000;

/**
 * The header-image wait may never take more than this FRACTION of the paint budget its caller
 * was willing to spend.
 *
 * The configured wait (25s) is sized for the client's proof, which runs off the monitor tick with
 * a 120s paint budget behind it. The same code path also serves `/check` and `/ping` on the bot's
 * strictly SERIAL ingress loop (20s budget) and the inline re-capture sweep (25s), where 25s of
 * extra waiting is charged to every other command or to the whole scheduler. A quarter scales it
 * to whoever is paying: 25s for a confirmed recovery, ~6s for the sweep, 5s for an owner command.
 */
const HEADER_IMAGE_WAIT_BUDGET_SHARE = 4;

/**
 * Warm-context key for a browser load. See {@link PageOptions.contextKey}.
 *
 * Keyed by ACCOUNT, so the deciding confirmation check and the capture that follows it seconds
 * later share one context — which is the whole point, because that pair is where the measured
 * 79.8s -> 18.5s cold/warm difference on the avatar actually lands. `confirmationContextId` wins
 * when a caller supplies one: it is part of the {@link ProbeOptions} contract, and until now
 * NOTHING in the codebase implemented it, so a caller setting it got silently nothing.
 *
 * This adds no page loads. It only reuses connections that are already open.
 */
function warmContextKey(validated: string, options: ProbeOptions): string {
  const explicit = options.confirmationContextId;
  return typeof explicit === 'string' && explicit.trim() !== ''
    ? `conf:${explicit.trim()}`
    : `user:${validated}`;
}

function validateUsername(raw: string): string {
  const trimmed = raw.trim().replace(/^@/, '');
  if (!USERNAME_RE.test(trimmed)) {
    throw new AppError(
      'INVALID_USERNAME',
      'Invalid Instagram username',
      'username failed validation',
    );
  }
  return trimmed.toLowerCase();
}

/** Only ever build the profile URL from an already-validated username. */
function profileUrl(validated: string): string {
  return `https://www.instagram.com/${validated}/`;
}

/** Map a thrown navigation/browser error to a safe, structured detector error code. */
function mapErrorToCode(err: unknown): DetectorErrorCode {
  if (isAppError(err) && err.code === 'BROWSER_ERROR') return 'BROWSER_CRASH';

  // The egress proxy never tunnelled the request — Chromium reports ERR_TUNNEL_CONNECTION_FAILED,
  // which is most often a sticky mobile session that expired. Checked FIRST, and before the
  // BROWSER_CRASH patterns below, because a failed tunnel also tears the page down: read as a crash
  // it would trigger a pointless browser restart, and the fresh browser would go out over the same
  // dead session and fail identically. It is a route fault, not a browser fault.
  if (isProxySessionFailure(err)) return 'PROXY_TUNNEL';

  const message = (err instanceof Error ? err.message : String(err)).toLowerCase();
  if (message.includes('timeout') || message.includes('timed out')) return 'TIMEOUT';
  if (
    message.includes('err_name_not_resolved') ||
    message.includes('name_not_resolved') ||
    message.includes('getaddrinfo') ||
    message.includes('dns')
  ) {
    return 'DNS';
  }
  if (
    message.includes('crash') ||
    message.includes('target closed') ||
    message.includes('browser has been closed') ||
    message.includes('browser has disconnected')
  ) {
    return 'BROWSER_CRASH';
  }
  return 'NAVIGATION';
}

export interface PlaywrightDetectorOptions {
  browser: BrowserManager;
  config: AppConfig;
  logger: Logger;
}

export class PlaywrightDetector implements Detector {
  private readonly browser: BrowserManager;
  private readonly config: AppConfig;
  private readonly logger: Logger;

  constructor(options: PlaywrightDetectorOptions) {
    this.browser = options.browser;
    this.config = options.config;
    this.logger = options.logger;
  }

  async probe(username: string, options: ProbeOptions = {}): Promise<ProbeResult> {
    const validated = validateUsername(username);
    const url = profileUrl(validated);
    const start = Date.now();

    // Classification needs no imagery — block it unless this probe will capture a screenshot.
    const capturing = options.captureScreenshot === true;
    const blockAssets = !capturing;
    // A capture load gets its OWN navigation budget and the reserved capture lane; a
    // classification load keeps the tighter CHECK_TIMEOUT_MS it has always had. One knob for both
    // is what aborted @trymaven's and @odpcompetitions' page loads at 45s, leaving them
    // unclassifiable — not merely unphotographable.
    const pageOptions: PageOptions = {
      blockAssets,
      contextKey: warmContextKey(validated, options),
    };
    if (capturing) pageOptions.purpose = 'capture';
    const navTimeoutMs = capturing ? this.captureNavTimeoutMs(options) : undefined;
    // The egress route this load leaves over. A `/proxy` switch replaces the browser underneath
    // in-flight probes on purpose, and their deaths must not be treated as a crash to recover
    // from — see {@link BrowserManager.isCurrentEgress}.
    const egressGeneration = this.browser.egressGeneration();
    try {
      return await this.browser.withPage(async (page) => {
        let status: number | null;
        try {
          status = await this.browser.loadProfile(
            page,
            url,
            navTimeoutMs === undefined ? {} : { timeoutMs: navTimeoutMs },
          );
        } catch (navErr) {
          await this.restartAfterCrash(navErr, egressGeneration);
          return this.failure(validated, start, navErr);
        }

        const html = await page.content();
        const finalUrl = page.url();
        const snapshot = extractSnapshot(html, {
          finalUrl,
          responseStatus: status,
          requestedUsername: validated,
        });
        const result: DetectorResult = { ...classify(snapshot), durationMs: Date.now() - start };

        // Instagram can reject the manually-created cookie jar after an IP/egress change and
        // redirect every browser-backed check to `accounts/update_risky_contactpoint`. That page
        // says nothing about the requested profile. Quarantine the state (without touching its
        // file) and tell the tiered wrapper that ONE clean, separately-governed retry is warranted.
        const storageStateQuarantined =
          result.evidence.errorCode === 'AUTH_SESSION_CHALLENGE' &&
          this.browser.quarantineStorageState();

        let screenshot: Screenshot | null = null;
        if (options.captureScreenshot && result.classification === 'ACTIVE') {
          screenshot = await this.tryScreenshot(
            page,
            validated,
            status,
            options.paintBudgetMs ?? DEFAULT_PAINT_BUDGET_MS,
          );
        }
        return {
          result,
          screenshot,
          restricted: snapshot.restrictedProfilePresent,
          ...(storageStateQuarantined ? { storageStateQuarantined: true } : {}),
        };
      }, pageOptions);
    } catch (err) {
      await this.restartAfterCrash(err, egressGeneration);
      return this.failure(validated, start, err);
    }
  }

  /**
   * Navigation ceiling for a CAPTURE load: the configured budget, lowered (never raised) to
   * whatever the caller said it could afford.
   *
   * A caller with its own hard deadline — the re-capture sweep's `withDeadline`, the confirmed
   * edge's remaining `SCREENSHOT_BUDGET_MS` — must be able to size the page load inside it.
   * Without that the two budgets were picked independently and the inner one (120s goto + 8s
   * settle) outgrew the outer one (90s), so the outer wrapper stopped being a backstop and became
   * a cliff that fired mid-`goto` on exactly the slow profiles it was raised for. `withDeadline`
   * does not cancel, so each of those also kept a Chromium page, a capture lane and a concurrency
   * slot alive for another ~70s to produce a result nobody was waiting for.
   *
   * Clamped rather than substituted, so a caller can only ever ask for LESS: a bad option value
   * can cost image quality, never a longer page load than the operator configured.
   */
  private captureNavTimeoutMs(options: ProbeOptions): number {
    const configured = captureSettings(this.config).timeoutMs;
    const requested = options.captureNavBudgetMs;
    if (typeof requested !== 'number' || !Number.isFinite(requested) || requested <= 0) {
      return configured;
    }
    return Math.min(configured, Math.floor(requested));
  }

  /**
   * Gate on the served HTML, then dismiss overlays, re-verify visibility, and capture — in
   * that order, because dismissal mutates the DOM the gate reads. Any failure degrades to
   * `null` rather than failing the whole probe.
   */
  private async tryScreenshot(
    page: Page,
    username: string,
    status: number | null,
    paintBudgetMs: number,
  ): Promise<Screenshot | null> {
    const startedMs = Date.now();
    try {
      // Read the page AS SERVED before anything mutates it. dismissOverlays deletes overlay
      // nodes from the DOM, so running it first would strip the very markup (login form,
      // consent block, error interstitial) that the HTML gate below exists to detect — the
      // gate would then be evaluated against a page its evidence had just been removed from.
      const html = await page.content();
      const finalUrl = page.url();
      const snapshot = extractSnapshot(html, {
        finalUrl,
        responseStatus: status,
        requestedUsername: username,
      });
      const recheck = classify(snapshot);
      if (recheck.classification !== 'ACTIVE') {
        this.logger.warn('profile no longer ACTIVE on screenshot re-read; skipping screenshot');
        return null;
      }
      // ACTIVE can be identity-confirmed behind a login wall (the login page still carries the
      // profile's og metadata, so `hasProfileStructures` alone is NOT enough — it's true even
      // for a login wall). Only screenshot when the profile is VISIBLY rendered: it has profile
      // structures AND there is no login form / redirect to login covering it. Otherwise fall
      // back to a text-only recovery rather than sending a misleading login-page image.
      // Only screenshot a GENUINELY rendered profile. A login wall or "Restricted profile"
      // age-gate is ACTIVE by identity but shows no viewable content — and Instagram serves
      // og:type=profile even on the logged-out login wall, so `hasProfileStructures` alone is
      // not enough. Require: profile structures AND no login form on the page AND not a
      // login redirect AND not a restricted gate. Otherwise fall back to text-only recovery.
      const visiblyRendered =
        snapshot.hasProfileStructures &&
        !snapshot.loginFormPresent &&
        !snapshot.loginWallPresent &&
        !snapshot.redirectedToLogin &&
        !snapshot.restrictedProfilePresent &&
        // "Something went wrong" carries the profile's og metadata, so it would otherwise
        // pass every check above and be sent to the client as proof of recovery.
        !snapshot.errorPagePresent &&
        // A cookie-consent interstitial covers the profile just as thoroughly as a login wall.
        !snapshot.consentBlockPresent;
      if (!visiblyRendered) {
        this.logger.info(
          snapshot.restrictedProfilePresent
            ? 'profile ACTIVE but restricted (age-gated); text-only recovery'
            : 'profile ACTIVE but login-gated / not visibly rendered; text-only recovery',
        );
        return null;
      }
      // The gate above proves the SERVED MARKUP describes a viewable profile. It says nothing
      // about whether that profile has been PAINTED — and on the production egress it very
      // often has not: measured 85.4s and 96.4s from navigation start on two of three
      // accounts. Capturing before then produced the blank white images that went to clients
      // as proof of recovery. Poll for the real paint predicate before anything else touches
      // the page; if it never holds, this profile gets a text-only recovery.
      //
      // The budget is the CALLER's, never an implicit default: this same line runs both under
      // the monitor's own deadline (where minutes are the right answer) and inline on the bot's
      // serial ingress loop (where they are not). See {@link DEFAULT_PAINT_BUDGET_MS}.
      const painted = await waitForProfilePainted(page, { username, timeoutMs: paintBudgetMs });
      if (!painted.ready) {
        this.logger.info('profile never finished painting; text-only recovery', {
          reason: painted.reason,
        });
        return null;
      }
      // The HTML gate above can only see markup. Logged out — which is how the VPS runs —
      // Instagram PAINTS a signup interstitial over the profile a second or two after load,
      // and it carries no dialog role, so no selector or text check reliably catches it.
      // Only now that the gate has read the served page is it safe to mutate: dismiss,
      // settle, and then prove by occlusion testing that the header is the thing actually
      // on screen. Anything short of proof means text-only.
      await dismissOverlays(page);
      const probe = await ensureHeaderVisible(page);
      if (!probe.visible) {
        this.logger.info('profile header not provably visible; text-only recovery', {
          reason: probe.reason,
          ...(probe.occluder !== null ? { occluder: probe.occluder } : {}),
        });
        return null;
      }
      // The settle/dismiss loop above spans seconds, so re-confirm we are still on the
      // profile: a mid-wait bounce to the login page would otherwise be photographed.
      if (!page.url().toLowerCase().includes(`/${username}`)) {
        this.logger.info('navigated away from the profile while settling; text-only recovery');
        return null;
      }
      // Timing already spent above — capture re-verifies (before AND after the shutter)
      // without repeating the settle wait. It re-checks paint too: that costs a single poll
      // on an already-painted page, and it is the chokepoint that produces the bytes, so it
      // owns the guarantee rather than trusting a caller to have waited. That re-check gets an
      // explicit, small budget: paint was proved moments ago, so a long one would only ever be
      // spent waiting out a page that regressed — doubling the wait already paid for above.
      //
      // The header-image wait is bounded THREE ways so it can never become the thing that
      // costs a client their alert: the configured ceiling, a quarter of the caller's paint
      // budget (see HEADER_IMAGE_WAIT_BUDGET_SHARE), and whatever is actually left of that
      // budget after the paint poll and the dismissal round already spent from it. When it
      // expires the capture happens anyway — it is not a gate.
      const spentMs = Date.now() - startedMs;
      const remainingMs = Math.max(0, paintBudgetMs - spentMs);
      const headerImageWaitMs = Math.min(
        captureSettings(this.config).headerImageWaitMs,
        Math.floor(paintBudgetMs / HEADER_IMAGE_WAIT_BUDGET_SHARE),
        remainingMs,
      );
      const captureOptions: CaptureOptions = {
        username,
        settleMs: 0,
        maxAttempts: 0,
        paintTimeoutMs: Math.min(PAINT_RECHECK_BUDGET_MS, paintBudgetMs),
      };
      if (headerImageWaitMs > 0) captureOptions.headerImageWaitMs = headerImageWaitMs;
      return await captureProfileScreenshot(page, captureOptions);
    } catch (err) {
      this.logger.warn('screenshot capture failed', {
        code: isAppError(err) ? err.code : 'INTERNAL',
      });
      return null;
    }
  }

  private failure(username: string, start: number, err: unknown): ProbeResult {
    const errorCode = mapErrorToCode(err);
    this.logger.warn('probe failed', { username, errorCode });
    const result: DetectorResult = {
      classification: 'UNKNOWN',
      evidence: {
        signalsVersion: SIGNALS_VERSION,
        activeSignals: [],
        goneSignals: [],
        identitySignalMatched: false,
        finalUrl: null,
        responseStatus: null,
        errorCode,
      },
      durationMs: Date.now() - start,
    };
    return { result, screenshot: null };
  }

  /** One failed launch/reconnect attempt is enough; the next scheduled retry remains bounded. */
  private async restartAfterCrash(err: unknown, egressGeneration: number): Promise<void> {
    if (mapErrorToCode(err) !== 'BROWSER_CRASH') return;
    // A `/proxy` switch tears the browser down BY DESIGN and immediately relaunches it on the new
    // route. Probes that were in flight die with "Target closed", which is indistinguishable from a
    // genuine crash at the error level — but restarting here would close the REPLACEMENT browser
    // (restart() is close() + relaunch) and kill every sibling probe with it, manufacturing the
    // next round of failures. Nothing is lost by skipping: `ensureBrowser` already relaunches on a
    // generation change, so the browser this would have restarted has been replaced anyway.
    if (!this.browser.isCurrentEgress(egressGeneration)) {
      this.logger.info('browser was replaced by an egress switch; not restarting after crash');
      return;
    }
    try {
      await this.browser.restart();
      this.logger.info('browser restarted after crash');
    } catch {
      // The scheduler records the original retryable failure and will retry later.
      this.logger.warn('browser restart failed');
    }
  }
}
