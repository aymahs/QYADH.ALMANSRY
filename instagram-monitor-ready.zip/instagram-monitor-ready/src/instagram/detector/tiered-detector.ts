/**
 * Two-tier {@link Detector}: fast HTTP probe for routine polling, real browser for anything
 * that must be trusted or photographed.
 *
 *   Tier 1 (HTTP)     ~0.3s,  1 request   -> routine "is it still GONE?" polling
 *   Tier 2 (Chromium) ~4-12s, 20-50 reqs  -> confirming a flip, and ALL screenshots
 *
 * The browser is ALWAYS used when:
 *   - a screenshot is requested (recovery proof, /check, /ping), or
 *   - the fast probe reports ACTIVE on a check that could CONFIRM a recovery — never notify on
 *     the cheap signal alone; the browser re-verifies and captures, or
 *   - the fast probe could not reach a trustworthy conclusion (transport failure / UNKNOWN).
 *
 * The one deliberate exception is {@link TieredProbeOptions.allowFastActive}: a confirmation
 * check that CANNOT be the deciding one may stand on the fast tier's own ACTIVE verdict. The
 * deciding check still goes to the browser, so no alert ever rests on fast-tier evidence alone —
 * it just costs one browser load per recovery instead of one per confirmation.
 *
 * A recovery is therefore still confirmed by, and screenshotted from, a real rendered page —
 * while routine polling gets ~30x cheaper and faster.
 *
 * The {@link CircuitBreaker} wraps both tiers: while it is OPEN nothing touches the network,
 * so a throttled IP is given room to recover instead of being hammered by the whole fleet.
 */

import type { AppConfig } from '../../config';
import type { Logger } from '../../logging';
import {
  SIGNALS_VERSION,
  type Detector,
  type DetectorErrorCode,
  type DetectorResult,
  type ProbeOptions,
  type ProbeResult,
} from '../../domain';
import {
  breakerOutcomeForCode,
  CircuitBreaker,
  type BreakerCheckpoint,
  type BreakerOutcome,
  type BreakerState,
} from '../circuit-breaker';
import { ESCALATION_STORM_STREAK } from '../load-governor';
import type { BrowserBudgetReport, BrowserLoadGovernor, LoadPriority } from '../load-governor';
import { ProxySessionHealer } from '../proxy-session';
import type { ProxySwitch } from '../proxy-switch';
import { httpProbe, dispatcherFor, type HttpProbeDeps } from './http-probe';

/**
 * The ONLY fast-probe outcomes from which "still banned" may be inferred: a page we genuinely
 * received that simply carried no profile metadata. Anything else (HTTP_5XX, redirects, consent
 * walls, transport errors) is a failed observation and must be escalated, never asserted as GONE.
 */
const INFERABLE_GONE_CODES: ReadonlySet<DetectorErrorCode | null> =
  new Set<DetectorErrorCode | null>(['UNRECOGNIZED_DOM', 'EMPTY_PAGE', null]);

/** How long a good canary result is trusted before it is re-checked. */
const CANARY_TTL_MS = 5 * 60 * 1000;
/**
 * A failed canary is retried this often.
 *
 * LOWERED FROM 60s, and the reason is a load bound rather than freshness. While the canary is red
 * EVERY fast negative escalates to a full Chromium page load, fleet-wide — the precise mechanism
 * that burned the first residential IP. The retry interval is therefore the length of the window
 * in which the fleet is stuck in the expensive posture after the route has already recovered, and
 * shortening it is nearly free: one cheap HTTP request per interval (4/min) against ~4,500
 * fast probes an hour that a 20-account fleet already sends. Quartering the window quarters the
 * cost of a transient red canary; the governor bounds what it can still spend.
 */
const CANARY_RETRY_MS = 15 * 1000;
/**
 * Consecutive checks that reached the fast tier and still had to be answered by the browser,
 * before /ping calls the tier degraded — and, now, before the governor stretches the fleet's
 * baseline cadence.
 *
 * The canary alone cannot see this: it only proves the CONTROL account resolves. If Instagram
 * starts serving monitored accounts something outside {@link INFERABLE_GONE_CODES} — a consent
 * interstitial, an explore redirect, an HTTP_5XX — every routine check escalates to a full
 * Chromium load while the (cached, mega-) control account keeps resolving, so the tier reports
 * healthy while answering nothing. At a 60s cadence a real storm crosses this in well under a
 * minute; a lone recovery escalation never gets near it.
 *
 * Shared with the governor so the /ping wording and the throttle both key off ONE number.
 */
const ESCALATION_STORM = ESCALATION_STORM_STREAK;

/** No egress route adopted yet — distinct from generation 0, which is a real route. */
const UNSET_GENERATION = -1;

/**
 * Tier-aware probe options. Deliberately NOT part of the shared {@link ProbeOptions} contract:
 * the domain has no concept of tiers, and a detector without a fast path (the Playwright one)
 * would have nothing to do with this. Extra keys are simply ignored by such detectors.
 */
export interface TieredProbeOptions extends ProbeOptions {
  /**
   * How this probe should be treated when the fleet-wide browser-load budget is under pressure.
   *
   * Omit and it defaults to {@link LoadPriority} `OWNER`, i.e. never deferred. That default is
   * deliberately the SAFE one: the high-volume callers (baseline polling, deletion-watch polling,
   * the re-capture sweep, bulk pre-checks) all live in this repository and label themselves, so a
   * caller that forgets can only ever cost budget — never a missed recovery.
   *
   * A `ROUTINE` probe that is refused comes back UNKNOWN with `errorCode: 'HTTP_429'`, exactly as
   * it does while the circuit breaker is open. It is never GONE and never ACTIVE: nothing was
   * observed, so nothing may be inferred.
   */
  loadPriority?: LoadPriority;
  /**
   * Let a fast-tier ACTIVE verdict STAND for this one check instead of escalating to a full
   * Chromium page load (20-50 requests, 4-12s) to re-verify it.
   *
   * ONLY safe on a check that cannot, by itself, confirm a recovery. A monitoring case needs
   * `CONFIRMATION_REQUIRED_COUNT` consecutive ACTIVE results, and before this option every one of
   * them bought its own browser load — three per recovery. The final one still does, so the
   * invariant that matters is untouched: NOBODY is ever told on fast-tier evidence alone.
   *
   * The caller owns this because only the caller knows where in the confirmation burst it is;
   * see `isDecidingConfirmation` in the monitor worker. Omit it and behaviour is exactly as
   * before — every identity match escalates.
   */
  allowFastActive?: boolean;
}

/** Did the caller mark this check as one whose ACTIVE verdict cannot confirm on its own? */
function allowsFastActive(options: ProbeOptions): boolean {
  return (options as TieredProbeOptions).allowFastActive === true;
}

/**
 * Budget priority for this probe. Unlabelled means OWNER — never deferred. See
 * {@link TieredProbeOptions.loadPriority} for why the permissive direction is the safe default.
 */
function priorityOf(options: ProbeOptions): LoadPriority {
  return (options as TieredProbeOptions).loadPriority ?? 'OWNER';
}

export interface TieredDetectorOptions {
  /** The real browser-backed detector (tier 2). */
  browserDetector: Detector;
  config: AppConfig;
  logger: Logger;
  breaker?: CircuitBreaker;
  /**
   * Fleet-wide budget on Chromium page loads. SHARED with every other detector in the process —
   * a per-detector budget would be no budget at all, since the two detectors together are exactly
   * how the ceiling gets exceeded. Omit for an ungoverned detector (tests only).
   */
  governor?: BrowserLoadGovernor;
  /** Runtime-switchable egress; when present the dispatcher follows it. */
  proxySwitch?: ProxySwitch;
  /**
   * When false the fast path is disabled entirely and every probe goes to the browser — but
   * still through the shared CircuitBreaker. Used by the deletion watcher, whose alert fires on
   * ACTIVE -> GONE and so must never rest on an INFERRED gone, yet must still back off with the
   * rest of the fleet when the egress route is throttled.
   */
  fastPath?: boolean;
  /**
   * Bounds on sticky-proxy-session rotation.
   *
   * SHARE ONE INSTANCE across detectors that share a {@link ProxySwitch} — the rate limit and the
   * give-up counter are fleet-wide properties of the route, and a per-detector healer would let
   * the deletion watcher rotate the session the monitor had just repaired. Omit and this detector
   * gets its own with the default bounds.
   */
  sessionHealer?: ProxySessionHealer;
  /** Injectable for tests. */
  httpProbeImpl?: typeof httpProbe;
  now?: () => number;
}

/**
 * Turn a "no profile metadata was served" fast result into GONE, preserving its evidence so
 * the recorded check still shows what was actually observed.
 */
function stillGone(fast: DetectorResult): DetectorResult {
  return {
    ...fast,
    classification: 'GONE',
    evidence: { ...fast.evidence, errorCode: null },
  };
}

/**
 * Which tier produced the FINAL answer for a probe.
 *
 * `deferred` is distinct from `blocked` on purpose: `blocked` means the circuit breaker refused
 * because the route looks THROTTLED, `deferred` means the governor refused because the fleet has
 * spent its hourly BROWSER-LOAD budget. Conflating them would hide the one the owner can act on.
 */
export type AnsweringTier = 'fast' | 'browser' | 'blocked' | 'deferred';

/**
 * Fast-tier health, as the detector itself sees it.
 *
 * This cannot be inferred from a `probe()` call: the tiered detector deliberately returns the
 * BROWSER's verdict whenever the fast tier fails, so a probe of a live control account looks
 * identical whether the fast tier answered it or silently fell over. /ping used to guess from the
 * classification and therefore reported "Fast probe: Working" with a completely dead fast tier.
 */
export type FastTierState = 'ok' | 'degraded' | 'disabled' | 'blocked';

export interface FastTierReport {
  state: FastTierState;
  /** Short, non-sensitive reason. Always populated, including on 'ok'. */
  detail: string;
  /** Is the egress route currently serving live profiles? (The canary verdict.) */
  canaryHealthy: boolean;
  breakerState: BreakerState;
  /** Milliseconds until the breaker admits traffic again; 0 unless OPEN. */
  breakerRetryAfterMs: number;
  /** Probes answered per tier since start — which tier is actually carrying the load. */
  answered: Readonly<Record<AnsweringTier, number>>;
  /**
   * Consecutive checks the fast tier could not conclude, so the browser had to. A run of these
   * is the only visible symptom of a tier that is up (green canary) but answering nothing.
   */
  consecutiveEscalations: number;
  /**
   * The fleet-wide Chromium page-load budget, or null when this detector is ungoverned. Free —
   * it is an in-memory count, so /ping pays nothing for it.
   */
  browserBudget: BrowserBudgetReport | null;
}

export interface FastTierReportOptions {
  /**
   * Ignore any cached canary verdict and MEASURE the route again.
   *
   * Off by default, and that default is the load bound: a red canary sends every fast negative
   * fleet-wide to a full Chromium load until it is retried, so a routine diagnostic must not be
   * able to manufacture that by being run repeatedly (see {@link CANARY_RETRY_MS}).
   *
   * `/proxy` turns it on for its CONFIRMING reading, and only there. `canaryOk` caches a failure
   * for {@link CANARY_RETRY_MS}, so a second report taken milliseconds later was answered from
   * that cache with no request at all — meaning one transient blip (a reset connection, a slow
   * exit, a single 429 on a freshly-rotated IP) both produced the "blind" verdict and then
   * "confirmed" itself, auto-reverting a perfectly healthy route the owner had just selected.
   * Costs one extra cheap HTTP GET on the rare path that is about to override the owner.
   */
  freshCanary?: boolean;
}

/**
 * The diagnostics surface the command handlers need. Only {@link TieredDetector} implements it,
 * so consumers feature-detect via {@link detectorDiagnostics} and degrade gracefully (the
 * Playwright detector alone has no fast tier to report on).
 */
export interface DetectorDiagnostics {
  /** Free — never touches the network. */
  breakerSnapshot(): { state: BreakerState; consecutive: number; retryAfterMs: number };
  /**
   * The fleet-wide Chromium page-load budget, or null when this detector is ungoverned. Free,
   * in-memory, and safe to call on every tick — the monitor worker reads it to size its baseline
   * interval, and the health monitor to tell the owner the fleet is self-throttling.
   *
   * OPTIONAL, and deliberately so. Making it mandatory would have folded it into the
   * feature-detect below, so any detector that did not implement it stopped being recognised as a
   * diagnostics source AT ALL — silently disabling the unrelated breaker checks that gate the
   * screenshot re-capture sweep and the bulk pre-check. A new capability must never be able to
   * switch off an old guard; call it as `diagnostics.browserBudget?.() ?? null`.
   */
  browserBudget?(): BrowserBudgetReport | null;
  /**
   * Copy the FLEET-WIDE back-off without disturbing it, and put it back.
   *
   * Exposed here rather than injected separately because the breaker this reaches is guaranteed to
   * be the one the detector's own `syncEgress` clears on a route change — a separately-wired
   * instance could silently be a different object, which is the whole class of bug this repairs.
   *
   * OPTIONAL for the same reason `browserBudget` is: folding a new capability into
   * {@link detectorDiagnostics}'s feature-detect would stop older implementations being recognised
   * as a diagnostics source at all, silently disabling the unrelated guards that depend on it.
   * Call as `diagnostics.captureBackOff?.()`.
   */
  captureBackOff?(): BreakerCheckpoint;
  /** Restore a {@link captureBackOff} after an egress change was undone. */
  restoreBackOff?(checkpoint: BreakerCheckpoint): void;
  /**
   * Costs at most ONE cheap HTTP request against the control account — never a browser page
   * load, and nothing at all while the breaker is open.
   */
  fastTierReport(options?: FastTierReportOptions): Promise<FastTierReport>;
}

export function detectorDiagnostics(detector: Detector): DetectorDiagnostics | null {
  const candidate = detector as Partial<DetectorDiagnostics>;
  return typeof candidate.fastTierReport === 'function' &&
    typeof candidate.breakerSnapshot === 'function'
    ? (candidate as DetectorDiagnostics)
    : null;
}

/**
 * The result of a check that never touched the network — the breaker refused it, or the governor
 * deferred it.
 *
 * UNKNOWN with a throttle code, NEVER GONE and never ACTIVE. Nothing was observed, so nothing may
 * be inferred: the state machine treats it as an inconclusive check and reschedules, which is the
 * difference between "deferred" and "dropped".
 */
function notObservedResult(): DetectorResult {
  // NOTE: callers pair this with `notObserved: true` on the ProbeResult. The flag — not this
  // error code — is what tells health accounting the check never happened; HTTP_429 here is
  // shape-identical to a real Instagram rate-limit and cannot carry that meaning on its own.
  return {
    classification: 'UNKNOWN',
    evidence: {
      signalsVersion: SIGNALS_VERSION,
      activeSignals: [],
      goneSignals: [],
      identitySignalMatched: false,
      finalUrl: null,
      responseStatus: null,
      errorCode: 'HTTP_429',
    },
    durationMs: 0,
  };
}

export class TieredDetector implements Detector {
  private readonly browserDetector: Detector;
  private readonly config: AppConfig;
  private readonly logger: Logger;
  private readonly breaker: CircuitBreaker;
  private readonly governor: BrowserLoadGovernor | null;
  private readonly httpProbeImpl: typeof httpProbe;
  private readonly proxySwitch: ProxySwitch | null;
  private readonly sessionHealer: ProxySessionHealer;
  private readonly now: () => number;
  private readonly fastPath: boolean;
  private dispatcherCache: HttpProbeDeps['dispatcher'];
  private dispatcherGeneration = UNSET_GENERATION;
  /** False when the configured proxy could not be turned into a dispatcher — fail closed. */
  private dispatcherOk = true;

  /**
   * Canary state: is the egress link currently serving live profiles?
   *
   * Deliberately NOT persisted across restarts, unlike the circuit breaker. Both stored answers
   * are worse than measuring again: a stored `true` would authorise "still gone" inferences on a
   * route this process has never checked — re-arming the exact blindness the canary exists to
   * prevent, which loses recoveries — while a stored `false` would send EVERY routine check to a
   * full Chromium load (20-50 requests instead of 1) from the very first probe, with no cheap
   * measurement in the way to correct it: a stampede at the moment load must fall.
   *
   * Starting unmeasured costs exactly ONE cheap HTTP request (concurrent callers share the
   * in-flight probe), and it describes the route this process is actually on. That measurement
   * IS the conservative startup posture.
   */
  private canaryHealthy = false;
  private canaryCheckedAt = 0;
  private canaryInFlight: Promise<boolean> | null = null;
  /** Why the last canary measurement failed, for {@link fastTierReport}. */
  private canaryLastDetail: string | null = null;
  /** Which tier answered, counted since start. Reported by /ping. */
  private readonly answered: Record<AnsweringTier, number> = {
    fast: 0,
    browser: 0,
    blocked: 0,
    deferred: 0,
  };
  /**
   * Consecutive checks that reached the fast tier and were still handed to the browser. Reset by
   * every fast-tier conclusion (including an identity match, which IS the tier working). A green
   * canary plus a long run here is the "up but answering nothing" failure /ping must not miss.
   */
  private consecutiveEscalations = 0;

  constructor(options: TieredDetectorOptions) {
    this.browserDetector = options.browserDetector;
    this.config = options.config;
    this.logger = options.logger;
    this.breaker = options.breaker ?? new CircuitBreaker();
    this.governor = options.governor ?? null;
    this.httpProbeImpl = options.httpProbeImpl ?? httpProbe;
    this.proxySwitch = options.proxySwitch ?? null;
    this.sessionHealer = options.sessionHealer ?? new ProxySessionHealer();
    this.now = options.now ?? Date.now;
    this.fastPath = options.fastPath ?? true;
  }

  /** Exposed so /ping and logging can report breaker state. */
  breakerSnapshot(): ReturnType<CircuitBreaker['snapshot']> {
    return this.breaker.snapshot();
  }

  /** See {@link DetectorDiagnostics.captureBackOff}. Free — reads four fields. */
  captureBackOff(): BreakerCheckpoint {
    return this.breaker.checkpoint();
  }

  /**
   * See {@link DetectorDiagnostics.restoreBackOff}.
   *
   * Binds the restored back-off to the generation in force AT THIS MOMENT, so the caller must
   * have already put the route back. That is what stops the next `syncEgress` — in this detector
   * or the deletion watcher's, which share the breaker — from treating the restored block as a
   * stale one and clearing it again.
   */
  restoreBackOff(checkpoint: BreakerCheckpoint): void {
    this.breaker.restore(checkpoint, this.proxySwitch?.gen() ?? 0);
  }

  /**
   * The fleet-wide Chromium page-load budget. Free (in-memory counters), so the monitor worker
   * can read it on every tick to size its baseline interval.
   */
  browserBudget(): BrowserBudgetReport | null {
    return this.governor?.report() ?? null;
  }

  /**
   * Adopt a new egress route if one was selected. MUST run before the circuit-breaker gate:
   * the breaker reset used to live inside dispatcher(), which is only reachable AFTER that gate,
   * so a `/proxy` switch made to escape a throttled IP could not clear the block it was meant to
   * escape — every probe kept short-circuiting on the new, healthy route.
   *
   * Returns false when a proxy is configured but its dispatcher cannot be built: the fast tier
   * then fails closed rather than silently exiting over this machine's own IP.
   */
  private syncEgress(): boolean {
    const gen = this.proxySwitch?.gen() ?? 0;
    // The breaker is process-wide and SHARED with the other detector, so it owns the question of
    // whether its back-off still describes the route in use; this detector only reports what
    // route it is now on. Deciding that here, from a per-detector counter, meant the lagging
    // detector wiped a block the fleet had re-earned on the new route (see adoptRoute).
    this.breaker.adoptRoute(gen);
    if (this.dispatcherGeneration === gen) return this.dispatcherOk;

    const wanted =
      this.proxySwitch !== null ? this.proxySwitch.current() : this.config.browserProxy;
    try {
      this.dispatcherCache = dispatcherFor(wanted);
      this.dispatcherOk = true;
    } catch (err) {
      this.dispatcherCache = undefined;
      this.dispatcherOk = false;
      this.logger.error(
        'proxy dispatcher could not be built; fast tier disabled (failing closed)',
        {
          error: err instanceof Error ? err.message : String(err),
        },
      );
    }
    this.dispatcherGeneration = gen;
    // Whatever this detector learned about the previous route no longer applies: its canary
    // verdict was measured somewhere else. (The BREAKER's equivalent invalidation is adoptRoute's
    // above — deliberately not repeated per detector.)
    this.canaryCheckedAt = 0;
    this.canaryHealthy = false;
    return this.dispatcherOk;
  }

  /** Pooled dispatcher for the current route. Keeps connections alive between probes. */
  private dispatcher(): HttpProbeDeps['dispatcher'] {
    return this.dispatcherCache;
  }

  /**
   * THE CANARY. "No profile metadata" means *still banned* — but ONLY if this egress route is
   * actually being served live profiles. On a login-walled or flaky link EVERY account looks
   * metadata-less, so that inference would silently manufacture GONE for accounts that had in
   * fact recovered: a bot that looks perfectly healthy while missing every recovery.
   *
   * So before trusting a negative, confirm a known-live control account still resolves through
   * the fast path. Cached briefly; concurrent callers share one in-flight check.
   */
  private async canaryOk(): Promise<boolean> {
    const now = this.now();
    const ttl = this.canaryHealthy ? CANARY_TTL_MS : CANARY_RETRY_MS;
    if (this.canaryCheckedAt !== 0 && now - this.canaryCheckedAt < ttl) return this.canaryHealthy;
    if (this.canaryInFlight !== null) return this.canaryInFlight;

    // Pin the egress generation this measurement belongs to. If /proxy switches routes while
    // the probe is in flight, the result describes the OLD route and must NOT be cached for
    // the new, untested one — that would re-arm the exact blindness the canary prevents.
    const startedGen = this.proxySwitch?.gen() ?? 0;

    this.canaryInFlight = (async (): Promise<boolean> => {
      try {
        const probe = await this.httpProbeImpl(
          this.config.controlUsername,
          { config: this.config, dispatcher: this.dispatcher() },
          Math.min(this.config.scheduling.checkTimeoutMs, 20000),
        );
        const ok = probe.result.evidence.identitySignalMatched;
        if ((this.proxySwitch?.gen() ?? 0) !== startedGen) {
          this.logger.info('canary: egress changed mid-probe; discarding stale result');
          this.canaryLastDetail = 'egress route changed mid-measurement';
          return false; // force a fresh measurement on the new route
        }
        this.canaryLastDetail = ok
          ? null
          : (probe.result.evidence.errorCode ?? 'no profile metadata');
        if (ok !== this.canaryHealthy) {
          this.logger.info(ok ? 'canary: egress healthy' : 'canary: egress NOT serving profiles', {
            control: this.config.controlUsername,
            errorCode: probe.result.evidence.errorCode,
          });
        }
        this.canaryHealthy = ok;
        this.canaryCheckedAt = this.now();
        return ok;
      } catch {
        if ((this.proxySwitch?.gen() ?? 0) === startedGen) {
          this.canaryHealthy = false;
          this.canaryCheckedAt = this.now();
          this.canaryLastDetail = 'transport failure reaching the control account';
        }
        return false;
      } finally {
        this.canaryInFlight = null;
      }
    })();
    return this.canaryInFlight;
  }

  /** Diagnostics for /ping. */
  canarySnapshot(): { healthy: boolean; checkedAt: number } {
    return { healthy: this.canaryHealthy, checkedAt: this.canaryCheckedAt };
  }

  /**
   * Ask the fast tier about ITSELF, rather than inferring its health from a probe's
   * classification. `probe()` falls back to the browser on every fast-tier failure, so its
   * verdict says nothing about whether the fast tier worked — which is why /ping reported a dead
   * fast tier as "Working".
   *
   * Costs at most one cheap HTTP request (the canary), never a browser page load, and nothing at
   * all while the breaker is open — the breaker exists precisely so a throttled route is left
   * alone. A canary verdict older than the retry window is re-measured rather than reported: a
   * health check that answers with a five-minute-old measurement is not a health check.
   *
   * The verdict rests on TWO signals, not just the canary. See {@link ESCALATION_STORM}.
   */
  async fastTierReport(options: FastTierReportOptions = {}): Promise<FastTierReport> {
    const egressOk = this.syncEgress();
    const breaker = this.breaker.snapshot();
    const base = {
      canaryHealthy: this.canaryHealthy,
      breakerState: breaker.state,
      breakerRetryAfterMs: breaker.retryAfterMs,
      answered: { ...this.answered },
      consecutiveEscalations: this.consecutiveEscalations,
      browserBudget: this.browserBudget(),
    };

    if (!this.fastPath) {
      // `canaryHealthy` is meaningless here — nothing ever measures it in browser-only mode — so
      // the /ping formatter suppresses the canary line for this state rather than printing a
      // never-measured "NOT serving live profiles" next to a healthy verdict.
      return { ...base, state: 'disabled', detail: 'browser-only mode (fast path off)' };
    }
    if (!egressOk) {
      return {
        ...base,
        state: 'degraded',
        detail: 'the configured proxy could not be turned into a dispatcher',
      };
    }
    if (breaker.state !== 'CLOSED') {
      return {
        ...base,
        state: 'blocked',
        detail:
          breaker.state === 'HALF_OPEN'
            ? 'fleet-wide back-off is being lifted (circuit breaker HALF_OPEN — one trial probe in flight)'
            : 'fleet-wide back-off engaged (circuit breaker OPEN)',
      };
    }

    // Re-measure rather than reporting an old verdict — but only once per retry window. Every
    // forced measurement is a fresh chance to catch a transient failure, and a failed canary
    // costs the WHOLE fleet a browser load per check until it is retried; a diagnostic must not
    // be able to manufacture that by being run repeatedly. A verdict younger than the retry
    // window is by definition as fresh as production's own view.
    //
    // `freshCanary` is the ONE caller allowed past that bound: a reading taken specifically to
    // second-guess a failure recorded moments ago would otherwise be answered by the very cache
    // that failure just wrote, confirming itself without measuring anything. See
    // {@link FastTierReportOptions.freshCanary}.
    if (options.freshCanary === true || this.now() - this.canaryCheckedAt >= CANARY_RETRY_MS) {
      this.canaryCheckedAt = 0;
    }
    const ok = await this.canaryOk();
    if (!ok) {
      return {
        ...base,
        canaryHealthy: false,
        state: 'degraded',
        detail: `the control account did not resolve over the current egress route (${
          this.canaryLastDetail ?? 'no profile metadata'
        })`,
      };
    }
    // A green canary is NOT enough. It only proves the (heavily cached) control account resolves;
    // if every monitored account is escalating anyway the tier answers nothing while looking
    // perfectly healthy, and each routine check silently becomes a full browser load.
    if (this.consecutiveEscalations >= ESCALATION_STORM) {
      return {
        ...base,
        canaryHealthy: true,
        state: 'degraded',
        detail: `the control account resolves, but the last ${this.consecutiveEscalations} monitored checks all had to be answered by the browser`,
      };
    }
    return {
      ...base,
      canaryHealthy: true,
      state: 'ok',
      detail: 'the control account resolves over the current egress route',
    };
  }

  async probe(username: string, options: ProbeOptions = {}): Promise<ProbeResult> {
    // Adopt any pending egress switch FIRST. This must precede the breaker gate, otherwise a
    // /proxy issued to escape a throttled IP could never clear the breaker that is blocking it.
    const egressOk = this.syncEgress();
    // The route this probe LEAVES OVER. Every breaker outcome below is stamped with it, so a
    // result that lands after a `/proxy` switch cannot move the back-off of the route it was
    // never observed on. `syncEgress` has just called `adoptRoute(gen)`, so this is by
    // construction the generation the breaker is bound to at admission time.
    const startGen = this.proxySwitch?.gen() ?? 0;

    // Fleet-wide back-off: while OPEN, do not touch the network at all.
    if (!this.breaker.allowRequest()) {
      const retryAfterMs = this.breaker.retryAfterMs();
      this.logger.warn('circuit breaker OPEN; skipping probe', {
        username,
        retryAfterSeconds: Math.round(retryAfterMs / 1000),
      });
      this.answered.blocked += 1;
      return { result: notObservedResult(), screenshot: null, notObserved: true };
    }

    try {
      return await this.probeAdmitted(username, options, startGen, egressOk);
    } catch (err) {
      // An ADMITTED probe that never reports back holds the HALF_OPEN trial slot until its TTL
      // expires — two minutes in which the breaker admits nobody else and the fleet is dark.
      // Nothing was observed, so nothing may be inferred: give the slot back, move nothing.
      this.breaker.record('INCONCLUSIVE', startGen);
      throw err;
    }
  }

  /** The probe proper, once the fleet-wide brake has admitted it. */
  private async probeAdmitted(
    username: string,
    options: ProbeOptions,
    startGen: number,
    egressOk: boolean,
  ): Promise<ProbeResult> {
    // A screenshot request always goes straight to the browser — the cheap probe cannot capture.
    // The browser is also the only safe tier when the proxy dispatcher could not be built, since
    // the fast path would otherwise exit over the wrong network entirely.
    if (options.captureScreenshot === true || !egressOk || !this.fastPath) {
      return this.viaBrowser(username, options, priorityOf(options), startGen);
    }

    const fastTimeoutMs = Math.min(this.config.scheduling.checkTimeoutMs, 20000);
    let fast = await this.httpProbeImpl(
      username,
      { config: this.config, dispatcher: this.dispatcher() },
      fastTimeoutMs,
    );

    // THE EGRESS ROUTE THIS PROBE IS ACTUALLY ON. Starts as the admitted generation and moves only
    // if a session rotation below re-routes us — every breaker record after this point is stamped
    // with it, so a rotation can never attribute an observation to the dead session it replaced.
    let generation = startGen;

    // A dead sticky proxy session: the gateway refused to tunnel, so Instagram never saw the
    // request. Rotate to a fresh session and retry ONCE — cheap (one more plain GET, never a
    // Chromium load) and bounded by the healer, which rate-limits the burst that a fleet-wide
    // session expiry produces and gives up entirely if rotation stops helping.
    //
    // Deliberately BEFORE the `transportFailed` escalation below. Escalating first would send the
    // check to a full browser load that goes out over the very same dead tunnel and fails
    // identically — paying 20-50 requests to learn nothing, for every account, until the owner
    // intervened by hand.
    if (fast.result.evidence.errorCode === 'PROXY_TUNNEL' && this.healProxySession(username)) {
      this.syncEgress();
      generation = this.proxySwitch?.gen() ?? 0;
      fast = await this.httpProbeImpl(
        username,
        { config: this.config, dispatcher: this.dispatcher() },
        fastTimeoutMs,
      );
    }

    // Reaching Instagram at all — whatever it said — is what proves the session is alive again, and
    // clears the healer's give-up counter so a future expiry is healed rather than refused.
    if (!fast.transportFailed) this.sessionHealer.noteHealthy();

    const code = fast.result.evidence.errorCode;

    // IMPORTANT: record EXACTLY ONE breaker outcome per check — whichever tier produces the
    // final answer. Recording the fast leg here unconditionally would zero the streak right
    // before the browser reports a throttle, so the counter would oscillate 0 -> 1 -> 0 and the
    // breaker could never reach its threshold. Worse, during throttling every check escalates
    // to a full browser load, so request volume would RISE exactly when back-off is needed.

    // Transport failure tells us nothing about the account — let the browser decide and record.
    if (fast.transportFailed) return this.escalate(username, options, generation);

    // Being throttled: this IS the final answer, so record it. The browser would only add load
    // for the same verdict.
    if (breakerOutcomeForCode(code) === 'THROTTLED') {
      this.recordOutcome('THROTTLED', generation, { username, tier: 'fast', errorCode: code });
      this.answered.fast += 1;
      this.setEscalationStreak(0);
      return { result: fast.result, screenshot: null };
    }

    // IDENTITY is the discriminator, not the classification. Instagram renders the
    // "Sorry, this page isn't available" copy CLIENT-SIDE, so a banned account's raw HTML
    // carries no unavailable message — but it also carries no profile metadata. A live
    // account's raw HTML does carry og:url/og:title/canonical for the username.
    // Measured 8/8 against the browser detector over live and banned accounts.
    if (fast.result.evidence.identitySignalMatched) {
      // NOTE: the escalation streak is deliberately NOT zeroed here for the whole branch any more.
      // Identity matching is only the fast tier WORKING when the tier also reached a verdict; an
      // identity match that still has to be handed to the browser IS an escalation, and zeroing the
      // streak on it pinned the storm signal at 0 on exactly the path that generates the most
      // browser load. See the CONTRADICTORY case at the bottom of this branch.

      // A non-deciding confirmation check may stand on the cheap verdict. Two conditions, both
      // required:
      //
      //  1. the CALLER declared this check unable to confirm on its own (see
      //     {@link TieredProbeOptions.allowFastActive}), so a browser verdict still gates the
      //     alert — it is simply spent on the check that actually decides; and
      //  2. the fast tier itself classified ACTIVE. Identity alone is NOT enough: Instagram's
      //     "Something went wrong" interstitial carries the profile's og metadata, so identity
      //     matches there too, and `classify()` correctly calls it UNKNOWN/ERROR_PAGE. Trusting
      //     identity rather than the verdict would turn a throttle page into a confirmation
      //     step. That page escalates, exactly as before.
      //
      // The verdict itself is produced by the SAME `classify()` pipeline the browser uses, over
      // server-rendered markup — the two were measured 8/8 in agreement on live and banned
      // accounts — so this trades a re-read of the same evidence, not the evidence itself.
      if (allowsFastActive(options) && fast.result.classification === 'ACTIVE') {
        this.setEscalationStreak(0);
        this.recordOutcome('SERVED', generation, { username, tier: 'fast', errorCode: code });
        this.answered.fast += 1;
        this.logger.info(
          'fast probe matched profile identity; non-deciding check, not escalating',
          {
            username,
            fastMs: fast.result.durationMs,
          },
        );
        return { result: fast.result, screenshot: null };
      }

      // A POSSIBLE recovery on the check that could confirm it — never act on the cheap signal
      // alone. The browser re-verifies and is what captures the screenshot.
      //
      // PRIORITY IS FORCED HERE, not taken from the caller. This is the one browser load that a
      // starved budget must never be allowed to eat: the fast tier has just seen the profile's
      // own identity metadata come back AND classified it ACTIVE, which is the leading edge of a
      // recovery, and the whole product is the promise that this check happens. Deriving it from
      // the evidence rather than trusting a caller's label means no future caller can forget to
      // say so and silently lose a recovery to routine polling that spent the budget first.
      //
      // THE ACTIVE VERDICT IS PART OF THE CONDITION, and that is the fix. The upgrade used to fire
      // on identity ALONE, so it also fired on every page carrying the profile's og metadata
      // *and* the unavailable copy — classify() calls that UNKNOWN/'CONTRADICTORY', which is not a
      // throttle code, so it is not caught by the early return above. Every routine check of such
      // an account became a forced-CONFIRMATION load that admit() refuses to bound, permanently
      // and invisibly: ~107 Chromium loads/hour from ONE account, with the storm signal pinned at
      // zero so /ping reported the fast tier healthy. A page we could not read is a FAILED
      // OBSERVATION, never evidence of a recovery, and it belongs on the governed path below.
      if (fast.result.classification === 'ACTIVE') {
        this.setEscalationStreak(0);
        this.logger.info('fast probe matched profile identity; escalating to browser', {
          username,
          fastMs: fast.result.durationMs,
        });
        return this.viaBrowser(username, options, 'CONFIRMATION', generation);
      }

      // Identity matched but the tier could NOT conclude (CONTRADICTORY, and anything else that
      // classify() refuses to call ACTIVE while identity is present). The fast tier did not answer
      // this check, so it counts towards the escalation streak — which is what drives the
      // governor's cadence back-off — and it keeps the CALLER's priority, so the governor can
      // actually bound it.
      this.logger.info('fast probe matched identity but could not conclude; escalating', {
        username,
        errorCode: code,
      });
      return this.escalate(username, options, generation);
    }

    // Only a page we actually SAW, that simply carried no profile metadata, may be read as
    // "still banned". A server error, an unexpected redirect or a consent interstitial is a
    // failed observation, not evidence about the account — those escalate instead.
    if (!INFERABLE_GONE_CODES.has(code)) return this.escalate(username, options, generation);

    // A truncated read may simply not have reached the evidence. Absence of signals in a partial
    // page is NOT evidence of absence, so never infer "still banned" from one.
    if (fast.bodyTruncated && code === 'EMPTY_PAGE') {
      return this.escalate(username, options, generation);
    }

    // No identity, no throttling. Before reading that as "still gone", confirm this egress
    // route is actually serving live profiles — otherwise the absence of metadata says nothing
    // about the account, and trusting it would silently mask a recovery.
    const canaryOk = await this.canaryOk();

    // The canary may have been measured on a DIFFERENT route if /proxy landed mid-check. A
    // negative measured on route A must never be validated by a canary from route B.
    if ((this.proxySwitch?.gen() ?? 0) !== generation) {
      this.logger.info('egress changed mid-check; escalating rather than inferring', { username });
      return this.escalate(username, options, generation);
    }

    if (canaryOk) {
      this.recordOutcome('SERVED', generation, { username, tier: 'fast', errorCode: code });
      this.answered.fast += 1;
      this.setEscalationStreak(0);
      return { result: stillGone(fast.result), screenshot: null };
    }
    // THE RED-CANARY COST BOUND.
    //
    // We must NOT read this negative as "still gone" — on a login-walled route every account
    // looks metadata-less, and trusting that would manufacture GONE for accounts that had in fact
    // recovered (harm rank 1, silently). So it escalates, exactly as before.
    //
    // What has changed is the PRICE. A red canary used to authorise an unbounded browser load:
    // every fast negative, fleet-wide, forever, retried only once a minute — ~4,500 Chromium page
    // loads an hour on a 20-account fleet, which is how the first residential IP was burned. It is
    // bounded three ways now, none of which weakens the inference above:
    //   1. the escalation is ROUTINE, so the governor's hourly ceiling caps how many of them the
    //      fleet may buy — beyond that the check is DEFERRED (inconclusive, retried), never
    //      asserted as GONE;
    //   2. {@link CANARY_RETRY_MS} is 15s rather than 60s, so the expensive posture ends four
    //      times sooner once the route recovers, at a cost of one cheap request per retry; and
    //   3. the escalation streak this feeds drives the governor's cadence back-off, so the fleet
    //      stops asking as often while the canary is red.
    // A recovery is still never missed: an identity match escalates as CONFIRMATION above, which
    // the governor never defers.
    this.logger.warn('canary unhealthy; not trusting the fast negative, escalating to browser', {
      username,
    });
    return this.escalate(username, options, generation);
  }

  /**
   * Rotate an expired sticky proxy session, returning true when the caller may retry ONCE.
   *
   * Every bound lives in {@link ProxySessionHealer}; this method's own job is to refuse the cases
   * where rotation is meaningless (no proxy, no session token, home route) and to make the event
   * VISIBLE. Silence is what turned the original failure into an all-night outage: the fleet was
   * failing every probe for a reason the provider considers routine, and nothing in the log said
   * so.
   *
   * `describe()` yields host:port only — the username carries the session token and must never
   * reach a log line.
   */
  private healProxySession(username: string): boolean {
    const proxySwitch = this.proxySwitch;
    if (proxySwitch === null || !proxySwitch.canRotateSession()) return false;

    const outcome = this.sessionHealer.attempt(() => proxySwitch.rotateSession());
    if (outcome === 'rotated') {
      this.logger.warn(
        'proxy tunnel refused (sticky session expired); rotated to a fresh session',
        {
          username,
          route: proxySwitch.describe(),
        },
      );
      // The previous session's canary verdict described a different exit IP entirely.
      this.canaryHealthy = false;
      this.canaryCheckedAt = 0;
      return true;
    }
    if (outcome === 'exhausted') {
      this.logger.error(
        'proxy tunnel still refused after repeated session rotations; the egress route needs attention',
        { username, route: proxySwitch.describe() },
      );
    }
    return false;
  }

  /**
   * Move the fleet-wide back-off, and — for the one outcome that can OPEN it — say so in the log.
   *
   * The silence here is what made the 2026-08-01 outage undiagnosable. `record(true)` had no log
   * statement of any kind on either tier, so the only trace a throttle trip left in 900 lines of
   * production log was its own aftermath: probes short-circuiting at 0.0s. Searching for
   * `LOGIN_WALL` / `HTTP_429` / `HTTP_403` / `ERROR_PAGE` / `CHALLENGE` found nothing and appeared
   * to prove the breaker had opened without evidence — when in fact the evidence was simply never
   * written down. A brake that can stop the whole fleet must record why.
   */
  private recordOutcome(
    outcome: BreakerOutcome,
    generation: number,
    context: { username: string; tier: AnsweringTier; errorCode: DetectorErrorCode | null },
  ): void {
    if (outcome !== 'THROTTLED') {
      this.breaker.record(outcome, generation);
      return;
    }
    const before = this.breaker.snapshot().state;
    const applied = this.breaker.record('THROTTLED', generation);
    if (!applied) {
      // The egress route moved while this probe was in flight, so it describes a route the fleet
      // is no longer on. Logged because a burst of these is what a `/proxy` switch looks like from
      // in here, and it must be visible that they were DISCARDED rather than counted.
      this.logger.info('throttle signal observed on a superseded egress route; discarded', {
        ...context,
        observedOnGeneration: generation,
      });
      return;
    }
    const after = this.breaker.snapshot();
    this.logger.warn('throttle evidence recorded against the fleet-wide breaker', {
      ...context,
      consecutive: after.consecutive,
      breakerState: after.state,
    });
    if (before === 'CLOSED' && after.state !== 'CLOSED') {
      this.logger.error('fleet-wide circuit breaker OPENED; all probes will short-circuit', {
        ...context,
        retryAfterSeconds: Math.round(after.retryAfterMs / 1000),
      });
    }
  }

  /**
   * The fast tier ran and could not conclude, so the browser answers. Counted separately from
   * {@link viaBrowser} — which also serves screenshot requests and browser-only mode — because
   * only a run of THESE means the cheap tier has stopped carrying traffic.
   *
   * Every path that reaches here has NO evidence of a recovery (a transport failure, a page we
   * could not read, or a negative we do not trust), so it keeps the caller's priority — which for
   * baseline polling is ROUTINE, and therefore governed. The one escalation that IS evidence of a
   * recovery bypasses this and goes straight to {@link viaBrowser} as CONFIRMATION.
   */
  private escalate(
    username: string,
    options: ProbeOptions,
    generation: number,
  ): Promise<ProbeResult> {
    this.setEscalationStreak(this.consecutiveEscalations + 1);
    return this.viaBrowser(username, options, priorityOf(options), generation);
  }

  /**
   * Keep the streak and the governor's view of it in step.
   *
   * The governor turns this into cadence back-off, which is what finally makes an escalation storm
   * VISIBLE to a brake: the escalated browser probes SUCCEED, so they report success to the
   * circuit breaker and it never opens while load is 20-50x normal.
   */
  private setEscalationStreak(value: number): void {
    this.consecutiveEscalations = value;
    this.governor?.reportEscalationStreak(value);
  }

  /**
   * Perform ONE Chromium page load — the only place in the process that does — after asking the
   * fleet-wide governor for permission.
   *
   * A refusal is a DEFERRAL, never a drop: the caller gets UNKNOWN, the state machine reschedules,
   * and the case is checked again. Nothing about the account is inferred, and the back-off does not
   * move, because nothing was observed — but the HALF_OPEN admission this probe consumed IS given
   * back, or a deferred check would hold the fleet's only trial slot for its full TTL.
   */
  private async viaBrowser(
    username: string,
    options: ProbeOptions,
    priority: LoadPriority,
    generation: number,
  ): Promise<ProbeResult> {
    if (this.governor !== null && !this.governor.admit(priority)) {
      this.answered.deferred += 1;
      this.logger.info('browser-load budget spent; deferring this routine check', {
        username,
        priority,
      });
      this.recordOutcome('INCONCLUSIVE', generation, {
        username,
        tier: 'deferred',
        errorCode: null,
      });
      return { result: notObservedResult(), screenshot: null, notObserved: true };
    }

    let out = await this.browserDetector.probe(username, options);
    this.answered.browser += 1;

    // The route this load actually went out over. A session rotation below moves it, and every
    // breaker record must follow — a verdict stamped with the dead session's generation is silently
    // DISCARDED by the breaker, so the fleet would learn nothing from the retry.
    let routeGeneration = generation;

    // The tunnel was refused, so Chromium never reached Instagram. This is the only tier the
    // deletion watcher and every screenshot request have (`fastPath: false` never runs the cheap
    // probe), so without healing here an expired session leaves exactly those paths dark — and the
    // deletion watcher's alert fires on ACTIVE -> GONE, which is the one that must never be missed.
    if (out.result.evidence.errorCode === 'PROXY_TUNNEL' && this.healProxySession(username)) {
      if (this.governor !== null && !this.governor.admit(priority)) {
        this.answered.deferred += 1;
        this.logger.info('browser-load budget spent before post-rotation retry; deferring', {
          username,
          priority,
        });
        this.recordOutcome('INCONCLUSIVE', routeGeneration, {
          username,
          tier: 'deferred',
          errorCode: 'PROXY_TUNNEL',
        });
        return out;
      }
      this.syncEgress();
      routeGeneration = this.proxySwitch?.gen() ?? 0;
      this.logger.warn('retrying browser probe over the rotated proxy session', { username });
      out = await this.browserDetector.probe(username, options);
      this.answered.browser += 1;
    }
    // The first load proved only that the optional owner-created cookie jar is challenged. The
    // browser detector has retired every context carrying it, so retry exactly once logged-out.
    // This is a second physical Chromium load and therefore receives a second governor admission;
    // hiding it inside one admission would make the hourly ceiling fictional.
    if (out.storageStateQuarantined === true) {
      if (this.governor !== null && !this.governor.admit(priority)) {
        this.answered.deferred += 1;
        this.logger.info('browser-load budget spent before clean-session retry; deferring', {
          username,
          priority,
        });
        this.recordOutcome('INCONCLUSIVE', routeGeneration, {
          username,
          tier: 'deferred',
          errorCode: 'AUTH_SESSION_CHALLENGE',
        });
        return out;
      }
      this.logger.warn('retrying browser probe without the rejected Instagram storage state', {
        username,
      });
      out = await this.browserDetector.probe(username, options);
      this.answered.browser += 1;
    }
    const errorCode = out.result.evidence.errorCode;
    // THREE answers, not two. `isThrottleSignal(code)` was used directly here, so every failed
    // OBSERVATION — NAVIGATION, TIMEOUT, BROWSER_CRASH, DNS — arrived at the breaker as `false`,
    // the positive claim "the IP is serving us again". That both zeroed genuine throttle streaks
    // and force-CLOSED a HALF_OPEN breaker on a crashed probe, releasing the fleet onto an IP that
    // was still being throttled. A browser torn down by a `/proxy` switch produces exactly those
    // codes, for every probe in flight, which is why a route change was self-defeating.
    const outcome = breakerOutcomeForCode(errorCode);
    // The tunnel carried this load, whatever Instagram then said — so the session is alive and the
    // healer's give-up counter may be cleared. Anything still PROXY_TUNNEL here means rotation did
    // not fix it, and that run must be allowed to reach the give-up bound.
    if (errorCode !== 'PROXY_TUNNEL') this.sessionHealer.noteHealthy();
    this.recordOutcome(outcome, routeGeneration, { username, tier: 'browser', errorCode });
    // Direct evidence that the route is throttled beats a cached "healthy" verdict. Without
    // this, a canary that passed moments earlier keeps authorising "still gone" inferences for
    // the rest of its TTL even as the browser watches the same route being walled.
    if (outcome === 'THROTTLED' && this.canaryHealthy) {
      this.logger.info('browser observed throttling; invalidating canary');
      this.canaryHealthy = false;
      this.canaryCheckedAt = 0;
    }
    return out;
  }
}
