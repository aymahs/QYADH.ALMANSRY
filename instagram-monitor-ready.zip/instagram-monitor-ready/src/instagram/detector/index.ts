/** Barrel for the Instagram detector: pure signals/classification + the live detector. */

export { extractSnapshot, usernameFromUrl, handleFromText, firstPathSegment } from './signals';
export type { SnapshotMeta } from './signals';
export { classify, classifyHtml } from './classify';
export { PlaywrightDetector } from './playwright-detector';
export type { PlaywrightDetectorOptions } from './playwright-detector';
export { httpProbe, proxyDispatcher, dispatcherFor } from './http-probe';
export type { HttpProbeDeps, HttpProbeOutcome } from './http-probe';
export { TieredDetector, detectorDiagnostics } from './tiered-detector';
export type {
  TieredDetectorOptions,
  AnsweringTier,
  DetectorDiagnostics,
  FastTierReport,
  FastTierState,
} from './tiered-detector';
