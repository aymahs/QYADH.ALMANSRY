/**
 * Pure classification: {@link PageSnapshot} -> {@link DetectorResult}.
 *
 * The ONLY place a page becomes ACTIVE / GONE / UNKNOWN. Both `/ping` and the monitor
 * go through here, so detection logic is never duplicated. `durationMs` is set to 0 —
 * the caller (which owns the clock) overwrites it after measuring the real probe time.
 */

import {
  ACTIVE_SIGNALS,
  GONE_SIGNALS,
  SIGNALS_VERSION,
  type Classification,
  type DetectorErrorCode,
  type DetectorResult,
  type PageSnapshot,
} from '../../domain';
import { extractSnapshot, handleFromText, usernameFromUrl, type SnapshotMeta } from './signals';

/**
 * Authoritative failures that mean we did NOT get a trustworthy page at all, and so override
 * even a matching identity: transport/browser failure, an HTTP error status, or a real
 * redirect to a challenge/checkpoint. (A login wall is deliberately NOT here — see classify.)
 */
function alwaysHardError(s: PageSnapshot): DetectorErrorCode | null {
  if (s.transportError) return s.transportError;
  const status = s.responseStatus;
  if (status === 403) return 'HTTP_403';
  if (status === 429) return 'HTTP_429';
  if (status !== null && status >= 500 && status <= 599) return 'HTTP_5XX';
  if (s.redirectedToAuthSessionChallenge) return 'AUTH_SESSION_CHALLENGE';
  if (s.redirectedToChallenge) return 'CHALLENGE';
  return null;
}

/** Collect the named strong ACTIVE signals present on this snapshot (evidence, always). */
function collectActiveSignals(s: PageSnapshot): { signals: string[]; identityMatched: boolean } {
  const req = s.requestedUsername;
  const signals: string[] = [];

  const canonicalMatches = usernameFromUrl(s.canonicalUrl) === req;
  const ogUrlMatches = usernameFromUrl(s.ogUrl) === req;
  const ogTitleMatches = handleFromText(s.ogTitle) === req;
  const headerMatches = s.headerUsername !== null && s.headerUsername === req;

  if (usernameFromUrl(s.finalUrl) === req) signals.push(ACTIVE_SIGNALS.URL_ON_USERNAME_PATH);
  if (!s.redirectedToLogin && !s.redirectedToChallenge && !s.redirectedToExploreOrHome) {
    signals.push(ACTIVE_SIGNALS.NOT_REDIRECTED_AWAY);
  }
  if (canonicalMatches) signals.push(ACTIVE_SIGNALS.CANONICAL_MATCHES);
  if (ogUrlMatches) signals.push(ACTIVE_SIGNALS.OG_URL_MATCHES);
  if (ogTitleMatches) signals.push(ACTIVE_SIGNALS.OG_TITLE_MATCHES);
  if (headerMatches) signals.push(ACTIVE_SIGNALS.HEADER_USERNAME_MATCHES);
  if (s.hasProfileStructures) signals.push(ACTIVE_SIGNALS.PROFILE_STRUCTURES_RENDERED);
  if (!s.unavailableMessagePresent) signals.push(ACTIVE_SIGNALS.NO_UNAVAILABLE_MESSAGE);

  const identityMatched = canonicalMatches || ogUrlMatches || ogTitleMatches || headerMatches;
  return { signals, identityMatched };
}

/**
 * Classify a single page snapshot. Pure and deterministic.
 *
 * - UNKNOWN for transport/browser failure, 403/429/5xx, challenge, login wall, consent
 *   block, empty page, unexpected redirect, contradictory signals, or unrecognized DOM.
 * - GONE only when a confirmed unavailable-profile message/title is present (and identity
 *   does not contradict it). Never from HTTP status alone.
 * - ACTIVE when profile metadata matches the EXACT requested username and no unavailable
 *   message is present — even behind a login wall (a banned account shows "Profile isn't
 *   available" with no identity, so a matching identity distinguishes a real/recovered one).
 *   A generic login/200 page with no matching identity is never ACTIVE.
 */
export function classify(snapshot: PageSnapshot): DetectorResult {
  const { signals: activeSignals, identityMatched } = collectActiveSignals(snapshot);
  const goneSignals = [
    ...(snapshot.unavailableMessagePresent ? [GONE_SIGNALS.UNAVAILABLE_MESSAGE] : []),
    ...(snapshot.unavailableTitlePresent ? [GONE_SIGNALS.UNAVAILABLE_TITLE] : []),
  ];

  const build = (
    classification: Classification,
    errorCode: DetectorErrorCode | null,
  ): DetectorResult => ({
    classification,
    evidence: {
      signalsVersion: SIGNALS_VERSION,
      activeSignals,
      goneSignals,
      identitySignalMatched: identityMatched,
      finalUrl: snapshot.finalUrl || null,
      responseStatus: snapshot.responseStatus,
      errorCode,
    },
    durationMs: 0,
  });

  // 1. Authoritative transport/status/challenge failure — we did not see a trustworthy page.
  const hardError = alwaysHardError(snapshot);
  if (hardError) return build('UNKNOWN', hardError);

  // 1b. Instagram's generic failure interstitial ("Something went wrong"). It still serves the
  //     profile's og metadata, so identity WOULD match and it would wrongly classify ACTIVE —
  //     and then be captured as the recovery screenshot. It is served while an IP is throttled,
  //     so it says nothing about the account: never ACTIVE, never GONE.
  if (snapshot.errorPagePresent) return build('UNKNOWN', 'ERROR_PAGE');

  // 2. GONE: a confirmed unavailable-profile page ("Sorry, this page isn't available." /
  //    "Profile isn't available"). Identity + unavailable together is contradictory.
  if (snapshot.unavailableMessagePresent || snapshot.unavailableTitlePresent) {
    if (identityMatched) return build('UNKNOWN', 'CONTRADICTORY');
    return build('GONE', null);
  }

  // 3. ACTIVE: the page carries profile metadata for the EXACT requested username and shows
  //    no unavailable message. That proves the profile exists and is accessible to Instagram
  //    — even when a login wall gates the full logged-out view (Instagram serves the profile's
  //    og:title/canonical on the login redirect for a real account, but shows "Profile isn't
  //    available" with NO identity for a banned one). This is what lets the bot detect a
  //    GONE -> ACTIVE recovery from a login-walling IP. The mandatory 3x-consecutive
  //    confirmation guards against a transient/stale signal.
  if (identityMatched) return build('ACTIVE', null);

  // 4. No identity and no unavailable message — the result cannot be trusted.
  if (snapshot.challengePresent) return build('UNKNOWN', 'CHALLENGE');
  if (snapshot.redirectedToLogin || snapshot.loginWallPresent)
    return build('UNKNOWN', 'LOGIN_WALL');
  if (snapshot.consentBlockPresent) return build('UNKNOWN', 'CONSENT_BLOCK');
  if (snapshot.redirectedToExploreOrHome) return build('UNKNOWN', 'UNEXPECTED_REDIRECT');
  if (snapshot.bodyTextLength <= 0) return build('UNKNOWN', 'EMPTY_PAGE');
  return build('UNKNOWN', 'UNRECOGNIZED_DOM');
}

/** Convenience for tests and the live path: extract then classify in one call. */
export function classifyHtml(html: string, meta: SnapshotMeta): DetectorResult {
  return classify(extractSnapshot(html, meta));
}
