/**
 * Lightweight HTTP probe — the FAST path.
 *
 * Instagram server-renders the identifying metadata (`og:url`, `og:title`, `canonical`) and the
 * "Sorry, this page isn't available" copy directly into the initial HTML document. So a single
 * plain GET is enough to decide ACTIVE / GONE / UNKNOWN — no browser needed.
 *
 * Why this matters:
 *   Chromium page load : ~4-12s, and 20-50 HTTP requests to Instagram (HTML+JS+CSS+images+XHR)
 *   This probe         : ~0.3s, and exactly 1 request
 *
 * That is ~30x faster per check AND ~30x less load on the proxy IP, which is what makes fast
 * polling survivable — request volume is what gets a residential IP rate-limited.
 *
 * It reuses the EXACT same {@link extractSnapshot} + {@link classify} pipeline as the browser
 * path, so classification can never diverge between the two transports. The browser is still
 * used for screenshots and for confirming a state flip (see the tiered detector).
 *
 * Only ever fetches `https://www.instagram.com/{validated username}/` — the same SSRF guard.
 */

import { Agent, ProxyAgent } from 'undici';
import type { AppConfig } from '../../config';
import {
  SIGNALS_VERSION,
  type Classification,
  type DetectorErrorCode,
  type DetectorResult,
} from '../../domain';
import { errorChainText, isProxySessionFailure } from '../proxy-session';
import { classify } from './classify';
import { extractSnapshot } from './signals';

/**
 * Hard ceiling on how much body to read. The identifying metadata (og:url / og:title /
 * canonical) lives in <head>, so we normally stop far earlier — see the `</head>` early exit
 * in {@link httpProbe}. This cap only bounds a pathological page.
 *
 * Keep it small: on a slow link (mobile proxies especially) reading a full ~590KB Instagram
 * document can exceed the probe timeout and produce a FALSE "no identity" — which would look
 * like "still banned" and silently miss a recovery.
 */
const MAX_BODY_BYTES = 128 * 1024;

const USERNAME_RE = /^[a-z0-9._]{1,30}$/i;

/** Headers of a real desktop Chrome navigation, so the response matches what a browser sees. */
const HEADERS: Record<string, string> = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) ' +
    'Chrome/124.0.0.0 Safari/537.36',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.9',
  'Accept-Encoding': 'gzip, deflate, br',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'none',
  'Sec-Fetch-User': '?1',
  'Cache-Control': 'no-cache',
  Pragma: 'no-cache',
};

/**
 * How much BODY to read after `</head>`. Instagram's throttle/interstitial copy ("Something
 * went wrong", "Please wait a few minutes", login prompts, consent walls) lives in the body,
 * NOT the head. Stopping at `</head>` made every one of those look like an empty page — and an
 * empty page was inferable as "still banned", silently masking recoveries on a throttled route.
 * This window is small enough to stay fast and large enough to see the interstitial.
 */
const BODY_PEEK_BYTES = 32 * 1024;

export interface HttpProbeOutcome {
  result: DetectorResult;
  /** True when the transport itself failed (as opposed to a page we could classify). */
  transportFailed: boolean;
  /**
   * True when the read stopped early. A truncated page may be missing body-borne evidence, so
   * callers MUST NOT infer "still gone" from the absence of signals in it.
   */
  bodyTruncated: boolean;
}

/**
 * Classify a thrown transport error.
 *
 * READS THE WHOLE `cause` CHAIN, and that is the fix rather than a refinement. Node's `fetch`
 * reports EVERY transport fault as a bare `TypeError: fetch failed` and hides the real error in
 * `.cause`, so the previous single-message match saw only the useless wrapper: a dead proxy tunnel,
 * a DNS failure and a refused connection all fell through to `NAVIGATION` alike. `PROXY_TUNNEL` in
 * particular could therefore never be distinguished — which is exactly why an expired mobile
 * session looked like ordinary flakiness and went on failing until someone noticed by hand.
 *
 * Proxy tunnel is tested FIRST because it is the most specific claim and the only one that is
 * self-healable; the rest stay in their original order.
 */
function mapFetchError(err: unknown): DetectorErrorCode {
  if (isProxySessionFailure(err)) return 'PROXY_TUNNEL';
  const m = errorChainText(err);
  if (m.includes('abort') || m.includes('timeout') || m.includes('timed out')) return 'TIMEOUT';
  if (m.includes('getaddrinfo') || m.includes('enotfound') || m.includes('dns')) return 'DNS';
  return 'NAVIGATION';
}

function failure(start: number, code: DetectorErrorCode): DetectorResult {
  return {
    classification: 'UNKNOWN' as Classification,
    evidence: {
      signalsVersion: SIGNALS_VERSION,
      activeSignals: [],
      goneSignals: [],
      identitySignalMatched: false,
      finalUrl: null,
      responseStatus: null,
      errorCode: code,
    },
    durationMs: Date.now() - start,
  };
}

/**
 * An undici Dispatcher. Deliberately kept opaque: `undici`'s own Dispatcher type and the copy
 * Node bundles as `undici-types` are structurally incompatible under exactOptionalPropertyTypes,
 * and we only ever pass this straight back to fetch.
 */
export type FetchDispatcher = object;

/**
 * Keep-alive pooling, applied to BOTH egress routes. Each probe otherwise pays a fresh
 * DNS + TCP + TLS handshake (through the proxy, or straight out), which on a mobile link is most
 * of the latency. Holding connections open across checks removes that cost from every probe
 * after the first.
 */
const POOL = {
  keepAliveTimeout: 60_000,
  keepAliveMaxTimeout: 300_000,
  connections: 8,
} as const;

/**
 * The DIRECT-egress pooled dispatcher, and the reason it has to exist at all.
 *
 * {@link POOL} used to be applied only inside `new ProxyAgent(...)`, so the direct path (which is
 * what production runs — PROXY_MODE=direct) got no dispatcher at all and fell through to undici's
 * global default. Every probe therefore paid a fresh DNS + TCP + TLS handshake to
 * www.instagram.com: pure, repeated, avoidable round-trips on the critical path of a recovery.
 *
 * A module-level singleton on purpose: pooling only pays if the SAME agent is reused across
 * probes, and the tiered detector rebuilds its dispatcher whenever the egress generation moves.
 * Idle sockets are reaped by `keepAliveTimeout`, so holding it costs nothing between checks.
 *
 * `allowH2` lets undici negotiate HTTP/2 with Instagram, which multiplexes every probe onto one
 * connection instead of one-per-request. (HTTP/3 is NOT attempted — Node has no production QUIC
 * client, so there is nothing to enable.)
 */
let directAgent: FetchDispatcher | undefined;

function directDispatcher(): FetchDispatcher {
  directAgent ??= new Agent({ ...POOL, allowH2: true });
  return directAgent;
}

/**
 * Build a pooled dispatcher for the given egress: a {@link ProxyAgent} when a proxy is
 * configured, the shared keep-alive {@link directDispatcher} otherwise. NEVER returns undefined
 * for a route we can serve — an unpooled probe is a fresh handshake every time.
 */
export function dispatcherFor(
  proxy: { server: string; username: string | null; password: string | null } | null,
): FetchDispatcher | undefined {
  if (proxy === null) return directDispatcher();
  const token =
    proxy.username !== null && proxy.password !== null
      ? `Basic ${Buffer.from(`${proxy.username}:${proxy.password}`).toString('base64')}`
      : undefined;
  // A URI undici rejects must NEVER silently fall back to a direct connection: that would send
  // the fast tier (and the canary) out over this machine's own IP while Chromium still used the
  // proxy — a hidden egress split, and an IP leak. Throw instead; the caller fails closed.
  return new ProxyAgent({
    uri: proxy.server,
    ...(token !== undefined ? { token } : {}),
    ...POOL,
  });
}

/** Pooled dispatcher for the statically-configured egress (proxy or direct). */
export function proxyDispatcher(config: AppConfig): FetchDispatcher | undefined {
  return dispatcherFor(config.browserProxy);
}

export interface HttpProbeDeps {
  config: AppConfig;
  dispatcher?: FetchDispatcher | undefined;
  fetchImpl?: typeof fetch;
}

/**
 * One lightweight GET, classified through the shared pipeline. Never throws — a transport
 * failure becomes UNKNOWN with a structured code, exactly like the browser path.
 */
export async function httpProbe(
  username: string,
  deps: HttpProbeDeps,
  timeoutMs = 15000,
): Promise<HttpProbeOutcome> {
  const start = Date.now();
  const validated = username.trim().replace(/^@/, '').toLowerCase();
  if (!USERNAME_RE.test(validated)) {
    return { result: failure(start, 'UNKNOWN_ERROR'), transportFailed: true, bodyTruncated: false };
  }
  const url = `https://www.instagram.com/${validated}/`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const doFetch = deps.fetchImpl ?? fetch;
    const init: RequestInit = {
      method: 'GET',
      headers: HEADERS,
      redirect: 'follow',
      signal: controller.signal,
    };
    // `dispatcher` is undici's non-standard escape hatch for proxying; it is not on the DOM
    // RequestInit type, and undici's own Dispatcher type conflicts with Node's bundled copy.
    if (deps.dispatcher !== undefined) {
      (init as Record<string, unknown>)['dispatcher'] = deps.dispatcher;
    }

    const res = await doFetch(url, init);

    // Instagram's full document is ~590KB, but everything we need is near the front: the
    // identity metadata in <head>, and the throttle/interstitial copy in the first slice of
    // <body>. Read to `</head>` PLUS a bounded body window, so a rate-limit page is actually
    // recognisable instead of looking like an empty page.
    //
    // Nothing is appended to the HTML. A previous version closed the document with an empty
    // `<body></body>`, which made the parser report zero body text and erased every body-borne
    // signal it had just buffered — turning throttle pages into "no signals", i.e. "still gone".
    let html = '';
    let truncated = false;
    const body = res.body;
    if (body) {
      const reader = body.getReader();
      const decoder = new TextDecoder();
      let total = 0;
      let headAt = -1;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.byteLength;
        html += decoder.decode(value, { stream: true });
        if (headAt < 0) {
          const i = html.indexOf('</head>');
          if (i >= 0) headAt = i;
        }
        const pastHead = headAt >= 0 && html.length - headAt >= BODY_PEEK_BYTES;
        if (pastHead || total >= MAX_BODY_BYTES) {
          truncated = true;
          await reader.cancel().catch(() => undefined);
          break;
        }
      }
    } else {
      html = await res.text();
    }

    const snapshot = extractSnapshot(html, {
      finalUrl: res.url || url,
      responseStatus: res.status,
      requestedUsername: validated,
    });
    const result: DetectorResult = { ...classify(snapshot), durationMs: Date.now() - start };
    return { result, transportFailed: false, bodyTruncated: truncated };
  } catch (err) {
    return {
      result: failure(start, mapFetchError(err)),
      transportFailed: true,
      bodyTruncated: false,
    };
  } finally {
    clearTimeout(timer);
  }
}
