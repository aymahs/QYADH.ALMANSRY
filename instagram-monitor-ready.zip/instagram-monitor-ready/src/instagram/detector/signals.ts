/**
 * Pure signal extraction: turn raw HTML + navigation metadata into a normalized
 * {@link PageSnapshot}. No network, no browser, no side effects — the SAME function
 * feeds both the live Playwright path and the static-fixture test path.
 *
 * Never store the parsed HTML anywhere; only the derived, non-sensitive snapshot escapes.
 */

import { parse, type HTMLElement } from 'node-html-parser';
import type { DetectorErrorCode, PageSnapshot } from '../../domain';

/** Metadata the browser (or a fixture harness) knows that the HTML alone does not. */
export interface SnapshotMeta {
  finalUrl: string;
  responseStatus: number | null;
  requestedUsername: string;
  transportError?: DetectorErrorCode | null;
}

/** Instagram username charset guard (also used to reject display-name text as a handle). */
const BARE_USERNAME_RE = /^[a-z0-9._]{1,30}$/i;
const HANDLE_RE = /@([a-z0-9._]{1,30})/i;

/** Normalize curly apostrophes/quotes so "isn’t" and "isn't" compare equal. */
function normalizeText(value: string): string {
  return value.replace(/[‘’ʼ]/g, "'").replace(/[“”]/g, '"').toLowerCase();
}

/** Pathname of an absolute (or already-relative) URL, tolerant of malformed input. */
function safePathname(url: string): string {
  try {
    return new URL(url).pathname;
  } catch {
    return url.startsWith('/') ? url : `/${url}`;
  }
}

/** First non-empty path segment of a URL/path (e.g. `/testuser/` -> `testuser`). */
export function firstPathSegment(url: string): string | null {
  const parts = safePathname(url)
    .split('/')
    .filter((p) => p.length > 0);
  return parts.length > 0 ? (parts[0] ?? null) : null;
}

/** Bare, lowercased username taken from the first path segment of a URL. */
export function usernameFromUrl(url: string | null): string | null {
  if (!url) return null;
  const seg = firstPathSegment(url);
  return seg ? seg.toLowerCase() : null;
}

/** Extract the `@handle` (lowercased, bare) from free text such as an og:title. */
export function handleFromText(text: string | null): string | null {
  if (!text) return null;
  const match = HANDLE_RE.exec(text);
  return match && match[1] ? match[1].toLowerCase() : null;
}

function metaContent(root: HTMLElement, attr: string, value: string): string | null {
  const el = root.querySelector(`meta[${attr}="${value}"]`);
  const content = el?.getAttribute('content');
  return content && content.trim().length > 0 ? content.trim() : null;
}

function getBodyText(root: HTMLElement): string {
  const body = root.querySelector('body') ?? root;
  const text = body.structuredText || body.text || '';
  return text.trim();
}

/** Read the profile header username from the DOM first, then fall back to og:title. */
function extractHeaderUsername(root: HTMLElement, ogTitle: string | null): string | null {
  const headerEl = root.querySelector('header h2') ?? root.querySelector('header h1');
  if (headerEl) {
    const t = headerEl.text.trim();
    const fromHandle = handleFromText(t);
    if (fromHandle) return fromHandle;
    if (BARE_USERNAME_RE.test(t)) return t.toLowerCase();
  }
  const fromTitle = handleFromText(ogTitle);
  if (fromTitle) return fromTitle;
  const anyHeading = root.querySelector('h2') ?? root.querySelector('h1');
  if (anyHeading) {
    const t = anyHeading.text.trim();
    if (BARE_USERNAME_RE.test(t)) return t.toLowerCase();
  }
  return null;
}

/**
 * Build a normalized snapshot from HTML + navigation metadata.
 * Classification never runs here — this only records observable facts.
 */
export function extractSnapshot(html: string, meta: SnapshotMeta): PageSnapshot {
  const requestedUsername = meta.requestedUsername.trim().toLowerCase();
  const root = parse(html || '');

  const canonicalUrl =
    root.querySelector('link[rel="canonical"]')?.getAttribute('href')?.trim() || null;
  const ogTitle = metaContent(root, 'property', 'og:title');
  const ogUrl = metaContent(root, 'property', 'og:url');
  const ogType = metaContent(root, 'property', 'og:type');
  const description = metaContent(root, 'name', 'description') ?? '';
  const rawTitle = root.querySelector('title')?.text?.trim() || null;

  const headerUsername = extractHeaderUsername(root, ogTitle);

  const bodyText = getBodyText(root);
  const bodyTextLength = bodyText.length;
  const scanText = normalizeText(`${bodyText}\n${description}\n${ogTitle ?? ''}`);

  // --- URL / redirect analysis -------------------------------------------------
  const finalUrlLower = meta.finalUrl.toLowerCase();
  const finalPath = safePathname(finalUrlLower);
  const firstSeg = usernameFromUrl(meta.finalUrl);
  const usernameInPath = firstSeg !== null && firstSeg === requestedUsername;

  const redirectedToLogin = finalPath.includes('/accounts/login') || firstSeg === 'login';
  const redirectedToChallenge = finalUrlLower.includes('/challenge') || firstSeg === 'challenge';
  // A manually-created logged-in storage state can later be rejected when Instagram dislikes
  // the egress/IP change. This is not evidence about the requested profile or the route itself:
  // it is a local session problem, and the browser can safely retry without that storage state.
  const redirectedToAuthSessionChallenge = finalPath.includes(
    '/accounts/update_risky_contactpoint',
  );
  const redirectedToExploreOrHome =
    finalPath === '/' || firstSeg === 'explore' || firstSeg === 'reels' || !usernameInPath;

  // --- Profile structure -------------------------------------------------------
  const hasFollowerText = scanText.includes('followers') && scanText.includes('following');
  const hasAppLinks =
    root.querySelector('meta[property="al:ios:url"]') !== null ||
    root.querySelector('meta[property="al:android:url"]') !== null;
  const hasProfileStructures = ogType === 'profile' || hasFollowerText || hasAppLinks;

  // --- Interstitials / negative markers ---------------------------------------
  const unavailableMessagePresent =
    scanText.includes("sorry, this page isn't available") ||
    scanText.includes('the link you followed may be broken');
  // Instagram can render an otherwise empty shell while making the profile state
  // explicit only in <title> (for example: "Profile isn't available • Instagram").
  const unavailableTitlePresent =
    normalizeText(rawTitle ?? '').includes("profile isn't available") ||
    normalizeText(rawTitle ?? '').includes("page isn't available");

  const hasPasswordInput =
    root.querySelector('input[name="password"]') !== null ||
    root.querySelector('input[type="password"]') !== null;
  const hasLoginPlaceholder =
    scanText.includes('phone number, username, or email') ||
    scanText.includes('mobile number, username or email') ||
    scanText.includes('log into instagram');
  const loginMarkers = hasPasswordInput || hasLoginPlaceholder;
  // Raw "a login form is on the page" fact, INDEPENDENT of the og-metadata masking that
  // (correctly) keeps `loginWallPresent` false so identity still classifies ACTIVE. The
  // screenshot guard needs this raw signal: Instagram serves og:type=profile even on the
  // logged-out login wall, which would otherwise let the wall pass as "visibly rendered".
  const loginFormPresent = loginMarkers;

  // A login prompt layered over a fully rendered, identified profile is NOT a login wall.
  const identityMetaPresent =
    usernameFromUrl(canonicalUrl) !== null ||
    usernameFromUrl(ogUrl) !== null ||
    handleFromText(ogTitle) !== null ||
    headerUsername !== null;
  const clearlyRenderedProfile = hasProfileStructures && identityMetaPresent;
  const loginWallPresent = loginMarkers && !clearlyRenderedProfile;

  // Age/sensitivity gate: the account exists (so it classifies ACTIVE) but its content is
  // only viewable while logged in, so there is nothing legitimate to screenshot.
  const restrictedProfilePresent =
    scanText.includes('restricted profile') ||
    scanText.includes('this profile is restricted') ||
    scanText.includes('this account is restricted');

  // Instagram's generic failure interstitial, typically served while an IP is throttled. It
  // still carries the profile's og metadata, so without this signal it classifies ACTIVE and
  // gets captured as the "recovered profile" screenshot. Never trust or capture it.
  // Require the interstitial's OWN wording AND the absence of real profile content: a live
  // profile whose bio or a post happens to contain "something went wrong" must not be
  // permanently unclassifiable (and must not be counted as a fleet-wide throttle).
  const errorPhrasePresent =
    scanText.includes("there's an issue and the page could not be loaded") ||
    scanText.includes('page could not be loaded') ||
    scanText.includes('something went wrong');
  const errorPagePresent = errorPhrasePresent && !hasFollowerText;

  const challengePresent =
    redirectedToChallenge ||
    scanText.includes('suspicious activity') ||
    scanText.includes('please wait a few minutes') ||
    scanText.includes('help us confirm') ||
    scanText.includes('checkpoint_required');

  const consentBlockPresent =
    scanText.includes('allow the use of cookies') ||
    scanText.includes('allow all cookies') ||
    scanText.includes('accept all cookies') ||
    scanText.includes('accept all');

  return {
    requestedUsername,
    finalUrl: meta.finalUrl,
    responseStatus: meta.responseStatus,
    redirectedToLogin,
    redirectedToChallenge,
    redirectedToAuthSessionChallenge,
    redirectedToExploreOrHome,
    canonicalUrl,
    ogTitle,
    ogUrl,
    headerUsername,
    hasProfileStructures,
    unavailableMessagePresent,
    unavailableTitlePresent,
    loginWallPresent,
    loginFormPresent,
    restrictedProfilePresent,
    errorPagePresent,
    challengePresent,
    consentBlockPresent,
    bodyTextLength,
    rawTitle,
    transportError: meta.transportError ?? null,
  };
}
