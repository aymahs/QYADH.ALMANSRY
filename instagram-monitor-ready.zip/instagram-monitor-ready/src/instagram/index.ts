/** Barrel for the Instagram module: detector, browser manager, and screenshot capture. */

export {
  extractSnapshot,
  usernameFromUrl,
  handleFromText,
  firstPathSegment,
  classify,
  classifyHtml,
  PlaywrightDetector,
  TieredDetector,
  httpProbe,
  proxyDispatcher,
  dispatcherFor,
} from './detector';
export type { SnapshotMeta, PlaywrightDetectorOptions, TieredDetectorOptions } from './detector';

export {
  CircuitBreaker,
  isThrottleSignal,
  backOffForRoute,
  EGRESS_BREAKER_NAME,
} from './circuit-breaker';
export type { CircuitBreakerOptions, BreakerState, DurableBreakerState } from './circuit-breaker';

export { ProxySwitch } from './proxy-switch';
export type { ProxyMode, ProxySettings, ProxyState } from './proxy-switch';
export { ProxySessionHealer, hasRotatableSession, rotateSessionToken } from './proxy-session';
export type { HealOutcome, ProxySessionHealerOptions } from './proxy-session';

export { BrowserManager } from './browser/browser-manager';
export type { BrowserManagerOptions, PageOptions } from './browser/browser-manager';

export { validateImage, dismissOverlays, captureProfileScreenshot } from './screenshot/capture';
