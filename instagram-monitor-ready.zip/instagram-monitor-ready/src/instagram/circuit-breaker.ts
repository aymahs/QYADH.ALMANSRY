/**
 * Global rate-limit circuit breaker.
 *
 * The failure this exists to prevent (observed in production, 2026-07-27): when the proxy IP
 * gets throttled, EVERY account's check fails, and because the retry ladder is per-account the
 * whole fleet retries at once — amplifying the request rate exactly when it must fall. A single
 * residential IP was burned from ~1,270 checks/hour and stayed blocked for hours.
 *
 * So back-off must be FLEET-WIDE, not per-account. When enough consecutive checks come back with
 * a throttling signal (login wall / 429 / error page / challenge), the breaker OPENS and every
 * probe short-circuits to UNKNOWN *without touching the network*, letting the IP cool down. After
 * the cooldown it goes HALF_OPEN and lets exactly one probe through: success closes it, failure
 * reopens with a doubled cooldown (capped).
 *
 * WHAT MAY ADVANCE IT (the 2026-08-01 outage). Only GENUINE THROTTLE EVIDENCE — a page Instagram
 * actually served that refused us. A navigation failure, a timeout, a browser torn down by a
 * `/proxy` switch, or a probe abandoned because the egress route moved under it are all FAILED
 * OBSERVATIONS: they said nothing about the route, so they move nothing. See {@link BreakerOutcome}
 * and the `observedOnGeneration` argument to {@link CircuitBreaker.record}.
 *
 * The back-off is DURABLE: every state transition is published through
 * {@link CircuitBreakerOptions.onTransition} and adopted again by {@link CircuitBreaker.rehydrate}
 * at startup. Without that, a restart mid-cooldown (deploy, OOM, crash, systemd) began CLOSED with
 * a zeroed streak and the whole fleet resumed full-rate checking against an IP that was still
 * being throttled — a crash loop made back-off structurally impossible.
 *
 * Pure and clock-injected, so it is fully testable without timers.
 */

import type { BreakerPhase, BreakerStateRecord } from '../domain/repositories';
import type { DetectorErrorCode } from '../domain';

/** Mirrors the persisted {@link BreakerPhase}, so the two can never drift apart. */
export type BreakerState = BreakerPhase;

/**
 * Everything needed to resume a cooldown after a restart. The remaining fields of
 * {@link BreakerStateRecord} (key, route, write time) belong to the caller that stores it.
 */
export type DurableBreakerState = Pick<
  BreakerStateRecord,
  'state' | 'openedAtUtc' | 'cooldownMs' | 'consecutive'
>;

/** Row key for the one process-wide egress breaker. */
export const EGRESS_BREAKER_NAME = 'egress';

/**
 * A point-in-time copy of the back-off, taken so that an egress switch which is later UNDONE can
 * put the fleet back exactly as it was.
 *
 * WHY THIS EXISTS. `/proxy` selects the new route BEFORE it can measure it — the canary has to go
 * out over the candidate — so {@link CircuitBreaker.adoptRoute} has already cleared this route's
 * block by the time the measurement comes back "blind". Restoring only the ROUTE then left the
 * fleet back on a throttled IP with its fleet-wide brake silently released (and CLOSED persisted
 * over the OPEN row, so a restart could not recover it either) while the reply told the owner
 * nothing had changed. Capturing this before the switch and putting it back on the revert is what
 * makes the revert a genuine transaction.
 *
 * Deliberately the RAW fields, not {@link CircuitBreaker.snapshot}'s derived view: reading the
 * derived state would apply an elapsed cooldown as a side effect, and a checkpoint must observe
 * without changing anything.
 */
export interface BreakerCheckpoint {
  state: BreakerState;
  consecutive: number;
  openedAtMs: number;
  cooldownMs: number;
}

/**
 * Which stored back-off, if any, applies to the route we are about to run on.
 *
 * Back-off is a property OF A ROUTE. Re-applying a burned proxy's hour-long block to the fresh
 * route the owner configured precisely to escape it would silently delay every recovery alert
 * for the whole cooldown — the worst outcome this system has. An unrecognised route therefore
 * starts clear, and earns its own back-off if it deserves one.
 */
export function backOffForRoute(
  stored: BreakerStateRecord | null,
  currentRoute: string,
): DurableBreakerState | null {
  return stored !== null && stored.egressRoute === currentRoute ? stored : null;
}

/**
 * What a finished probe proved about THE EGRESS ROUTE — which is the only thing this breaker
 * reasons about. Deliberately three states, not two.
 *
 * The two-state (`boolean`) version is what caused the 2026-08-01 outage. Every caller derived it
 * as `isThrottleSignal(errorCode)`, so every FAILED OBSERVATION — a navigation error, a timeout, a
 * browser torn down mid-probe by a `/proxy` switch — arrived as `false`, i.e. as the positive
 * assertion "the IP is serving us again". That is not a weaker claim than the truth, it is a
 * different one, and it is wrong in both directions at once:
 *
 *   - it ZEROES a genuine throttle streak, so the breaker cannot reach its threshold while the
 *     fleet is escalating (every escalated browser probe that failed reset the counter), and
 *   - it force-CLOSES a HALF_OPEN breaker, releasing the whole fleet back onto an IP that is
 *     still being throttled — harm rank 3, which blinds every client.
 *
 * `INCONCLUSIVE` is the missing third answer: nothing was observed, so nothing may be inferred,
 * so NOTHING about the back-off may move.
 */
export type BreakerOutcome = 'THROTTLED' | 'SERVED' | 'INCONCLUSIVE';

/**
 * The single mapping from a detector error code to what it proves about the ROUTE.
 *
 * Exhaustive by type (`Record<DetectorErrorCode, …>`) on purpose: a new error code cannot compile
 * until someone states which bucket it belongs to. The previous shape — a Set of throttle codes,
 * with everything else implicitly meaning "served" — made the dangerous answer the DEFAULT, so
 * every code added since has silently been treated as evidence that the IP is healthy.
 *
 * THROTTLED is unchanged, exactly as before: the five codes that mean Instagram is refusing this
 * IP. The breaker's real purpose is untouched — these still open it, still back off exponentially,
 * and still persist.
 */
const OUTCOME_BY_CODE: Readonly<Record<DetectorErrorCode, BreakerOutcome>> = {
  // Instagram answered, and the answer was "not you" / "not now". Genuine throttle evidence.
  LOGIN_WALL: 'THROTTLED',
  HTTP_429: 'THROTTLED',
  HTTP_403: 'THROTTLED',
  ERROR_PAGE: 'THROTTLED',
  CHALLENGE: 'THROTTLED',

  // We never got a trustworthy answer at all. Says nothing about the route's standing with
  // Instagram — NAVIGATION and BROWSER_CRASH in particular are exactly what a deliberate browser
  // teardown (a `/proxy` switch) manufactures for every probe that was in flight.
  TIMEOUT: 'INCONCLUSIVE',
  DNS: 'INCONCLUSIVE',
  NAVIGATION: 'INCONCLUSIVE',
  BROWSER_CRASH: 'INCONCLUSIVE',
  // The egress proxy never tunnelled the request, so Instagram never saw it. Treating this as
  // THROTTLED would open the fleet-wide brake — blinding every client for the cooldown — over a
  // provider-side session expiry that one rotated token fixes in a second. It is the purest
  // possible "nothing was observed".
  PROXY_TUNNEL: 'INCONCLUSIVE',
  // The route returned a page, but the rejected cookie jar is local mutable state. The tiered
  // detector retries once without it; this first leg must neither open nor close route back-off.
  AUTH_SESSION_CHALLENGE: 'INCONCLUSIVE',
  // An Instagram 5xx is neither a refusal nor a page: it is a failed observation with a status.
  HTTP_5XX: 'INCONCLUSIVE',
  UNKNOWN_ERROR: 'INCONCLUSIVE',

  // A real document came back over this route. We may not have been able to read the ACCOUNT from
  // it, but the ROUTE is demonstrably being served, which is the only question here.
  CONSENT_BLOCK: 'SERVED',
  EMPTY_PAGE: 'SERVED',
  UNEXPECTED_REDIRECT: 'SERVED',
  CONTRADICTORY: 'SERVED',
  UNRECOGNIZED_DOM: 'SERVED',
};

/**
 * What this probe outcome proves about the route. `null` (no error code) is a page we read
 * cleanly, so the route is being served.
 */
export function breakerOutcomeForCode(code: DetectorErrorCode | null): BreakerOutcome {
  return code === null ? 'SERVED' : OUTCOME_BY_CODE[code];
}

/**
 * Is this code genuine evidence the IP is being throttled? Derived from the one table above so the
 * two can never drift apart.
 */
export function isThrottleSignal(code: DetectorErrorCode | null): boolean {
  return code !== null && OUTCOME_BY_CODE[code] === 'THROTTLED';
}

/** A HALF_OPEN admission that never reports back is reclaimed after this long. */
const HALF_OPEN_SLOT_TTL_MS = 2 * 60 * 1000;

/** No egress route bound yet — distinct from generation 0, which is a real route. */
const UNBOUND_ROUTE = -1;

/** A stored number is never trusted: NaN/Infinity/negative all fall back. */
function safeNumber(value: number, fallback: number): number {
  return Number.isFinite(value) && value >= 0 ? value : fallback;
}

export interface CircuitBreakerOptions {
  /** Consecutive throttle signals before the breaker opens. */
  threshold?: number;
  /** First cooldown, doubled on each failed half-open probe. */
  initialCooldownMs?: number;
  /** Upper bound on the cooldown. */
  maxCooldownMs?: number;
  now?: () => number;
  /**
   * Called on every state TRANSITION (and only then — never on the probe hot path) with the
   * snapshot to store. Fire-and-forget by contract: it must not block, and anything it throws
   * is swallowed, because losing a write costs durability while throwing would cost the check.
   */
  onTransition?: (state: DurableBreakerState) => void;
}

export class CircuitBreaker {
  private state: BreakerState = 'CLOSED';
  private consecutive = 0;
  private openedAt = 0;
  private cooldownMs: number;
  private halfOpenInFlight = false;
  /** When the HALF_OPEN slot was handed out, so a lost probe cannot wedge it forever. */
  private halfOpenAdmittedAt = 0;
  /**
   * The egress generation the state currently held was earned on. It lives HERE rather than in
   * each detector because the breaker is process-wide while detectors are not — see
   * {@link CircuitBreaker.adoptRoute}.
   */
  private routeGeneration = UNBOUND_ROUTE;

  private readonly threshold: number;
  private readonly initialCooldownMs: number;
  private readonly maxCooldownMs: number;
  private readonly now: () => number;
  private readonly onTransition: ((state: DurableBreakerState) => void) | null;

  constructor(options: CircuitBreakerOptions = {}) {
    this.threshold = options.threshold ?? 5;
    this.initialCooldownMs = options.initialCooldownMs ?? 10 * 60 * 1000;
    this.maxCooldownMs = options.maxCooldownMs ?? 60 * 60 * 1000;
    this.cooldownMs = this.initialCooldownMs;
    this.now = options.now ?? Date.now;
    this.onTransition = options.onTransition ?? null;
  }

  /**
   * Adopt a persisted back-off at startup, so a restart resumes the REMAINING cooldown instead
   * of starting CLOSED against an IP that is still mid-cooldown.
   *
   * Everything here is defensive, because a stored value must never be able to WEDGE the bot:
   *  - nothing stored, or a phase that is not OPEN/HALF_OPEN -> stay CLOSED (a fresh start),
   *  - an unreadable open-time -> HALF_OPEN, the most bounded non-closed posture: exactly one
   *    trial probe decides it, rather than trusting a garbage timestamp for a whole cooldown,
   *  - a far-future open-time (clock skew, corruption) cannot yield more than one full cooldown,
   *    and the cooldown itself is clamped to the configured maximum.
   *
   * Call once, before the first probe. Deliberately does NOT fire
   * {@link CircuitBreakerOptions.onTransition}: restoring what is already stored is not a
   * transition, and re-writing it on every boot would just churn the row.
   */
  rehydrate(stored: DurableBreakerState | null): void {
    if (stored === null || (stored.state !== 'OPEN' && stored.state !== 'HALF_OPEN')) return;

    this.consecutive = Math.floor(safeNumber(stored.consecutive, 0));
    this.cooldownMs = Math.min(
      Math.max(safeNumber(stored.cooldownMs, this.initialCooldownMs), this.initialCooldownMs),
      this.maxCooldownMs,
    );
    this.halfOpenInFlight = false;
    this.halfOpenAdmittedAt = 0;

    const openedAtMs = stored.openedAtUtc === null ? Number.NaN : Date.parse(stored.openedAtUtc);
    if (!Number.isFinite(openedAtMs)) {
      this.state = 'HALF_OPEN';
      return;
    }
    const now = this.now();
    // The Math.min pins a future-dated open-time to one full cooldown instead of an open-ended
    // block; the Math.max turns a long-elapsed one into "cooldown already served".
    const remainingMs = Math.min(
      Math.max(0, this.cooldownMs - (now - openedAtMs)),
      this.cooldownMs,
    );
    if (remainingMs === 0) {
      // The stored cooldown has already been served, so let one trial probe decide rather than
      // resuming at full rate — a crash loop then costs one probe per boot, not a stampede.
      this.state = 'HALF_OPEN';
      return;
    }
    this.state = 'OPEN';
    this.openedAt = now - (this.cooldownMs - remainingMs);
  }

  /** Current state, after applying any elapsed cooldown. */
  currentState(): BreakerState {
    if (this.state === 'OPEN' && this.now() - this.openedAt >= this.cooldownMs) {
      this.state = 'HALF_OPEN';
      this.halfOpenInFlight = false;
      this.notify();
    }
    return this.state;
  }

  /**
   * Whether a probe may hit the network right now. In HALF_OPEN exactly one caller is admitted;
   * everyone else keeps waiting until that probe reports back.
   */
  allowRequest(): boolean {
    const state = this.currentState();
    if (state === 'CLOSED') return true;
    if (state === 'OPEN') return false;
    // HALF_OPEN admits exactly one prober. The slot is normally released by record(), but a
    // probe that throws (or is abandoned) would otherwise wedge the breaker permanently and
    // silently stop ALL monitoring — so the admission also expires on its own.
    if (this.halfOpenInFlight) {
      if (this.now() - this.halfOpenAdmittedAt < HALF_OPEN_SLOT_TTL_MS) return false;
    }
    this.halfOpenInFlight = true;
    this.halfOpenAdmittedAt = this.now();
    return true;
  }

  /**
   * Bind the back-off to an egress route, clearing it ONLY when the route genuinely changed
   * under the state now held.
   *
   * Callers are the detectors, which each learn about a `/proxy` switch lazily — on their own
   * next probe. Two TieredDetectors share this one breaker (the monitor fleet's, and the deletion
   * watcher's), and the deletion watcher only probes when a watch is due, so it can be minutes or
   * hours behind. While each detector decided for itself whether it was seeing a route CHANGE,
   * that straggler's catch-up called {@link reset} long after the fleet had re-earned a block ON
   * THE NEW ROUTE — wiping it in memory and, because reset() publishes, in the store too, so the
   * whole fleet resumed full rate against an IP that was still being throttled and a restart in
   * that window came back CLOSED. Keying on the generation the BREAKER adopted makes the clear
   * idempotent per switch: the first detector to catch up performs it, every later one is a no-op.
   *
   * The first binding never clears: it is the route this process started on, so a back-off
   * rehydrated for it (already route-matched by {@link backOffForRoute}) must be kept.
   */
  adoptRoute(generation: number): void {
    if (this.routeGeneration === generation) return;
    const wasBound = this.routeGeneration !== UNBOUND_ROUTE;
    this.routeGeneration = generation;
    if (wasBound) this.reset();
  }

  /**
   * Copy the back-off as it stands, WITHOUT disturbing it, so an egress switch that is later
   * reverted can put it back. See {@link BreakerCheckpoint}.
   */
  checkpoint(): BreakerCheckpoint {
    return {
      state: this.state,
      consecutive: this.consecutive,
      openedAtMs: this.openedAt,
      cooldownMs: this.cooldownMs,
    };
  }

  /**
   * Put back a {@link checkpoint} taken before a route change that has now been UNDONE, and bind
   * the restored back-off to `generation` — the generation of the route the fleet is on AGAIN.
   *
   * Both halves are load-bearing. Without the state, the fleet resumes full-rate probing against
   * an IP Instagram was actively throttling (harm rank 3, which blinds the whole fleet). Without
   * the re-binding, the next detector to call {@link adoptRoute} would see a generation it has not
   * adopted and {@link reset} the very block just restored — so the caller MUST revert the route
   * first and pass the generation now in force.
   *
   * Anything the abandoned route earned in the meantime is deliberately discarded: it describes a
   * route we are no longer on, which is exactly the judgement {@link adoptRoute} makes.
   */
  restore(checkpoint: BreakerCheckpoint, generation: number): void {
    this.state = checkpoint.state;
    this.consecutive = checkpoint.consecutive;
    this.openedAt = checkpoint.openedAtMs;
    this.cooldownMs = checkpoint.cooldownMs;
    // A HALF_OPEN slot handed out under the abandoned route means nothing here; leaving it set
    // would wedge the trial probe that is supposed to decide whether the cooldown can lift.
    this.halfOpenInFlight = false;
    this.halfOpenAdmittedAt = 0;
    this.routeGeneration = generation;
    // reset() has already persisted CLOSED over the stored row, so the store is now WRONG and a
    // restart would come back with no back-off at all. Publishing is what repairs it.
    this.notify();
  }

  /** Forget everything — used when the egress route changes and history no longer applies. */
  reset(): void {
    this.state = 'CLOSED';
    this.consecutive = 0;
    this.openedAt = 0;
    this.cooldownMs = this.initialCooldownMs;
    this.halfOpenInFlight = false;
    this.halfOpenAdmittedAt = 0;
    // Persist it: otherwise a /proxy switch made to escape a throttled route would leave the
    // OLD route's block in the store, and the next restart would re-apply it to the new one.
    this.notify();
  }

  /**
   * Record what a finished probe proved about the ROUTE, and say which egress generation it was
   * OBSERVED ON. Returns whether the outcome was applied (false = discarded as stale).
   *
   * `observedOnGeneration` is the whole `/proxy` fix, and it belongs here rather than in the
   * detectors for the same reason {@link adoptRoute} does: the breaker is process-wide, the
   * detectors are not, and only the breaker knows which route the back-off it is holding describes.
   *
   * A deliberate egress switch tears the browser down BY DESIGN, so every probe that was in flight
   * fails — and those failures used to be recorded against the route that had just been adopted,
   * which {@link adoptRoute} had (correctly) just given a clean slate. A `/proxy` issued to ESCAPE
   * a throttled IP therefore imported the old route's dying probes onto the new one and re-opened
   * the fleet-wide brake on a route that had never been measured, blocking both. A result may only
   * move the back-off of the route it was actually observed on.
   *
   * Omit the generation and no staleness check is made — that form exists for callers that hold no
   * route at all (the breaker's own unit tests). Production always passes it.
   */
  record(outcome: BreakerOutcome | boolean, observedOnGeneration?: number): boolean {
    // The boolean form is retained because the two advancing inputs are unambiguous on their own;
    // what was unsafe was DERIVING it from an error code, which is why that derivation now lives
    // in exactly one place ({@link breakerOutcomeForCode}) and returns three answers, not two.
    const resolved: BreakerOutcome =
      typeof outcome === 'boolean' ? (outcome ? 'THROTTLED' : 'SERVED') : outcome;

    if (observedOnGeneration !== undefined && observedOnGeneration !== this.routeGeneration) {
      // Observed on a route we are no longer on. Discard it entirely — including any HALF_OPEN
      // admission it might look like it holds, because adoptRoute()/restore() already cleared the
      // slot when they re-bound the state.
      return false;
    }

    if (resolved === 'INCONCLUSIVE') {
      // Nothing was observed, so the streak, the state and the cooldown all stand exactly as they
      // were. The one thing that MUST move is the HALF_OPEN admission this probe consumed: leaving
      // it held would block every other probe in the fleet until the slot's TTL expired, and the
      // trial that is supposed to decide whether the cooldown can lift would never be retried.
      this.releaseHalfOpenSlot();
      return true;
    }

    if (resolved === 'THROTTLED') {
      this.consecutive += 1;
      if (this.state === 'HALF_OPEN') {
        // The cooldown was not long enough — back off harder.
        this.cooldownMs = Math.min(this.cooldownMs * 2, this.maxCooldownMs);
        this.open();
        return true;
      }
      if (this.consecutive >= this.threshold) this.open();
      return true;
    }

    // A clean result: the IP is serving us again.
    this.consecutive = 0;
    if (this.state !== 'CLOSED') {
      this.state = 'CLOSED';
      this.halfOpenInFlight = false;
      this.cooldownMs = this.initialCooldownMs;
      this.notify();
    }
    return true;
  }

  /**
   * Give back a HALF_OPEN admission without judging the route. Not a state transition, so it is
   * deliberately NOT published — nothing durable changed.
   */
  private releaseHalfOpenSlot(): void {
    if (this.state !== 'HALF_OPEN') return;
    this.halfOpenInFlight = false;
    this.halfOpenAdmittedAt = 0;
  }

  private open(): void {
    this.state = 'OPEN';
    this.openedAt = this.now();
    this.halfOpenInFlight = false;
    this.notify();
  }

  /**
   * Publish the durable snapshot. Called on transitions only, so the store never sees the
   * per-probe hot path. A store that throws must not be able to break detection.
   */
  private notify(): void {
    if (this.onTransition === null) return;
    try {
      this.onTransition({
        state: this.state,
        openedAtUtc: this.state === 'CLOSED' ? null : new Date(this.openedAt).toISOString(),
        cooldownMs: this.cooldownMs,
        consecutive: this.consecutive,
      });
    } catch {
      // Best-effort durability: the next transition writes again.
    }
  }

  /** Milliseconds until the next probe is allowed (0 when requests may flow). */
  retryAfterMs(): number {
    if (this.currentState() !== 'OPEN') return 0;
    return Math.max(0, this.cooldownMs - (this.now() - this.openedAt));
  }

  /** Diagnostics for /ping and logging. */
  snapshot(): { state: BreakerState; consecutive: number; retryAfterMs: number } {
    return {
      state: this.currentState(),
      consecutive: this.consecutive,
      retryAfterMs: this.retryAfterMs(),
    };
  }
}
