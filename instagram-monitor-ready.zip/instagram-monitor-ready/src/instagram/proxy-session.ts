/**
 * Self-healing for an expired MOBILE-PROXY SESSION — the failure that silently ends monitoring.
 *
 * Decodo hands out a sticky exit IP per *session*, pinned by a token embedded in the proxy
 * username (`…-session-<token>-sessionduration-<minutes>`). Sessions expire BY DESIGN. Once one
 * does, the gateway stops tunnelling and answers every CONNECT with `502` and a body that says the
 * session has ended. Nothing about that is a problem with Instagram, with the account, or with the
 * IP's standing — but the bot could not tell, so it behaved as if monitoring were merely failing:
 * every probe became a transport error, every transport error escalated to a full Chromium load
 * that failed the same way, and the fleet stayed dark until the owner noticed by hand. That is
 * harm rank 1 (a client is never told about a recovery), reached from a condition the provider
 * considers routine and that one new token fixes in a second.
 *
 * The cure is the shape the browser's rejected-cookie-jar path already proved: DETECT the specific
 * signature, MUTATE the one piece of local state that is wrong, and hand the caller a one-shot
 * retry — never a loop.
 *
 * WHAT THIS MODULE WILL NOT DO, and why each bound exists:
 *
 *   - It will not rotate on an HTTP response. A gateway fault and an Instagram fault both mention
 *     502, and they mean opposite things. See {@link isProxySessionFailure}: only a request that
 *     THREW before any response can qualify, because that is the structural signature of a tunnel
 *     that was never established. An origin 502 arrives as a resolved response with a status and
 *     is classified as HTTP_5XX exactly as before.
 *   - It will not rotate on 407. That is "your credentials are wrong", which a new session token
 *     cannot fix; rotating would burn session slots forever against a config error.
 *   - It will not feed the circuit breaker. A dead session is a TRANSPORT fault, not evidence that
 *     Instagram is throttling the IP. Opening the fleet-wide brake here would blind every client
 *     for the cooldown over something a rotation fixes immediately — the breaker exists to protect
 *     a throttled residential IP, and mixing the two is how a 10-minute outage gets manufactured
 *     from a 1-second fault. `PROXY_TUNNEL` is mapped to INCONCLUSIVE in `OUTCOME_BY_CODE`.
 *   - It will not rotate without limit. {@link ProxySessionHealer} enforces a minimum interval and
 *     gives up after a run of consecutive attempts, because if rotation is not helping then the
 *     session is not what is broken (gateway down, credit exhausted, network gone) and a rotation
 *     storm would exhaust the account's session allowance while hiding the real fault.
 *
 * NOTHING HERE MAY BE LOGGED VERBATIM. The proxy username CONTAINS the session token and the
 * account name, so it is a credential: callers log `host:port` (`ProxySwitch.describe()`) and the
 * healer's own verdict, never the username or the token.
 */

/**
 * The literal that marks the session segment inside the proxy username.
 *
 * Matching on this rather than on a position is what makes the rotation safe against the rest of
 * the username changing shape: Decodo's format carries several `-key-value-` pairs
 * (`sessionduration`, region selectors) whose presence and order vary by plan, and an index-based
 * edit would silently corrupt a neighbouring field the first time one was added.
 */
const SESSION_MARKER = '-session-';

/** Characters a minted token may use. Lowercase alphanumeric matches what the gateway issues. */
const TOKEN_ALPHABET = 'abcdefghijklmnopqrstuvwxyz0123456789';

/** Length of a minted token when the existing one gives no better hint. */
const DEFAULT_TOKEN_LENGTH = 10;

/**
 * Does this username carry a session token we know how to replace?
 *
 * A username WITHOUT one is not a fault — it is a proxy that does not use sticky sessions (or the
 * home route, which has no username at all). Such a route simply has nothing to heal, and the
 * caller must degrade to its normal error handling rather than treating the absence as a failure.
 */
export function hasRotatableSession(username: string | null | undefined): boolean {
  return typeof username === 'string' && username.includes(SESSION_MARKER);
}

/** Mint a fresh session token. Not a security boundary — it only needs to differ from the last. */
function mintToken(length: number): string {
  let out = '';
  for (let i = 0; i < length; i += 1) {
    out += TOKEN_ALPHABET[Math.floor(Math.random() * TOKEN_ALPHABET.length)];
  }
  return out;
}

/**
 * Replace the session token in `username`, returning the new username — or null when there is no
 * session segment to replace (so the caller can tell "nothing to do" from "done").
 *
 * Only the token itself is touched: everything before `-session-` and everything from the NEXT
 * `-` onwards is preserved byte-for-byte, so `-sessionduration-30` and any region selectors
 * survive untouched. A token at the very end of the string (no trailing segment) is handled too.
 *
 * The replacement is guaranteed to DIFFER from the token it replaces. A rotation that happened to
 * mint the same value would look like a successful heal, reconnect to the same dead session, and
 * burn the caller's one retry — turning the bounded recovery into a silent no-op.
 */
export function rotateSessionToken(
  username: string,
  mint: (length: number) => string = mintToken,
): string | null {
  const markerAt = username.indexOf(SESSION_MARKER);
  if (markerAt < 0) return null;

  const tokenAt = markerAt + SESSION_MARKER.length;
  const nextDash = username.indexOf('-', tokenAt);
  const tokenEnd = nextDash < 0 ? username.length : nextDash;
  const current = username.slice(tokenAt, tokenEnd);
  const length = current.length > 0 ? current.length : DEFAULT_TOKEN_LENGTH;

  let replacement = mint(length);
  // Bounded, not a `while (true)`: a caller-injected mint that always returns the same value must
  // not hang the probe path. After a few tries, fall back to a value that CANNOT collide.
  for (let i = 0; i < 5 && replacement === current; i += 1) replacement = mint(length);
  if (replacement === current) replacement = `${current}x`;

  return username.slice(0, tokenAt) + replacement + username.slice(tokenEnd);
}

/**
 * Gateway statuses that a fresh session can plausibly fix.
 *
 * 407 is deliberately EXCLUDED: it means the credentials themselves were rejected, which no new
 * session token repairs. Rotating on it would spin against a configuration error, consuming the
 * plan's session allowance and masking the actual cause behind a stream of "healed" log lines.
 */
const ROTATABLE_GATEWAY_STATUSES: ReadonlySet<number> = new Set([502, 503, 504]);

/**
 * Signatures of a proxy tunnel that was never established, across both transports.
 *
 * undici (fast tier) rejects a failed CONNECT with `Proxy response (502) !== 200 when HTTP
 * Tunneling`; Chromium (browser tier) surfaces `ERR_TUNNEL_CONNECTION_FAILED`. Both are matched
 * loosely on purpose — an over-specific string match is the classic way a detector like this
 * silently never fires after an upstream wording change, which would restore the exact outage it
 * exists to prevent.
 */
const TUNNEL_STATUS_RE = /proxy\s+response\s*\((\d{3})\)/i;
const TUNNEL_PHRASE_RE =
  /err_tunnel_connection_failed|err_proxy_connection_failed|when http tunneling|session has ended|session expired/i;

/**
 * Flatten an error's `cause` chain into one lowercase haystack.
 *
 * REQUIRED, not defensive. Node's `fetch` reports every transport fault as a bare
 * `TypeError: fetch failed` and hides the real error in `.cause`, so a matcher that reads only
 * `err.message` sees the useless outer wrapper and concludes "not a tunnel failure" — every time,
 * for the one condition this module exists to catch.
 */
export function errorChainText(err: unknown): string {
  const parts: string[] = [];
  let current: unknown = err;
  for (let depth = 0; current !== null && current !== undefined && depth < 8; depth += 1) {
    if (current instanceof Error) {
      parts.push(current.message);
      const code = (current as { code?: unknown }).code;
      if (typeof code === 'string') parts.push(code);
      current = (current as { cause?: unknown }).cause;
    } else {
      parts.push(String(current));
      break;
    }
  }
  return parts.join(' | ').toLowerCase();
}

/**
 * Is this thrown error a dead/refused proxy tunnel that a new session token could fix?
 *
 * `receivedResponse` is the structural guard that separates a GATEWAY 502 from an INSTAGRAM 502,
 * and it is the reason this cannot misfire on the origin: a tunnel failure means no response was
 * ever received, so any caller that HAS a response must pass true and is refused here. Callers
 * must also gate on actually being on a proxied route — on the home connection there is no tunnel
 * and nothing to rotate.
 */
export function isProxySessionFailure(err: unknown, receivedResponse = false): boolean {
  if (receivedResponse) return false;
  const text = errorChainText(err);
  if (text === '') return false;

  const status = TUNNEL_STATUS_RE.exec(text);
  if (status !== null) {
    const code = Number(status[1]);
    return ROTATABLE_GATEWAY_STATUSES.has(code);
  }
  return TUNNEL_PHRASE_RE.test(text);
}

/** What one heal attempt did. Every outcome is reportable; none of them throw. */
export type HealOutcome =
  /** A new session token is in force. The caller may retry ONCE. */
  | 'rotated'
  /** Rotated too recently — the caller must not retry, to avoid a rotation storm. */
  | 'rate-limited'
  /** Consecutive rotations have not helped, so the session is not what is broken. */
  | 'exhausted'
  /** This route has no session token to rotate (home connection, or a non-sticky proxy). */
  | 'unavailable';

export interface ProxySessionHealerOptions {
  /**
   * Consecutive rotations, with no healthy probe in between, before the healer gives up.
   *
   * Small on purpose. A genuinely expired session is fixed by the FIRST rotation; a second or
   * third failing identically is evidence the fault is elsewhere (gateway down, credit exhausted,
   * no network), and continuing would burn the plan's session allowance while hiding the real
   * cause behind a stream of successful-looking heals.
   */
  maxConsecutive?: number;
  /**
   * Floor on the interval between rotations.
   *
   * The fleet probes concurrently, so a single dead session produces a BURST of simultaneous
   * failures — without this, every one of them would rotate, and the later rotations would discard
   * the working session the first one had just obtained.
   */
  minIntervalMs?: number;
  now?: () => number;
}

const DEFAULT_MAX_CONSECUTIVE = 3;
const DEFAULT_MIN_INTERVAL_MS = 30_000;

/**
 * Bounds on session rotation, kept in one place so the probe path cannot accidentally loop.
 *
 * Deliberately NOT persisted. A restart is the one moment we genuinely do not know whether the
 * session is alive, and a stored "exhausted" would carry a dead verdict into a process that has
 * never measured the route — suppressing the first, cheapest, most likely-to-work rotation and
 * leaving the fleet dark for exactly the reason this module was written.
 */
export class ProxySessionHealer {
  private readonly maxConsecutive: number;
  private readonly minIntervalMs: number;
  private readonly now: () => number;
  private consecutive = 0;
  private lastRotatedAtMs: number | null = null;

  constructor(options: ProxySessionHealerOptions = {}) {
    this.maxConsecutive = options.maxConsecutive ?? DEFAULT_MAX_CONSECUTIVE;
    this.minIntervalMs = options.minIntervalMs ?? DEFAULT_MIN_INTERVAL_MS;
    this.now = options.now ?? Date.now;
  }

  /**
   * Try to heal. `rotate` performs the actual mutation and reports whether a token was replaced;
   * it is only invoked once every bound above has been satisfied.
   */
  attempt(rotate: () => boolean): HealOutcome {
    if (this.consecutive >= this.maxConsecutive) return 'exhausted';

    const now = this.now();
    const last = this.lastRotatedAtMs;
    // `now - last < 0` guards a clock that moved backwards: treating a negative gap as "long
    // enough" would let the burst this interval exists to suppress through unchallenged.
    if (last !== null && now - last < this.minIntervalMs) return 'rate-limited';

    if (!rotate()) return 'unavailable';

    this.consecutive += 1;
    this.lastRotatedAtMs = now;
    return 'rotated';
  }

  /**
   * Report that the route is working again, clearing the give-up counter.
   *
   * Called on any probe that actually reached Instagram — which is what makes `maxConsecutive` a
   * bound on *consecutive futile* rotations rather than a lifetime cap. Without this, a bot that
   * healed successfully three times over three days would refuse to heal a fourth time forever.
   */
  noteHealthy(): void {
    this.consecutive = 0;
  }

  /** Diagnostics for the owner-facing health surfaces. Credential-free by construction. */
  snapshot(): { consecutive: number; exhausted: boolean; lastRotatedAtMs: number | null } {
    return {
      consecutive: this.consecutive,
      exhausted: this.consecutive >= this.maxConsecutive,
      lastRotatedAtMs: this.lastRotatedAtMs,
    };
  }
}
