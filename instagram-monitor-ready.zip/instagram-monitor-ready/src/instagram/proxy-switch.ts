/**
 * Runtime-switchable egress route, and the switch-then-VERIFY flow behind `/proxy`.
 *
 * The browser and the HTTP probe both ask this object which proxy (if any) to use, instead of
 * reading `config.browserProxy` directly. That makes the egress path changeable at RUNTIME —
 * so the owner can flip between the home connection and a mobile proxy with a bot command,
 * without editing `.env` and restarting.
 *
 * Switching bumps a generation counter. Consumers that cache a connection (the browser, the
 * undici dispatcher) compare generations and rebuild themselves when it changes, so a switch
 * takes effect on the very next check.
 *
 * WHY THE VERIFICATION LIVES HERE. The two routes are not equally valid, and which one works
 * depends on the HOST, not on the config:
 *
 *   - on the owner's home PC, 'direct' is a residential IP that Instagram serves normally;
 *   - on the VPS, 'direct' is a datacenter IP that Instagram answers with HTTP 429 — measured
 *     0/9 identity. A fleet switched to 'direct' there detects NO recoveries at all.
 *
 * `set()` cannot tell those apart: it only knows whether a proxy is configured. So a bare
 * `set()` + "✅ switched" reply was a confident claim backed by nothing, and on the VPS it
 * silently blinded every monitored client (harm rank 1). {@link switchEgressRoute} is the only
 * thing the command surfaces should call: it switches, then MEASURES the new route against the
 * control account, and reports what it actually found.
 */

import type { Detector } from '../domain';
import type { Logger } from '../logging';
import type { AppConfig } from '../config';
// Deep import (not the detector barrel) so this module never pulls Playwright into scope — the
// command surfaces import it, and they must stay browser-free. The reverse edge is type-only.
import { detectorDiagnostics } from './detector/tiered-detector';
import type { FastTierReport } from './detector/tiered-detector';
import { hasRotatableSession, rotateSessionToken } from './proxy-session';

export type ProxyMode = 'direct' | 'proxy';

export interface ProxySettings {
  server: string;
  username: string | null;
  password: string | null;
}

export interface ProxyState {
  mode: ProxyMode;
  /** The proxy in use, or null when running direct. */
  active: ProxySettings | null;
  /** Whether a proxy is even configured (i.e. whether 'proxy' mode is available). */
  configured: boolean;
  /** Increments on every change; consumers rebuild cached connections when it moves. */
  generation: number;
}

/**
 * How long an auto-reverted route stays "insistable".
 *
 * Repeat the SAME `/proxy` command inside this window and the switch is honoured instead of being
 * reverted a second time — the owner may be deliberately moving to a route they know is down (a
 * proxy whose credit has run out, a home line about to come back). One protective revert is a
 * safety net; two in a row would be the command refusing to obey.
 *
 * Long enough to read the warning and retype, short enough that the same command tomorrow gets
 * the safety net again.
 */
export const EGRESS_INSIST_WINDOW_MS = 10 * 60 * 1000;

/**
 * Outer bound on the post-switch verification.
 *
 * The Telegram polling loop awaits update handlers ONE AT A TIME, so an unbounded verification
 * would freeze all bot ingress — including the `/ping` the owner would run to find out why. The
 * inner control probe already caps itself at `min(checkTimeoutMs, 20s)`; this leaves margin for
 * it to finish and be reported rather than pre-empted.
 *
 * Covers the WHOLE command, both readings included — the confirming measurement is given only
 * what the first one left, so this stays the real ceiling on the ingress freeze rather than half
 * of it.
 */
export const EGRESS_VERIFY_TIMEOUT_MS = 25_000;

export class ProxySwitch {
  private mode: ProxyMode;
  private generation = 0;
  /**
   * NOT readonly, because {@link rotateSession} replaces the sticky-session token inside the
   * username. Every read goes through {@link current}, so consumers that cache a connection see
   * the change through the generation counter exactly as they do for a `/proxy` switch.
   */
  private configured: ProxySettings | null;
  /**
   * The last route an auto-revert overrode, and when. Lives HERE rather than in a command handler
   * because ONE ProxySwitch is shared by the Telegram and Discord surfaces: kept per-surface, a
   * `/proxy direct` on Telegram followed by the same command on Discord would look like two first
   * attempts and could never be made to stick.
   */
  private lastReverted: { mode: ProxyMode; atMs: number } | null = null;

  constructor(config: AppConfig, initialMode?: ProxyMode) {
    this.configured = config.browserProxy;
    // PROXY_MODE decides the starting route, so a host can have the proxy CONFIGURED but start
    // on its own connection — which is exactly what makes `/proxy mobile` available on a machine
    // that normally runs direct. Falls back to 'direct' if 'proxy' is asked for with none set.
    const wanted = initialMode ?? config.proxyMode;
    this.mode = wanted === 'proxy' && this.configured === null ? 'direct' : wanted;
  }

  /** The proxy to use right now, or null for a direct connection. */
  current(): ProxySettings | null {
    return this.mode === 'proxy' ? this.configured : null;
  }

  state(): ProxyState {
    return {
      mode: this.mode,
      active: this.current(),
      configured: this.configured !== null,
      generation: this.generation,
    };
  }

  /**
   * Switch egress. Returns false (without changing anything) when asking for 'proxy' but none
   * is configured. A no-op switch does NOT bump the generation, so it never forces a needless
   * browser restart.
   *
   * NOT for command handlers — it reports only whether a proxy is CONFIGURED, never whether the
   * selected route can actually reach Instagram. Use {@link switchEgressRoute}.
   */
  set(mode: ProxyMode): boolean {
    if (mode === 'proxy' && this.configured === null) return false;
    if (mode === this.mode) return true;
    this.mode = mode;
    this.generation += 1;
    return true;
  }

  /** Generation counter — consumers cache against this. */
  gen(): number {
    return this.generation;
  }

  /**
   * Replace the sticky-session token in the configured proxy's username, so the next connection
   * is issued a FRESH session (and a fresh exit IP) by the gateway.
   *
   * Returns false — changing nothing, and NOT bumping the generation — when there is nothing to
   * rotate: no proxy configured, no username, no session segment, or the fleet is currently on the
   * home route where there is no tunnel to repair. A needless bump is not free: it forces every
   * consumer to tear down and rebuild a perfectly good browser and dispatcher.
   *
   * Bumping the generation deliberately also re-binds the circuit breaker (`adoptRoute`), which
   * discards back-off earned on the old session. That is correct rather than incidental: a rotated
   * session is a DIFFERENT exit IP, so throttle evidence gathered against the previous one no
   * longer describes the route the fleet is on.
   *
   * The new username is never returned or logged — it contains the token, and it is a credential.
   */
  rotateSession(): boolean {
    const settings = this.configured;
    if (this.mode !== 'proxy' || settings === null || settings.username === null) return false;
    const rotated = rotateSessionToken(settings.username);
    if (rotated === null) return false;
    this.configured = { ...settings, username: rotated };
    this.generation += 1;
    return true;
  }

  /** Does the current route carry a sticky session that {@link rotateSession} could replace? */
  canRotateSession(): boolean {
    return this.mode === 'proxy' && hasRotatableSession(this.configured?.username ?? null);
  }

  /** Record that an auto-revert overrode a request for `mode`, so a repeat can insist. */
  noteAutoReverted(mode: ProxyMode, nowMs: number): void {
    this.lastReverted = { mode, atMs: nowMs };
  }

  /** Is this request a deliberate repeat of one that was just auto-reverted? */
  isDeliberateRepeat(mode: ProxyMode, nowMs: number): boolean {
    const last = this.lastReverted;
    return (
      last !== null &&
      last.mode === mode &&
      nowMs - last.atMs >= 0 &&
      nowMs - last.atMs <= EGRESS_INSIST_WINDOW_MS
    );
  }

  /** Forget the last auto-revert — any outcome that did NOT revert clears the insist state. */
  clearAutoRevert(): void {
    this.lastReverted = null;
  }

  /** Host:port only, safe to show in a chat reply (never the credentials). */
  describe(): string {
    if (this.mode === 'direct') return 'direct (this machine’s own connection)';
    const s = this.configured;
    if (s === null) return 'direct (no proxy configured)';
    try {
      // A schemeless "host:port" parses as a URL whose *protocol* is the host, yielding an
      // empty hostname — which would print a meaningless "proxy :80" and hide the
      // misconfiguration. Default the scheme so the real host is shown either way.
      const raw = /^[a-z][a-z0-9+.-]*:\/\//i.test(s.server) ? s.server : `http://${s.server}`;
      const u = new URL(raw);
      if (u.hostname === '') return 'proxy (malformed BROWSER_PROXY_SERVER)';
      return `proxy ${u.hostname}:${u.port || '80'}`;
    } catch {
      return 'proxy (malformed BROWSER_PROXY_SERVER)';
    }
  }
}

/**
 * The words the owner types. The canonical pair is `home` and `vps`, named after WHERE the
 * traffic leaves from, because that is what actually differs and what the owner reasons about:
 *
 *   /proxy home  -> this machine's own connection. On the owner's PC that is the residential
 *                   line (free, measured 3/3 identity at ~423 ms).
 *   /proxy vps   -> the configured proxy, currently Decodo mobile (metered per GB, 9/9 at
 *                   ~557 ms), which is what keeps monitoring alive while the PC is off.
 *
 * `direct` and `mobile` remain accepted so older habits, docs and scripts keep working.
 */
export type EgressRouteWord = 'direct' | 'mobile';

/**
 * Parse a `/proxy` argument. Returns null for anything unrecognised so both surfaces reject
 * identically.
 */
export function parseEgressRoute(input: string): EgressRouteWord | null {
  const token = input.trim().toLowerCase();
  if (token === 'home' || token === 'direct') return 'direct';
  if (token === 'vps' || token === 'mobile' || token === 'decodo') return 'mobile';
  return null;
}

/**
 * What a control-account measurement concluded about the route now in force.
 *
 * Three states, not two. "I could not look" is NOT "I looked and saw nothing": reporting a
 * breaker-blocked or timed-out check as a blind route would be a confident wrong diagnosis, and
 * it would trigger an auto-revert on no evidence at all.
 */
export interface EgressVerification {
  status: 'verified' | 'blind' | 'unverified';
  /** Short, credential-free explanation. Always populated. */
  detail: string;
  /**
   * Wall-clock milliseconds the measurement took, or null when no FRESH measurement is
   * guaranteed (a no-op switch can be answered from the canary's cache, and reporting ~0 ms as
   * "the route responded in 0 ms" would be a fabricated reading).
   */
  latencyMs: number | null;
}

/** The result of one `/proxy <route>`, rendered by `egressSwitchResult` on both surfaces. */
export type EgressSwitchOutcome =
  /** 'mobile' asked for with no BROWSER_PROXY_SERVER set. Nothing changed. */
  | { kind: 'unavailable'; current: string }
  /** Already on the requested route. Nothing changed — but the route was still measured. */
  | {
      kind: 'unchanged';
      current: string;
      requested: EgressRouteWord;
      verification: EgressVerification;
      alternative: EgressRouteWord | null;
    }
  /** The route changed and the measurement did not say "blind". */
  | {
      kind: 'switched';
      current: string;
      requested: EgressRouteWord;
      verification: EgressVerification;
      alternative: EgressRouteWord | null;
    }
  /** The route changed, could not see Instagram, and was put back. */
  | {
      kind: 'reverted';
      attempted: string;
      current: string;
      requested: EgressRouteWord;
      detail: string;
    }
  /** The route changed, cannot see Instagram, and was LEFT there because the owner insisted. */
  | {
      kind: 'kept-blind';
      current: string;
      requested: EgressRouteWord;
      detail: string;
      alternative: EgressRouteWord | null;
    };

export interface EgressSwitchDeps {
  proxySwitch: ProxySwitch;
  /** The SAME detector the fleet uses, so the measurement is of the fleet's actual route. */
  detector: Detector;
  logger: Logger;
  /** Wall clock — real time, for the measured latency and the insist window. Tests inject. */
  now?: () => number;
  /** Outer bound on the verification. Tests inject. */
  timeoutMs?: number;
}

const TIMED_OUT = Symbol('egress-verify-timeout');

/** Race a promise against a timer, always clearing the timer so no handle is left dangling. */
function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T | typeof TIMED_OUT> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<typeof TIMED_OUT>((resolve) => {
    timer = setTimeout(() => resolve(TIMED_OUT), ms);
  });
  return Promise.race([promise, timeout]).finally(() => {
    clearTimeout(timer);
  });
}

/** The route word that is NOT the requested one, or null when it is not selectable. */
function otherRoute(requested: EgressRouteWord, configured: boolean): EgressRouteWord | null {
  if (requested === 'direct') return configured ? 'mobile' : null;
  return 'direct';
}

/**
 * Measure whether the route currently in force is being served live Instagram profiles.
 *
 * USES THE CHEAP TIER, DELIBERATELY. `fastTierReport()` costs at most ONE plain HTTP GET of the
 * control account (~1 request, ~0.5s) and never a Chromium page load (20-50 requests, 4-12s), so
 * it consumes none of the fleet-wide browser-load budget that protects the shared IP. The signal
 * it reports — `canaryHealthy`, i.e. `identitySignalMatched` on a known-live control account — is
 * also the ONLY one that discriminates a working route from a blind one: HTTP 200 and "no
 * unavailable message" both pass on a login-walled or throttled proxy, so neither is evidence.
 *
 * `state` is deliberately NOT the discriminator. It also goes 'degraded' during an escalation
 * storm, which is a fleet-LOAD problem on a route that is still serving profiles perfectly well;
 * reverting on that would undo a good switch for the wrong reason.
 */
async function verifyEgress(deps: {
  detector: Detector;
  logger: Logger;
  now: () => number;
  timeoutMs: number;
  /** Force a NEW measurement instead of accepting a cached canary verdict. */
  freshCanary: boolean;
}): Promise<EgressVerification> {
  const diagnostics = detectorDiagnostics(deps.detector);
  if (diagnostics === null) {
    return {
      status: 'unverified',
      detail: 'this instance exposes no fast-tier diagnostics, so no route check was possible',
      latencyMs: null,
    };
  }

  const startedAt = deps.now();
  let report: FastTierReport | typeof TIMED_OUT;
  try {
    report = await withTimeout(
      diagnostics.fastTierReport({ freshCanary: deps.freshCanary }),
      deps.timeoutMs,
    );
  } catch (err) {
    deps.logger.warn('egress verification threw', {
      error: err instanceof Error ? err.message : String(err),
    });
    return {
      status: 'unverified',
      detail: 'the control-account check failed before it could reach Instagram',
      latencyMs: null,
    };
  }
  const latencyMs = deps.now() - startedAt;

  if (report === TIMED_OUT) {
    return {
      status: 'unverified',
      detail: `the control-account check did not finish within ${Math.round(deps.timeoutMs / 1000)}s`,
      latencyMs: null,
    };
  }
  // The breaker refused to touch the network, so nothing was observed. Calling that "blind" would
  // blame the route for a back-off that was earned elsewhere.
  if (report.state === 'blocked') {
    return { status: 'unverified', detail: report.detail, latencyMs: null };
  }
  // Browser-only detector: it never measures a canary, so there is no verdict to read.
  if (report.state === 'disabled') {
    return { status: 'unverified', detail: report.detail, latencyMs: null };
  }
  if (report.canaryHealthy) {
    return { status: 'verified', detail: report.detail, latencyMs };
  }
  return { status: 'blind', detail: report.detail, latencyMs };
}

/**
 * `/proxy <route>` — switch egress and then tell the owner the TRUTH about what happened.
 *
 * Shared verbatim by the Telegram and Discord surfaces (they already share one ProxySwitch, so
 * the state genuinely matches; sharing the decision too is what keeps the WORDING matching).
 *
 * AUTO-REVERT, and why. A `/proxy direct` on the VPS selects a datacenter IP that Instagram
 * refuses outright — measured 0/9 identity, HTTP_429 on every probe. Leaving the fleet there and
 * merely warning would mean every monitored client's recovery goes unnoticed for as long as the
 * owner takes to read the message: harm rank 1, at fleet scale, from one mistyped word. Reverting
 * restores the route the fleet was already running on, so the worst case of a revert is exactly
 * the state that existed one second before the command — it can never make things worse than not
 * having typed it. The owner is told, in the same message, precisely what was tried, what was
 * found, and where they now are.
 *
 * THE REVERT IS A TRANSACTION OVER THE BACK-OFF TOO, and that is not a detail. Selecting a route
 * is what makes it measurable, so by the time the verdict arrives the detector has already told
 * the shared {@link CircuitBreaker} it moved, and the breaker has cleared the block belonging to
 * the route we are about to return to — in memory AND in the store. Putting back only the route
 * therefore used to leave the fleet hammering a still-throttled IP with its fleet-wide brake
 * released, under a reply that said nothing had changed: the harm-rank-3 -> harm-rank-1 cascade,
 * reached by the most natural reaction to a throttle (try the other route). The checkpoint below
 * is what makes the sentence above true rather than aspirational.
 *
 * It cannot ping-pong: there is at most ONE verification and ONE revert per command, and the
 * route reverted TO is never re-verified (so it can never trigger a further switch). And it
 * cannot fight a deliberate second attempt: the overridden route is remembered on the shared
 * switch, so repeating the same command within {@link EGRESS_INSIST_WINDOW_MS} is honoured and
 * left in place, with a louder warning instead of a revert.
 */
export async function switchEgressRoute(
  requested: EgressRouteWord,
  deps: EgressSwitchDeps,
): Promise<EgressSwitchOutcome> {
  const { proxySwitch, detector, logger } = deps;
  const now = deps.now ?? Date.now;
  const timeoutMs = deps.timeoutMs ?? EGRESS_VERIFY_TIMEOUT_MS;

  const mode: ProxyMode = requested === 'mobile' ? 'proxy' : 'direct';
  const before = proxySwitch.state();
  if (mode === 'proxy' && !before.configured) {
    return { kind: 'unavailable', current: proxySwitch.describe() };
  }

  const previousMode = before.mode;
  const changed = mode !== previousMode;
  // Read BEFORE the revert bookkeeping below can overwrite it.
  const insisted = changed && proxySwitch.isDeliberateRepeat(mode, now());
  const alternative = otherRoute(requested, before.configured);

  // Captured BEFORE the switch, because selecting the route is what makes the detector clear the
  // back-off earned on the one we are leaving. Null on a detector with no diagnostics surface —
  // which is also a detector that can never report `blind`, so it can never reach the revert.
  const diagnostics = detectorDiagnostics(detector);
  const backOffBefore = diagnostics?.captureBackOff?.() ?? null;

  proxySwitch.set(mode);
  const attempted = proxySwitch.describe();

  const verifyStartedAt = now();
  let verification = await verifyEgress({ detector, logger, now, timeoutMs, freshCanary: false });

  // CONFIRM BEFORE OVERRIDING THE OWNER, WITH A SECOND MEASUREMENT — not a second look at the
  // first one's cache.
  //
  // Two different single-reading failures land here as `blind`, and neither is evidence about the
  // route: a canary already in flight when the route changed is discarded as stale, and any
  // transient blip on the new link (a reset connection, a slow exit, one 429 on a freshly-rotated
  // IP) comes back as "no identity" because `httpProbe` never throws. There is no retry anywhere
  // below this, so without a genuinely fresh reading ONE unlucky HTTP GET auto-reverts a route the
  // owner deliberately selected — and in the VPS shape reverts INTO the blind one.
  //
  // `freshCanary` is what makes it a measurement: `canaryOk` caches a failure for CANARY_RETRY_MS,
  // so a plain second report milliseconds later was answered from the cache the failure had just
  // written and confirmed itself having measured nothing. The cost is one extra cheap HTTP GET on
  // a rare owner command — never a Chromium load — and it buys the difference between one probe
  // and two deciding whether the fleet moves.
  //
  // Only a CONCLUSIVE second reading may cancel the revert. "I could not look" (timeout, breaker,
  // no diagnostics) is not counter-evidence, and letting it through would leave the fleet on a
  // route whose only actual measurement said blind.
  if (verification.status === 'blind' && changed && !insisted) {
    // ONE budget across both readings. The documented outer bound exists because the Telegram
    // polling loop awaits handlers one at a time, so two independently-timed readings would freeze
    // ALL bot ingress for twice as long as the constant promises. In practice this is never tight:
    // a first reading that spent the whole budget TIMED OUT, which is 'unverified' and never
    // reaches here.
    const remainingMs = timeoutMs - (now() - verifyStartedAt);
    const confirmation =
      remainingMs > 0
        ? await verifyEgress({ detector, logger, now, timeoutMs: remainingMs, freshCanary: true })
        : null;
    if (confirmation !== null && confirmation.status === 'verified') {
      logger.info('egress verification recovered on a second reading; not reverting', {
        requested,
        first: verification.detail,
      });
      verification = confirmation;
    }
  }

  if (verification.status === 'blind' && changed && !insisted) {
    proxySwitch.set(previousMode);
    // Route first, THEN the back-off: `restoreBackOff` binds the restored block to the generation
    // in force when it is called, and that must be the reverted route's.
    if (backOffBefore !== null) diagnostics?.restoreBackOff?.(backOffBefore);
    proxySwitch.noteAutoReverted(mode, now());
    logger.warn('egress switch REVERTED: the requested route cannot see Instagram', {
      requested,
      detail: verification.detail,
    });
    return {
      kind: 'reverted',
      attempted,
      current: proxySwitch.describe(),
      requested,
      detail: verification.detail,
    };
  }

  // Any outcome that did not revert clears the insist state: the next `/proxy` to this route
  // starts again from a clean safety net rather than inheriting an old override.
  proxySwitch.clearAutoRevert();

  if (verification.status === 'blind' && changed) {
    logger.error('egress switched to a route that CANNOT see Instagram (owner insisted)', {
      requested,
      detail: verification.detail,
    });
    return {
      kind: 'kept-blind',
      current: proxySwitch.describe(),
      requested,
      detail: verification.detail,
      alternative,
    };
  }

  logger.info('egress route command handled', {
    requested,
    changed,
    verification: verification.status,
  });
  return {
    kind: changed ? 'switched' : 'unchanged',
    current: proxySwitch.describe(),
    requested,
    verification,
    alternative,
  };
}
