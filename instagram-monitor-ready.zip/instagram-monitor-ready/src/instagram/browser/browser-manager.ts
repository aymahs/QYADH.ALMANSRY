/**
 * Owns exactly ONE Chromium instance (local launch or a remote `BROWSER_WS_ENDPOINT`)
 * and hands out {@link BrowserContext}s. No stealth, ever.
 *
 * CONTEXT REUSE (and why the old "every check starts from a clean context" line is now a
 * default rather than an invariant). Per-host DNS+TCP+TLS setup through the mobile proxy is the
 * dominant cost of a page load: the same avatar settled at 79.8s on a cold context and 18.5s on
 * a second load inside the same one, and the profile page touches ~14 hosts. A caller may
 * therefore name a `contextKey` and get a KEPT-WARM context whose connections are already open.
 * It buys that purely by reusing what is already there — it adds no page loads, which is the
 * only currency the residential IP actually charges. Contexts are bounded three ways (age, loads
 * served, pool size) and are dropped whenever the egress route changes. Callers that name no key
 * keep the historical fresh-isolated-context behaviour exactly.
 *
 * A tiny internal semaphore bounds concurrent `withPage` work to
 * `config.scheduling.maxBrowserConcurrency`, and a second one reserves a slot for non-capture
 * work so a long capture cannot starve routine checks (see `captureLaneLimit`); the scheduler
 * stays the source of truth for higher-level pacing. Any launch/context failure surfaces as
 * AppError('BROWSER_ERROR').
 */

import { existsSync } from 'node:fs';
import { chromium, type Browser, type BrowserContext, type Page } from 'playwright';
import { captureSettings, type AppConfig } from '../../config';
import type { Logger } from '../../logging';
import { AppError } from '../../domain';
import type { ProxySwitch } from '../proxy-switch';

/**
 * Resource types the CLASSIFIER never looks at. Instagram pulls megabytes of images, fonts and
 * CSS that contribute nothing to ACTIVE/GONE — the decision comes from metadata and text.
 * Aborting them is the single biggest speed win on a slow or metered egress path. They are
 * NOT blocked when a screenshot is being captured, since the picture obviously needs them.
 */
const CLASSIFY_BLOCKED_TYPES = new Set(['image', 'media', 'font', 'stylesheet']);

/**
 * The ONLY resource type a CAPTURE load drops outright. A cropped header card cannot contain a
 * video or an audio track under any layout, and reel previews are the single heaviest thing the
 * profile page pulls. Everything a verdict could conceivably depend on — the document, scripts,
 * xhr/fetch, stylesheets, fonts — is untouched, which is what keeps `classify()` immune to this.
 */
const CAPTURE_BLOCKED_TYPES = new Set(['media']);

/**
 * A 1x1 fully transparent GIF, 43 bytes, generated here and never fetched.
 *
 * Over-budget images are FULFILLED with this rather than aborted. An abort fires the element's
 * `error` path, and Instagram's own JS is free to react to that (retry, error state, re-render);
 * a 200 with a valid image means the page sees nothing unusual at all, `img.complete` still flips
 * to true so the header-image wait can never hang on a blocked request, and the layout box keeps
 * whatever size CSS gave it. No bytes cross the mobile proxy either way.
 */
const TRANSPARENT_PIXEL = Buffer.from(
  'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
  'base64',
);

/** How long close() waits for in-flight probes before tearing the browser down anyway. */
const DRAIN_TIMEOUT_MS = 15_000;

/** Bounded settle for a decisive rendered signal after domcontentloaded. */
const SETTLE_TIMEOUT_MS = 8_000;

/**
 * How long a kept-warm context may live, and how many loads it may serve, before it is retired.
 *
 * Both bounds exist because a reused context is a persistent browser profile: cookies, caches and
 * storage accumulate in it. Ten minutes comfortably spans the window that actually matters — the
 * deciding confirmation check and the capture that follows it seconds later — while guaranteeing
 * that nothing is carried across a monitoring cycle.
 */
const WARM_CONTEXT_TTL_MS = 10 * 60_000;
const WARM_CONTEXT_MAX_LOADS = 25;
/** Ceiling on how many warm contexts are held open at once (each is a real browser profile). */
const MAX_WARM_CONTEXTS = 4;

/**
 * Abort images/media/fonts/CSS for a classification-only load. Instagram pulls megabytes of
 * imagery the classifier never reads — the verdict comes from metadata and text — so dropping
 * them cuts both page time and egress bytes substantially. Routing failures are swallowed:
 * a page that loads everything is slower, never wrong.
 */
async function installAssetBlocker(page: Page): Promise<void> {
  try {
    await page.route('**/*', (route) => {
      const type = route.request().resourceType();
      if (CLASSIFY_BLOCKED_TYPES.has(type)) {
        route.abort().catch(() => undefined);
      } else {
        route.continue().catch(() => undefined);
      }
    });
  } catch {
    // Best effort only.
  }
}

/**
 * Stop paying mobile-proxy bandwidth for pixels the crop throws away.
 *
 * The delivered image is a cropped HEADER CARD — the post grid is discarded — yet the capture
 * load used to fetch the whole grid, and every image still pending at capture time was measured
 * to be a grid thumbnail. The obvious filter is unusable: the SAME `instagram.f*.fna.fbcdn.net`
 * hosts serve the avatar and the thumbnails, so nothing about the host or the path can separate
 * them, and Instagram re-shards both freely.
 *
 * The discriminator used instead is REQUEST ORDER, and it comes straight out of that measurement:
 * the header's images had already settled while the grid's were still in flight, because the
 * header precedes the grid in the document and Chromium requests images as the tree is built. So
 * the first `maxImages` image requests go to the network and everything after that is served the
 * local transparent pixel.
 *
 * FAILS OPEN toward the avatar in three separate ways, deliberately: the budget is several times
 * larger than an avatar plus a full highlight tray; the avatar is among the earliest image
 * requests a profile page makes; and a routing failure here leaves the page loading everything,
 * exactly as before. A card with a grey circle is bad; a card that never arrives is worse.
 *
 * It CANNOT change a verdict. `classify()` reads serialized markup plus the main document's
 * status, and nothing here touches the document, scripts, xhr/fetch, CSS or fonts. A fulfilled
 * image is a 200 — no request failure event exists for Instagram's client-side renderer to react
 * to — and the `<img>` element and its `src` are unchanged in `page.content()`.
 */
async function installCaptureAssetBudget(page: Page, maxImages: number): Promise<void> {
  let imagesRequested = 0;
  try {
    await page.route('**/*', (route) => {
      const type = route.request().resourceType();
      if (type === 'image') {
        imagesRequested += 1;
        if (imagesRequested <= maxImages) {
          route.continue().catch(() => undefined);
          return;
        }
        route
          .fulfill({
            status: 200,
            contentType: 'image/gif',
            // Instagram marks some images `crossorigin`; without this header those would fail
            // CORS and take the error path the fulfil exists to avoid.
            headers: { 'access-control-allow-origin': '*', 'cache-control': 'no-store' },
            body: TRANSPARENT_PIXEL,
          })
          .catch(() => {
            // Fulfilment is best effort; letting it through costs bandwidth, never correctness.
            route.continue().catch(() => undefined);
          });
        return;
      }
      if (CAPTURE_BLOCKED_TYPES.has(type)) {
        route.abort().catch(() => undefined);
        return;
      }
      route.continue().catch(() => undefined);
    });
  } catch {
    // Best effort only — an uninstalled budget means a slower capture, never a wrong one.
  }
}

/** Realistic modern desktop Chrome UA (no stealth — just avoids an obviously-bot default). */
const DESKTOP_USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) ' +
  'Chrome/124.0.0.0 Safari/537.36';

const VIEWPORT = { width: 1280, height: 900 } as const;

export interface BrowserManagerOptions {
  config: AppConfig;
  logger: Logger;
  /** Runtime-switchable egress. When omitted, the static `config.browserProxy` is used. */
  proxySwitch?: ProxySwitch;
}

/**
 * What a page load is FOR. The two jobs need opposite budgets, so they must be distinguishable
 * here rather than sharing one `CHECK_TIMEOUT_MS`: classification reads server-rendered identity
 * metadata (present at domcontentloaded), a capture needs full paint plus the header's images.
 */
export type PagePurpose = 'classify' | 'capture';

/** Per-call knobs for {@link BrowserManager.withPage}. */
export interface PageOptions {
  /**
   * Abort images/media/fonts/CSS. Safe (and much faster) for classification-only loads;
   * must be false whenever a screenshot will be taken.
   */
  blockAssets?: boolean;
  /**
   * Defaults to `'classify'`. `'capture'` gets the longer navigation budget, the post-grid image
   * budget, and a RESERVED LANE in the concurrency semaphore (see
   * {@link BrowserManager.captureLaneLimit}).
   */
  purpose?: PagePurpose;
  /**
   * Reuse a kept-warm {@link BrowserContext} under this key instead of creating a fresh isolated
   * one. Per-host DNS+TCP+TLS setup through the mobile proxy is a dominant cost — the avatar of
   * @instagram settled at 79.8s on a cold context and 18.5s on a second load in the same one —
   * and the page touches ~14 hosts, so this is the single cheapest speed-up available: it reuses
   * connections that are already open and adds no page loads at all.
   *
   * Omit for the historical behaviour (fresh context, closed afterwards).
   */
  contextKey?: string;
}

/** One kept-warm context and the bookkeeping that decides when it must be retired. */
interface WarmContext {
  key: string;
  context: BrowserContext;
  /** Egress generation it was created under; a /proxy switch invalidates it. */
  generation: number;
  createdAtMs: number;
  lastUsedMs: number;
  loads: number;
  /** How many `withPage` calls are inside it right now. */
  inUse: number;
  /** Set once it must not serve another load; closed when the last user leaves. */
  retired: boolean;
}

/** What a `withPage` call holds while it runs, and how it gives it back. */
interface ContextLease {
  context: BrowserContext;
  release: () => Promise<void>;
}

export class BrowserManager {
  private readonly config: AppConfig;
  private readonly logger: Logger;
  private readonly proxySwitch: ProxySwitch | null;

  private browser: Browser | null = null;
  private launching: Promise<Browser> | null = null;
  private readonly contexts = new Set<BrowserContext>();
  /** Egress generation the current browser was launched with. */
  private launchedGeneration = -1;
  /** Egress generation the in-flight launch is for, so a stale launch is never reused. */
  private launchingGeneration = -1;

  // Concurrency semaphore for withPage().
  private active = 0;
  private readonly waiters: Array<() => void> = [];
  // Sub-semaphore that keeps captures from occupying every slot. See captureLaneLimit().
  private capturesActive = 0;
  private readonly captureWaiters: Array<() => void> = [];
  /** Kept-warm contexts by caller-supplied key. */
  private readonly warm = new Map<string, WarmContext>();
  /** Did at least one context actually receive the configured owner-created storage state? */
  private storageStateApplied = false;
  /** Once rejected, no new context in this process may inherit the challenged session. */
  private storageStateQuarantined = false;

  constructor(options: BrowserManagerOptions) {
    this.config = options.config;
    this.logger = options.logger;
    this.proxySwitch = options.proxySwitch ?? null;
  }

  /**
   * Lazily launch or connect the single shared browser. A locally-launched Chromium binds its
   * proxy at launch, so if the egress route was switched at runtime the browser is torn down
   * and relaunched — that is what makes /proxy take effect on the very next check.
   */
  private async ensureBrowser(): Promise<Browser> {
    const gen = this.proxySwitch?.gen() ?? 0;
    if (this.browser && this.browser.isConnected() && this.launchedGeneration === gen) {
      return this.browser;
    }
    // A launch already under way for THIS generation is shared; one for a stale generation is
    // awaited and then superseded, so a switch is never silently served by the old egress.
    if (this.launching !== null && this.launchingGeneration === gen) return this.launching;
    if (this.launching !== null) {
      await this.launching.catch(() => undefined);
      if (this.browser && this.browser.isConnected() && this.launchedGeneration === gen) {
        return this.browser;
      }
    }

    this.launchingGeneration = gen;
    this.launching = (async (): Promise<Browser> => {
      const stale = this.browser;
      if (stale !== null) {
        this.logger.info('egress changed; replacing browser');
        // Detach FIRST, then dispose in the background. Disposing inline would deadlock: the
        // caller holds a withPage semaphore slot, so a draining close() could never observe
        // active === 0 and would burn its whole timeout before force-closing the contexts of
        // every other in-flight probe. Only new contexts come from the replacement.
        //
        // SIBLING PROBES DO NOT SURVIVE THIS, and pretending otherwise (an earlier version of
        // this comment did) hid a real failure. `stale.close()` closes its contexts and pages, so
        // every probe in flight dies with "Target closed" / a cancelled navigation — i.e. as
        // BROWSER_CRASH or NAVIGATION. That is UNAVOIDABLE and it is CORRECT: the whole point of
        // the switch is that no further byte leaves over the abandoned route, and delaying the
        // close to let siblings finish would keep traffic on an IP the owner just abandoned
        // (harm rank 3). What must not happen is those self-inflicted deaths being mistaken for
        // evidence — so they are INCONCLUSIVE to the circuit breaker (see `breakerOutcomeForCode`)
        // and they must not trigger a crash-restart of the browser that just replaced this one
        // (see `isCurrentEgress`).
        this.browser = null;
        this.contexts.clear();
        // Warm contexts belong to the browser that is going away, and their whole value is the
        // live connections inside them — which die with it. Forget them here as well as at the
        // generation check, so nothing can hand out a handle to a closing context.
        this.warm.clear();
        void stale.close().catch(() => undefined);
      }
      return this.launchBrowser();
    })();

    try {
      this.browser = await this.launching;
      this.launchedGeneration = gen;
      return this.browser;
    } finally {
      this.launching = null;
    }
  }

  private async launchBrowser(): Promise<Browser> {
    try {
      if (this.config.browserWsEndpoint) {
        this.logger.debug('connecting to remote browser');
        return await chromium.connect(this.config.browserWsEndpoint);
      }
      this.logger.debug('launching local chromium', { proxied: this.config.browserProxy !== null });
      // Container-hardening flags: `--disable-dev-shm-usage` makes Chromium use /tmp instead
      // of the tiny (often 64MB) /dev/shm that container runtimes give, which otherwise
      // crashes it while rendering heavy pages; `--no-sandbox` is required when the sandbox
      // cannot be set up in the container. Only navigates to instagram.com, so this is safe.
      const proxy = this.proxyOption();
      return await chromium.launch({
        headless: true,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-gpu',
        ],
        ...(proxy !== undefined ? { proxy } : {}),
      });
    } catch (err) {
      throw new AppError(
        'BROWSER_ERROR',
        'Failed to launch or connect the browser',
        err instanceof Error ? err.message : undefined,
      );
    }
  }

  /**
   * Playwright proxy option built from config, or undefined when unproxied. Applied at BOTH
   * launch (local Chromium) and context level — the context is what carries the proxy when the
   * browser is a REMOTE one reached over BROWSER_WS_ENDPOINT, where we never call launch().
   */
  private proxyOption(): { server: string; username?: string; password?: string } | undefined {
    // The runtime switch wins when present, so /proxy can change egress without a restart.
    const p = this.proxySwitch !== null ? this.proxySwitch.current() : this.config.browserProxy;
    if (p === null) return undefined;
    return {
      server: p.server,
      ...(p.username !== null ? { username: p.username } : {}),
      ...(p.password !== null ? { password: p.password } : {}),
    };
  }

  /** Fresh, isolated context with a strict default timeout. Caller MUST close it. */
  async newContext(): Promise<BrowserContext> {
    const browser = await this.ensureBrowser();
    try {
      const contextOptions: Parameters<Browser['newContext']>[0] = {
        viewport: { ...VIEWPORT },
        // 2x (retina) so profile-header screenshots render crisp and larger, not soft/small.
        deviceScaleFactor: 2,
        userAgent: DESKTOP_USER_AGENT,
        locale: 'en-US',
      };
      const proxy = this.proxyOption();
      if (proxy !== undefined) contextOptions.proxy = proxy;
      // Opt-in logged-in mode: reuse a session file the OWNER created by logging in manually.
      // Only when the file actually exists — otherwise run logged-out (the default) rather
      // than crash. The path is never logged; the file itself is the owner's login secret.
      if (this.config.igStorageState && !this.storageStateQuarantined) {
        if (existsSync(this.config.igStorageState)) {
          contextOptions.storageState = this.config.igStorageState;
          this.storageStateApplied = true;
        } else {
          this.logger.warn('IG_STORAGE_STATE set but file not found; running logged-out');
        }
      }
      const context = await browser.newContext(contextOptions);
      // The context default is the CLASSIFY budget; a capture page raises its own in withPage().
      // It has to be per-page now, because one warm context serves loads of both purposes.
      const timeout = this.config.scheduling.checkTimeoutMs;
      context.setDefaultTimeout(timeout);
      context.setDefaultNavigationTimeout(timeout);
      this.contexts.add(context);
      context.on('close', () => this.contexts.delete(context));
      return context;
    } catch (err) {
      throw new AppError(
        'BROWSER_ERROR',
        'Failed to create a browser context',
        err instanceof Error ? err.message : undefined,
      );
    }
  }

  /**
   * The ONE settle wait before classification, and it is deliberately the only one.
   *
   * Every branch `classify()` can take is covered here:
   *   - ACTIVE by rendered structure -> `header`, `main [role="tablist"]`, `main img`
   *   - GONE                          -> the client-rendered "this page isn't available" copy
   *   - ACTIVE by identity            -> og:url / og:title / canonical, which Instagram
   *     SERVER-renders into <head> and are therefore already present at domcontentloaded
   *     (the HTTP probe classifies from exactly that markup, with no JS at all).
   *
   * So once this resolves, the decisive evidence for both verdicts is attached.
   */
  private static readonly SETTLE_SELECTOR =
    'header, main [role="tablist"], main img, ' +
    ':text("this page isn\'t available"), :text("this page isn’t available")';

  /**
   * Navigate to a URL (domcontentloaded, capped) and return the HTTP status, if any.
   *
   * `timeoutMs` exists because ONE ceiling cannot serve both jobs. A capture load carries CSS,
   * fonts and the header's images, and one blocking resource from static.cdninstagram.com was
   * measured at 107s on its own — so under the classify budget the goto was aborted and the
   * account could not even be CLASSIFIED, which is how two of three production accounts came
   * back UNKNOWN/TIMEOUT with no image. Omit it and the classify budget applies, as before.
   */
  async loadProfile(
    page: Page,
    url: string,
    options: { timeoutMs?: number } = {},
  ): Promise<number | null> {
    const timeout = options.timeoutMs ?? this.config.scheduling.checkTimeoutMs;
    const response = await page.goto(url, {
      waitUntil: 'domcontentloaded',
      timeout,
    });
    // Instagram hydrates the body client-side after domcontentloaded. Give it a bounded
    // chance to render a decisive signal (profile header, or the unavailable message)
    // before the caller serializes page.content() — otherwise body-dependent signals are
    // missing and every live check degrades to UNKNOWN. Best-effort: a page that never
    // settles simply falls through to classification on whatever has rendered.
    const settleMs = Math.min(SETTLE_TIMEOUT_MS, timeout);
    await page
      .waitForSelector(BrowserManager.SETTLE_SELECTOR, { timeout: settleMs, state: 'attached' })
      .catch(() => undefined);
    // REMOVED (deliberately, and the removal was contested): a
    // `waitForLoadState('networkidle', { timeout: 2500 })` used to sit here. Instagram never
    // reaches networkidle — measured zero times in 120s across three accounts — so it could only
    // ever burn its full 2500ms on EVERY browser load, on the critical path of a recovery alert.
    //
    // The objection on record was that removing it might make `classify()` read a half-populated
    // DOM. It cannot: the selector above is a superset of what classify() reads (see
    // SETTLE_SELECTOR), and this wait ran strictly AFTER it, so it added no coverage — only
    // delay. It is also not a capture gate: the screenshot path polls its own paint predicate.
    return response ? response.status() : null;
  }

  /**
   * Run `fn` with a page, honoring the concurrency limit and ALWAYS releasing what it took
   * (even on throw). The page is always closed; the CONTEXT is closed too unless it is a warm
   * one being kept for the next load.
   */
  async withPage<T>(
    fn: (page: Page, context: BrowserContext) => Promise<T>,
    options: PageOptions = {},
  ): Promise<T> {
    const isCapture = options.purpose === 'capture';
    // Order matters: the capture lane is taken BEFORE the shared semaphore, never while holding
    // it. A capture that is waiting for a lane token therefore occupies no slot, so the two
    // gates cannot deadlock against each other.
    if (isCapture) await this.acquireCaptureLane();
    try {
      await this.acquire();
      try {
        const lease = await this.leaseContext(options.contextKey);
        let page: Page | null = null;
        try {
          page = await lease.context.newPage();
          // Per-PAGE, not per-context: one warm context serves classify and capture loads alike,
          // so the budget has to travel with the job rather than with the profile.
          const timeout = isCapture
            ? captureSettings(this.config).timeoutMs
            : this.config.scheduling.checkTimeoutMs;
          page.setDefaultTimeout(timeout);
          page.setDefaultNavigationTimeout(timeout);
          if (options.blockAssets === true) {
            await installAssetBlocker(page);
          } else if (isCapture) {
            await installCaptureAssetBudget(page, captureSettings(this.config).maxImages);
          }
          return await fn(page, lease.context);
        } finally {
          // Closing the page first drops its routes and its in-flight requests, so a retired
          // warm context never lingers on work from the load that just ended.
          if (page !== null) await page.close().catch(() => undefined);
          await lease.release();
        }
      } finally {
        this.release();
      }
    } finally {
      if (isCapture) this.releaseCaptureLane();
    }
  }

  /**
   * Take a context for one load: a kept-warm one when the caller named a key, otherwise a fresh
   * isolated one exactly as before. A warm context is retired (and closed once its last user
   * leaves) when it ages out, has served enough loads, or belongs to a superseded egress route.
   */
  private async leaseContext(key: string | undefined): Promise<ContextLease> {
    if (key === undefined || key === '') {
      const context = await this.newContext();
      return { context, release: () => context.close().catch(() => undefined) };
    }

    const gen = this.proxySwitch?.gen() ?? 0;
    const nowMs = Date.now();
    const existing = this.warm.get(key);
    if (existing !== undefined) {
      const stale =
        existing.retired ||
        existing.generation !== gen ||
        existing.loads >= WARM_CONTEXT_MAX_LOADS ||
        nowMs - existing.createdAtMs >= WARM_CONTEXT_TTL_MS;
      if (!stale) {
        existing.loads += 1;
        existing.inUse += 1;
        existing.lastUsedMs = nowMs;
        return { context: existing.context, release: () => this.releaseWarm(existing) };
      }
      this.warm.delete(key);
      this.retireWarm(existing);
    }

    // Each warm context is a real browser profile, so the pool is capped; evict least-recently-
    // used, which is the one whose connections are most likely dead anyway.
    while (this.warm.size >= MAX_WARM_CONTEXTS) {
      let oldest: WarmContext | null = null;
      for (const entry of this.warm.values()) {
        if (oldest === null || entry.lastUsedMs < oldest.lastUsedMs) oldest = entry;
      }
      if (oldest === null) break;
      this.warm.delete(oldest.key);
      this.retireWarm(oldest);
    }

    const context = await this.newContext();
    const entry: WarmContext = {
      key,
      context,
      generation: gen,
      createdAtMs: nowMs,
      lastUsedMs: nowMs,
      loads: 1,
      inUse: 1,
      retired: false,
    };
    this.warm.set(key, entry);
    // A context that dies on its own (browser crash, remote disconnect) must not be handed out
    // again as if its connections were still open.
    context.on('close', () => {
      entry.retired = true;
      if (this.warm.get(key) === entry) this.warm.delete(key);
    });
    return { context, release: () => this.releaseWarm(entry) };
  }

  /** Give a warm context back; close it only if it was retired while this load was using it. */
  private async releaseWarm(entry: WarmContext): Promise<void> {
    entry.inUse = Math.max(0, entry.inUse - 1);
    entry.lastUsedMs = Date.now();
    if (entry.retired && entry.inUse === 0) {
      await entry.context.close().catch(() => undefined);
    }
  }

  /** Mark a warm context unusable, closing it immediately if nothing is inside it. */
  private retireWarm(entry: WarmContext): void {
    entry.retired = true;
    if (entry.inUse === 0) void entry.context.close().catch(() => undefined);
  }

  /**
   * Stop using an owner-created storage state after Instagram routes it to an account-security
   * checkpoint.
   *
   * This is deliberately process-local and reversible by restart: the file is never modified or
   * deleted, and the owner remains the only actor who can replace it through `npm run login`.
   * Existing warm contexts are retired because each carries its own copy of the rejected cookies;
   * in-flight users finish, then releaseWarm closes them. Returns true exactly once, and only if a
   * context really used the configured state, so callers cannot manufacture retry loops from an
   * unrelated redirect.
   */
  quarantineStorageState(): boolean {
    if (!this.storageStateApplied || this.storageStateQuarantined) return false;
    this.storageStateQuarantined = true;
    for (const [key, entry] of this.warm) {
      this.warm.delete(key);
      this.retireWarm(entry);
    }
    this.logger.warn(
      'Instagram rejected the configured storage state; quarantining it and retrying logged-out',
    );
    return true;
  }

  /**
   * How many CAPTURES may hold a semaphore slot at once — one fewer than the shared limit.
   *
   * A capture is now allowed a genuinely long page load (up to `CAPTURE_TIMEOUT_MS`, then a paint
   * poll, then the header-image wait), and several can be in flight at once: the confirmed edge
   * runs off-tick per case, the re-capture sweep runs inline, and the owner's `/check` arrives
   * whenever they type it. Without a reserved slot, three or four slow captures would hold every
   * slot in `MAX_BROWSER_CONCURRENCY` for minutes and routine checks — the thing that DETECTS a
   * recovery in the first place — would simply queue behind them. That is harm rank 1 at fleet
   * scale, traded for one client's picture.
   *
   * At `MAX_BROWSER_CONCURRENCY=1` there is nothing to reserve and the limit degrades to 1; that
   * configuration has no parallelism to protect in the first place.
   */
  private captureLaneLimit(): number {
    return Math.max(1, Math.max(1, this.config.scheduling.maxBrowserConcurrency) - 1);
  }

  private acquireCaptureLane(): Promise<void> {
    if (this.capturesActive < this.captureLaneLimit()) {
      this.capturesActive += 1;
      return Promise.resolve();
    }
    return new Promise<void>((resolve) => {
      this.captureWaiters.push(() => {
        this.capturesActive += 1;
        resolve();
      });
    });
  }

  private releaseCaptureLane(): void {
    this.capturesActive -= 1;
    const next = this.captureWaiters.shift();
    if (next) next();
  }

  private acquire(): Promise<void> {
    const max = Math.max(1, this.config.scheduling.maxBrowserConcurrency);
    if (this.active < max) {
      this.active += 1;
      return Promise.resolve();
    }
    return new Promise<void>((resolve) => {
      this.waiters.push(() => {
        this.active += 1;
        resolve();
      });
    });
  }

  private release(): void {
    this.active -= 1;
    const next = this.waiters.shift();
    if (next) next();
  }

  /**
   * Close every outstanding context, then the browser. Idempotent.
   *
   * Waits (briefly, bounded) for in-flight `withPage` work to finish first: `close()` is
   * reachable from a crash-restart and from the egress-generation relaunch, and tearing the
   * browser down underneath another probe would destroy an unrelated check. After the grace
   * period it proceeds regardless, so a wedged page can never block shutdown.
   */
  async close(): Promise<void> {
    await this.drain(DRAIN_TIMEOUT_MS);
    // Warm contexts are also in `contexts`, so the loop below closes them; drop the handles first
    // so nothing can lease one out from under a shutdown that is already under way.
    this.warm.clear();
    for (const context of [...this.contexts]) {
      await context.close().catch(() => undefined);
    }
    this.contexts.clear();
    if (this.browser) {
      await this.browser.close().catch(() => undefined);
      this.browser = null;
    }
  }

  /** Wait for active withPage() calls to finish, up to `timeoutMs`. */
  private async drain(timeoutMs: number): Promise<void> {
    const deadline = Date.now() + timeoutMs;
    while (this.active > 0 && Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 100));
    }
  }

  /**
   * The egress generation traffic is leaving over right now. Read it BEFORE a page load and hand
   * it back to {@link isCurrentEgress} to tell a real browser failure apart from one this process
   * caused on purpose.
   */
  egressGeneration(): number {
    return this.proxySwitch?.gen() ?? 0;
  }

  /**
   * Is the browser a probe observed still the one in use, or has a `/proxy` switch replaced it?
   *
   * THE CASCADE THIS PREVENTS. A switch tears the browser down by design, so every in-flight probe
   * fails with "Target closed" — which `mapErrorToCode` correctly reads as BROWSER_CRASH, and the
   * detector answered by calling {@link restart}. But `restart()` is `close()` + relaunch, so each
   * of those "crashes" closed the browser that had ALREADY been relaunched for the NEW route,
   * killing every sibling probe with it and manufacturing the next round of crashes. One `/proxy`
   * therefore produced a self-sustaining burst of navigation failures for minutes afterwards.
   */
  isCurrentEgress(generation: number): boolean {
    return this.egressGeneration() === generation;
  }

  /** Bounded recovery hook used after a detected Chromium crash. */
  async restart(): Promise<void> {
    await this.close();
    await this.ensureBrowser();
  }
}
