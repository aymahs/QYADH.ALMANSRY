/**
 * FLEET-WIDE RATE GOVERNOR FOR CHROMIUM PAGE LOADS.
 *
 * The scarce resource is not "checks" and not "accounts" — it is BROWSER PAGE LOADS against the
 * single residential/mobile IP. One fast HTTP probe is 1 request; one Chromium load is 20-50, and
 * roughly 200 of them per hour is what burned the first residential IP. Nothing in this system
 * counted them, so two independent explosions were structurally invisible:
 *
 *   1. the deletion watcher is browser-only by design and shared the recovery baseline interval,
 *      so ONE watch cost ~225 loads/hour — two watches alone exceeded the whole fleet's ceiling;
 *   2. during an escalation storm (or with a red canary) every routine check becomes a browser
 *      load. The {@link CircuitBreaker} cannot see either: those escalated loads SUCCEED, so they
 *      report success and the breaker never opens. It is a reactive brake on THROTTLING, not a
 *      budget on VOLUME, and volume is what burns the IP in the first place.
 *
 * So this is a budget, not a brake: a rolling-hour ceiling every browser load must be admitted
 * through, fleet-wide (one instance, shared by every detector).
 *
 * PRIORITY IS THE WHOLE POINT. Losing a recovery confirmation is harm rank 1; delaying a routine
 * poll is not. Routine polling is therefore the ONLY thing that can be refused, and it is DEFERRED
 * — the caller re-schedules and comes back — never dropped. A confirmation burst, the screenshot
 * that proves a recovery, and an explicit owner command are admitted unconditionally. They are
 * bounded by how often recoveries and owner commands actually happen (a handful of loads each,
 * days apart), so letting them through is cheap; starving one is the failure this product exists
 * to prevent.
 *
 * Routine admission is gated on TOTAL consumption, not on routine consumption alone. That is
 * deliberate: a busy recovery hour then squeezes routine polling rather than the other way round,
 * which is exactly the priority order we want, and it makes total load self-limiting at
 * `routineAllowance` plus whatever priority traffic genuinely occurred.
 *
 * DURABLE, and that is not decoration. An in-memory window resets to zero on every boot, so a
 * crash loop (deploy, OOM, systemd) would hand each incarnation a fresh full budget — the governor
 * would become a load AMPLIFIER in precisely the situation it exists for. The window is therefore
 * kept as one-minute buckets and written through a best-effort store; a lost write costs accuracy,
 * never a check.
 *
 * Pure and clock-injected, so it is fully testable without timers.
 */

import type { Logger } from '../logging';

/**
 * Why a browser load is being requested. Only ROUTINE may ever be refused.
 *
 *  - `ROUTINE`   baseline polling, deletion-watch polling, the screenshot re-capture sweep, bulk
 *                pre-checks: work that loses nothing by happening a minute later.
 *  - `CONFIRMATION` a check that could confirm a recovery (or a deletion), and the capture that
 *                proves it. Never refused — this is the harm-rank-1 path.
 *  - `OWNER`     an explicit owner command (/check, /unban, /ping) and anything unlabelled.
 *                Never refused; the default is deliberately the SAFE one, so a caller that
 *                forgets to classify itself is never starved.
 */
export type LoadPriority = 'ROUTINE' | 'CONFIRMATION' | 'OWNER';

/** Rolling window the budget is measured over. */
export const GOVERNOR_WINDOW_MS = 60 * 60 * 1000;
/** One bucket per minute: compact enough to persist on every roll, fine enough to be honest. */
const BUCKET_COUNT = 60;
const BUCKET_MS = GOVERNOR_WINDOW_MS / BUCKET_COUNT;

/**
 * Consecutive checks that reached the fast tier and still had to be answered by the browser
 * before the fleet is treated as being in an ESCALATION STORM.
 *
 * Lives here rather than in the detector because it is now a THROTTLING input, not just a /ping
 * line: the detector reports the streak, and the governor turns it into cadence back-off. At a
 * 15s baseline a real storm crosses 20 in well under a minute; a lone recovery escalation never
 * gets near it.
 */
export const ESCALATION_STORM_STREAK = 20;

/**
 * Fraction of the hourly ceiling routine polling may consume. The remainder is headroom that
 * exists so a confirmation burst, its screenshot, and an owner command are never queued behind
 * routine traffic that has already spent the budget.
 */
const DEFAULT_ROUTINE_FRACTION = 0.75;

/** Hardest the baseline interval may be stretched under pressure (15s -> 120s at the default). */
const MAX_INTERVAL_MULTIPLIER = 8;
/** Utilisation at which the cadence ramp starts; below this the fleet polls at full speed. */
const RAMP_START = 0.5;
/** Stretch applied the moment an escalation storm is detected, ahead of the budget ramp. */
const STORM_INTERVAL_MULTIPLIER = 4;

/** Do not repeat the "routine polling is being deferred" warning more often than this. */
const DEFER_LOG_INTERVAL_MS = 60_000;
/** Minimum gap between durable writes, so the hot path never turns into an I/O loop. */
const PERSIST_INTERVAL_MS = 5_000;

interface Bucket {
  /** Every admitted load, whatever its priority. */
  total: number;
  /** Admitted loads that were ROUTINE — reporting only; admission is gated on `total`. */
  routine: number;
  /** Routine loads REFUSED. The number that says self-throttling is actually happening. */
  deferred: number;
}

/**
 * The durable form of the window. Newest-first so rehydration never has to reason about where the
 * ring pointer was when the process died.
 */
export interface GovernorSnapshot {
  /** Absolute bucket index (epoch ms / BUCKET_MS) of `buckets[0]`. */
  newestBucket: number;
  /** `buckets[0]` is the newest minute, `buckets[1]` the one before it, and so on. */
  buckets: Bucket[];
}

/**
 * Best-effort durability port. Both halves are fire-and-forget by contract: anything thrown is
 * swallowed by the governor, because losing a write costs accuracy while throwing would cost a
 * check.
 */
export interface GovernorStore {
  load(): GovernorSnapshot | null;
  save(snapshot: GovernorSnapshot): void;
  /**
   * Settle whatever {@link GovernorStore.save} queued. OPTIONAL, because a store with no async
   * work behind it has nothing to settle.
   *
   * It exists because `save` is fire-and-forget: the file store chains an async write and returns
   * immediately, so `flush()` on shutdown queued a write that `process.exit(0)` then dropped —
   * handing the next boot a window missing the minutes that mattered most, which is exactly the
   * "fresh full budget after a crash loop" the durability exists to prevent.
   */
  drain?(): Promise<void>;
}

/** Everything /ping and the health monitor need. Free — never touches the network. */
export interface BrowserBudgetReport {
  /** Rolling-hour ceiling on browser page loads. */
  capacity: number;
  /** The slice of it routine polling may spend. */
  routineAllowance: number;
  windowMs: number;
  /** Loads admitted in the window, all priorities. */
  used: number;
  /** ...of which routine. */
  routineUsed: number;
  /** Routine loads REFUSED in the window. Non-zero means the fleet is self-throttling. */
  deferred: number;
  /** Multiplier currently applied to the baseline poll interval. 1 = full speed. */
  intervalMultiplier: number;
  /** Consecutive browser-answered checks, as last reported by the fast tier. */
  escalationStreak: number;
  /** True once the escalation streak crosses {@link ESCALATION_STORM_STREAK}. */
  storm: boolean;
  /** True when routine polling is being slowed or refused. */
  throttling: boolean;
  /** True when priority traffic alone has carried consumption past the ceiling. */
  overCapacity: boolean;
  /** Short, non-sensitive, always populated — including when nothing is wrong. */
  reason: string;
}

export interface BrowserLoadGovernorOptions {
  /** Rolling-hour ceiling. See the justification on BROWSER_LOADS_PER_HOUR in config. */
  capacity?: number;
  /** Fraction of `capacity` routine polling may spend (0 < f <= 1). */
  routineFraction?: number;
  now?: () => number;
  logger?: Logger;
  /** Durable window. Omit for a purely in-memory governor (tests, or a driver with no state dir). */
  store?: GovernorStore;
}

function emptyBucket(): Bucket {
  return { total: 0, routine: 0, deferred: 0 };
}

/** A stored number is never trusted: NaN/Infinity/negative all collapse to 0. */
function safeCount(value: unknown): number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0 ? Math.floor(value) : 0;
}

export class BrowserLoadGovernor {
  private readonly capacityValue: number;
  private readonly routineAllowanceValue: number;
  private readonly now: () => number;
  private readonly logger: Logger | null;
  private readonly store: GovernorStore | null;

  /** Newest-first, at most {@link BUCKET_COUNT} entries. */
  private buckets: Bucket[] = [];
  /** Absolute index of `buckets[0]`; -1 until the first admission. */
  private newestBucket = -1;
  private escalationStreak = 0;
  private lastDeferLogMs = 0;
  private lastPersistMs = 0;

  constructor(options: BrowserLoadGovernorOptions = {}) {
    const capacity = Math.max(1, Math.floor(options.capacity ?? 120));
    const fraction = Math.min(
      1,
      Math.max(0.1, options.routineFraction ?? DEFAULT_ROUTINE_FRACTION),
    );
    this.capacityValue = capacity;
    // At least one, or routine polling could be locked out entirely by a hostile config.
    this.routineAllowanceValue = Math.max(1, Math.floor(capacity * fraction));
    this.now = options.now ?? Date.now;
    this.logger = options.logger ?? null;
    this.store = options.store ?? null;
  }

  /**
   * Adopt the window the previous incarnation of this process left behind.
   *
   * Call once, before the first admission. Everything is defensive: a stored value must never be
   * able to WEDGE the fleet (which would stop every browser-answered check), so anything
   * unreadable simply starts clean, and nothing older than the window is adopted at all.
   */
  rehydrate(): void {
    if (this.store === null) return;
    let snapshot: GovernorSnapshot | null = null;
    try {
      snapshot = this.store.load();
    } catch {
      snapshot = null;
    }
    if (snapshot === null || !Array.isArray(snapshot.buckets)) return;
    const newest = snapshot.newestBucket;
    if (typeof newest !== 'number' || !Number.isFinite(newest) || newest < 0) return;

    const current = Math.floor(this.now() / BUCKET_MS);
    // A stored window from the future (clock skew, a corrupt row) is discarded rather than
    // trusted: adopting it would suppress real checks for up to an hour.
    if (newest > current) return;
    const age = current - newest;
    if (age >= BUCKET_COUNT) return; // entirely outside the window

    const adopted: Bucket[] = [];
    for (let i = 0; i < age; i += 1) adopted.push(emptyBucket());
    for (const b of snapshot.buckets.slice(0, BUCKET_COUNT - age)) {
      adopted.push({
        total: safeCount(b?.total),
        routine: safeCount(b?.routine),
        deferred: safeCount(b?.deferred),
      });
    }
    this.buckets = adopted.slice(0, BUCKET_COUNT);
    this.newestBucket = current;
    this.logger?.info('browser-load budget restored across restart', {
      used: this.used(),
      capacity: this.capacityValue,
      minutesAdopted: this.buckets.length - age,
    });
  }

  /**
   * Ask permission to perform ONE Chromium page load, recording it when granted.
   *
   * Returns false only for {@link LoadPriority} `ROUTINE`, and only once the routine allowance is
   * spent. The caller MUST treat false as "defer and come back", never as evidence about the
   * account — see the deferred result in the tiered detector.
   */
  admit(priority: LoadPriority): boolean {
    const nowMs = this.now();
    this.roll(nowMs);
    const bucket = this.buckets[0];
    /* c8 ignore next */
    if (bucket === undefined) return true; // unreachable: roll() always seeds bucket 0

    if (priority === 'ROUTINE' && this.used() >= this.routineAllowanceValue) {
      bucket.deferred += 1;
      this.logDeferral(nowMs);
      this.persist(nowMs, false);
      return false;
    }

    bucket.total += 1;
    if (priority === 'ROUTINE') bucket.routine += 1;
    this.persist(nowMs, false);
    return true;
  }

  /**
   * Publish the fast tier's consecutive-escalation streak.
   *
   * This is what finally connects the ESCALATION_STORM signal to something that THROTTLES rather
   * than merely reports: a storm means every routine check has become a browser load, which the
   * circuit breaker structurally cannot see because those loads succeed.
   */
  reportEscalationStreak(streak: number): void {
    this.escalationStreak = Number.isFinite(streak) && streak > 0 ? Math.floor(streak) : 0;
  }

  /**
   * Multiplier the monitor worker applies to its baseline poll interval.
   *
   * SECONDARY, and worth being honest about: stretching the interval reduces how fast the budget
   * is spent and how much pointless reschedule churn a saturated fleet generates, but it cannot by
   * itself hold the fleet under the ceiling — at 20 monitors even a 120s interval is 600 checks an
   * hour, and if every one escalated that would still be 600 loads. {@link admit} is what actually
   * bounds the number; this just stops the fleet spending its whole time being deferred.
   */
  intervalMultiplier(): number {
    const utilisation = this.used() / this.routineAllowanceValue;
    const ramped =
      utilisation <= RAMP_START
        ? 1
        : 1 +
          ((Math.min(utilisation, 1) - RAMP_START) / (1 - RAMP_START)) *
            (MAX_INTERVAL_MULTIPLIER - 1);
    const storm = this.escalationStreak >= ESCALATION_STORM_STREAK ? STORM_INTERVAL_MULTIPLIER : 1;
    const combined = Math.max(1, Math.min(MAX_INTERVAL_MULTIPLIER, Math.max(ramped, storm)));
    // Two decimals: enough resolution to matter, stable enough to assert on.
    return Math.round(combined * 100) / 100;
  }

  /** Free, in-memory diagnostics. Safe to call from /ping, the health monitor and every tick. */
  report(): BrowserBudgetReport {
    this.roll(this.now());
    const used = this.used();
    const routineUsed = this.sum((b) => b.routine);
    const deferred = this.sum((b) => b.deferred);
    const multiplier = this.intervalMultiplier();
    const storm = this.escalationStreak >= ESCALATION_STORM_STREAK;
    const overCapacity = used > this.capacityValue;
    const throttling = deferred > 0 || multiplier > 1;

    return {
      capacity: this.capacityValue,
      routineAllowance: this.routineAllowanceValue,
      windowMs: GOVERNOR_WINDOW_MS,
      used,
      routineUsed,
      deferred,
      intervalMultiplier: multiplier,
      escalationStreak: this.escalationStreak,
      storm,
      throttling,
      overCapacity,
      reason: this.describe(used, deferred, multiplier, storm, overCapacity),
    };
  }

  /**
   * Force the window to disk and WAIT for it (shutdown). Best-effort, like every other write here
   * — a store that throws or has no drain simply resolves.
   *
   * Awaiting is the point: `persist` only hands the snapshot to the store, which queues an async
   * write. Returning before it lands let `process.exit(0)` drop the very buckets the next boot
   * must not be allowed to spend again.
   */
  async flush(): Promise<void> {
    this.persist(this.now(), true);
    try {
      await this.store?.drain?.();
    } catch {
      // Durability must never be able to hold up (or fail) a shutdown.
    }
  }

  /** WHY the fleet is (or is not) backing off. Never empty — silence is the failure mode here. */
  private describe(
    used: number,
    deferred: number,
    multiplier: number,
    storm: boolean,
    overCapacity: boolean,
  ): string {
    const budget = `${used}/${this.capacityValue} browser loads this hour (routine allowance ${this.routineAllowanceValue})`;
    if (deferred > 0) {
      return `${budget} — routine polling DEFERRED ${deferred} time(s); confirmations, captures and owner commands are still admitted`;
    }
    if (storm) {
      return `${budget} — escalation storm: ${this.escalationStreak} consecutive checks answered by the browser, baseline interval stretched ${multiplier}x`;
    }
    if (overCapacity) {
      return `${budget} — over the ceiling on priority traffic alone (confirmations, captures, owner commands)`;
    }
    if (multiplier > 1) {
      return `${budget} — baseline interval stretched ${multiplier}x to stay inside the budget`;
    }
    return `${budget} — no throttling`;
  }

  private used(): number {
    return this.sum((b) => b.total);
  }

  private sum(pick: (b: Bucket) => number): number {
    let total = 0;
    for (const b of this.buckets) total += pick(b);
    return total;
  }

  /** Advance the window to `nowMs`, retiring whole minutes that have fallen out of it. */
  private roll(nowMs: number): void {
    const index = Math.floor(nowMs / BUCKET_MS);
    if (this.newestBucket === -1) {
      this.newestBucket = index;
      this.buckets = [emptyBucket()];
      return;
    }
    // A clock that jumped BACKWARDS (NTP correction, the NetworkCorrectedClock resync) must not
    // roll anything: keeping the counts we already have is the conservative direction, whereas
    // rebuilding the window would hand the fleet a fresh budget.
    if (index <= this.newestBucket) return;

    const gap = Math.min(index - this.newestBucket, BUCKET_COUNT);
    for (let i = 0; i < gap; i += 1) this.buckets.unshift(emptyBucket());
    if (this.buckets.length > BUCKET_COUNT) this.buckets.length = BUCKET_COUNT;
    this.newestBucket = index;
    this.persist(nowMs, true);
  }

  private logDeferral(nowMs: number): void {
    if (nowMs - this.lastDeferLogMs < DEFER_LOG_INTERVAL_MS) return;
    this.lastDeferLogMs = nowMs;
    // Self-throttling is a fact the owner needs, not an internal detail — so it is never silent.
    this.logger?.warn('browser-load budget spent; deferring routine polling', {
      used: this.used(),
      capacity: this.capacityValue,
      routineAllowance: this.routineAllowanceValue,
      escalationStreak: this.escalationStreak,
    });
  }

  private persist(nowMs: number, force: boolean): void {
    if (this.store === null) return;
    if (!force && nowMs - this.lastPersistMs < PERSIST_INTERVAL_MS) return;
    this.lastPersistMs = nowMs;
    try {
      this.store.save({
        newestBucket: this.newestBucket,
        buckets: this.buckets.map((b) => ({ ...b })),
      });
    } catch {
      // Best-effort durability: the next write tries again. A failing disk must never be able to
      // stop a check.
    }
  }
}
