/**
 * Detector health monitor. When the rolling UNKNOWN rate is high while several
 * cases are actively monitored, it probes the configured CONTROL username with
 * the SAME detector the monitor uses. A failing control probe means the
 * detector itself is degraded (not the monitored accounts).
 *
 * Alert hygiene is the whole point of the streak logic below. A control probe is
 * one HTTP/browser round trip against Instagram, so it fails transiently all the
 * time; warning on the first failure and un-warning on the first success turned
 * every blip into a WARNING+RESTORED pair. The owner got eight such pairs in one
 * night while the fleet was working correctly throughout. So:
 *
 *  - warn only after {@link WARN_AFTER_CONSECUTIVE_FAILURES} consecutive failures;
 *  - say "restored" only after {@link RESTORE_AFTER_CONSECUTIVE_SUCCESSES} consecutive successes;
 *  - and only say "restored" if a warning was actually ANNOUNCED, tracked by the persisted
 *    `lastWarningSentUtc` and deliberately NOT by `detectorUnhealthy` (which only means "an
 *    incident is open, keep probing" and is set on the first failed probe, long before anything
 *    is announced).
 *
 * Every one of those decisions is anchored to the persisted health row rather than to this
 * object, because an incident regularly outlives the process — see the incident-state block below.
 *
 * Case statuses are never touched.
 */

import type { Clock, Detector, Repositories, SchedulerHealth, TelegramClient } from '../domain';
import { ACTIVE_STATUSES } from '../domain';
import type { AppConfig } from '../config';
import type { Logger } from '../logging';
import type { DiscordNotifier } from '../bot/discord/discord-notifier';
// Deep import (not the detector barrel) so the health monitor never pulls Playwright into scope.
import { detectorDiagnostics } from '../instagram/detector/tiered-detector';
import type { TieredProbeOptions } from '../instagram/detector/tiered-detector';
import { monitoringRestored, monitoringWarning } from '../notifications/formatter';

/** Rolling UNKNOWN rate at or above which the detector is suspect. */
const UNKNOWN_RATE_THRESHOLD = 0.8;
/** Minimum active cases before a high unknown rate is meaningful. */
const MIN_ACTIVE_CASES = 2;
/** Do not repeat the degradation warning more often than this. */
const WARNING_SUPPRESSION_MS = 30 * 60 * 1000;
/**
 * Consecutive failed control probes before the owner is told. At the ~5-minute evaluation cadence
 * this is ~15 minutes of sustained failure — long enough that a single flaky page load, a DNS
 * hiccup or one throttled request can never reach the owner.
 */
const WARN_AFTER_CONSECUTIVE_FAILURES = 3;
/**
 * Consecutive successful control probes before "restored" is sent. One good probe in the middle of
 * a flapping incident is not a recovery; it used to be, and it produced half of every spurious pair.
 */
const RESTORE_AFTER_CONSECUTIVE_SUCCESSES = 2;
/** Health row name shared with the scheduler worker. */
const HEALTH_NAME = 'scheduler';

export interface HealthMonitorDeps {
  repos: Repositories;
  detector: Detector;
  client: TelegramClient;
  /** Resolves the paired owner's chat id, or null while unpaired. */
  ownerChatId: () => Promise<number | null>;
  config: AppConfig;
  clock: Clock;
  logger: Logger;
  /** Optional best-effort Discord mirror (#status) for degraded/restored alerts. */
  discord?: DiscordNotifier;
}

export class HealthMonitor {
  private readonly repos: Repositories;
  private readonly detector: Detector;
  private readonly client: TelegramClient;
  private readonly ownerChatId: () => Promise<number | null>;
  private readonly config: AppConfig;
  private readonly clock: Clock;
  private readonly logger: Logger;
  private readonly discord: DiscordNotifier | null;

  // ---------------------------------------------------------------------------------------------
  // Incident state. The streak counters below are IN MEMORY because `migrate()` only runs
  // CREATE TABLE IF NOT EXISTS, so a new column would never reach the owner's live database.
  //
  // Losing them across a restart is NOT harmless, which an earlier version of this comment got
  // wrong. An incident routinely outlives the process: at the 5-minute cadence
  // WARN_AFTER_CONSECUTIVE_FAILURES needs 15 minutes of UNINTERRUPTED uptime, and a host that
  // restarts more often than that (crash loop, OOM, the Windows scheduled-task relaunch,
  // home-PC sleep/wake) reset the count to 0 every boot and never warned at all. In the other
  // direction a restart mid-incident zeroed the "announced" flag, so the recovery closed the
  // incident SILENTLY and no RESTORED could ever be sent for it.
  //
  // Both directions are therefore anchored to columns that already exist on the live row:
  //
  //  - `detectorUnhealthy` (an incident is open) re-seeds the failure streak on the first
  //    evaluation of a new process — see {@link resumeFromPersistedIncident};
  //  - `lastWarningSentUtc` (non-null == the owner actually heard the warning for the OPEN
  //    incident) replaces the in-memory "announced" flag, and doubles as a restart-proof floor
  //    under the 30-minute repeat suppression.
  // ---------------------------------------------------------------------------------------------

  /** Consecutive failed control probes. Re-seeded from the persisted incident after a restart. */
  private consecutiveFailures = 0;
  /** Consecutive successful control probes. */
  private consecutiveSuccesses = 0;
  /**
   * Consecutive evaluations in which an incident was open, the control probe still failed, and
   * the FLEET's own unknown rate was nonetheless healthy. This is the second way an incident may
   * close: the fleet's ~650 clean checks an hour outrank one account's red probe as evidence.
   */
  private consecutiveHealthyFleet = 0;
  /**
   * Has this process already reconciled its streaks with the persisted incident? The seeding must
   * happen exactly once per process, not on every evaluation, or it would overwrite a live streak.
   */
  private resumed = false;
  /**
   * When the last warning was ATTEMPTED (not delivered), for the 30-minute repeat suppression.
   *
   * It counts attempts rather than deliveries because the previous implementation derived
   * suppression from the persisted `lastWarningSentUtc`, which is only written when the send
   * SUCCEEDS. A failed send therefore left it null forever, and the suppression term
   * `lastWarnedMs === null` was OR-ed into the warn condition — so it re-opened the gate on every
   * single evaluation. Telegram being unreachable is exactly the situation the health monitor
   * fires in, so that was a 5-minute alert flood waiting to happen.
   *
   * The persisted send time is now consulted TOO, but only ever to ADD suppression (see
   * {@link onControlFailed}); it can no longer re-open the gate the way the old null test did.
   */
  private lastWarnAttemptMs: number | null = null;

  constructor(deps: HealthMonitorDeps) {
    this.repos = deps.repos;
    this.detector = deps.detector;
    this.client = deps.client;
    this.ownerChatId = deps.ownerChatId;
    this.config = deps.config;
    this.clock = deps.clock;
    this.logger = deps.logger;
    this.discord = deps.discord ?? null;
  }

  /** One health evaluation; the app calls this roughly every 5 minutes. */
  async evaluate(): Promise<void> {
    const now = this.clock.now();
    const nowIso = now.toISOString();

    // ALWAYS record the browser-load budget, before any early return. Self-throttling is a fact
    // the owner needs, not an internal detail: the fleet quietly checking at a fraction of the
    // configured rate looks identical, from the outside, to a fleet that is simply slow — and this
    // runs every five minutes whether or not anything else is wrong.
    this.recordBrowserBudget();

    const health = await this.repos.health.get(HEALTH_NAME);
    if (health === null) return; // no scheduler activity recorded yet

    const activeCount = await this.repos.cases.countByStatuses(ACTIVE_STATUSES);
    const degraded =
      health.recentUnknownRate >= UNKNOWN_RATE_THRESHOLD && activeCount >= MIN_ACTIVE_CASES;

    // Adopt whatever incident the previous process left open, exactly once, BEFORE the gate below
    // can return: a closed incident must still mark this process as reconciled so a later failure
    // starts a genuinely fresh streak rather than inheriting a stale seed.
    this.resumeFromPersistedIncident(health);

    // Probe the control account while degraded, and also while flagged unhealthy so recovery is
    // detected even after the unknown rate falls. Staying SILENT must never stop the probe loop:
    // the streak that ends the incident can only be built by continuing to probe.
    if (!degraded && !health.detectorUnhealthy) return;

    let controlActive = false;
    try {
      // `allowFastActive` — and this is the fix for a five-hour false alarm on 2026-08-04.
      //
      // Without it, an ACTIVE control account ALWAYS escalates to a full Chromium load, so the
      // health verdict rested entirely on the single most fragile operation in the system. That
      // morning the VPS recorded ~650 clean fast-tier checks per hour with ZERO errors — a
      // demonstrably healthy fleet, which also proves the canary was green, since "still gone"
      // cannot be inferred without it — while the browser probe of the control account kept
      // failing behind the proxy. Result: "MONITORING WARNING" every 30 minutes about a fleet
      // that was working perfectly. Crying wolf is not a harmless failure; it teaches the owner
      // to ignore the one message that must never be ignored.
      //
      // This check cannot confirm a recovery — the control account is not a monitored case at
      // all — which is exactly the precondition the option documents. It also measures what the
      // fleet ACTUALLY runs on: the fast tier answers ~95% of checks, so a fast-tier verdict is
      // MORE representative of fleet health than one browser load, not less.
      //
      // Genuine faults still warn, and that is what keeps this honest: a throttled route makes
      // the fast probe return HTTP_429/LOGIN_WALL rather than ACTIVE, which escalates to the
      // browser exactly as before and fails exactly as before. Only the case "fast tier healthy,
      // browser walled" changes verdict — and that is the case where the fleet is fine.
      const controlOptions: TieredProbeOptions = { allowFastActive: true };
      const probe = await this.detector.probe(this.config.controlUsername, controlOptions);
      controlActive = probe.result.classification === 'ACTIVE';
    } catch (err) {
      this.logger.warn('health monitor: control probe threw', { err });
      controlActive = false;
    }

    if (controlActive) {
      await this.onControlOk(health, nowIso);
      return;
    }
    await this.onControlFailed(health, now.getTime(), nowIso, degraded);
  }

  /** A good control probe: advance the success streak and close the incident once it completes. */
  private async onControlOk(health: SchedulerHealth, nowIso: string): Promise<void> {
    this.consecutiveFailures = 0;
    this.consecutiveSuccesses += 1;

    if (this.consecutiveSuccesses < RESTORE_AFTER_CONSECUTIVE_SUCCESSES) {
      // Not a recovery yet. Record that the control answered, but leave `detectorUnhealthy` set:
      // clearing it here would let the gate above stop probing as soon as the unknown rate fell,
      // and the second success that actually ends the incident would never happen.
      await this.repos.health.upsert({ ...health, lastControlOkUtc: nowIso, updatedAtUtc: nowIso });
      return;
    }

    await this.closeIncident(health, nowIso, { recordControlOk: true });
  }

  /**
   * End the open incident: RESTORED to the owner if a warning was actually delivered, then clear
   * the durable flags. Shared by the two ways an incident can end — the control account answering
   * ({@link onControlOk}) and the FLEET itself proving healthy while the control stays red
   * ({@link onControlFailed}).
   */
  private async closeIncident(
    health: SchedulerHealth,
    nowIso: string,
    options: { recordControlOk: boolean },
  ): Promise<void> {
    // Only tell the owner it is over if we actually told them it had started — read from the
    // DURABLE record, not from a field of this object. An incident regularly outlives the process,
    // and an in-memory flag meant a restart mid-incident silently swallowed the RESTORED: the
    // upsert below then closed the incident, so nothing could ever re-send it and the owner's last
    // word on a fully recovered fleet stayed "monitoring degraded".
    if (health.lastWarningSentUtc !== null) {
      await this.notifyOwner(monitoringRestored().text);
    }
    // Let the NEXT incident warn on its own merits rather than inheriting this one's window.
    this.lastWarnAttemptMs = null;
    this.consecutiveFailures = 0;
    this.consecutiveSuccesses = 0;
    this.consecutiveHealthyFleet = 0;

    await this.repos.health.upsert({
      ...health,
      ...(options.recordControlOk ? { lastControlOkUtc: nowIso } : {}),
      detectorUnhealthy: false,
      // Cleared WITH the incident it belongs to. That is what makes the non-null test above mean
      // "announced for the incident that is open right now": left set, it would authorise a lone
      // RESTORED for the next short blip that never earned a warning of its own.
      lastWarningSentUtc: null,
      updatedAtUtc: nowIso,
    });
  }

  /**
   * Adopt the persisted incident once per process.
   *
   * `detectorUnhealthy` is written on the FIRST failed probe, so finding it already set at startup
   * proves the previous process saw a failure and never saw the recovery. Resuming the streak one
   * short of the threshold makes the next failed probe warn, instead of restarting the 15-minute
   * count from zero on every boot — which is how a restart loop during a genuinely sustained
   * outage produced no warning at all, the worst outcome this monitor has.
   *
   * Over-warning is bounded from the other end: {@link onControlFailed} also consults the
   * persisted `lastWarningSentUtc`, so however often the process restarts the owner still gets at
   * most one warning per {@link WARNING_SUPPRESSION_MS}.
   */
  private resumeFromPersistedIncident(health: SchedulerHealth): void {
    if (this.resumed) return;
    this.resumed = true;
    if (!health.detectorUnhealthy) return;
    this.consecutiveFailures = WARN_AFTER_CONSECUTIVE_FAILURES - 1;
  }

  /** A failed control probe: advance the failure streak and warn once it is long enough. */
  private async onControlFailed(
    health: SchedulerHealth,
    nowMs: number,
    nowIso: string,
    degraded: boolean,
  ): Promise<void> {
    this.consecutiveSuccesses = 0;

    // THE FLEET OUTRANKS THE CONTROL ACCOUNT — the 2026-08-04 rule, learned twice in one day.
    //
    // A warning may only ever be built from evaluations in which the fleet itself was degraded
    // (`recentUnknownRate` over threshold). A failed control probe while the unknown rate is
    // healthy is evidence about ONE unmonitored account's reachability, not about the product —
    // that exact combination produced "MONITORING WARNING" every 30 minutes on a morning the
    // fleet logged ~650 clean checks an hour with a recorded unknown rate of 4e-155. Zero real
    // checks were degraded; only the diagnostic was.
    //
    // The same evidence closes the incident outright after a short streak. Without this second
    // exit an incident could stay open indefinitely against a healthy fleet — probing, failing,
    // and re-warning every suppression window until a control probe happened to succeed twice,
    // which on a proxy egress can take hours. The RESTORED the owner gets cites the truth: the
    // fleet is answering normally.
    //
    // A real outage cannot hide in this branch: when Instagram throttles the route, monitored
    // checks return HTTP_429/LOGIN_WALL, the unknown rate climbs past the threshold within
    // minutes at a 60-120s cadence, `degraded` flips true, and the warn path below runs exactly
    // as it always has.
    if (!degraded) {
      this.consecutiveFailures = 0;
      this.consecutiveHealthyFleet += 1;
      if (this.consecutiveHealthyFleet >= RESTORE_AFTER_CONSECUTIVE_SUCCESSES) {
        await this.closeIncident(health, nowIso, { recordControlOk: false });
      }
      return;
    }
    this.consecutiveHealthyFleet = 0;
    this.consecutiveFailures += 1;

    // Suppression is the LATER of the in-memory attempt clock and the durable send record. The
    // in-memory half also counts sends that FAILED (a Telegram outage must not be retried every
    // five minutes); the durable half survives a restart, so the resumed streak above cannot turn
    // a crash loop into one warning per boot. Both terms only ever ADD suppression — the old bug
    // was a `lastWarningSentUtc === null` term OR-ed into the WARN condition, which re-opened the
    // gate precisely when sends were failing. A null/unparseable timestamp here yields NaN or
    // -Infinity, both of which compare false, i.e. it fails towards warning rather than silence.
    const lastWarnMs = Math.max(
      this.lastWarnAttemptMs ?? Number.NEGATIVE_INFINITY,
      health.lastWarningSentUtc === null
        ? Number.NEGATIVE_INFINITY
        : new Date(health.lastWarningSentUtc).getTime(),
    );
    const rateLimited = nowMs - lastWarnMs <= WARNING_SUPPRESSION_MS;
    const shouldWarn = this.consecutiveFailures >= WARN_AFTER_CONSECUTIVE_FAILURES && !rateLimited;

    if (!shouldWarn) {
      // Silent, but the incident is open: persist that so the probe loop survives the unknown rate
      // falling back to normal. Only written on the transition, to keep this monitor's write rate
      // (and its overlap with the scheduler's own writes to this row) exactly as it was.
      if (!health.detectorUnhealthy) {
        await this.repos.health.upsert({
          ...health,
          detectorUnhealthy: true,
          updatedAtUtc: nowIso,
        });
      }
      return;
    }

    // Append the throttle state to the warning the owner is about to get. A degraded detector and
    // a spent browser-load budget are the same incident seen from two ends — the fast tier stops
    // answering, every check becomes a page load, the budget drains — so telling them apart in one
    // message is what turns "monitoring is degraded" into something actionable.
    const throttle = this.browserBudgetLine();

    // Advance the repeat-suppression clock on the ATTEMPT, before the send. If the send fails we
    // still must not try again for 30 minutes: a Telegram outage would otherwise be retried every
    // evaluation forever, because nothing else records that we already tried.
    this.lastWarnAttemptMs = nowMs;

    const sent = await this.notifyOwner(
      throttle === null ? monitoringWarning().text : `${monitoringWarning().text}\n\n${throttle}`,
    );

    await this.repos.health.upsert({
      ...health,
      detectorUnhealthy: true,
      // The durable "the owner actually heard it" record for THIS incident, cleared when the
      // incident closes. Written only on a successful send, which is exactly what makes it safe to
      // authorise a later RESTORED: a warning that never arrived must not produce a "restored" that
      // would be the only message of the incident. It is also the restart-proof floor under the
      // repeat suppression above — where a null means "no durable evidence, fall back to memory",
      // never "go ahead and warn again".
      lastWarningSentUtc: sent ? nowIso : health.lastWarningSentUtc,
      updatedAtUtc: nowIso,
    });
  }

  /**
   * Log the fleet's browser-load budget every evaluation.
   *
   * Deliberately a log line rather than a message: at a five-minute cadence a notification would
   * be spam, and a crash loop would turn it into a flood. The owner reads the live figure with
   * /ping; this is the durable record that says when the throttling started.
   */
  private recordBrowserBudget(): void {
    const budget = detectorDiagnostics(this.detector)?.browserBudget?.() ?? null;
    if (budget === null) return;
    const fields = {
      used: budget.used,
      capacity: budget.capacity,
      routineAllowance: budget.routineAllowance,
      deferred: budget.deferred,
      intervalMultiplier: budget.intervalMultiplier,
      escalationStreak: budget.escalationStreak,
      reason: budget.reason,
    };
    if (budget.throttling || budget.overCapacity) {
      this.logger.warn('health monitor: fleet is self-throttling browser page loads', fields);
    } else {
      this.logger.info('health monitor: browser-load budget', fields);
    }
  }

  /** One owner-readable line about the budget, or null when there is no governor to report on. */
  private browserBudgetLine(): string | null {
    const budget = detectorDiagnostics(this.detector)?.browserBudget?.() ?? null;
    if (budget === null) return null;
    return `Browser loads: ${budget.used}/${budget.capacity} this hour. ${budget.reason}`;
  }

  /**
   * Deliver a health alert to the owner via Telegram and (best-effort) the Discord #status
   * mirror. Returns true when delivered by EITHER channel — the caller uses this to decide whether
   * the owner may later be told the incident is over.
   */
  private async notifyOwner(text: string): Promise<boolean> {
    // Telegram is the primary channel and goes FIRST — the best-effort Discord mirror must never
    // delay it (a slow/unreachable Discord API could otherwise stall the send up to the notifier
    // timeout). Discord runs after and only contributes to the delivery result.
    let telegramOk = false;
    const chatId = await this.ownerChatId();
    if (chatId === null) {
      this.logger.warn('health monitor: no paired owner; message not sent');
    } else {
      try {
        await this.client.sendMessage({ chat_id: chatId, text });
        telegramOk = true;
      } catch (err) {
        this.logger.error('health monitor: failed to send owner message', { err });
      }
    }

    const discordOk = this.discord !== null ? await this.discord.status(text) : false;
    return telegramOk || discordOk;
  }
}
