/**
 * The DEDICATED wallet bot: its own token, its own pairing, its own long-poll loop — hosted in
 * the same process as the monitor bot but sharing nothing with its command router. A slow balance
 * fetch here can never delay an /unban; a monitor outage never mutes a wallet alert.
 *
 * Pairing mirrors the monitor bot's model: the FIRST /start carrying the correct secret becomes
 * the owner chat; everything else is ignored (this bot has exactly one legitimate user).
 */

import type { Logger } from '../logging';
import type { TelegramClient, TelegramUpdate } from '../domain';
import type { EtherscanClient } from './chains/etherscan';
import type { TronGridClient } from './chains/trongrid';
import type { WalletsConfig } from './config';
import { formatBalances, formatChainTrouble } from './formatter';
import type { WalletStore } from './persistence';
import type { WalletBalance } from './types';
import type { WalletWatcher } from './watcher';

const USDT_ETH_CONTRACT = '0xdac17f958d2ee523a2206206994597c13d831ec7';
/** /wallets hits 8 live API calls; a floor between runs keeps a fat finger from spending them. */
const BALANCE_COOLDOWN_MS = 10_000;

export interface WalletBotOptions {
  config: WalletsConfig;
  store: WalletStore;
  telegram: TelegramClient;
  etherscan: EtherscanClient;
  trongrid: TronGridClient;
  watcher: WalletWatcher;
  logger: Logger;
  now?: () => Date;
}

export class WalletBot {
  private readonly config: WalletsConfig;
  private readonly store: WalletStore;
  private readonly telegram: TelegramClient;
  private readonly etherscan: EtherscanClient;
  private readonly trongrid: TronGridClient;
  private readonly watcher: WalletWatcher;
  private readonly logger: Logger;
  private readonly now: () => Date;
  private running = false;
  private offset = 0;
  private lastBalancesAt = 0;

  constructor(options: WalletBotOptions) {
    this.config = options.config;
    this.store = options.store;
    this.telegram = options.telegram;
    this.etherscan = options.etherscan;
    this.trongrid = options.trongrid;
    this.watcher = options.watcher;
    this.logger = options.logger;
    this.now = options.now ?? ((): Date => new Date());
  }

  /**
   * The one chat this bot serves: an explicit wallet pairing, or — the normal case — the MAIN
   * bot's owner from the shared database. The fallback is what makes pairing self-service-free:
   * the owner already proved who they are to the monitor bot, and Telegram authenticates the
   * sender id on every update, so demanding a second secret was pure friction (measured: the
   * owner's first pairing attempt failed on it and the failure was silent).
   */
  private ownerChatId(): number | null {
    return this.store.pairedChatId() ?? this.store.mainOwnerChatId();
  }

  /** Deliver one alert to the owner. Throws when no owner is known yet — the outbox then
   *  retries, so alerts produced before first contact are queued, not lost. */
  async sendAlert(html: string): Promise<void> {
    const chatId = this.ownerChatId();
    if (chatId === null) throw new Error('wallet bot has no known owner yet');
    await this.telegram.sendMessage({
      chat_id: chatId,
      text: html,
      parse_mode: 'HTML',
      disable_web_page_preview: true,
    });
  }

  /** Long-poll loop. Runs until stop(); one iteration per getUpdates batch. */
  async run(): Promise<void> {
    this.running = true;
    await this.telegram.setMyCommands([
      { command: 'wallets', description: 'Check the balance of each wallet' },
    ]);
    this.logger.info('wallet bot: polling started');
    while (this.running) {
      try {
        const updates = await this.telegram.getUpdates(this.offset, 25);
        for (const update of updates) {
          this.offset = Math.max(this.offset, update.update_id + 1);
          await this.handle(update);
        }
      } catch (err) {
        this.logger.warn('wallet bot: poll cycle failed', {
          error: err instanceof Error ? err.message : String(err),
        });
        await new Promise((r) => setTimeout(r, 5000));
      }
    }
  }

  stop(): void {
    this.running = false;
  }

  private async handle(update: TelegramUpdate): Promise<void> {
    const message = update.message;
    const text = message?.text?.trim();
    const chatId = message?.chat.id;
    if (message === undefined || text === undefined || chatId === undefined) return;

    // The owner is recognised by AUTHENTICATED SENDER ID (explicit pairing, or the main bot's
    // owner from the shared DB). Any owner message before an explicit pairing exists records one,
    // so the binding is durable even if the main owner row is ever re-paired.
    const owner = this.ownerChatId();
    if (owner !== null && chatId === owner) {
      if (this.store.pairedChatId() === null) {
        this.store.pairOwner(chatId, this.now().toISOString());
        this.logger.info('wallet bot: owner auto-paired from the main bot owner');
        await this.sendPairedWelcome(chatId);
        if (text.startsWith('/start')) return; // the welcome IS the /start response
      }
      if (text.startsWith('/start')) {
        await this.sendPairedWelcome(chatId);
        return;
      }
      if (text === '/wallets' || text.startsWith('/wallets@')) {
        await this.handleBalances(chatId);
      }
      return;
    }

    // Not the known owner. The SECRET path remains for the one legitimate stranger case: a fresh
    // install whose main bot is not paired yet. Everything else gets silence — this bot's
    // existence and contents are financial information, and any reply confirms both.
    if (text.startsWith('/start')) {
      const secret = text.split(/\s+/)[1] ?? '';
      if (owner === null && secret === this.config.pairingSecret) {
        this.store.pairOwner(chatId, this.now().toISOString());
        this.logger.info('wallet bot: owner paired via secret');
        await this.sendPairedWelcome(chatId);
        return;
      }
      this.logger.warn('wallet bot: /start from an unrecognised chat', { chatId });
    }
  }

  private async sendPairedWelcome(chatId: number): Promise<void> {
    await this.telegram.sendMessage({
      chat_id: chatId,
      text:
        '🔐 <b>Wallet bot paired.</b>\n\n' +
        `Watching ${String(this.config.wallets.length)} wallets. You will get an alert for every ` +
        'confirmed transfer in or out.\n\nCommands:\n/wallets — balance of each wallet',
      parse_mode: 'HTML',
    });
  }

  private async handleBalances(chatId: number): Promise<void> {
    const nowMs = this.now().getTime();
    if (nowMs - this.lastBalancesAt < BALANCE_COOLDOWN_MS) return;
    this.lastBalancesAt = nowMs;

    const balances: WalletBalance[] = [];
    for (const wallet of this.config.wallets) {
      try {
        if (wallet.chain === 'eth') {
          const [native, usdt] = [
            await this.etherscan.balance(wallet.address),
            await this.etherscan.tokenBalance(wallet.address, USDT_ETH_CONTRACT, 6),
          ];
          balances.push({
            label: wallet.label,
            chain: 'eth',
            address: wallet.address,
            native,
            usdt,
          });
        } else {
          const acct = await this.trongrid.account(wallet.address);
          balances.push({
            label: wallet.label,
            chain: 'tron',
            address: wallet.address,
            native: acct.trx,
            usdt: acct.usdt,
          });
        }
      } catch (err) {
        this.logger.warn('wallet balance fetch failed', {
          wallet: wallet.label,
          error: err instanceof Error ? err.message : String(err),
        });
        balances.push({
          label: `${wallet.label} (error)`,
          chain: wallet.chain,
          address: wallet.address,
          native: 0,
          usdt: 0,
        });
      }
    }

    let text = formatBalances(balances, this.now().toISOString());
    const trouble = formatChainTrouble(this.watcher.failureSnapshot());
    if (trouble !== null) text += `\n\n${trouble}`;
    if (this.trongrid.runningKeyless()) {
      text += '\n\nℹ️ TronGrid key was rejected (401) — running keyless at a lower rate limit.';
    }
    await this.telegram.sendMessage({
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      disable_web_page_preview: true,
    });
  }
}
