/**
 * Wallet-tracker persistence. OWNS ITS OWN SQLite CONNECTION to the shared database file —
 * deliberately not threaded through the existing `SqliteDatabase`/repository classes, so this
 * feature is added without editing a single existing file. WAL mode (already enabled on this
 * database) makes a second in-process connection safe.
 *
 * Tables are created with CREATE TABLE IF NOT EXISTS only, matching the repository's migration
 * discipline: there is no ALTER path, so getting the shape right the first time matters.
 */

import Database from 'better-sqlite3';

import type { TransferDirection } from './types';

export interface WalletTxRow {
  id: number;
  wallet_address: string;
  chain: string;
  txid: string;
  log_index: number;
  direction: TransferDirection;
  token_contract: string | null;
  symbol: string;
  amount: number;
  fee_native: number | null;
  counterparty: string;
  block_time_utc: string;
  seen_at_utc: string;
  alerted: 0 | 1;
}

export interface WalletAlertRow {
  id: number;
  tx_row_id: number;
  status: 'PENDING' | 'CLAIMED' | 'SENT' | 'FAILED';
  attempts: number;
  last_error: string | null;
}

export class WalletStore {
  private readonly db: Database.Database;

  constructor(databasePath: string) {
    this.db = new Database(databasePath);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('busy_timeout = 5000');
    this.ensureTables();
  }

  close(): void {
    this.db.close();
  }

  private ensureTables(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS wallet_txs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_address TEXT NOT NULL,
        chain TEXT NOT NULL,
        txid TEXT NOT NULL,
        log_index INTEGER NOT NULL,
        direction TEXT NOT NULL,
        token_contract TEXT,
        symbol TEXT NOT NULL,
        amount REAL NOT NULL,
        fee_native REAL,
        counterparty TEXT NOT NULL,
        block_time_utc TEXT NOT NULL,
        seen_at_utc TEXT NOT NULL,
        alerted INTEGER NOT NULL DEFAULT 0,
        UNIQUE (wallet_address, txid, log_index)
      );
      CREATE TABLE IF NOT EXISTS wallet_cursors (
        wallet_address TEXT PRIMARY KEY,
        position TEXT NOT NULL,
        updated_at_utc TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS wallet_alert_outbox (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tx_row_id INTEGER NOT NULL UNIQUE REFERENCES wallet_txs(id),
        status TEXT NOT NULL DEFAULT 'PENDING',
        attempts INTEGER NOT NULL DEFAULT 0,
        last_error TEXT,
        created_at_utc TEXT NOT NULL,
        updated_at_utc TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS wallet_owner (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        telegram_chat_id INTEGER NOT NULL,
        paired_at_utc TEXT NOT NULL
      );
    `);
  }

  // ---------------------------------------------------------------------------------- cursors

  /** The stored cursor, or null when this wallet has never been seen before. */
  getCursor(walletAddress: string): string | null {
    const row = this.db
      .prepare('SELECT position FROM wallet_cursors WHERE wallet_address = ?')
      .get(walletAddress) as { position: string } | undefined;
    return row?.position ?? null;
  }

  setCursor(walletAddress: string, position: string, nowUtc: string): void {
    this.db
      .prepare(
        `INSERT INTO wallet_cursors (wallet_address, position, updated_at_utc) VALUES (?, ?, ?)
         ON CONFLICT(wallet_address) DO UPDATE SET position = excluded.position, updated_at_utc = excluded.updated_at_utc`,
      )
      .run(walletAddress, position, nowUtc);
  }

  // ------------------------------------------------------------------------------ transactions

  /**
   * Record a transfer. Returns the new row id, or null when this (wallet, txid, logIndex) has
   * been seen before — the dedupe that makes re-polling, restarts and HA failovers unable to
   * produce a second alert for the same transfer.
   */
  insertTx(row: Omit<WalletTxRow, 'id' | 'alerted'>): number | null {
    const result = this.db
      .prepare(
        `INSERT OR IGNORE INTO wallet_txs
           (wallet_address, chain, txid, log_index, direction, token_contract, symbol, amount,
            fee_native, counterparty, block_time_utc, seen_at_utc)
         VALUES (@wallet_address, @chain, @txid, @log_index, @direction, @token_contract, @symbol,
                 @amount, @fee_native, @counterparty, @block_time_utc, @seen_at_utc)`,
      )
      .run(row);
    return result.changes === 1 ? Number(result.lastInsertRowid) : null;
  }

  getTx(id: number): WalletTxRow | null {
    return (
      (this.db.prepare('SELECT * FROM wallet_txs WHERE id = ?').get(id) as WalletTxRow) ?? null
    );
  }

  // ------------------------------------------------------------------------------------ outbox

  enqueueAlert(txRowId: number, nowUtc: string): void {
    this.db
      .prepare(
        `INSERT OR IGNORE INTO wallet_alert_outbox (tx_row_id, status, created_at_utc, updated_at_utc)
         VALUES (?, 'PENDING', ?, ?)`,
      )
      .run(txRowId, nowUtc, nowUtc);
  }

  /**
   * Claim the next pending alert — claim-then-send, exactly like the notification outbox: the
   * row is marked CLAIMED before any network call, so a crash mid-send leaves a CLAIMED row to
   * inspect rather than a re-sendable PENDING one.
   */
  claimNextAlert(nowUtc: string): (WalletAlertRow & { tx: WalletTxRow }) | null {
    const claim = this.db.transaction((): (WalletAlertRow & { tx: WalletTxRow }) | null => {
      const alert = this.db
        .prepare(`SELECT * FROM wallet_alert_outbox WHERE status = 'PENDING' ORDER BY id LIMIT 1`)
        .get() as WalletAlertRow | undefined;
      if (alert === undefined) return null;
      this.db
        .prepare(
          `UPDATE wallet_alert_outbox SET status = 'CLAIMED', attempts = attempts + 1, updated_at_utc = ? WHERE id = ?`,
        )
        .run(nowUtc, alert.id);
      const tx = this.getTx(alert.tx_row_id);
      if (tx === null) return null;
      return { ...alert, attempts: alert.attempts + 1, status: 'CLAIMED', tx };
    });
    return claim();
  }

  markAlertSent(alertId: number, txRowId: number, nowUtc: string): void {
    const tx = this.db.transaction(() => {
      this.db
        .prepare(`UPDATE wallet_alert_outbox SET status = 'SENT', updated_at_utc = ? WHERE id = ?`)
        .run(nowUtc, alertId);
      this.db.prepare('UPDATE wallet_txs SET alerted = 1 WHERE id = ?').run(txRowId);
    });
    tx();
  }

  /** A failed send goes back to PENDING (bounded by attempts) or FAILED once exhausted. */
  releaseAlert(alertId: number, error: string, maxAttempts: number, nowUtc: string): void {
    const row = this.db
      .prepare('SELECT attempts FROM wallet_alert_outbox WHERE id = ?')
      .get(alertId) as { attempts: number } | undefined;
    const status = row !== undefined && row.attempts >= maxAttempts ? 'FAILED' : 'PENDING';
    this.db
      .prepare(
        `UPDATE wallet_alert_outbox SET status = ?, last_error = ?, updated_at_utc = ? WHERE id = ?`,
      )
      .run(status, error.slice(0, 300), nowUtc, alertId);
  }

  /**
   * Adopt CLAIMED rows left by a previous process. On restart nothing else will ever touch them:
   * without this, a crash between claim and send would strand the alert forever — the missed-
   * notification failure this outbox exists to prevent. They return to PENDING (the send may or
   * may not have gone out; a possible duplicate is ranked better than a certain silence).
   */
  recoverStaleClaims(nowUtc: string): number {
    return this.db
      .prepare(
        `UPDATE wallet_alert_outbox SET status = 'PENDING', updated_at_utc = ? WHERE status = 'CLAIMED'`,
      )
      .run(nowUtc).changes;
  }

  // ------------------------------------------------------------------------------------ owner

  pairedChatId(): number | null {
    const row = this.db.prepare('SELECT telegram_chat_id FROM wallet_owner WHERE id = 1').get() as
      { telegram_chat_id: number } | undefined;
    return row?.telegram_chat_id ?? null;
  }

  /**
   * The MAIN monitor bot's paired owner, from the shared database. This is what lets the wallet
   * bot recognise its owner without a second secret ceremony: both bots have exactly one
   * legitimate user, Telegram authenticates the sender id on every update, and a private chat's
   * id IS that user's id. Read-only against a table the main app owns; absent (fresh install,
   * main bot unpaired) simply means null.
   */
  mainOwnerChatId(): number | null {
    try {
      const row = this.db.prepare('SELECT telegram_user_id FROM owner LIMIT 1').get() as
        { telegram_user_id: number } | undefined;
      return row?.telegram_user_id ?? null;
    } catch {
      return null; // the main app's owner table is not in this database
    }
  }

  pairOwner(chatId: number, nowUtc: string): void {
    this.db
      .prepare(
        `INSERT INTO wallet_owner (id, telegram_chat_id, paired_at_utc) VALUES (1, ?, ?)
         ON CONFLICT(id) DO UPDATE SET telegram_chat_id = excluded.telegram_chat_id, paired_at_utc = excluded.paired_at_utc`,
      )
      .run(chatId, nowUtc);
  }
}
