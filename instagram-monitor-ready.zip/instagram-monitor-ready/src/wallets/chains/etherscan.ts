/**
 * Etherscan V2 client (V1 was sunset in 2025; one key serves every chain via `chainid`).
 * Free tier: 5 req/s, 100k/day — this module's whole polling load is ~8k/day.
 *
 * Every method returns normalised {@link ChainTransfer}s or plain numbers; nothing downstream
 * knows Etherscan's response shapes. `fetchImpl` is injectable so tests replay the REAL captured
 * responses from the 2026-08-04 probe — including the scam-airdrop rows — without any network.
 */

import type { ChainTransfer } from '../types';

const BASE = 'https://api.etherscan.io/v2/api?chainid=1';

/** Well-known mainnet token contracts, by lowercase address. Display symbols come from here —
 *  NEVER from the API row — for allowlisted tokens, so a scam token cannot spoof its way into a
 *  trusted-looking alert. */
export const ETH_TOKEN_ALLOWLIST: ReadonlyMap<string, string> = new Map([
  ['0xdac17f958d2ee523a2206206994597c13d831ec7', 'USDT'],
  ['0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48', 'USDC'],
]);

interface EtherscanEnvelope {
  status: string;
  message: string;
  result: unknown;
}

interface TokenTxRow {
  hash: string;
  from: string;
  to: string;
  contractAddress: string;
  value: string;
  tokenSymbol: string;
  tokenDecimal: string;
  confirmations: string;
  timeStamp: string;
  gasPrice: string;
  gasUsed: string;
  blockNumber: string;
  transactionIndex: string;
}

interface NativeTxRow {
  hash: string;
  from: string;
  to: string;
  value: string;
  confirmations: string;
  timeStamp: string;
  gasPrice: string;
  gasUsed: string;
  blockNumber: string;
  isError: string;
}

export interface EtherscanClientOptions {
  apiKey: string;
  fetchImpl?: typeof fetch;
}

export class EtherscanClient {
  private readonly apiKey: string;
  private readonly fetchImpl: typeof fetch;

  constructor(options: EtherscanClientOptions) {
    this.apiKey = options.apiKey;
    this.fetchImpl = options.fetchImpl ?? fetch;
  }

  private async call(params: string): Promise<unknown> {
    const res = await this.fetchImpl(`${BASE}&${params}&apikey=${this.apiKey}`);
    if (!res.ok) throw new Error(`etherscan HTTP ${String(res.status)}`);
    const body = (await res.json()) as EtherscanEnvelope;
    // "No transactions found" arrives as status 0 with an empty result — that is an answer, not
    // an error. A genuine error carries a string result explaining itself.
    if (body.status !== '1' && !Array.isArray(body.result)) {
      if (
        typeof body.message === 'string' &&
        body.message.toLowerCase().includes('no transactions')
      ) {
        return [];
      }
      throw new Error(
        `etherscan: ${body.message} ${typeof body.result === 'string' ? body.result : ''}`,
      );
    }
    return body.result;
  }

  /** Native ETH balance, in ETH. */
  async balance(address: string): Promise<number> {
    const result = (await this.call(
      `module=account&action=balance&address=${address}&tag=latest`,
    )) as string;
    return Number(result) / 1e18;
  }

  /** ERC-20 balance for one contract, in token units. */
  async tokenBalance(address: string, contract: string, decimals: number): Promise<number> {
    const result = (await this.call(
      `module=account&action=tokenbalance&address=${address}&contractaddress=${contract}&tag=latest`,
    )) as string;
    return Number(result) / 10 ** decimals;
  }

  /** ERC-20 transfers touching `address` from `startBlock` (inclusive), oldest first. */
  async tokenTransfers(address: string, startBlock: number): Promise<ChainTransfer[]> {
    const rows = (await this.call(
      `module=account&action=tokentx&address=${address}&startblock=${String(startBlock)}&sort=asc&page=1&offset=100`,
    )) as TokenTxRow[];
    return rows.map((r, i) => this.mapTokenRow(r, i));
  }

  /** Native ETH transfers touching `address` from `startBlock`, oldest first. Failed txs skipped. */
  async nativeTransfers(address: string, startBlock: number): Promise<ChainTransfer[]> {
    const rows = (await this.call(
      `module=account&action=txlist&address=${address}&startblock=${String(startBlock)}&sort=asc&page=1&offset=100`,
    )) as NativeTxRow[];
    return rows
      .filter((r) => r.isError !== '1' && r.value !== '0')
      .map((r) => ({
        chain: 'eth' as const,
        txid: r.hash,
        logIndex: -1, // native transfer: one per tx, distinct from any token log index
        from: r.from.toLowerCase(),
        to: r.to.toLowerCase(),
        tokenContract: null,
        symbol: 'ETH',
        amount: Number(r.value) / 1e18,
        confirmations: Number(r.confirmations),
        feeNative: (Number(r.gasPrice) * Number(r.gasUsed)) / 1e18,
        blockTimeUtc: new Date(Number(r.timeStamp) * 1000).toISOString(),
      }));
  }

  /** Highest mined block — the cursor unit for this chain. */
  async latestBlock(): Promise<number> {
    const res = await this.fetchImpl(
      `${BASE}&module=proxy&action=eth_blockNumber&apikey=${this.apiKey}`,
    );
    if (!res.ok) throw new Error(`etherscan HTTP ${String(res.status)}`);
    const body = (await res.json()) as { result: string };
    return Number.parseInt(body.result, 16);
  }

  private mapTokenRow(r: TokenTxRow, index: number): ChainTransfer {
    const contract = r.contractAddress.toLowerCase();
    const trusted = ETH_TOKEN_ALLOWLIST.get(contract);
    return {
      chain: 'eth',
      // transactionIndex is per-block; combined with the row order it distinguishes multiple
      // transfers inside one tx without needing the raw log index Etherscan does not expose.
      txid: r.hash,
      logIndex: Number(r.transactionIndex) * 1000 + index,
      from: r.from.toLowerCase(),
      to: r.to.toLowerCase(),
      tokenContract: contract,
      // Trusted symbol for allowlisted contracts; the chain-reported one (display-only,
      // untrusted) for everything else.
      symbol: trusted ?? r.tokenSymbol,
      amount: Number(r.value) / 10 ** Number(r.tokenDecimal),
      confirmations: Number(r.confirmations),
      feeNative: (Number(r.gasPrice) * Number(r.gasUsed)) / 1e18,
      blockTimeUtc: new Date(Number(r.timeStamp) * 1000).toISOString(),
    };
  }
}
