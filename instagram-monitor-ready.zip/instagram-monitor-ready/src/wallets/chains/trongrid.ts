/**
 * TronGrid client. The API key is OPTIONAL by design: the 2026-08-04 probe measured the owner's
 * key rejected with 401 while keyless access worked — so a configured-but-bad key must degrade to
 * keyless (lower rate limit, still correct) rather than kill the TRON tier. `noteUnauthorized`
 * latches that per process.
 *
 * Only `only_confirmed=true` endpoints are used, so every row this client returns is safe to
 * alert on without a separate confirmation gate.
 */

import type { ChainTransfer } from '../types';

const BASE = 'https://api.trongrid.io';

/** TRON mainnet USDT (TRC-20). The allowlist keys on this, never on a reported symbol. */
export const TRON_USDT_CONTRACT = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';

interface Trc20Row {
  transaction_id: string;
  from: string;
  to: string;
  value: string;
  block_timestamp: number;
  token_info?: { symbol?: string; decimals?: number; address?: string };
}

interface TronAccount {
  balance?: number;
  trc20?: Array<Record<string, string>>;
}

export interface TronGridClientOptions {
  apiKey: string | null;
  fetchImpl?: typeof fetch;
}

export class TronGridClient {
  private readonly fetchImpl: typeof fetch;
  private apiKey: string | null;

  constructor(options: TronGridClientOptions) {
    this.apiKey = options.apiKey;
    this.fetchImpl = options.fetchImpl ?? fetch;
  }

  private headers(): Record<string, string> {
    return this.apiKey !== null ? { 'TRON-PRO-API-KEY': this.apiKey } : {};
  }

  private async call(path: string): Promise<unknown> {
    let res = await this.fetchImpl(`${BASE}${path}`, { headers: this.headers() });
    if (res.status === 401 && this.apiKey !== null) {
      // Bad key. Latch keyless for the rest of the process and retry once: correctness over
      // rate-limit headroom.
      this.apiKey = null;
      res = await this.fetchImpl(`${BASE}${path}`, { headers: {} });
    }
    if (!res.ok) throw new Error(`trongrid HTTP ${String(res.status)}`);
    return res.json();
  }

  /** True once the client has fallen back to keyless — surfaced so the owner can be told once. */
  runningKeyless(): boolean {
    return this.apiKey === null;
  }

  /** TRX + USDT balances. */
  async account(address: string): Promise<{ trx: number; usdt: number }> {
    const body = (await this.call(`/v1/accounts/${address}`)) as {
      success?: boolean;
      data?: TronAccount[];
    };
    const acct = body.data?.[0];
    if (body.success !== true || acct === undefined) {
      // A never-funded TRON account has no on-chain record; that is a zero balance, not an error.
      return { trx: 0, usdt: 0 };
    }
    const usdtEntry = acct.trc20?.find((t) => t[TRON_USDT_CONTRACT] !== undefined);
    return {
      trx: (acct.balance ?? 0) / 1e6,
      usdt: usdtEntry !== undefined ? Number(usdtEntry[TRON_USDT_CONTRACT]) / 1e6 : 0,
    };
  }

  /** Confirmed TRC-20 transfers touching `address` at/after `minTimestampMs`, oldest first. */
  async trc20Transfers(address: string, minTimestampMs: number): Promise<ChainTransfer[]> {
    const body = (await this.call(
      `/v1/accounts/${address}/transactions/trc20?only_confirmed=true&order_by=block_timestamp,asc&min_timestamp=${String(minTimestampMs)}&limit=100`,
    )) as { success?: boolean; data?: Trc20Row[] };
    if (body.success !== true || body.data === undefined) return [];
    return body.data
      .filter((r) => r.value !== undefined)
      .map((r) => {
        const contract = r.token_info?.address ?? '';
        const decimals = r.token_info?.decimals ?? 6;
        return {
          chain: 'tron' as const,
          txid: r.transaction_id,
          logIndex: 0, // TRC-20 endpoint yields one row per transfer event already
          from: r.from,
          to: r.to,
          tokenContract: contract,
          symbol: contract === TRON_USDT_CONTRACT ? 'USDT' : (r.token_info?.symbol ?? '?'),
          amount: Number(r.value) / 10 ** decimals,
          confirmations: null, // only_confirmed=true — confirmed by construction
          feeNative: null, // fetched separately, only for outgoing alerts
          blockTimeUtc: new Date(r.block_timestamp).toISOString(),
        };
      });
  }

  /**
   * Fee for one transaction, in TRX — one extra call, made ONLY for outgoing transfers that are
   * actually being alerted (alerts are rare; polling never pays this).
   */
  async transactionFeeTrx(txid: string): Promise<number | null> {
    try {
      const res = await this.fetchImpl(`${BASE}/wallet/gettransactioninfobyid`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...this.headers() },
        body: JSON.stringify({ value: txid }),
      });
      if (!res.ok) return null;
      const body = (await res.json()) as { fee?: number };
      return body.fee !== undefined ? body.fee / 1e6 : 0;
    } catch {
      // The alert is still worth sending without a fee line; never block on this.
      return null;
    }
  }
}
