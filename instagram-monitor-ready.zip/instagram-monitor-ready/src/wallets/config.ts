/**
 * Wallet-tracker configuration — deliberately a STANDALONE loader, not an extension of the main
 * `loadConfig`. The owner's instruction for this feature was "build this separately, touch
 * nothing else": keeping the schema here means the running system's config path is not edited at
 * all, and the feature switches on purely by the presence of its own env keys.
 *
 * The feature is watch-only by construction: addresses and READ-ONLY API keys. Nothing in this
 * module — or anywhere in this codebase — may ever hold a private key, seed phrase, or any
 * ability to move funds.
 */

export type WalletChain = 'eth' | 'tron';

export interface WatchedWallet {
  chain: WalletChain;
  /** Checksummed/base58 address exactly as configured; comparisons are case-aware per chain. */
  address: string;
  /** Owner-facing name ("Ledger TRC"). Shown in every alert, so it must stay short. */
  label: string;
}

export interface WalletsConfig {
  wallets: WatchedWallet[];
  /** The DEDICATED wallet bot's token — never the monitor bot's. */
  botToken: string;
  /** Pairing secret for the wallet bot's own /start handshake. */
  pairingSecret: string;
  etherscanApiKey: string;
  /** Optional: TronGrid works keyless at a lower rate limit (measured 2026-08-04). */
  tronGridApiKey: string | null;
  pollSeconds: number;
  /** Transfers below this (in token units) are recorded but never alerted. */
  minAlertAmount: number;
  /** ETH confirmations before a transfer may be alerted (reorg guard). */
  ethConfirmations: number;
}

const ETH_ADDRESS_RE = /^0x[0-9a-fA-F]{40}$/;
const TRON_ADDRESS_RE = /^T[1-9A-HJ-NP-Za-km-z]{33}$/;

/**
 * Parse `WALLETS=chain|address|label;chain|address|label;…` — the exact format the owner supplied.
 * Throws on anything malformed: a silently-dropped wallet is a wallet that is silently not being
 * watched, which is this feature's harm rank 1.
 */
export function parseWallets(raw: string): WatchedWallet[] {
  const wallets: WatchedWallet[] = [];
  for (const entry of raw.split(';')) {
    const trimmed = entry.trim();
    if (trimmed === '') continue;
    const parts = trimmed.split('|');
    if (parts.length !== 3) {
      throw new Error(
        `WALLETS entry has ${String(parts.length)} fields, expected 3: chain|address|label`,
      );
    }
    const [chainRaw = '', addressRaw = '', labelRaw = ''] = parts;
    const chain = chainRaw.trim().toLowerCase();
    const address = addressRaw.trim();
    const label = labelRaw.trim();
    if (chain !== 'eth' && chain !== 'tron') {
      throw new Error(`WALLETS: unknown chain "${chain}" (expected eth or tron)`);
    }
    if (chain === 'eth' && !ETH_ADDRESS_RE.test(address)) {
      throw new Error('WALLETS: malformed eth address');
    }
    if (chain === 'tron' && !TRON_ADDRESS_RE.test(address)) {
      throw new Error('WALLETS: malformed tron address');
    }
    if (label === '') throw new Error('WALLETS: empty label');
    wallets.push({ chain, address, label });
  }
  if (wallets.length === 0) throw new Error('WALLETS is set but contains no wallets');
  return wallets;
}

/**
 * Load the feature's config, or null when it is not configured — null simply means the wallet
 * feature stays off, which is how the same build runs on hosts with and without it.
 */
export function loadWalletsConfig(env: NodeJS.ProcessEnv): WalletsConfig | null {
  const walletsRaw = env['WALLETS'];
  const botToken = env['WALLET_BOT_TOKEN'];
  if (walletsRaw === undefined || walletsRaw === '' || botToken === undefined || botToken === '') {
    return null;
  }
  // THE one catastrophic mix-up, refused outright: if the wallet bot ran on the MONITOR bot's
  // token, two getUpdates loops would fight over one update stream and each would steal the
  // other's messages — including /unban commands, silently. Refusing to start the wallet feature
  // costs wallet alerts; starting it would cost monitor commands. Not a close call.
  const monitorToken = env['TELEGRAM_BOT_TOKEN'];
  if (monitorToken !== undefined && monitorToken !== '' && botToken === monitorToken) {
    throw new Error(
      "WALLET_BOT_TOKEN must be a DIFFERENT bot from TELEGRAM_BOT_TOKEN — two polling loops on one token steal each other's updates",
    );
  }
  const pairingSecret = env['WALLET_PAIRING_SECRET'] ?? '';
  if (pairingSecret.length < 8) {
    throw new Error('WALLET_PAIRING_SECRET is required (min 8 chars) when WALLETS is set');
  }
  const etherscanApiKey = env['ETHERSCAN_API_KEY'] ?? '';
  if (etherscanApiKey === '') {
    throw new Error('ETHERSCAN_API_KEY is required when WALLETS is set');
  }
  const tronKey = env['TRONGRID_API_KEY'];
  return {
    wallets: parseWallets(walletsRaw),
    botToken,
    pairingSecret,
    etherscanApiKey,
    tronGridApiKey: tronKey !== undefined && tronKey !== '' ? tronKey : null,
    pollSeconds: clampInt(env['WALLET_POLL_SECONDS'], 45, 15, 600),
    minAlertAmount: clampFloat(env['WALLET_MIN_ALERT'], 1, 0, 1_000_000),
    ethConfirmations: clampInt(env['WALLET_CONFIRMATIONS_ETH'], 12, 1, 200),
  };
}

/**
 * Every wallet-feature secret present in the environment, for the logger's scrub list. Collected
 * even when the feature is off: the keys being in the env is what makes them scrubbable-worthy,
 * not whether anything is currently using them.
 */
export function walletSecrets(env: NodeJS.ProcessEnv): string[] {
  return [
    env['WALLET_BOT_TOKEN'],
    env['WALLET_PAIRING_SECRET'],
    env['ETHERSCAN_API_KEY'],
    env['TRONGRID_API_KEY'],
  ].filter((v): v is string => v !== undefined && v !== '');
}

function clampInt(raw: string | undefined, fallback: number, min: number, max: number): number {
  const n = raw === undefined ? NaN : Number.parseInt(raw, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function clampFloat(raw: string | undefined, fallback: number, min: number, max: number): number {
  const n = raw === undefined ? NaN : Number.parseFloat(raw);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}
