/**
 * Wallet-tracker entry point. The ONLY line the main app will ever need:
 *
 *   const wallets = createWalletFeature({ env: process.env, databasePath, logger });
 *   if (wallets !== null) void wallets.start();
 *
 * Returns null when the feature is unconfigured, so hosts without the env keys run exactly as
 * before. Wiring this into app.ts is DEFERRED until the owner approves it; nothing imports this
 * module yet, and the running system is unchanged by its existence.
 */

import type { Logger } from '../logging';
import { HttpTelegramClient } from '../bot/telegram-client/http-client';
import { EtherscanClient } from './chains/etherscan';
import { TronGridClient } from './chains/trongrid';
import { loadWalletsConfig } from './config';
import { WalletBot } from './bot';
import { WalletStore } from './persistence';
import { WalletWatcher } from './watcher';

export { loadWalletsConfig, parseWallets, walletSecrets } from './config';
export type { WalletsConfig, WatchedWallet, WalletChain } from './config';
export { WalletStore } from './persistence';
export { WalletWatcher } from './watcher';
export { WalletBot } from './bot';
export { EtherscanClient, ETH_TOKEN_ALLOWLIST } from './chains/etherscan';
export { TronGridClient, TRON_USDT_CONTRACT } from './chains/trongrid';
export { formatAlert, formatBalances } from './formatter';

export interface WalletFeatureOptions {
  env: NodeJS.ProcessEnv;
  /** Path to the SHARED SQLite file; this module opens its own WAL connection to it. */
  databasePath: string;
  logger: Logger;
}

export interface WalletFeature {
  /** Starts the bot loop and the polling loop; resolves when stop() is called. */
  start(): Promise<void>;
  stop(): void;
}

export function createWalletFeature(options: WalletFeatureOptions): WalletFeature | null {
  const config = loadWalletsConfig(options.env);
  if (config === null) return null;
  const logger = options.logger;

  const store = new WalletStore(options.databasePath);
  const etherscan = new EtherscanClient({ apiKey: config.etherscanApiKey });
  const trongrid = new TronGridClient({ apiKey: config.tronGridApiKey });
  const telegram = new HttpTelegramClient({ token: config.botToken, logger });

  // Two-phase construction: the watcher needs a sender, the sender lives on the bot, and the bot
  // needs the watcher for its status line. The indirection breaks the cycle without a setter on
  // either class's public surface.
  let bot: WalletBot | null = null;
  const watcher = new WalletWatcher({
    config,
    store,
    etherscan,
    trongrid,
    logger,
    sendAlert: async (html) => {
      if (bot === null) throw new Error('wallet bot not started');
      await bot.sendAlert(html);
    },
  });
  bot = new WalletBot({ config, store, telegram, etherscan, trongrid, watcher, logger });
  const startedBot = bot;

  let timer: ReturnType<typeof setInterval> | null = null;
  let ticking = false;

  return {
    async start(): Promise<void> {
      timer = setInterval(() => {
        // Re-entrancy guard: a slow tick must queue behind itself, not overlap itself.
        if (ticking) return;
        ticking = true;
        void watcher
          .tick()
          .catch((err: unknown) => {
            logger.error('wallet watcher tick threw', {
              error: err instanceof Error ? err.message : String(err),
            });
          })
          .finally(() => {
            ticking = false;
          });
      }, config.pollSeconds * 1000);
      logger.info('wallet feature started', {
        wallets: config.wallets.length,
        pollSeconds: config.pollSeconds,
      });
      await startedBot.run();
    },
    stop(): void {
      if (timer !== null) clearInterval(timer);
      startedBot.stop();
      store.close();
    },
  };
}
