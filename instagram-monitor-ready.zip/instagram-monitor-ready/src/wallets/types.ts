/**
 * The chain-neutral transfer shape both chain clients normalise into. One shape means the
 * watcher, the dedupe, the allowlist and the formatter are written ONCE and tested once.
 */

import type { WalletChain } from './config';

export interface ChainTransfer {
  chain: WalletChain;
  /** Transaction hash/id, chain-native form. */
  txid: string;
  /**
   * Position of this transfer within the transaction. One ETH tx can emit several ERC-20
   * transfers; without this in the dedupe key the second transfer of a tx would be dropped as a
   * "duplicate" of the first.
   */
  logIndex: number;
  /** Sender address, chain-native form. */
  from: string;
  /** Recipient address, chain-native form. */
  to: string;
  /**
   * Token contract address, or null for the chain's native asset (ETH / TRX). The ALLOWLIST keys
   * on this, never on the symbol — scam tokens fake symbols freely (measured on these exact
   * wallets: "Duhash.games" airdrops crafted to look like USDT deposits).
   */
  tokenContract: string | null;
  /** Display symbol as reported by the chain. Untrusted; display-only. */
  symbol: string;
  /** Human units (already divided by decimals). */
  amount: number;
  /** Confirmations at observation time; null where the API only returns confirmed rows. */
  confirmations: number | null;
  /** Fee paid by the SENDER, in the chain's native unit; null when unknown. */
  feeNative: number | null;
  blockTimeUtc: string;
}

export type TransferDirection = 'IN' | 'OUT';

/** A transfer bound to the watched wallet it concerns, with its direction resolved. */
export interface WalletEvent {
  walletAddress: string;
  walletLabel: string;
  direction: TransferDirection;
  transfer: ChainTransfer;
}

export interface WalletBalance {
  label: string;
  chain: WalletChain;
  address: string;
  /** Native asset amount (ETH / TRX). */
  native: number;
  /** USDT amount (the one token balance the owner asked to see). */
  usdt: number;
}
