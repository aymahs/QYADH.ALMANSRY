/**
 * The wallet watcher: discover → filter → record → enqueue → send. One tick covers every wallet.
 *
 * Ordering of protections (each earns its place):
 *   1. FIRST SIGHT of a wallet seeds its cursor to the chain's current position and alerts
 *      nothing — installing this feature must not replay history as an alert storm.
 *   2. The ALLOWLIST admits only known token contracts and native assets. Scam airdrops
 *      (measured on these exact wallets) are recorded for the ledger but never alerted: pushing
 *      one would hand the owner phishing bait formatted as a trusted deposit.
 *   3. ETH transfers below the confirmation floor are left for a LATER tick — the cursor only
 *      advances past what was actually processed, so nothing is skipped, and nothing is alerted
 *      that a reorg could still erase.
 *   4. The UNIQUE index dedupes across re-polls, restarts and HA failovers.
 *   5. Claim-then-send outbox: a crash mid-send can strand a claim (recovered to PENDING at
 *      startup) but can never double-send within one process lifetime.
 */

import type { Logger } from '../logging';
import { ETH_TOKEN_ALLOWLIST, type EtherscanClient } from './chains/etherscan';
import { TRON_USDT_CONTRACT, type TronGridClient } from './chains/trongrid';
import type { WalletsConfig, WatchedWallet } from './config';
import { formatAlert } from './formatter';
import type { WalletStore } from './persistence';
import type { ChainTransfer, TransferDirection } from './types';

const MAX_SEND_ATTEMPTS = 5;

export interface WalletWatcherOptions {
  config: WalletsConfig;
  store: WalletStore;
  etherscan: EtherscanClient;
  trongrid: TronGridClient;
  /** Sends one owner alert; the bot supplies this. Throws on failure. */
  sendAlert: (html: string) => Promise<void>;
  logger: Logger;
  now?: () => Date;
}

export class WalletWatcher {
  private readonly config: WalletsConfig;
  private readonly store: WalletStore;
  private readonly etherscan: EtherscanClient;
  private readonly trongrid: TronGridClient;
  private readonly sendAlert: (html: string) => Promise<void>;
  private readonly logger: Logger;
  private readonly now: () => Date;
  /** Per-chain failure streaks, for bounded backoff without cross-chain contamination. */
  private readonly failures: Record<'eth' | 'tron', number> = { eth: 0, tron: 0 };
  /** Ticks left to skip per chain — the backoff itself: doubles per failure, capped at 16 ticks
   *  (~12 min at the default cadence). The other chain keeps polling at full cadence. */
  private readonly skipTicks: Record<'eth' | 'tron', number> = { eth: 0, tron: 0 };

  constructor(options: WalletWatcherOptions) {
    this.config = options.config;
    this.store = options.store;
    this.etherscan = options.etherscan;
    this.trongrid = options.trongrid;
    this.sendAlert = options.sendAlert;
    this.logger = options.logger;
    this.now = options.now ?? ((): Date => new Date());
    // Claims stranded by a previous process would otherwise never send.
    const recovered = this.store.recoverStaleClaims(this.now().toISOString());
    if (recovered > 0) {
      this.logger.warn('wallet outbox: recovered stale claims from a previous process', {
        recovered,
      });
    }
  }

  /** One full pass: every wallet, then the outbox. Never throws — failures back off per chain. */
  async tick(): Promise<void> {
    for (const chain of ['eth', 'tron'] as const) {
      if (this.skipTicks[chain] > 0) this.skipTicks[chain] -= 1;
    }
    for (const wallet of this.config.wallets) {
      // A chain in backoff is skipped as a whole; one bad API must not delay the other chain.
      if (this.skipTicks[wallet.chain] > 0) continue;
      try {
        if (wallet.chain === 'eth') await this.tickEth(wallet);
        else await this.tickTron(wallet);
        this.failures[wallet.chain] = 0;
      } catch (err) {
        this.failures[wallet.chain] += 1;
        this.skipTicks[wallet.chain] = Math.min(2 ** this.failures[wallet.chain], 16);
        this.logger.warn('wallet poll failed; backing off this chain', {
          wallet: wallet.label,
          chain: wallet.chain,
          consecutive: this.failures[wallet.chain],
          skipTicks: this.skipTicks[wallet.chain],
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
    await this.drainOutbox();
  }

  /** Consecutive failures per chain, for the owner-facing status line. */
  failureSnapshot(): { eth: number; tron: number } {
    return { ...this.failures };
  }

  private async tickEth(wallet: WatchedWallet): Promise<void> {
    const cursor = this.store.getCursor(wallet.address);
    if (cursor === null) {
      const tip = await this.etherscan.latestBlock();
      this.store.setCursor(wallet.address, String(tip + 1), this.now().toISOString());
      this.logger.info('wallet watch started (eth)', { wallet: wallet.label, fromBlock: tip + 1 });
      return; // first sight: seed only, never alert history
    }
    const fromBlock = Number(cursor);
    const [tokens, natives] = [
      await this.etherscan.tokenTransfers(wallet.address, fromBlock),
      await this.etherscan.nativeTransfers(wallet.address, fromBlock),
    ];

    // Advance the cursor only past FULLY PROCESSED blocks. An under-confirmed transfer keeps the
    // cursor at its block so the next tick sees it again once it has matured.
    let advanceTo = fromBlock;
    let sawImmature = false;
    const all = [...tokens, ...natives].sort((a, b) =>
      a.blockTimeUtc.localeCompare(b.blockTimeUtc),
    );
    for (const transfer of all) {
      const confirmations = transfer.confirmations ?? 0;
      if (confirmations < this.config.ethConfirmations) {
        sawImmature = true;
        continue;
      }
      this.recordTransfer(wallet, transfer);
    }
    if (!sawImmature) {
      // Everything seen was processed; next tick starts just past the tip we already covered.
      const tip = await this.etherscan.latestBlock();
      advanceTo = Math.max(fromBlock, tip - this.config.ethConfirmations);
      this.store.setCursor(wallet.address, String(advanceTo), this.now().toISOString());
    }
  }

  private async tickTron(wallet: WatchedWallet): Promise<void> {
    const cursor = this.store.getCursor(wallet.address);
    if (cursor === null) {
      this.store.setCursor(wallet.address, String(this.now().getTime()), this.now().toISOString());
      this.logger.info('wallet watch started (tron)', { wallet: wallet.label });
      return;
    }
    const minTs = Number(cursor);
    const transfers = await this.trongrid.trc20Transfers(wallet.address, minTs);
    let maxTs = minTs;
    for (const transfer of transfers) {
      this.recordTransfer(wallet, transfer);
      const ts = new Date(transfer.blockTimeUtc).getTime();
      if (ts > maxTs) maxTs = ts;
    }
    // +1ms: the min_timestamp filter is inclusive, and re-reading the last row every tick forever
    // would depend solely on the dedupe. Belt and braces, not either alone.
    if (maxTs > minTs) {
      this.store.setCursor(wallet.address, String(maxTs + 1), this.now().toISOString());
    }
  }

  /** Record one transfer; enqueue an alert only if it passes every gate. */
  private recordTransfer(wallet: WatchedWallet, transfer: ChainTransfer): void {
    const direction = this.directionFor(wallet, transfer);
    if (direction === null) return; // touches the address only as an internal hop — not ours

    const rowId = this.store.insertTx({
      wallet_address: wallet.address,
      chain: transfer.chain,
      txid: transfer.txid,
      log_index: transfer.logIndex,
      direction,
      token_contract: transfer.tokenContract,
      symbol: transfer.symbol,
      amount: transfer.amount,
      fee_native: transfer.feeNative,
      counterparty: direction === 'IN' ? transfer.from : transfer.to,
      block_time_utc: transfer.blockTimeUtc,
      seen_at_utc: this.now().toISOString(),
    });
    if (rowId === null) return; // seen before

    if (!this.isAllowlisted(transfer)) {
      this.logger.info('wallet transfer recorded but NOT alerted (token outside allowlist)', {
        wallet: wallet.label,
        symbol: transfer.symbol,
      });
      return;
    }
    if (transfer.amount < this.config.minAlertAmount) return; // dust: recorded, not alerted

    this.store.enqueueAlert(rowId, this.now().toISOString());
  }

  private directionFor(wallet: WatchedWallet, t: ChainTransfer): TransferDirection | null {
    const address = wallet.chain === 'eth' ? wallet.address.toLowerCase() : wallet.address;
    if (t.to === address) return 'IN';
    if (t.from === address) return 'OUT';
    return null;
  }

  /** Native assets always; tokens only by KNOWN CONTRACT — never by symbol. */
  private isAllowlisted(t: ChainTransfer): boolean {
    if (t.tokenContract === null) return true; // ETH / TRX native
    if (t.chain === 'eth') return ETH_TOKEN_ALLOWLIST.has(t.tokenContract);
    return t.tokenContract === TRON_USDT_CONTRACT;
  }

  private async drainOutbox(): Promise<void> {
    for (;;) {
      const claimed = this.store.claimNextAlert(this.now().toISOString());
      if (claimed === null) return;
      try {
        const wallet = this.config.wallets.find((w) => w.address === claimed.tx.wallet_address);
        // Fee for outgoing TRON transfers is fetched lazily, only now that an alert is real.
        let feeNative = claimed.tx.fee_native;
        if (feeNative === null && claimed.tx.chain === 'tron' && claimed.tx.direction === 'OUT') {
          feeNative = await this.trongrid.transactionFeeTrx(claimed.tx.txid);
        }
        const html = formatAlert(claimed.tx, wallet?.label ?? claimed.tx.wallet_address, feeNative);
        await this.sendAlert(html);
        this.store.markAlertSent(claimed.id, claimed.tx.id, this.now().toISOString());
      } catch (err) {
        this.store.releaseAlert(
          claimed.id,
          err instanceof Error ? err.message : String(err),
          MAX_SEND_ATTEMPTS,
          this.now().toISOString(),
        );
        return; // stop draining this tick; the next tick retries
      }
    }
  }
}
