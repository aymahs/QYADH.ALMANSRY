/**
 * Owner-facing rendering for wallet alerts and balances. Telegram HTML, IST timestamps, and the
 * same visual register as the monitor bot's messages.
 *
 * Addresses are always shortened to head…tail in message text; the full address travels only
 * inside the explorer link. Fees are shown on OUTGOING transfers only — the sender pays them, so
 * a fee line on an incoming transfer would be someone else's cost presented as the owner's.
 */

import type { WalletTxRow } from './persistence';
import type { WalletBalance } from './types';

const IST_OPTS: Intl.DateTimeFormatOptions = {
  timeZone: 'Asia/Kolkata',
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  hour: 'numeric',
  minute: '2-digit',
  hour12: true,
};

function istTime(iso: string): string {
  return `${new Intl.DateTimeFormat('en-IN', IST_OPTS).format(new Date(iso))} IST`;
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function shortAddress(addr: string): string {
  return addr.length <= 14 ? addr : `${addr.slice(0, 6)}…${addr.slice(-4)}`;
}

function shortTx(txid: string): string {
  return `${txid.slice(0, 8)}…${txid.slice(-4)}`;
}

function explorerUrl(chain: string, txid: string): string {
  return chain === 'eth'
    ? `https://etherscan.io/tx/${txid}`
    : `https://tronscan.org/#/transaction/${txid}`;
}

/** Group thousands, keep meaningful decimals: 4003.891 -> "4,003.89", 0.0135 ETH stays precise. */
function formatAmount(amount: number, symbol: string): string {
  const decimals = symbol === 'ETH' || symbol === 'TRX' ? 6 : 2;
  return amount.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: decimals,
  });
}

export function formatAlert(
  tx: WalletTxRow,
  walletLabel: string,
  feeNative: number | null,
): string {
  const incoming = tx.direction === 'IN';
  const feeUnit = tx.chain === 'eth' ? 'ETH' : 'TRX';
  const lines = [
    incoming
      ? `📥 <b>RECEIVED — ${escapeHtml(walletLabel)}</b>`
      : `📤 <b>SENT — ${escapeHtml(walletLabel)}</b>`,
    '',
    `<b>${incoming ? '+' : '−'}${formatAmount(tx.amount, tx.symbol)} ${escapeHtml(tx.symbol)}</b>`,
    `${incoming ? 'From' : 'To'}: <code>${escapeHtml(shortAddress(tx.counterparty))}</code>`,
  ];
  if (!incoming && feeNative !== null) {
    lines.push(`Fee: ${formatAmount(feeNative, feeUnit)} ${feeUnit}`);
  }
  lines.push(
    `Time: ${istTime(tx.block_time_utc)}`,
    '',
    `Tx: <a href="${explorerUrl(tx.chain, tx.txid)}">${shortTx(tx.txid)}</a>`,
  );
  return lines.join('\n');
}

export function formatBalances(balances: WalletBalance[], nowIso: string): string {
  const lines = ['💰 <b>WALLET BALANCES</b>', ''];
  const width = Math.max(...balances.map((b) => b.label.length));
  for (const b of balances) {
    const native = `${formatAmount(b.native, b.chain === 'eth' ? 'ETH' : 'TRX')} ${b.chain === 'eth' ? 'ETH' : 'TRX'}`;
    const usdt = `${formatAmount(b.usdt, 'USDT')} USDT`;
    lines.push(`<code>${escapeHtml(b.label.padEnd(width))}</code>  ${usdt} · ${native}`);
  }
  lines.push('', `Updated: ${istTime(nowIso)}`);
  return lines.join('\n');
}

/** One line per chain for a lightweight status view inside /wallets when a chain is failing. */
export function formatChainTrouble(failures: { eth: number; tron: number }): string | null {
  const parts: string[] = [];
  if (failures.eth > 0) parts.push(`Etherscan failing (${String(failures.eth)} in a row)`);
  if (failures.tron > 0) parts.push(`TronGrid failing (${String(failures.tron)} in a row)`);
  if (parts.length === 0) return null;
  return `⚠️ ${parts.join(' · ')} — balances may be stale, alerts resume automatically.`;
}
