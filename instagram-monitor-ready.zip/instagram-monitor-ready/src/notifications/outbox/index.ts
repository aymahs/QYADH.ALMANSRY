/** Barrel for the notification outbox worker. */

export type { OutboxWorkerDeps } from './worker';
export { OutboxWorker } from './worker';
