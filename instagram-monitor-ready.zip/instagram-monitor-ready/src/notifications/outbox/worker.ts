/**
 * The outbox worker: drains the durable notification queue, up to
 * {@link DRAIN_PER_TICK} items per tick. Duplicate alerts and post-/clear alerts are made
 * impossible by a layered set of guards:
 *
 *  1. cleared cases never notify (checked on every delivery, and again via a
 *     compare-and-save re-read before the case is closed out);
 *  2. a case whose notification was already sent never notifies again;
 *  3. `claimNotification` is an atomic single-winner claim across workers;
 *  4. an ambiguous Telegram outcome closes the OWNER alert out immediately so it
 *     can never be re-sent — while the client half proceeds regardless, driven by
 *     the client link's own delivery status (see {@link OutboxWorker.sendOwnerAlert}).
 *
 * The opposite failure — a MISSED client notification — is covered by
 * {@link OutboxWorker.rescueStrandedClientDeliveries}, a slow sweep that finishes a client
 * delivery abandoned by a crash after the owner alert was already recorded SENT.
 *
 * Deferral mechanism (documented choice): the {@link OutboxRepository} interface
 * has no explicit "requeue" method, so a deferred item is simply left CLAIMED.
 * `requeueStale` — run at the top of every tick — resets CLAIMED items older
 * than the stale window (10 minutes) back to PENDING. Each claim increments
 * `attempts`; once a failure occurs with `attempts >= maxAttempts` the item is
 * marked FAILED so nothing ever loops forever.
 */

import { readFile, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import type {
  Clock,
  MonitoringCase,
  OutboxItem,
  OutboxKind,
  Repositories,
  SentMessage,
  TelegramClient,
} from '../../domain';
import { isAppError } from '../../domain';
// Not re-exported by the domain barrel; imported from the module that owns the policy, the
// same way the deletion worker reaches DELETION_PENDING_ALERT_STATUSES.
import type { ClientSendOutcome } from '../../domain/clients';
import {
  CLIENT_DELIVERY_DONE_STATUSES,
  CLIENT_DELIVERY_IN_FLIGHT_STATUS,
  CLIENT_DELIVERY_OWED_STATUS,
  classifyClientSendFailure,
  clientRetryExhausted,
  ownerPingRetryExhausted,
} from '../../domain/clients';
import type { AppConfig } from '../../config';
import type { Logger } from '../../logging';
import type { DiscordNotifier } from '../../bot/discord/discord-notifier';
import {
  recoveryButton,
  recoveryCaption,
  recoveryTextFallback,
  recoveryRestrictedText,
  clientRecoveryCaption,
  clientRecoveryText,
  ownerActionRequired,
} from '../formatter';

/** Delivery attempts (claims) before an item is marked FAILED. */
const DEFAULT_MAX_ATTEMPTS = 3;
/** A CLAIMED item older than this is considered abandoned and is requeued. */
const STALE_CLAIM_MS = 10 * 60 * 1000;
/** Cadence of the stranded-client-delivery sweep. It scans, so it must not run every tick. */
const CLIENT_RESCUE_INTERVAL_MS = 60 * 1000;
/** Default directory holding captured screenshots. */
const DEFAULT_SCREENSHOT_DIR = 'data/screenshots';
/**
 * Tick cadence. Fast on purpose: this interval is dead time sitting between a confirmed recovery
 * and the client being told, and the tick is free when the queue is empty (one indexed claim
 * query, no Telegram call).
 */
const DEFAULT_TICK_MS = 300;
/**
 * How many items ONE tick may drain before yielding.
 *
 * The queue used to be drained one item per tick, so a downgrade (RECOVERY_PHOTO whose file went
 * missing -> RECOVERY_TEXT) enqueued a row that then waited a whole tick to go out. Draining
 * cannot multiply Telegram calls: each pass is a single-winner `claimNextPending`, so it sends
 * exactly what the queue actually holds and stops the moment it is empty. The bound is what keeps
 * one tick from monopolising the loop when a backlog is being worked off.
 */
const DRAIN_PER_TICK = 5;

export interface OutboxWorkerDeps {
  repos: Repositories;
  client: TelegramClient;
  config: AppConfig;
  clock: Clock;
  logger: Logger;
  /** Resolves the paired owner's chat id, or null while unpaired. */
  ownerChatId: () => Promise<number | null>;
  /** Directory holding captured screenshots (default `data/screenshots`). */
  screenshotDir?: string;
  /** Total delivery attempts per item before giving up (default 3). */
  maxAttempts?: number;
  /** Optional best-effort Discord mirror; fires AFTER the Telegram owner delivery succeeds. */
  discord?: DiscordNotifier;
}

export class OutboxWorker {
  private readonly repos: Repositories;
  private readonly client: TelegramClient;
  private readonly config: AppConfig;
  private readonly clock: Clock;
  private readonly logger: Logger;
  private readonly ownerChatId: () => Promise<number | null>;
  private readonly screenshotDir: string;
  private readonly maxAttempts: number;
  private readonly discord: DiscordNotifier | null;

  private timer: ReturnType<typeof setInterval> | null = null;
  private inFlight: Promise<void> | null = null;
  /** Epoch ms of the last client-delivery sweep (0 = never, so the first tick runs one). */
  private lastClientRescueMs = 0;

  constructor(deps: OutboxWorkerDeps) {
    this.repos = deps.repos;
    this.client = deps.client;
    this.config = deps.config;
    this.clock = deps.clock;
    this.logger = deps.logger;
    this.ownerChatId = deps.ownerChatId;
    this.screenshotDir = deps.screenshotDir ?? DEFAULT_SCREENSHOT_DIR;
    this.maxAttempts = deps.maxAttempts ?? DEFAULT_MAX_ATTEMPTS;
    this.discord = deps.discord ?? null;
  }

  /** One tick: requeue abandoned claims, then drain up to {@link DRAIN_PER_TICK} items. */
  async runOnce(): Promise<void> {
    const now = this.clock.now();
    const nowIso = now.toISOString();

    // Both of these SCAN, so they stay once-per-tick and are not pulled into the drain loop
    // below — a 300ms tick must not turn them into a hot query.
    await this.repos.outbox.requeueStale(
      new Date(now.getTime() - STALE_CLAIM_MS).toISOString(),
      nowIso,
    );

    if (now.getTime() - this.lastClientRescueMs >= CLIENT_RESCUE_INTERVAL_MS) {
      this.lastClientRescueMs = now.getTime();
      await this.rescueStrandedClientDeliveries(now).catch((err: unknown) => {
        this.logger.error('outbox worker: client delivery sweep failed', { err });
      });
    }

    for (let drained = 0; drained < DRAIN_PER_TICK; drained += 1) {
      // The single-winner claim is unchanged, and it is what bounds the work: an empty queue
      // returns null on the first pass and the tick costs one query.
      const item = await this.repos.outbox.claimNextPending(this.clock.now().toISOString());
      if (item === null) return;

      try {
        await this.deliver(item, this.clock.now());
      } catch (err) {
        await this.handleSendError(item, err, this.clock.now().toISOString());
      }
    }
  }

  /**
   * Start the tick loop. Runs an immediate first tick (which performs the
   * startup `requeueStale` crash recovery), then repeats on the interval,
   * skipping ticks while a previous one is still in flight.
   */
  start(intervalMs = DEFAULT_TICK_MS): void {
    if (this.timer !== null) return;
    const tick = (): void => {
      if (this.inFlight !== null) return;
      this.inFlight = this.runOnce()
        .catch((err: unknown) => {
          this.logger.error('outbox worker: tick failed', { err });
        })
        .finally(() => {
          this.inFlight = null;
        });
    };
    tick();
    this.timer = setInterval(tick, intervalMs);
  }

  /** Stop the tick loop and wait for any in-flight tick to complete. */
  async stop(): Promise<void> {
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.inFlight !== null) {
      await this.inFlight;
    }
  }

  /** Route one claimed item through the guards and the kind-specific sender. */
  private async deliver(item: OutboxItem, now: Date): Promise<void> {
    const nowIso = now.toISOString();

    const c = await this.repos.cases.findById(item.caseId);
    if (c === null) {
      await this.repos.outbox.markFailed(item.id, 'case_missing', nowIso);
      return;
    }
    // Cleared cases NEVER notify.
    if (c.status === 'CLEARED' || c.clearedAtUtc !== null) {
      await this.repos.outbox.markFailed(item.id, 'case_cleared', nowIso);
      return;
    }
    // Dedup: the recovery notification is sent at most once per case.
    if (
      (item.kind === 'RECOVERY_PHOTO' || item.kind === 'RECOVERY_TEXT') &&
      c.notificationSentAtUtc !== null
    ) {
      await this.repos.outbox.markFailed(item.id, 'already_notified', nowIso);
      return;
    }

    // Resolved before claimNotification so an unpaired bot never burns the
    // single-winner claim: the item just stays deferred until pairing.
    const chatId = await this.ownerChatId();
    if (chatId === null) {
      this.logger.warn('outbox worker: no paired owner; deferring item', { itemId: item.id });
      return; // left CLAIMED; requeueStale will retry after the stale window
    }

    switch (item.kind) {
      case 'RECOVERY_PHOTO':
        await this.sendRecoveryPhoto(item, c, chatId, now);
        return;
      case 'RECOVERY_TEXT':
        await this.sendRecoveryText(item, c, chatId, now);
        return;
      case 'SCREENSHOT_FOLLOWUP':
        await this.sendScreenshotFollowup(item, c, chatId, now);
        return;
      default: {
        const exhaustive: never = item.kind;
        await this.repos.outbox.markFailed(item.id, `unknown_kind:${String(exhaustive)}`, nowIso);
      }
    }
  }

  private async sendRecoveryPhoto(
    item: OutboxItem,
    c: MonitoringCase,
    chatId: number,
    now: Date,
  ): Promise<void> {
    const nowIso = now.toISOString();
    const filePath = this.screenshotPath(c.id);

    // Resolve the file BEFORE claiming so a downgrade never strands the claim.
    const photo = await readIfExists(filePath);
    if (photo === null) {
      await this.enqueueOrRevive(c.id, 'RECOVERY_TEXT', nowIso);
      await this.repos.outbox.markFailed(item.id, 'screenshot_missing', nowIso);
      this.logger.warn('outbox worker: screenshot missing; downgraded to text', {
        caseId: c.id,
      });
      return;
    }

    const fresh = await this.acquireNotificationClaim(item, c, now);
    if (fresh === null) return;

    const caption = recoveryCaption(
      fresh.normalizedUsername,
      fresh.startedAtUtc,
      fresh.confirmedAtUtc ?? nowIso,
      this.config.displayTimezone,
    );
    const messageId = await this.sendOwnerAlert(() =>
      this.client.sendPhoto({
        chat_id: chatId,
        photo,
        caption,
        reply_markup: recoveryButton(fresh.normalizedUsername),
      }),
    );

    const sentIso = this.clock.now().toISOString();
    await this.repos.outbox.markSent(item.id, sentIso, messageId);
    // Held rather than inlined: `notificationSentAtUtc` is the immutable anchor the client
    // delivery's retry budget is measured from, and the pre-close-out `fresh` still has it null.
    const notified: MonitoringCase = {
      ...fresh,
      status: 'NOTIFIED',
      notificationSentAtUtc: sentIso,
      telegramMessageId: messageId,
      screenshotStatus: 'SENT',
      updatedAtUtc: sentIso,
    };
    const closed = await this.closeOutAsNotified(notified);
    if (!closed) {
      // The owner cleared this monitor mid-send. "Cleared cases NEVER notify" wins over the
      // client half too, so stop here rather than pushing into a cancelled client's chat.
      await deleteIfExists(filePath);
      return;
    }
    // CLIENT FIRST — they are the one paying for this alert. The Discord mirror below is an
    // internal convenience for the owner, and running it here (as it used to) put a whole
    // photo upload to Discord's API in front of the client's message: measured ~0.9s of the
    // client's recovery latency spent on our own bookkeeping.
    //
    // Independent of the owner send's outcome: idempotency lives in the client link's own
    // delivery status, so the client is reached exactly once either way.
    await this.deliverToClient(notified, photo, this.clock.now()).catch(() => undefined);
    // Best-effort Discord mirror (#unbans). The notifier never throws and a null discord is a
    // no-op; the extra `catch` is belt-and-braces so a Discord failure can never reach the
    // caller's error handling and re-drive a delivery that already happened. It fires on an
    // AMBIGUOUS owner send too — that is precisely when the owner needs a second channel,
    // since the Telegram alert may never have arrived.
    await this.discord
      ?.unban(caption, { buffer: photo, filename: `${fresh.normalizedUsername}.png` })
      .catch(() => undefined);
    await this.cleanUpScreenshot(notified.id, filePath);
  }

  /**
   * Delete the proof screenshot — unless a client delivery is still owed a retry.
   *
   * The retry path re-reads this file. Deleting it while the client is still owed the message
   * silently downgrades their recovery alert to text, i.e. the picture the alert is built around
   * is lost to a transient network blip. Once the client half is settled (delivered, or handed to
   * the owner) there is nothing left that wants it.
   */
  private async cleanUpScreenshot(caseId: string, filePath: string): Promise<void> {
    const link = await this.repos.clientLinks.findByMonitorId(caseId);
    if (link !== null && link.clientDeliveryStatus === CLIENT_DELIVERY_OWED_STATUS) return;
    await deleteIfExists(filePath);
  }

  private async sendRecoveryText(
    item: OutboxItem,
    c: MonitoringCase,
    chatId: number,
    now: Date,
  ): Promise<void> {
    const nowIso = now.toISOString();

    const fresh = await this.acquireNotificationClaim(item, c, now);
    if (fresh === null) return;

    // A "Restricted profile" recovery is intentionally text-only (nothing viewable to
    // capture) — send the honest "restricted" copy and never chase a screenshot follow-up.
    // Any other text recovery is a screenshot FAILURE the monitor worker will re-capture.
    const isRestricted = fresh.screenshotStatus === 'RESTRICTED';
    const text = isRestricted
      ? recoveryRestrictedText(
          fresh.normalizedUsername,
          fresh.startedAtUtc,
          fresh.confirmedAtUtc ?? nowIso,
          this.config.displayTimezone,
        )
      : recoveryTextFallback(
          fresh.normalizedUsername,
          fresh.startedAtUtc,
          fresh.confirmedAtUtc ?? nowIso,
          this.config.displayTimezone,
        );

    const messageId = await this.sendOwnerAlert(() =>
      this.client.sendMessage({
        chat_id: chatId,
        text,
        reply_markup: recoveryButton(fresh.normalizedUsername),
      }),
    );

    const sentIso = this.clock.now().toISOString();
    await this.repos.outbox.markSent(item.id, sentIso, messageId);
    // See sendRecoveryPhoto: the closed-out snapshot, not `fresh`, is what the client half needs.
    const notified: MonitoringCase = {
      ...fresh,
      status: 'NOTIFIED',
      notificationSentAtUtc: sentIso,
      telegramMessageId: messageId,
      // A text recovery means the proof image did NOT go out. Recording that on the case is the
      // whole retry mechanism: `FAILED` is what the monitor's re-capture sweep looks for. It also
      // covers the downgrade path (a RECOVERY_PHOTO whose file went missing), which used to close
      // out still labelled CAPTURED and so was never chased. `RESTRICTED` is not a failure —
      // there is nothing viewable to capture — so it is never re-taken.
      screenshotStatus: isRestricted ? 'RESTRICTED' : 'FAILED',
      updatedAtUtc: sentIso,
    };
    const closed = await this.closeOutAsNotified(notified);
    if (!closed) return;
    // CLIENT FIRST, then our own mirror — see the ordering note in sendRecoveryPhoto.
    // Client business delivery (text-only, since no rendered screenshot was captured).
    await this.deliverToClient(notified, null, this.clock.now()).catch(() => undefined);
    // Best-effort Discord mirror (#unbans), text-only. Also fires on an ambiguous owner send.
    await this.discord?.unban(text).catch(() => undefined);
    // NOTE: SCREENSHOT_FOLLOWUP is deliberately NOT enqueued here. This handler has no screenshot
    // and cannot make one, so a row queued now could only claim, find nothing, and be failed —
    // a retry that merely looked like it existed. The monitor worker enqueues it once it has
    // actually re-captured a file.
  }

  /**
   * Deliver the recovery into the linked client conversation on behalf of the owner's Business
   * account. Independent of owner delivery, idempotent via the link's delivery status, and
   * honest about Telegram's 24h reply-window limit (never a fake "delivered").
   *
   * THE SEND AND THE BOOKKEEPING ARE DIFFERENT EVENTS AND LIVE IN DIFFERENT STEPS. They used to
   * share one try block, which made two opposite failures indistinguishable:
   *
   *  - a transient send failure (429, a network blip, a momentary 5xx) was treated as terminal.
   *    The link went straight to OWNER_ACTION_REQUIRED, which the rescue sweep deliberately
   *    refuses to touch, so the paying client's recovery alert was lost for good on ONE bad
   *    packet — the exact failure this product exists to prevent;
   *  - a failure of the "delivered" WRITE after a SUCCESSFUL send landed in the same catch. When
   *    the escalation write failed too (the usual case — it is the same sick database), the whole
   *    thing threw, the caller swallowed it, and the link was left still owed. The sweep then
   *    sent the client a second "YOUR ACCOUNT IS BACK".
   *
   * Both are fixed by claim-then-send: the link is parked in {@link CLIENT_DELIVERY_IN_FLIGHT_STATUS}
   * BEFORE the message goes out. A definite failure rewinds it to
   * {@link CLIENT_DELIVERY_OWED_STATUS} and the sweep retries; anything else — a possibly-landed
   * send, a lost bookkeeping write, a crash mid-send — leaves it parked, and a parked link is
   * NEVER re-sent, only escalated to the owner.
   */
  private async deliverToClient(c: MonitoringCase, photo: Buffer | null, now: Date): Promise<void> {
    const nowIso = now.toISOString();
    const link = await this.repos.clientLinks.findByMonitorId(c.id);
    if (link === null) return; // owner-only monitor
    if (CLIENT_DELIVERY_DONE_STATUSES.includes(link.clientDeliveryStatus)) {
      return; // already delivered — idempotent
    }

    const ownerId = await this.ownerChatId();

    // A previous pass got as far as putting a message on the wire and never recorded what came
    // back (its "delivered" write failed, or the process died). The client may already be
    // holding this alert, so re-sending is the one thing we must not do: hand it to the owner.
    if (link.clientDeliveryStatus === CLIENT_DELIVERY_IN_FLIGHT_STATUS) {
      await this.escalateClientDelivery(
        c,
        ownerId,
        'previous send outcome never recorded',
        now,
        nowIso,
      );
      return;
    }

    const connection = await this.repos.businessConnections.findById(link.businessConnectionId);
    if (connection === null || !connection.isEnabled || !connection.rights.canReply) {
      const status =
        connection === null || !connection.isEnabled
          ? 'BUSINESS_CONNECTION_DISABLED'
          : 'BUSINESS_PERMISSION_MISSING';
      // Same hazard as escalateClientDelivery: both of these statuses are terminal for the rescue
      // sweep, so committing one while the ping fell on the floor buries the client for good. Only
      // a ping that landed (or a spent ping budget) may commit it; otherwise park the link in the
      // "escalation pending" state the sweep DOES revisit — it can only ever re-ping from there,
      // never re-send, and the connection is disabled anyway.
      const told =
        ownerId !== null && (await this.pingOwnerActionRequired(ownerId, c.normalizedUsername));
      await this.repos.clientLinks.updateDeliveryStatus(
        c.id,
        told || ownerPingRetryExhausted(this.clientRetryAnchor(c), now)
          ? status
          : CLIENT_DELIVERY_IN_FLIGHT_STATUS,
        nowIso,
      );
      return;
    }

    // ---- Claim. If THIS write fails nothing has been sent, so the link keeps whatever
    // retryable state it had and a later sweep tries again.
    await this.repos.clientLinks.updateDeliveryStatus(
      c.id,
      CLIENT_DELIVERY_IN_FLIGHT_STATUS,
      nowIso,
    );

    // ---- Send. NOTHING else belongs in this try: every statement inside it is a statement
    // whose failure would be misread as "the client was not told".
    const confirmedIso = c.confirmedAtUtc ?? nowIso;
    const tz = this.config.displayTimezone;
    let outcome: ClientSendOutcome;
    try {
      if (photo !== null) {
        await this.client.sendPhoto({
          chat_id: link.clientChatId,
          photo,
          caption: clientRecoveryCaption(c.normalizedUsername, c.startedAtUtc, confirmedIso, tz),
          reply_markup: recoveryButton(c.normalizedUsername),
          business_connection_id: link.businessConnectionId,
        });
      } else {
        const msg = clientRecoveryText(c.normalizedUsername, c.startedAtUtc, confirmedIso, tz);
        const params: Parameters<TelegramClient['sendMessage']>[0] = {
          chat_id: link.clientChatId,
          text: msg.text,
          business_connection_id: link.businessConnectionId,
        };
        if (msg.replyMarkup) params.reply_markup = msg.replyMarkup;
        await this.client.sendMessage(params);
      }
      outcome = 'DELIVERED';
    } catch (err) {
      outcome = classifyClientSendFailure(err);
      this.logger.warn('client business delivery failed', {
        monitorId: c.id,
        outcome,
        code: isAppError(err) ? err.code : 'unknown',
      });
    }

    // ---- Record. A throw from here leaves the link parked in the in-flight status, which is
    // precisely the durable "do not send this again" marker the sweep reads.
    if (outcome === 'DELIVERED') {
      await this.repos.clientLinks.updateDeliveryStatus(c.id, 'BUSINESS_DELIVERED', nowIso);
      this.logger.info('client business delivery ok', { monitorId: c.id });
      return;
    }
    if (outcome === 'POSSIBLY_DELIVERED') {
      await this.escalateClientDelivery(c, ownerId, 'send outcome unknowable', now, nowIso);
      return;
    }
    // Definitely not delivered. Retry until the budget is spent, then let the owner finish it.
    if (clientRetryExhausted(this.clientRetryAnchor(c), now)) {
      await this.escalateClientDelivery(c, ownerId, 'retry budget exhausted', now, nowIso);
      return;
    }
    await this.repos.clientLinks.updateDeliveryStatus(c.id, CLIENT_DELIVERY_OWED_STATUS, nowIso);
  }

  /**
   * Immutable instant the client's retry budget runs from. The owner alert's send time is
   * written once and never rewritten, and the first client attempt happens microseconds later,
   * so it is both stable across restarts and a fair measure of how long the client has waited.
   */
  private clientRetryAnchor(c: MonitoringCase): string {
    return c.notificationSentAtUtc ?? c.confirmedAtUtc ?? c.startedAtUtc;
  }

  /**
   * Hand a client delivery to the owner: OWNER_ACTION_REQUIRED is terminal for the sweep, so this
   * is the single point where the retry loop ends.
   *
   * CLAIM-THEN-PING, and the ordering is the whole fix. It used to write OWNER_ACTION_REQUIRED
   * FIRST and then make ONE unretried ping whose failure was swallowed — bounding the owner to *at
   * most* one notification, which includes ZERO. Nothing in the system ever revisits that status
   * (`rescueStrandedClientDeliveries` sweeps only OWED and IN_FLIGHT, `/ping` and `/clients` never
   * read it), so a dropped ping meant the client was never told AND the owner never learned they
   * had to do it by hand. And the drop is CORRELATED with the escalation: we are here precisely
   * because Telegram egress has been failing for the whole 15-minute client-retry window.
   *
   * So the link is parked in {@link CLIENT_DELIVERY_IN_FLIGHT_STATUS} first — the durable "NEVER
   * send this client another message" marker, which is exactly the guarantee an escalation needs —
   * and only a ping that PROVABLY landed is allowed to commit the terminal status. A ping that did
   * not land leaves the link parked, and the 60s sweep comes back for the PING alone: it re-enters
   * {@link deliverToClient}, which routes an in-flight link straight back here and never re-sends.
   *
   * The retry is bounded by {@link ownerPingRetryExhausted} so a genuinely unreachable owner
   * (blocked bot, deleted chat, still unpaired) settles instead of pinging Telegram forever.
   */
  private async escalateClientDelivery(
    c: MonitoringCase,
    ownerChatId: number | null,
    reason: string,
    now: Date,
    nowIso: string,
  ): Promise<void> {
    // Claim first: from here on the client must never receive another copy, whatever happens to
    // the ping below or to this process.
    await this.repos.clientLinks.updateDeliveryStatus(
      c.id,
      CLIENT_DELIVERY_IN_FLIGHT_STATUS,
      nowIso,
    );
    this.logger.error('outbox worker: client delivery handed to the owner', {
      monitorId: c.id,
      reason,
    });

    const told =
      ownerChatId !== null &&
      (await this.pingOwnerActionRequired(ownerChatId, c.normalizedUsername));
    if (!told && !ownerPingRetryExhausted(this.clientRetryAnchor(c), now)) {
      this.logger.error('outbox worker: owner escalation ping did not land; will retry', {
        monitorId: c.id,
        unpaired: ownerChatId === null,
      });
      return; // left parked: the sweep retries the PING, never another client send
    }
    await this.repos.clientLinks.updateDeliveryStatus(c.id, 'OWNER_ACTION_REQUIRED', nowIso);
    if (!told) {
      this.logger.error(
        'outbox worker: owner could not be reached about a stranded client delivery',
        { monitorId: c.id, username: c.normalizedUsername },
      );
    }
  }

  /**
   * Rescue a client half stranded by a crash AFTER the owner alert was recorded SENT.
   *
   * `markSent` commits before both the case close-out and {@link deliverToClient}, so a container
   * restart in that window leaves the link sitting at BUSINESS_DELIVERY_PENDING with nothing left
   * to drive it: the outbox row is SENT so it is never claimed again, and the scheduler's sweep
   * deliberately refuses to revive a SENT row. That stranded the paying client permanently and
   * silently — the worst failure this system has.
   *
   * This is also the retry loop for a transient client-send failure: such a link is rewound to
   * BUSINESS_DELIVERY_PENDING, so the two cases are the same work and need the same sweep. An
   * in-flight link is picked up too, but only so it can be escalated — {@link deliverToClient}
   * never re-sends one. That is also what drives the owner-ping retry: an escalation whose ping
   * did not land leaves the link parked in-flight, so each pass re-attempts the PING alone.
   *
   * The owner-escalated statuses stay terminal for this sweep, otherwise it would re-ping the
   * owner every minute forever — which is safe now precisely because that status is written only
   * once the ping has provably landed (or its bounded budget is spent). Delivery stays idempotent
   * via the link's own status, exactly as on the normal path.
   */
  private async rescueStrandedClientDeliveries(now: Date): Promise<void> {
    for (const link of await this.repos.clientLinks.listAll()) {
      if (
        link.clientDeliveryStatus !== CLIENT_DELIVERY_OWED_STATUS &&
        link.clientDeliveryStatus !== CLIENT_DELIVERY_IN_FLIGHT_STATUS
      ) {
        continue;
      }
      const c = await this.repos.cases.findById(link.monitorId);
      if (c === null || c.status === 'CLEARED' || c.clearedAtUtc !== null) continue;
      const items = await this.repos.outbox.findByCase(c.id);
      // The owner's alert is the proof the recovery is real. Without it the outbox still owns
      // this case and delivering to the client now could jump ahead of a cancelled recovery.
      const ownerAlerted = items.some(
        (i) => (i.kind === 'RECOVERY_PHOTO' || i.kind === 'RECOVERY_TEXT') && i.status === 'SENT',
      );
      if (!ownerAlerted) continue;
      this.logger.warn('outbox worker: resuming an unfinished client delivery', {
        monitorId: c.id,
        status: link.clientDeliveryStatus,
      });
      // The screenshot may already have been cleaned up; a text delivery is the honest fallback.
      const filePath = this.screenshotPath(c.id);
      const photo = await readIfExists(filePath);
      await this.deliverToClient(c, photo, now);
      // Held back by cleanUpScreenshot while the client was owed a retry; this pass is what
      // finally releases it once their delivery is settled either way.
      await this.cleanUpScreenshot(c.id, filePath);
    }
  }

  /**
   * Tell the owner a client delivery needs finishing by hand. Returns whether the message
   * PROVABLY reached Telegram.
   *
   * The boolean is the point: this used to swallow every failure into `undefined`, which made a
   * dropped ping indistinguishable from a delivered one and let the caller commit a terminal
   * status on the strength of a send that never happened. `TELEGRAM_AMBIGUOUS` is reported as
   * NOT told, deliberately — the cost of being wrong that way is one duplicate owner ping (harm
   * rank 4), against a permanently stranded client (harm rank 1) the other way.
   */
  private async pingOwnerActionRequired(ownerChatId: number, username: string): Promise<boolean> {
    const msg = ownerActionRequired(username);
    const params: Parameters<TelegramClient['sendMessage']>[0] = {
      chat_id: ownerChatId,
      text: msg.text,
    };
    if (msg.replyMarkup) params.reply_markup = msg.replyMarkup;
    try {
      await this.client.sendMessage(params);
      return true;
    } catch (err) {
      this.logger.error('outbox worker: owner action-required ping failed', {
        code: isAppError(err) ? err.code : 'unknown',
      });
      return false;
    }
  }

  /**
   * Deliver the proof screenshot that the recovery alert went out without. Enqueued by the
   * monitor worker only once it has actually re-captured a file, so unlike before there is
   * always something to send.
   */
  private async sendScreenshotFollowup(
    item: OutboxItem,
    c: MonitoringCase,
    chatId: number,
    now: Date,
  ): Promise<void> {
    const nowIso = now.toISOString();

    if (c.status !== 'NOTIFIED') {
      await this.deferOrFail(item, 'case_not_notified', nowIso);
      return;
    }
    const filePath = this.screenshotPath(c.id);
    const photo = await readIfExists(filePath);
    if (photo === null) {
      await this.deferOrFail(item, 'screenshot_missing', nowIso);
      return;
    }

    // A reply to the original recovery message, intentionally without caption. An AMBIGUOUS
    // recovery send left no message id to reply to; skip the owner's copy rather than post a
    // contextless photo.
    //
    // The owner's copy NEVER holds up the CLIENT's proof below — they are the one paying for it.
    // Letting the send throw did exactly that: `reply_to_message_id` is rejected outright once the
    // owner deletes the message it points at (or the bot is re-paired to another chat), and up to
    // RECAPTURE_WINDOW_MS separates the two, so that is routine. The rejection is a plain
    // TELEGRAM_ERROR, which `sendOwnerAlert` rethrows, so every attempt aborted before `markSent`
    // and before `deliverProofToClient` — and once the item exhausted its attempts nothing could
    // revive it (the case is already screenshotStatus CAPTURED, which the re-capture sweep skips).
    // The client silently never got the picture the text-only alert promised.
    const replyToMessageId = c.telegramMessageId;
    let messageId: number | null = null;
    if (replyToMessageId !== null) {
      try {
        messageId = await this.sendOwnerAlert(() =>
          this.client.sendPhoto({
            chat_id: chatId,
            photo,
            reply_to_message_id: replyToMessageId,
          }),
        );
      } catch (err) {
        this.logger.error('outbox worker: owner follow-up photo failed; client proof continues', {
          caseId: c.id,
          detail: isAppError(err) ? err.code : err instanceof Error ? err.message : String(err),
        });
      }
    }

    const sentIso = this.clock.now().toISOString();
    await this.repos.outbox.markSent(item.id, sentIso, messageId);
    await this.repos.cases.save({ ...c, screenshotStatus: 'SENT', updatedAtUtc: sentIso });
    await this.deliverProofToClient(c, photo);
    await deleteIfExists(filePath);
  }

  /**
   * Send the re-captured screenshot into the linked client chat, as the proof their text-only
   * recovery message promised. Deliberately captionless: the recovery itself was already
   * announced, and repeating that copy would read as a second "your account is back".
   *
   * Only ever chases a client who WAS told. A link still pending or escalated belongs to
   * {@link deliverToClient} and {@link rescueStrandedClientDeliveries}, which deliver the full
   * recovery message — jumping in here would leave them with a bare photo and no explanation.
   */
  private async deliverProofToClient(c: MonitoringCase, photo: Buffer): Promise<void> {
    const link = await this.repos.clientLinks.findByMonitorId(c.id);
    if (link === null) return; // owner-only monitor
    if (
      link.clientDeliveryStatus !== 'BUSINESS_DELIVERED' &&
      link.clientDeliveryStatus !== 'FALLBACK_BOT_DELIVERED'
    ) {
      return;
    }
    const connection = await this.repos.businessConnections.findById(link.businessConnectionId);
    if (connection === null || !connection.isEnabled || !connection.rights.canReply) return;
    try {
      await this.client.sendPhoto({
        chat_id: link.clientChatId,
        photo,
        business_connection_id: link.businessConnectionId,
      });
      this.logger.info('client proof screenshot delivered', { monitorId: c.id });
    } catch (err) {
      // Never rethrow: the owner's copy has already been marked SENT, so a throw here would only
      // re-send that. The client is not left uninformed either — they have the recovery message
      // itself; only the picture is missing, and this log is how that surfaces.
      this.logger.warn('client proof screenshot failed', {
        monitorId: c.id,
        code: isAppError(err) ? err.code : 'unknown',
      });
    }
  }

  /**
   * Perform an owner-facing send, absorbing ONLY the ambiguous outcome. Returns the Telegram
   * message id, or null when the send may or may not have landed.
   *
   * Ambiguity is resolved HERE, at the send site, and never in {@link handleSendError}. The
   * caller still holds the fresh case and the photo bytes, so it can close the owner alert out
   * — it is never re-sent, because a duplicate "YOUR ACCOUNT IS BACK" to a paying client is
   * unacceptable — and still run the independent client delivery underneath. An earlier fix
   * closed the case from `handleSendError`, which sits ABOVE `deliverToClient` on the call
   * path: every client-linked monitor was then silently stranded with no owner ping and no
   * sweep, because the case looked notified. That was a permanent miss, and far worse.
   */
  private async sendOwnerAlert(send: () => Promise<SentMessage>): Promise<number | null> {
    try {
      const sent = await send();
      return sent.message_id;
    } catch (err) {
      if (!isAppError(err) || err.code !== 'TELEGRAM_AMBIGUOUS') throw err;
      this.logger.error('outbox worker: owner send outcome unknown; closing it out unretried', {
        detail: err.message,
      });
      return null;
    }
  }

  /**
   * Persist the NOTIFIED close-out, dropping it if a /clear landed while we were sending.
   * Returns false when the save was dropped — the case is gone, so nothing further is due.
   */
  private async closeOutAsNotified(next: MonitoringCase): Promise<boolean> {
    const stored = await this.repos.cases.findById(next.id);
    if (stored === null || stored.status === 'CLEARED' || stored.clearedAtUtc !== null) {
      this.logger.warn('outbox worker: close-out dropped; case cleared mid-send', {
        caseId: next.id,
      });
      return false;
    }
    await this.repos.cases.save(next);
    return true;
  }

  /**
   * Make sure (caseId, kind) has a deliverable row. `enqueue` is idempotent-on-conflict, so on
   * its own it silently does nothing when an exhausted FAILED row already exists — which is
   * exactly the row a downgrade needs to revive.
   */
  private async enqueueOrRevive(caseId: string, kind: OutboxKind, nowIso: string): Promise<void> {
    await this.repos.outbox.enqueue({ caseId, kind, createdAtUtc: nowIso });
    await this.repos.outbox.reopenFailed(caseId, kind, nowIso);
  }

  /**
   * Atomically claim the sole right to notify. Returns the fresh case when this
   * caller may proceed (won the claim, or took over a stale claim from a
   * crashed worker), or null when the item was failed/deferred instead.
   */
  private async acquireNotificationClaim(
    item: OutboxItem,
    c: MonitoringCase,
    now: Date,
  ): Promise<MonitoringCase | null> {
    const nowIso = now.toISOString();
    const won = await this.repos.cases.claimNotification(c.id, nowIso);
    const fresh = await this.repos.cases.findById(c.id);
    if (fresh === null) {
      await this.repos.outbox.markFailed(item.id, 'case_missing', nowIso);
      return null;
    }
    if (won) return fresh;

    if (fresh.notificationSentAtUtc !== null) {
      await this.repos.outbox.markFailed(item.id, 'already_notified', nowIso);
      return null;
    }
    const claimedAt = fresh.notificationClaimedAtUtc;
    const stale =
      claimedAt !== null && now.getTime() - new Date(claimedAt).getTime() > STALE_CLAIM_MS;
    if (!stale) {
      // A live claimant may still be sending: defer rather than risk a duplicate.
      await this.deferOrFail(item, 'claim_contention_gave_up', nowIso);
      return null;
    }
    // The claimant crashed before sending: safe to take over.
    this.logger.warn('outbox worker: taking over stale notification claim', { caseId: c.id });
    return fresh;
  }

  /** Defer (leave CLAIMED for requeueStale) or mark FAILED once attempts are spent. */
  private async deferOrFail(item: OutboxItem, failLabel: string, nowIso: string): Promise<void> {
    if (item.attempts >= this.maxAttempts) {
      await this.repos.outbox.markFailed(item.id, failLabel, nowIso);
      this.logger.error('outbox worker: giving up on item', {
        itemId: item.id,
        caseId: item.caseId,
        reason: failLabel,
        attempts: item.attempts,
      });
    } else {
      this.logger.info('outbox worker: deferring item for retry', {
        itemId: item.id,
        reason: failLabel,
        attempts: item.attempts,
      });
    }
  }

  /**
   * Send-failure policy for ORDINARY failures: defer (leave CLAIMED for `requeueStale`) until
   * `maxAttempts` claims are spent, then mark the item FAILED.
   *
   * `TELEGRAM_AMBIGUOUS` no longer arrives here — every owner send routes through
   * {@link sendOwnerAlert}, which resolves it where the case and the photo are still in hand.
   * Should one ever escape, it is failed immediately rather than deferred: deferring hands it
   * to `requeueStale`, which would re-send an alert that may already have landed. Failing it
   * leaves the rescue to the stranded-notification sweep, which is the right trade — this
   * project treats a MISSED client notification as worse than a duplicate.
   */
  private async handleSendError(item: OutboxItem, err: unknown, nowIso: string): Promise<void> {
    if (isAppError(err) && err.code === 'TELEGRAM_AMBIGUOUS') {
      await this.repos.outbox.markFailed(item.id, 'ambiguous_unhandled', nowIso);
      this.logger.error('outbox worker: unhandled ambiguous delivery; item failed', {
        itemId: item.id,
        caseId: item.caseId,
        kind: item.kind,
      });
      return;
    }

    const detail = isAppError(err) ? err.code : err instanceof Error ? err.message : String(err);
    if (item.attempts >= this.maxAttempts) {
      await this.repos.outbox.markFailed(item.id, `telegram_error:${detail}`, nowIso);
      this.logger.error('outbox worker: delivery failed permanently', {
        itemId: item.id,
        caseId: item.caseId,
        detail,
      });
    } else {
      this.logger.warn('outbox worker: delivery failed; deferring', {
        itemId: item.id,
        detail,
        attempts: item.attempts,
      });
    }
  }

  private screenshotPath(caseId: string): string {
    return join(this.screenshotDir, `${caseId}.png`);
  }
}

/** Read a file, returning null when it does not exist. */
async function readIfExists(filePath: string): Promise<Buffer | null> {
  try {
    return await readFile(filePath);
  } catch (err) {
    if (isErrnoException(err) && err.code === 'ENOENT') return null;
    throw err;
  }
}

/** Delete a file, ignoring a missing file. */
async function deleteIfExists(filePath: string): Promise<void> {
  try {
    await unlink(filePath);
  } catch (err) {
    if (isErrnoException(err) && err.code === 'ENOENT') return;
    throw err;
  }
}

function isErrnoException(err: unknown): err is NodeJS.ErrnoException {
  return err instanceof Error && 'code' in err;
}
