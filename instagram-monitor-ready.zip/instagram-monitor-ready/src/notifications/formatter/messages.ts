/**
 * Pure message formatters. Every function returns plain, deterministic text (and an
 * optional inline keyboard) with no side effects — the outbox and command layers turn
 * these into Telegram payloads. Wording here is the single source of truth for the bot's
 * user-facing copy.
 */

import type { InlineKeyboardMarkup, ClientIdentity } from '../../domain';
import { formatDuration, formatIstDateTime, durationMsBetween, profileUrl } from '../../core';
// Type-only: erased at build time, so the pure formatter layer still pulls no runtime code from
// the Instagram/egress side.
import type { EgressRouteWord, EgressSwitchOutcome } from '../../instagram/proxy-switch';

/** A formatted outgoing message: text plus an optional inline keyboard. */
export interface FormattedMessage {
  text: string;
  replyMarkup?: InlineKeyboardMarkup;
}

/** Listable case status as surfaced to `/list`. */
export type MonitoredStatus = 'MONITORING' | 'CONFIRMING' | 'ERROR_BACKOFF' | 'UNKNOWN_BACKOFF';

/** One row for the `/list` view. */
export interface MonitoredItem {
  username: string;
  status: MonitoredStatus;
  confirmationCount: number;
  startedIso: string;
  lastResult?: 'ACTIVE' | 'GONE' | 'UNKNOWN' | null;
  consecutiveUnknownCount?: number;
  nextCheckAtIso?: string | null;
  lastCheckedAtIso?: string | null;
}

const CONFIRMATION_TARGET = 3;

/** `/unban` acceptance block. */
export function monitoringStarted(
  username: string,
  startedIso: string,
  tz: string,
): FormattedMessage {
  return {
    text: [
      '👀 Monitoring Started',
      '',
      `User: @${username}`,
      `Started: ${formatIstDateTime(startedIso, tz)}`,
      'Status: Checking Instagram',
      '',
      "I'll notify you as soon as the account is confirmed active.",
    ].join('\n'),
  };
}

/**
 * `/unban` acceptance when the live pre-check did NOT complete.
 *
 * A distinct block rather than a footnote on {@link monitoringStarted}, mirroring the
 * "❓ Monitoring, but NOT pre-checked" bucket {@link bulkMonitoringStarted} already prints.
 * The account IS enrolled either way — refusing to monitor because a probe failed would risk a
 * missed recovery, the worst failure this system has — but "👀 Monitoring Started" reads as
 * "we looked, and it is down". A login wall, a navigation timeout or an open circuit breaker all
 * answer UNKNOWN while proving nothing, and if the page was in fact already public it is
 * confirmed ACTIVE within minutes and a recovery that never happened is announced.
 */
export function monitoringStartedUnverified(
  username: string,
  startedIso: string,
  tz: string,
  reason: string,
): FormattedMessage {
  return {
    text: [
      '❓ Monitoring, but NOT pre-checked',
      '',
      `User: @${username}`,
      `Started: ${formatIstDateTime(startedIso, tz)}`,
      'Status: Monitoring — nothing has verified this page is down',
      '',
      reason,
      `If @${username} is already public it will alert as "unbanned" shortly — run`,
      `/check ${username}, or /clear ${username}.`,
    ].join('\n'),
  };
}

/** `/unban` on an already-tracked username. */
export function alreadyMonitoring(
  username: string,
  startedIso: string,
  now: Date,
): FormattedMessage {
  const elapsed = formatDuration(now.getTime() - new Date(startedIso).getTime());
  return {
    text: [
      'ℹ️ Already Monitoring',
      '',
      `@${username} is already being monitored.`,
      `Monitoring time: ${elapsed}`,
    ].join('\n'),
  };
}

/** Compact duration for the dense /list view: "2d 04h" / "4h 21m" / "21m 09s" / "9s".
 *  Kept CHARACTER-IDENTICAL to the Discord embed's compactDuration so the two surfaces read
 *  the same account the same way. */
function compactDuration(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(s / 86400);
  const hours = Math.floor((s % 86400) / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;
  if (days > 0) return `${days}d ${String(hours).padStart(2, '0')}h`;
  if (hours > 0) return `${hours}h ${String(mins).padStart(2, '0')}m`;
  if (mins > 0) return `${mins}m ${String(secs).padStart(2, '0')}s`;
  return `${secs}s`;
}

function compactRetryLine(nextCheckAtIso: string | null | undefined, now: Date): string {
  if (!nextCheckAtIso) return 'retry pending';
  const delta = new Date(nextCheckAtIso).getTime() - now.getTime();
  return delta <= 0 ? `overdue ${compactDuration(-delta)}` : `retry in ${compactDuration(delta)}`;
}

/** Telegram messages hard-cap at 4096 chars; stay under it with margin. */
const LIST_TEXT_BUDGET = 3900;

/**
 * `/list` view: EVERY account in ONE message, grouped by status, one line each — the same dense
 * shape as the Discord embed the owner preferred. Pagination is gone by request: at one line per
 * account, well over a hundred accounts fit inside Telegram's 4096-char message cap. If that cap
 * is ever actually threatened the list truncates with an explicit "… and N more" line — an honest
 * cut, never a silent one, and never a Page 2 to ask for.
 */
export function listView(items: MonitoredItem[], now: Date): FormattedMessage {
  const total = items.length;
  if (total === 0) {
    return {
      text: '👀 Monitored Accounts\n\nNo Instagram accounts are currently being monitored.',
    };
  }

  const line = (item: MonitoredItem): string => {
    const elapsed = compactDuration(now.getTime() - new Date(item.startedIso).getTime());
    if (item.status === 'CONFIRMING') {
      return `@${item.username} · ${item.confirmationCount}/${CONFIRMATION_TARGET} · ${elapsed}`;
    }
    if (item.status === 'ERROR_BACKOFF' || item.status === 'UNKNOWN_BACKOFF') {
      return `@${item.username} · ${elapsed} · ${compactRetryLine(item.nextCheckAtIso, now)}`;
    }
    return `@${item.username} · ${elapsed}`;
  };

  const groups: Array<{ header: string; members: MonitoredItem[] }> = [
    { header: '🟢 Monitoring', members: items.filter((i) => i.status === 'MONITORING') },
    { header: '🟡 Confirming', members: items.filter((i) => i.status === 'CONFIRMING') },
    { header: '🔴 Error backoff', members: items.filter((i) => i.status === 'ERROR_BACKOFF') },
    { header: '⚪ Unclear response', members: items.filter((i) => i.status === 'UNKNOWN_BACKOFF') },
  ];

  const blocks: string[] = [];
  let used = 0;
  let dropped = 0;
  for (const g of groups) {
    if (g.members.length === 0) continue;
    const header = `${g.header}: ${g.members.length}`;
    const lines = [header];
    used += header.length + 2;
    for (const m of g.members) {
      const l = line(m);
      if (used + l.length + 1 > LIST_TEXT_BUDGET) {
        dropped += 1;
        continue;
      }
      lines.push(l);
      used += l.length + 1;
    }
    blocks.push(lines.join('\n'));
  }

  let text = `👀 Monitored Accounts — ${total}\n\n${blocks.join('\n\n')}`;
  if (dropped > 0) text += `\n\n… and ${dropped} more`;
  return { text };
}

/** `/clear` success. */
export function monitoringRemoved(username: string): FormattedMessage {
  return { text: `🗑 Monitoring Removed\n\n@${username} is no longer being monitored.` };
}

/** `/clear` on an untracked username. */
export function notFound(username: string): FormattedMessage {
  return { text: `ℹ️ Not Found\n\n@${username} is not currently being monitored.` };
}

/** `/ping` when every component is healthy. */
export function pingHealthy(input: {
  accounts: number;
  probeSeconds: number;
  /**
   * Screenshot subsystem status on the control probe. 'working' = a fresh screenshot was
   * captured. 'limited' = the control profile was login-gated so nothing was captured; this
   * is expected (Instagram gates the mega-account) and live monitored profiles still capture.
   */
  screenshot?: 'working' | 'limited';
  /**
   * The fast (HTTP) tier's OWN report on itself. Reported separately because it carries almost
   * all real traffic, and it cannot be inferred from a probe: the tiered detector falls back to
   * the browser on every fast-tier failure, so a dead fast tier used to print "Working".
   * Omitted when the injected detector has no fast tier to report on.
   */
  fastTier?: {
    state: 'ok' | 'degraded' | 'disabled' | 'blocked';
    detail: string;
    /** Probes answered per tier, so "Working" is backed by a number rather than a canary alone. */
    answered?: TierCounts;
  };
  /** Canary verdict: is the egress route serving live profiles at all? */
  canaryHealthy?: boolean;
  /**
   * The fleet-wide Chromium page-load budget. Always shown when present, healthy or not: the
   * owner is running on a single residential IP, and how much of this hour's budget has been
   * spent is the number that predicts the next burn.
   */
  browserBudget?: BrowserBudgetLine;
}): FormattedMessage {
  const screenshotLine =
    input.screenshot === 'limited'
      ? 'Screenshot capture: Limited (control profile login-gated; live profiles capture normally)'
      : 'Screenshot capture: Working';
  const extra: string[] = [];
  if (input.fastTier !== undefined) {
    extra.push(fastTierLine(input.fastTier.state, input.fastTier.detail, input.fastTier.answered));
  }
  // Browser-only mode never measures a canary, so printing one would be a fabricated reading.
  if (input.canaryHealthy !== undefined && input.fastTier?.state !== 'disabled') {
    extra.push(
      input.canaryHealthy
        ? 'Egress canary: Serving live profiles'
        : 'Egress canary: NOT serving live profiles (cheap "still gone" results are not trusted)',
    );
  }
  if (input.browserBudget !== undefined) {
    extra.push(...browserBudgetLines(input.browserBudget));
  }
  return {
    text: [
      '✅ Monitoring System Healthy',
      '',
      'Browser: Working',
      'Instagram detector: ACTIVE',
      ...extra,
      screenshotLine,
      'Database: Working',
      'Scheduler: Working',
      `Monitoring: ${input.accounts} accounts`,
      `Probe time: ${input.probeSeconds.toFixed(2)} seconds`,
    ].join('\n'),
  };
}

/** Probes answered per tier since start, as the detector counts them. */
export interface TierCounts {
  fast: number;
  browser: number;
  blocked: number;
  /** Routine checks the browser-load governor deferred (rescheduled, never dropped). */
  deferred?: number;
}

/** The subset of the governor's report /ping renders. Mirrors `BrowserBudgetReport`. */
export interface BrowserBudgetLine {
  capacity: number;
  routineAllowance: number;
  used: number;
  deferred: number;
  intervalMultiplier: number;
  baselineIntervalSeconds: number;
  throttling: boolean;
  reason: string;
}

/**
 * The browser-load budget, as the owner needs to read it.
 *
 * Three facts, and all three are load-bearing: how much of the hour's Chromium budget is gone
 * (the number that predicts the next IP burn), what the poll interval ACTUALLY is right now
 * (self-throttling must never be something the owner has to infer from slow alerts), and WHY.
 */
export function browserBudgetLines(b: BrowserBudgetLine): string[] {
  const effective = Math.round(b.baselineIntervalSeconds * b.intervalMultiplier);
  const lines = [
    `Browser loads: ${b.used}/${b.capacity} this hour (routine cap ${b.routineAllowance})`,
  ];
  lines.push(
    b.intervalMultiplier > 1
      ? `Check interval: ${effective}s — SLOWED from ${b.baselineIntervalSeconds}s (${b.intervalMultiplier}x)`
      : `Check interval: ${effective}s`,
  );
  if (b.throttling) {
    lines.push(`Self-throttling: ${b.reason}`);
    if (b.deferred > 0) {
      lines.push(
        'Recovery confirmations, screenshots and your own commands are NOT affected — only routine polling is deferred.',
      );
    }
  }
  return lines;
}

/**
 * One line describing the fast tier, shared by the healthy and unhealthy `/ping` bodies so the
 * owner reads the same wording either way.
 *
 * On 'ok' the tier split is printed alongside it. "Working" on its own is a claim about the
 * control account; the split is the evidence that the tier is actually carrying real traffic,
 * and it is the number that moves first when the egress route starts costing browser loads.
 */
export function fastTierLine(
  state: 'ok' | 'degraded' | 'disabled' | 'blocked',
  detail: string,
  answered?: TierCounts,
): string {
  switch (state) {
    case 'ok': {
      const reached = answered === undefined ? 0 : answered.fast + answered.browser;
      return reached === 0
        ? 'Fast probe: Working'
        : `Fast probe: Working — answered ${answered?.fast ?? 0} of ${reached} checks`;
    }
    case 'disabled':
      return `Fast probe: Off — ${detail}`;
    case 'blocked':
      return `Fast probe: Paused — ${detail}`;
    case 'degraded':
      // Spelled out because the cost is not obvious: with the fast tier down EVERY routine check
      // becomes a full Chromium load, roughly 30x the requests against a single residential IP.
      return `Fast probe: DEGRADED — ${detail}. Every check now costs a full browser load.`;
  }
}

/**
 * Owner-facing name for a route word, as it appears in the command that selects it.
 *
 * The INTERNAL words stay 'direct'/'mobile' (they name the transport), but the owner types
 * 'home'/'vps' (they name where the traffic leaves from). Rendering goes through this one
 * function so a suggestion in any reply is always a command that actually parses.
 */
function routeCommand(route: EgressRouteWord): string {
  return route === 'direct' ? '/proxy home' : '/proxy vps';
}

/**
 * The bare `/proxy` view: where traffic exits right now, and what else is selectable.
 *
 * `current` MUST come from `ProxySwitch.describe()`, which is host:port only. Proxy credentials
 * are secrets and never appear in a chat reply.
 */
export function egressStatus(input: { current: string; configured: boolean }): FormattedMessage {
  return {
    text: [
      '🌐 Egress route',
      '',
      `Current: ${input.current}`,
      `Proxy configured: ${input.configured ? 'yes' : 'no'}`,
      '',
      'Switch with:',
      '/proxy home — this machine’s own connection (free)',
      '/proxy vps — the configured proxy (metered per GB)',
      '',
      'Either way I check the new route against the control account before confirming, and',
      'put the fleet back if it cannot see Instagram.',
      '',
      'Note: "home" is whatever network THIS instance sits on — your home line when the bot runs',
      'on your PC, but the datacenter IP (which Instagram blocks) when it runs on the VPS.',
    ].join('\n'),
  };
}

/**
 * The reply to `/proxy <route>`, rendered from what was actually MEASURED.
 *
 * One formatter for both surfaces on purpose. The owner reads Telegram and Discord as one
 * system; two copies of this wording would drift, and the case that matters most — "the fleet is
 * now blind" — is exactly the one that must never be softer on one surface than the other.
 *
 * Nothing here interpolates anything but `ProxySwitch.describe()` output and detector detail
 * strings, both of which are credential-free by construction.
 */
export function egressSwitchResult(
  outcome: EgressSwitchOutcome,
  controlUsername: string,
): FormattedMessage {
  const control = `@${controlUsername}`;
  switch (outcome.kind) {
    case 'unavailable':
      return {
        text: [
          '⚠️ No proxy is configured (BROWSER_PROXY_SERVER is empty), so "vps" is unavailable.',
          '',
          `Nothing changed — still on: ${outcome.current}`,
        ].join('\n'),
      };

    case 'reverted':
      // The loudest message in this file, and the one the VPS case produces. It must read as an
      // ALARM, not a status line: the owner asked for something that would have stopped every
      // client alert, and the only reason it did not is that the bot refused.
      return {
        text: [
          '🚨 EGRESS NOT SWITCHED — that route is BLIND',
          '',
          `Tried: ${outcome.attempted}`,
          `Instagram did not serve the control account (${control}) over it:`,
          `  ${outcome.detail}`,
          '',
          'A route that cannot see Instagram detects NO recoveries, so I put the fleet back on:',
          `  ${outcome.current}`,
          '(that is the route you were already on — I did not re-test it; run /ping to confirm.)',
          '',
          'If you meant to switch anyway, send the same command again within 10 minutes and I',
          `will leave it there:  ${routeCommand(outcome.requested)}`,
        ].join('\n'),
      };

    case 'kept-blind':
      return {
        text: [
          '🚨 EGRESS SWITCHED — AND THE FLEET IS NOW BLIND',
          '',
          `Now using: ${outcome.current}`,
          `Instagram did not serve the control account (${control}) over it:`,
          `  ${outcome.detail}`,
          '',
          'You asked twice, so I left it there. NO RECOVERY WILL BE DETECTED on this route —',
          'no client will be told their account is back.',
          ...(outcome.alternative === null
            ? []
            : ['', `To go back: ${routeCommand(outcome.alternative)}`]),
        ].join('\n'),
      };

    case 'switched':
    case 'unchanged': {
      const changed = outcome.kind === 'switched';
      const header = changed
        ? outcome.verification.status === 'verified'
          ? '✅ Egress switched — and VERIFIED'
          : outcome.verification.status === 'unverified'
            ? '⚠️ Egress switched, but NOT verified'
            : '🚨 EGRESS SWITCHED — AND THE FLEET IS NOW BLIND'
        : outcome.verification.status === 'verified'
          ? 'ℹ️ Already on that route — nothing changed'
          : outcome.verification.status === 'unverified'
            ? '⚠️ Already on that route — nothing changed, and I could not check it'
            : '🚨 Already on that route — AND IT IS BLIND';

      const lines = [header, '', `${changed ? 'Now using' : 'Current'}: ${outcome.current}`];
      switch (outcome.verification.status) {
        case 'verified':
          lines.push(
            // Latency is only quoted for a real switch, which always forces a fresh measurement.
            // A no-op does not invalidate the canary cache, so its verdict can legitimately be a
            // few seconds old and answered with no request at all — and a sub-millisecond reading
            // means the same thing. Either way, printing it would be a fabricated round trip.
            changed && outcome.verification.latencyMs !== null && outcome.verification.latencyMs > 0
              ? `Checked: Instagram served the control account (${control}) over it in ${outcome.verification.latencyMs} ms.`
              : `Checked: Instagram served the control account (${control}) over it.`,
          );
          if (changed) lines.push('', 'Monitoring continues from the next check.');
          break;
        case 'unverified':
          lines.push(
            `I could NOT confirm this route can see Instagram:`,
            `  ${outcome.verification.detail}`,
            '',
            'Until it is confirmed, treat the fleet as possibly blind — run /ping in a moment.',
          );
          break;
        case 'blind':
          lines.push(
            `Instagram did not serve the control account (${control}) over it:`,
            `  ${outcome.verification.detail}`,
            '',
            'NO RECOVERY WILL BE DETECTED on this route — no client will be told their account',
            'is back.',
          );
          if (outcome.alternative !== null) {
            lines.push('', `To move off it: ${routeCommand(outcome.alternative)}`);
          }
          break;
      }
      return { text: lines.join('\n') };
    }
  }
}

/**
 * `/ping` when one or more components failed.
 *
 * `context` carries facts the owner needs REGARDLESS of the verdict — today the browser-load
 * budget and the effective check interval. They used to be printed only on the healthy path,
 * which meant the one reading that explains a slow fleet vanished exactly when the fleet was
 * slow.
 */
export function pingUnhealthy(failures: string[], context: string[] = []): FormattedMessage {
  const lines = [
    '❌ Monitoring System Unhealthy',
    '',
    'The following components reported problems:',
  ];
  for (const failure of failures) {
    lines.push(`- ${failure}`);
  }
  if (context.length > 0) {
    lines.push('', ...context);
  }
  return { text: lines.join('\n') };
}

/** Exact caption sent with the recovery screenshot. */
export function recoveryCaption(
  username: string,
  startedIso: string,
  confirmedIso: string,
  tz: string,
): string {
  return [
    `You can use @${username} again`,
    '',
    `TAT: ${formatDuration(durationMsBetween(startedIso, confirmedIso))}`,
    `Time: ${formatIstDateTime(confirmedIso, tz)}`,
    'By: @r.nmc',
  ].join('\n');
}

/** Text-only fallback used when the screenshot could not be captured. */
export function recoveryTextFallback(
  username: string,
  startedIso: string,
  confirmedIso: string,
  tz: string,
): string {
  const notice = '⚠️ Screenshot capture failed — retrying in the background.';
  return `${notice}\n\n${recoveryCaption(username, startedIso, confirmedIso, tz)}`;
}

/**
 * `/unban` recovery for a "Restricted profile" (age-gated) account. No screenshot exists —
 * Instagram only shows its content while logged in — so we say so honestly and point the
 * owner at "Open Instagram" to view it in their own signed-in app. NOT a capture failure.
 */
export function recoveryRestrictedText(
  username: string,
  startedIso: string,
  confirmedIso: string,
  tz: string,
): string {
  const notice = '🔒 Restricted profile — tap Open Instagram to view it in your app.';
  return `${recoveryCaption(username, startedIso, confirmedIso, tz)}\n\n${notice}`;
}

/**
 * `/ban` deletion confirmed: the watched account went ACTIVE -> GONE (deleted / deactivated /
 * banned), confirmed 3x. Text-only — a gone page has nothing to screenshot.
 */
export function deletionConfirmed(
  username: string,
  startedIso: string,
  confirmedIso: string,
  tz: string,
): string {
  return [
    '🚫 INSTAGRAM ACCOUNT NO LONGER AVAILABLE',
    '',
    `User @${username} has gone inactive (deleted, deactivated, or banned) on Instagram.`,
    '',
    `⏱ Watched for: ${formatDuration(durationMsBetween(startedIso, confirmedIso))}`,
    `🕒 Confirmed gone: ${formatIstDateTime(confirmedIso, tz)}`,
  ].join('\n');
}

/**
 * `/bulkunban`: ONE consolidated confirmation for a batch, instead of a message per account.
 * Breaks the batch into started (new), already-monitoring, and skipped-invalid.
 */
export function bulkMonitoringStarted(input: {
  /** Monitoring, and CONFIRMED not currently public by a live pre-check. */
  started: string[];
  already: string[];
  /** Skipped because the profile is ALREADY public — monitoring would fire a false recovery. */
  alreadyLive?: string[];
  /**
   * Monitoring, but the live pre-check could NOT be completed (deadline, or the shared circuit
   * breaker is open). Kept separate from `started` on purpose: silently mixing unverified
   * accounts into "started" is exactly how a false "ACCOUNT UNBANNED" reaches a client.
   */
  unverified?: string[];
  /** Why verification stopped, when `unverified` is non-empty (e.g. fleet back-off). */
  unverifiedReason?: string;
  invalid: string[];
  failed: string[];
  truncated: boolean;
}): FormattedMessage {
  const { started, already, invalid, failed, truncated } = input;
  const alreadyLive = input.alreadyLive ?? [];
  const unverified = input.unverified ?? [];
  const newlyMonitored = started.length + unverified.length;
  const nothingNew = newlyMonitored === 0 && already.length === 0;
  const lines: string[] = [
    nothingNew ? 'ℹ️ Bulk Monitor' : '✅ Bulk Monitoring Started',
    '',
    `Now monitoring ${newlyMonitored} new account${newlyMonitored === 1 ? '' : 's'}.`,
  ];
  if (started.length > 0) {
    lines.push(started.map((u) => `@${u}`).join(', '));
  }
  if (unverified.length > 0) {
    lines.push(
      '',
      `❓ Monitoring, but NOT pre-checked (${unverified.length}): ${unverified
        .map((u) => `@${u}`)
        .join(', ')}`,
      input.unverifiedReason ?? 'The live check could not be completed.',
      'If one of these is already public it will alert as "unbanned" shortly — run /check on it,',
      'or /clear it.',
    );
  }
  if (already.length > 0) {
    lines.push(
      '',
      `ℹ️ Already monitoring (${already.length}): ${already.map((u) => `@${u}`).join(', ')}`,
    );
  }
  if (alreadyLive.length > 0) {
    lines.push(
      '',
      `✅ Already active, not monitored (${alreadyLive.length}): ${alreadyLive
        .map((u) => `@${u}`)
        .join(', ')}`,
      'These pages are already public — use /ban to be told if one goes down.',
    );
  }
  if (failed.length > 0) {
    lines.push(
      '',
      `❗ Failed — please re-add (${failed.length}): ${failed.map((u) => `@${u}`).join(', ')}`,
    );
  }
  if (invalid.length > 0) {
    lines.push('', `⚠️ Skipped invalid (${invalid.length}): ${invalid.join(', ')}`);
  }
  if (truncated) {
    lines.push('', 'Note: only the first 50 usernames were processed.');
  }
  // Only promise per-account alerts when something is actually being monitored.
  if (newlyMonitored > 0) {
    lines.push('', "I'll notify you here as each account is confirmed active.");
  }
  return { text: lines.join('\n') };
}

/** One client's monitored pages, for the /clients view. */
export interface ClientGroup {
  clientChatId: number;
  identity: ClientIdentity | null;
  pages: string[];
}

/** A human label for a client: '@user (First Last)' / '@user' / 'First Last' / 'Client #id'. */
function clientLabel(identity: ClientIdentity | null, clientChatId: number): string {
  if (identity !== null) {
    const name = [identity.firstName, identity.lastName]
      .filter((p): p is string => !!p)
      .join(' ')
      .trim();
    if (identity.username !== null && name !== '') return `@${identity.username} (${name})`;
    if (identity.username !== null) return `@${identity.username}`;
    if (name !== '') return name;
  }
  return `Client #${clientChatId}`;
}

/**
 * `/clients`: monitored pages grouped by the client chat they were started in, plus a
 * "Direct" group for pages started in the owner's own DM. Owner-facing only.
 */
export function clientsView(
  clients: ClientGroup[],
  direct: string[],
  page = 1,
  pageSize = 8,
): FormattedMessage {
  if (clients.length === 0 && direct.length === 0) {
    return { text: '👥 Clients\n\nNo monitored accounts yet.' };
  }
  // Paginate by client so the message can never exceed Telegram's 4096-char limit.
  const totalPages = Math.max(1, Math.ceil(clients.length / pageSize));
  const currentPage = Math.min(Math.max(1, Math.floor(page)), totalPages);
  const start = (currentPage - 1) * pageSize;
  const pageClients = clients.slice(start, start + pageSize);

  const lines: string[] = [`👥 Clients — ${clients.length}`, ''];
  for (const g of pageClients) {
    lines.push(`👤 ${clientLabel(g.identity, g.clientChatId)}`);
    for (const p of g.pages) lines.push(`   • @${p}`);
    lines.push('');
  }
  // Show the "Direct" group once, on the last page.
  if (direct.length > 0 && currentPage === totalPages) {
    lines.push(`📥 Direct (your DM) — ${direct.length}`);
    for (const p of direct) lines.push(`   • @${p}`);
  }
  let text = lines.join('\n').trimEnd();
  if (totalPages > 1) text += `\n\nPage ${currentPage}/${totalPages}`;
  return { text };
}

/** Inline keyboard with a single "Open Instagram" link (SSRF-guarded via profileUrl). */
export function recoveryButton(username: string): InlineKeyboardMarkup {
  return { inline_keyboard: [[{ text: 'Open Instagram', url: profileUrl(username) }]] };
}

/** /check: probe started (the browser check takes several seconds). */
export function checkInProgress(username: string): FormattedMessage {
  return { text: `🔎 Checking @${username}…` };
}

/** /check: caption for the screenshot when the profile is live. */
export function checkActiveCaption(username: string): string {
  return `✅ @${username} is already active.`;
}

/** Business chat: confirmation shown to the client when the owner starts monitoring in-chat. */
export function businessMonitoringStarted(
  username: string,
  startedIso: string,
  tz: string,
): FormattedMessage {
  return {
    text: [
      '🔎 RECOVERY MONITORING STARTED',
      '',
      `Instagram: @${username}`,
      'Status: Waiting for the profile to become publicly active',
      `Started: ${formatIstDateTime(startedIso, tz)}`,
      '',
      'You will receive an update here when recovery is confirmed.',
    ].join('\n'),
    replyMarkup: recoveryButton(username),
  };
}

/**
 * Business chat: `/unban` refused because this page is already linked to a DIFFERENT client chat.
 *
 * Deliberately says nothing about the other client: this lands in a second paying customer's
 * conversation, so it may not disclose who else is being monitored. The actionable detail goes to
 * the owner's DM ({@link ownerClientLinkConflict}) instead.
 */
export function businessMonitorLinkedElsewhere(username: string): FormattedMessage {
  return {
    text: [
      '⚠️ NOT STARTED',
      '',
      `Instagram: @${username}`,
      'This page is already linked to another conversation, so monitoring was not started here.',
      '',
      'We have been notified and will follow up.',
    ].join('\n'),
  };
}

/**
 * Owner DM: a `/unban` was refused because the monitor already belongs to another client chat.
 *
 * The owner has to see this and act. One monitor can carry ONE client chat id, and the first
 * client was already told "RECOVERY MONITORING STARTED" — re-pointing the link would leave them
 * permanently untold about their own recovery. So the first link is kept and the owner is named
 * the chat that owns it, because only they can decide which client should receive the alert.
 */
export function ownerClientLinkConflict(params: {
  username: string;
  existingChatId: number;
  existingIdentity: ClientIdentity | null;
  attemptedChatId: number;
}): FormattedMessage {
  const { username, existingChatId, existingIdentity, attemptedChatId } = params;
  // Always spell out the numeric chat id: a display name can be shared or missing, and the owner
  // needs to be able to tell the two conversations apart with certainty. Owner DM only.
  const label = clientLabel(existingIdentity, existingChatId);
  const linkedTo =
    label === `Client #${existingChatId}` ? label : `${label} [chat ${existingChatId}]`;
  return {
    text: [
      '⚠️ CLIENT LINK CONFLICT',
      '',
      `/unban @${username} did NOT start anything in the chat you just typed in.`,
      '',
      `@${username} is already linked to another client chat, and that link was kept:`,
      `   • Alert goes to: ${linkedTo}`,
      `   • You typed it in: Client #${attemptedChatId}`,
      '',
      'Only one chat can receive the recovery alert.',
      `To move it, run /clear ${username} first — that stops monitoring for the client above —`,
      'then re-run /unban inside the chat that should receive the alert.',
    ].join('\n'),
  };
}

/**
 * Owner DM: a business command arrived on a connection id this bot has no record of.
 *
 * Telegram emits the `business_connection` update ONLY on connect / change / disconnect — never
 * on startup — so a reset database, a fresh volume, or the bot being down at the moment the owner
 * (re)connected leaves no stored row for a connection that is perfectly live. The command cannot
 * be run, and the owner MUST hear about it: dropping it in silence is what let the owner believe
 * a client was being monitored when nothing was.
 */
export function businessConnectionUnrecognised(params: {
  command: string;
  clientChatId: number;
}): FormattedMessage {
  const { command, clientChatId } = params;
  return {
    text: [
      '⚠️ COMMAND NOT RUN — BUSINESS CONNECTION NOT RECOGNISED',
      '',
      `Your /${command} in Client #${clientChatId} was NOT carried out, so nothing is being`,
      'monitored for that client.',
      '',
      'This bot has no record of the Telegram Business connection the message arrived on.',
      'Telegram only announces a connection when it is made or changed, so a restart on a fresh',
      'database can leave a live connection unknown.',
      '',
      'Fix it in Telegram:',
      '   1. Settings → Business → Chatbots',
      '   2. Turn the bot OFF, then ON again (re-select the same chats)',
      `   3. Re-type /${command} in that client's chat`,
      '',
      'Until then, /unban, /ban and /check inside client chats will not work.',
    ].join('\n'),
  };
}

/**
 * Owner DM: a command the owner typed inside a client chat threw and did not finish.
 *
 * The router's business branch returns before the outer catch has a message to answer, so a
 * failure there used to be swallowed whole — the owner saw "🔎 Checking @x…" and then nothing,
 * and assumed it had worked.
 *
 * `unlinked` is the dangerous aftermath and gets its own body. Creating the case/watch and creating
 * the client link are two separate writes with no transaction between them, so a failure after the
 * first leaves a row that carries no client chat: it runs, the recovery or deletion is detected,
 * and the delivery path finds no link and treats it as owner-only. The client is never told —
 * the worst failure this system has — so the owner is told exactly what survived and how to
 * repair it, instead of a generic apology that reads like nothing happened.
 *
 * The two repairs are NOT interchangeable, which is why `kind` exists. A second `/unban` reuses the
 * existing case and falls through to the link write, so re-running it genuinely adds the missing
 * link. A second `/ban` does not: it finds the active watch, answers "already being watched" and
 * returns BEFORE the link write, so the gap would survive the repair and the owner would be left
 * believing it was closed.
 */
export function ownerBusinessCommandFailed(params: {
  command: string;
  clientChatId: number;
  /** Short error text. Owner DM only, and only so the owner can diagnose it. */
  detail: string;
  /**
   * An active monitor (`/unban`) or deletion watch (`/ban`) exists for this page, but with no link
   * to the chat it was typed in. `kind` selects the repair that actually closes the gap.
   */
  unlinked?: { username: string; kind: 'monitor' | 'watch' };
}): FormattedMessage {
  const { command, clientChatId, detail } = params;
  const unlinked = params.unlinked;
  let lines: string[];
  if (unlinked === undefined) {
    lines = [
      '⚠️ COMMAND FAILED IN A CLIENT CHAT',
      '',
      `Your /${command} in Client #${clientChatId} hit an error and did not finish.`,
      'It may have set up nothing at all, and the client was told nothing.',
      '',
      `Check what actually exists (/list, /banlist), then re-run /${command} in that chat.`,
    ];
  } else if (unlinked.kind === 'monitor') {
    lines = [
      '⚠️ MONITOR STARTED, CLIENT NOT LINKED',
      '',
      `Your /${command} in Client #${clientChatId} hit an error part-way through.`,
      '',
      `@${unlinked.username} IS being monitored, but the link to that client chat was NOT saved.`,
      'A recovery would therefore alert you only — the client would never be told.',
      '',
      'Fix it:',
      `   1. Re-run /${command} ${unlinked.username} in that client's chat — it reuses the same`,
      '      monitor and only adds the missing link.',
      `   2. If that keeps failing, run /clear ${unlinked.username} and start over.`,
    ];
  } else {
    lines = [
      '⚠️ DELETION WATCH STARTED, CLIENT NOT LINKED',
      '',
      `Your /${command} in Client #${clientChatId} hit an error part-way through.`,
      '',
      `@${unlinked.username} IS being watched for deletion, but the link to that client chat was`,
      'NOT saved. A deletion would therefore alert you only — the client would never be told.',
      '',
      'Fix it — re-running /ban ALONE will not work, it stops at "already being watched":',
      `   1. /unwatch ${unlinked.username}`,
      `   2. Then re-type /${command} ${unlinked.username} in that client's chat.`,
    ];
  }
  return { text: [...lines, '', `Error: ${detail}`].join('\n') };
}

/**
 * Owner DM: a `/unban` inside a client chat enrolled the page — and told the CLIENT it had —
 * without a completed pre-check.
 *
 * Owner-only, exactly like {@link ownerClientLinkConflict}: the client's confirmation stays clean
 * customer copy, and the detail that has to be ACTED on goes where only the owner reads it. The
 * stakes are the client's though. Nothing verified that page is down, so if it was already public
 * it is confirmed active within minutes and the client is told "YOUR INSTAGRAM PROFILE IS ACTIVE
 * AGAIN" for a recovery that never happened — the owner needs the chance to catch it first.
 */
export function ownerBusinessPrecheckUnverified(params: {
  username: string;
  clientChatId: number;
  /** Why nothing was observed. Written by the pre-check, shown verbatim. */
  reason: string;
}): FormattedMessage {
  const { username, clientChatId, reason } = params;
  return {
    text: [
      '❓ MONITORING STARTED WITHOUT A PRE-CHECK',
      '',
      `Your /unban @${username} in Client #${clientChatId} IS monitoring, and the client has been`,
      'told so — but the live check that normally runs first did not complete.',
      '',
      reason,
      `Nobody has confirmed @${username} is currently down.`,
      '',
      'If it is already public it will be confirmed active within minutes, and THE CLIENT will be',
      'told their profile has recovered.',
      '',
      `Check it yourself with /check ${username}, then /clear ${username} if it is already live.`,
    ].join('\n'),
  };
}

/** Business chat: the client-facing recovery caption sent into their conversation. */
export function clientRecoveryCaption(
  username: string,
  startedIso: string,
  confirmedIso: string,
  tz: string,
): string {
  const recovery = formatDuration(Date.parse(confirmedIso) - Date.parse(startedIso));
  return [
    '✅ YOUR INSTAGRAM PROFILE IS ACTIVE AGAIN',
    '',
    `@${username} has been confirmed as publicly available on Instagram.`,
    '',
    `⏱ Recovery time: ${recovery}`,
    `🕒 Confirmed: ${formatIstDateTime(confirmedIso, tz)}`,
  ].join('\n');
}

/** Business chat: text-only client recovery (when no rendered screenshot could be captured). */
export function clientRecoveryText(
  username: string,
  startedIso: string,
  confirmedIso: string,
  tz: string,
): FormattedMessage {
  return {
    text: clientRecoveryCaption(username, startedIso, confirmedIso, tz),
    replyMarkup: recoveryButton(username),
  };
}

/** Business chat: confirmation shown to the client when the owner starts a deletion watch. */
export function businessDeletionWatchStarted(
  username: string,
  startedIso: string,
  tz: string,
): FormattedMessage {
  return {
    text: [
      '🔎 DELETION MONITORING STARTED',
      '',
      `Instagram: @${username}`,
      'Status: Currently active — watching for it to go down',
      `Started: ${formatIstDateTime(startedIso, tz)}`,
      '',
      'You will receive an update here if the account becomes unavailable.',
    ].join('\n'),
    replyMarkup: recoveryButton(username),
  };
}

/**
 * Business chat: the client-facing deletion alert sent into their conversation. Deliberately
 * plainer than the owner copy — it states the observable fact (the profile is no longer
 * publicly available) without speculating about why.
 */
export function clientDeletionConfirmed(
  username: string,
  startedIso: string,
  confirmedIso: string,
  tz: string,
): FormattedMessage {
  return {
    text: [
      '🚫 INSTAGRAM PROFILE NO LONGER AVAILABLE',
      '',
      `@${username} is no longer publicly accessible on Instagram.`,
      '',
      `⏱ Watched for: ${formatDuration(durationMsBetween(startedIso, confirmedIso))}`,
      `🕒 Confirmed: ${formatIstDateTime(confirmedIso, tz)}`,
    ].join('\n'),
    replyMarkup: recoveryButton(username),
  };
}

/** Owner note appended to the owner recovery when a client chat is linked. */
export function ownerClientDeliveryLine(delivered: boolean): string {
  return delivered
    ? '👤 Client notification: Delivered'
    : '👤 Client notification: Delivery pending';
}

/** Owner alert when Telegram will not allow the automated business reply (window closed). */
export function ownerActionRequired(username: string): FormattedMessage {
  return {
    text: [
      `⚠️ @${username} IS ACTIVE`,
      '',
      'The Instagram profile has recovered, but Telegram would not allow the automated',
      'Business reply in the client chat (the 24h reply window is closed).',
      '',
      'The screenshot and message are ready — please send them to the client manually.',
    ].join('\n'),
    replyMarkup: recoveryButton(username),
  };
}

/**
 * Owner alert when the automated business reply could not deliver a confirmed DELETION.
 *
 * A separate message rather than a shared one, because the owner ACTS on this ping by hand-
 * delivering the news. The recovery copy above says the profile "IS ACTIVE" and "has recovered",
 * which — sent to a client whose account has just gone down — is the exact opposite of the truth.
 * It also promises a screenshot; a deletion alert has none, since a gone page has nothing to
 * capture.
 */
export function ownerActionRequiredDeletion(username: string): FormattedMessage {
  return {
    text: [
      `⚠️ @${username} IS NO LONGER AVAILABLE`,
      '',
      'The Instagram profile has gone down (deleted, deactivated, or banned), but Telegram',
      'would not allow the automated Business reply in the client chat (the 24h reply window',
      'is closed).',
      '',
      'The deletion message is ready — please send it to the client manually.',
    ].join('\n'),
    replyMarkup: recoveryButton(username),
  };
}

/** /check: profile is live but the screenshot could not be captured. */
export function checkActiveNoScreenshot(username: string): FormattedMessage {
  return {
    text: `✅ @${username} is already active.\n\n(Screenshot capture failed — the profile itself is fine.)`,
    replyMarkup: recoveryButton(username),
  };
}

/** /check: profile shows Instagram's unavailable page. */
export function checkGone(username: string): FormattedMessage {
  return {
    text: [
      `🚫 @${username} is not available right now.`,
      '',
      `Use /unban ${username} to monitor it and get notified the moment it comes back.`,
    ].join('\n'),
  };
}

/** /check: the page could not be classified reliably. */
export function checkUnknown(username: string, reason: string | null): FormattedMessage {
  return {
    text: [
      `❓ Could not determine the status of @${username} right now` +
        (reason !== null ? ` (${reason})` : '') +
        '.',
      '',
      'Instagram may be rate-limiting or showing a login wall. Try again in a few minutes.',
    ].join('\n'),
  };
}

/** Concise owner-only production-path diagnostic. */
export function checkDiagnostic(input: {
  username: string;
  classification: 'ACTIVE' | 'GONE' | 'UNKNOWN';
  profileMatch: boolean;
  unavailable: boolean;
  loginWall: boolean;
  screenshotOk: boolean;
  durationMs: number;
  action: string;
}): FormattedMessage {
  return {
    text: [
      '🔍 LIVE CHECK',
      '',
      `Instagram: @${input.username}`,
      `Result: ${input.classification}`,
      `Profile match: ${input.profileMatch ? 'Yes' : 'No'}`,
      `Unavailable message: ${input.unavailable ? 'Yes' : 'No'}`,
      `Login wall: ${input.loginWall ? 'Yes' : 'No'}`,
      `Screenshot capture: ${input.screenshotOk ? 'Working' : 'Unavailable'}`,
      `Response time: ${(input.durationMs / 1000).toFixed(1)} seconds`,
      `Action: ${input.action}`,
    ].join('\n'),
  };
}

/** Health warning sent when the detector degrades. */
export function monitoringWarning(): FormattedMessage {
  return {
    text: [
      '⚠️ MONITORING WARNING',
      '',
      'The monitoring system is degraded. Instagram checks may be delayed or returning',
      "UNKNOWN more often than usual. I'll let you know when things are back to normal.",
    ].join('\n'),
  };
}

/** Health recovery sent when the detector returns to normal. */
export function monitoringRestored(): FormattedMessage {
  return {
    text: [
      '✅ MONITORING RESTORED',
      '',
      'The monitoring system is healthy again and checks have resumed normally.',
    ].join('\n'),
  };
}

const SUPERVISOR_INSTAGRAM_URL = 'https://www.instagram.com/r.nmc/';
const SUPERVISOR_TELEGRAM_URL = 'https://t.me/tj_0t';
const SUPERVISOR_WHATSAPP_URL = 'https://wa.me/967773875320';
const ADD_CREDIT_URL =
  'https://wa.me/967773875320?text=%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A5%D8%B6%D8%A7%D9%81%D8%A9%20%D8%B1%D8%B5%D9%8A%D8%AF';

/** `/start` welcome and owner controls shown after the existing secure pairing. */
export function startGuide(): FormattedMessage {
  return {
    text: [
      'مرحباً بك في نظام مراقبة الحسابات.',
      '',
      'يمكنك إضافة حساب جديد ومتابعة جميع التغييرات التي تحدث عليه.',
      '',
      'المشرف:',
      '⁽ᯓ 🇾🇪☠︎︎ ツ اݪقــ͢ـ̸̐ـــ̸ᷤـــ̮ـ͢ــياډﮪ ايمڼ اݪمڼـــصࢪي',
      '',
      'Instagram: @r.nmc',
      'Telegram: @tj_0t',
      'WhatsApp: +967773875320',
      '',
      '➕ إضافة حساب: /unban username',
      '📋 حساباتي: /list',
      '🔎 فحص حساب: /check username',
      '🛑 إيقاف المراقبة: /clear username',
      '💚 حالة النظام: /ping',
    ].join('\n'),
    replyMarkup: {
      inline_keyboard: [
        [
          { text: '📷 Instagram', url: SUPERVISOR_INSTAGRAM_URL },
          { text: '✈️ Telegram', url: SUPERVISOR_TELEGRAM_URL },
        ],
        [{ text: '📱 WhatsApp للتواصل', url: SUPERVISOR_WHATSAPP_URL }],
        [{ text: '💰 إضافة رصيد', url: ADD_CREDIT_URL }],
      ],
    },
  };
}

/** Owner pairing succeeded. */
export function pairedOk(): FormattedMessage {
  return { text: '✅ Paired. You are now the owner of this monitor.' };
}

/** Owner pairing failed (wrong code or already paired). */
export function pairingInvalid(): FormattedMessage {
  return { text: '❌ Pairing failed. The code is invalid or this bot is already paired.' };
}

/** Message shown to any non-owner user, group, or channel. */
export function notAuthorized(): FormattedMessage {
  return { text: '🚫 Not authorized. This is a private bot.' };
}
