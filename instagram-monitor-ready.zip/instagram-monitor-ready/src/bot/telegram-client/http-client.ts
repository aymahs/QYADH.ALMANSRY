/**
 * HTTP implementation of {@link TelegramClient} over the Telegram Bot API.
 *
 * Design notes:
 * - JSON methods POST an `application/json` body; `sendPhoto` uses multipart/form-data.
 * - A *send* (sendMessage/sendPhoto) reports `TELEGRAM_AMBIGUOUS` ONLY when the outcome is
 *   genuinely unknowable — the request was already on the wire when the connection died or
 *   our own timeout aborted it. The caller must then reconcile rather than blindly retry.
 *   Everything that proves nothing was delivered (name resolution, refused connect, TLS
 *   handshake, a rejected envelope, a gateway page) surfaces `TELEGRAM_ERROR`, which the
 *   outbox retries normally. Over-reporting AMBIGUOUS was worse than useless: it suppressed
 *   the retry of alerts that had definitively NOT reached the owner.
 * - Read-only/idempotent methods never report AMBIGUOUS at all.
 * - The bot token is never placed into log fields.
 */

import type {
  BotCommand,
  ChatInfo,
  SendMessageParams,
  SendPhotoParams,
  SentMessage,
  SetWebhookParams,
  TelegramClient,
  TelegramUpdate,
} from '../../domain';
import { AppError, isAppError } from '../../domain';
import type { Logger } from '../../logging/logger';

export interface HttpTelegramClientOptions {
  token: string;
  logger: Logger;
  /** Injectable for tests. Defaults to the global `fetch`. */
  fetchImpl?: typeof fetch;
  /** Per-request timeout in milliseconds. Default 30000. */
  timeoutMs?: number;
  /** API origin. Default `https://api.telegram.org`. */
  apiBase?: string;
}

/** Telegram response envelope. */
interface TelegramEnvelope<T> {
  ok: boolean;
  result?: T;
  description?: string;
}

interface SendOptions {
  method: string;
  body: string | FormData;
  /** When true, set `Content-Type: application/json`. Form bodies leave it unset. */
  json: boolean;
  timeoutMs: number;
  /** When true, a network/timeout failure becomes TELEGRAM_AMBIGUOUS. */
  ambiguous: boolean;
}

const DEFAULT_TIMEOUT_MS = 30000;
const DEFAULT_API_BASE = 'https://api.telegram.org';
const DEFAULT_PHOTO_FILENAME = 'screenshot.png';
/** Gateway timeout: the only non-JSON response whose delivery outcome stays unknowable. */
const GATEWAY_TIMEOUT_STATUS = 504;

/**
 * `cause.code` values that prove the request never reached Telegram. Name resolution, the TCP
 * connect and the TLS handshake all fail BEFORE a single request byte is accepted, so a send
 * that failed this way definitively did not deliver and is safe to retry.
 *
 * Deliberately absent: ECONNRESET / ETIMEDOUT / UND_ERR_SOCKET. Those can land after the
 * request was fully written, which is exactly the unknowable case AMBIGUOUS exists for.
 */
const NOT_SENT_ERROR_CODES: ReadonlySet<string> = new Set([
  'ENOTFOUND',
  'EAI_AGAIN',
  'EAI_NODATA',
  'ECONNREFUSED',
  'EHOSTUNREACH',
  'ENETUNREACH',
  'EACCES',
  'UND_ERR_CONNECT_TIMEOUT',
  'CERT_HAS_EXPIRED',
  'DEPTH_ZERO_SELF_SIGNED_CERT',
  'SELF_SIGNED_CERT_IN_CHAIN',
  'UNABLE_TO_VERIFY_LEAF_SIGNATURE',
  'ERR_TLS_CERT_ALTNAME_INVALID',
  'ERR_SSL_WRONG_VERSION_NUMBER',
]);

export class HttpTelegramClient implements TelegramClient {
  private readonly token: string;
  private readonly logger: Logger;
  private readonly fetchImpl: typeof fetch;
  private readonly timeoutMs: number;
  private readonly apiBase: string;

  constructor(options: HttpTelegramClientOptions) {
    this.token = options.token;
    this.logger = options.logger;
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    this.apiBase = options.apiBase ?? DEFAULT_API_BASE;
  }

  async getMe(): Promise<{ id: number; username?: string }> {
    return this.send<{ id: number; username?: string }>({
      method: 'getMe',
      body: JSON.stringify({}),
      json: true,
      timeoutMs: this.timeoutMs,
      ambiguous: false,
    });
  }

  async getChat(chatId: number): Promise<ChatInfo | null> {
    // Best-effort: "chat not found" / rate-limit / network all mean "no identity available".
    try {
      return await this.send<ChatInfo>({
        method: 'getChat',
        body: JSON.stringify({ chat_id: chatId }),
        json: true,
        timeoutMs: this.timeoutMs,
        ambiguous: false,
      });
    } catch {
      return null;
    }
  }

  async sendMessage(params: SendMessageParams): Promise<SentMessage> {
    const result = await this.send<{ message_id: number }>({
      method: 'sendMessage',
      body: JSON.stringify(params),
      json: true,
      timeoutMs: this.timeoutMs,
      ambiguous: true,
    });
    return { message_id: result.message_id };
  }

  async sendPhoto(params: SendPhotoParams): Promise<SentMessage> {
    const form = new FormData();
    form.append('chat_id', String(params.chat_id));
    if (params.caption !== undefined) {
      form.append('caption', params.caption);
    }
    if (params.parse_mode !== undefined) {
      form.append('parse_mode', params.parse_mode);
    }
    if (params.reply_markup !== undefined) {
      form.append('reply_markup', JSON.stringify(params.reply_markup));
    }
    if (params.reply_to_message_id !== undefined) {
      form.append('reply_to_message_id', String(params.reply_to_message_id));
    }
    if (params.business_connection_id !== undefined) {
      form.append('business_connection_id', params.business_connection_id);
    }
    const filename = params.filename ?? DEFAULT_PHOTO_FILENAME;
    // Copy into a fresh view so the Blob part type is unambiguous.
    const blob = new Blob([new Uint8Array(params.photo)]);
    form.append('photo', blob, filename);

    const result = await this.send<{ message_id: number }>({
      method: 'sendPhoto',
      body: form,
      json: false,
      timeoutMs: this.timeoutMs,
      ambiguous: true,
    });
    return { message_id: result.message_id };
  }

  async setWebhook(params: SetWebhookParams): Promise<boolean> {
    return this.send<boolean>({
      method: 'setWebhook',
      body: JSON.stringify(params),
      json: true,
      timeoutMs: this.timeoutMs,
      ambiguous: false,
    });
  }

  async deleteWebhook(dropPendingUpdates?: boolean): Promise<boolean> {
    return this.send<boolean>({
      method: 'deleteWebhook',
      body: JSON.stringify({ drop_pending_updates: dropPendingUpdates ?? false }),
      json: true,
      timeoutMs: this.timeoutMs,
      ambiguous: false,
    });
  }

  async setMyCommands(commands: BotCommand[]): Promise<boolean> {
    return this.send<boolean>({
      method: 'setMyCommands',
      body: JSON.stringify({ commands }),
      json: true,
      timeoutMs: this.timeoutMs,
      ambiguous: false,
    });
  }

  async getUpdates(
    offset: number,
    timeoutSeconds: number,
    allowedUpdates?: readonly string[],
  ): Promise<TelegramUpdate[]> {
    return this.send<TelegramUpdate[]>({
      method: 'getUpdates',
      body: JSON.stringify({
        offset,
        timeout: timeoutSeconds,
        ...(allowedUpdates ? { allowed_updates: allowedUpdates } : {}),
      }),
      json: true,
      // Allow the long-poll to run for its full duration plus the base HTTP budget.
      timeoutMs: this.timeoutMs + timeoutSeconds * 1000,
      ambiguous: false,
    });
  }

  private async send<T>(opts: SendOptions): Promise<T> {
    const url = `${this.apiBase}/bot${this.token}/${opts.method}`;
    const controller = new AbortController();
    const timer = setTimeout(() => {
      controller.abort();
    }, opts.timeoutMs);
    this.logger.debug('telegram request', { method: opts.method });
    try {
      const response = await this.fetchImpl(url, {
        method: 'POST',
        body: opts.body,
        signal: controller.signal,
        ...(opts.json ? { headers: { 'Content-Type': 'application/json' } } : {}),
      });
      const envelope = await readEnvelope<T>(response, opts);
      if (!envelope.ok) {
        throw new AppError(
          'TELEGRAM_ERROR',
          envelope.description ?? `telegram ${opts.method} returned ok:false`,
        );
      }
      return envelope.result as T;
    } catch (err) {
      // A rejected envelope is a real, classified error — do not reinterpret it.
      if (isAppError(err)) {
        throw err;
      }
      this.logger.warn('telegram request failed', {
        method: opts.method,
        reason: err instanceof Error ? err.name : 'unknown',
      });
      if (opts.ambiguous && !definitelyNotDelivered(err)) {
        throw new AppError('TELEGRAM_AMBIGUOUS', 'network outcome uncertain');
      }
      throw new AppError('TELEGRAM_ERROR', `telegram ${opts.method} request failed`);
    } finally {
      clearTimeout(timer);
    }
  }
}

/**
 * Parse the Bot API envelope.
 *
 * `response.json()` rejects two very different ways and only one of them proves anything. A
 * `SyntaxError` means the body arrived in FULL and simply was not an API envelope — a gateway
 * or captive-portal page — so the call never reached the backend and the send is safe to retry.
 * Any other rejection (socket reset mid-body, our own timeout aborting the read) means the body
 * never finished arriving; that says nothing on its own, but a 2xx status line had already been
 * received, and Telegram only writes one after it has accepted and processed the send. On the
 * residential-proxy egress this is routine, and calling it "definitely not delivered" made the
 * outbox re-send an alert the owner already had.
 *
 * 504 stays ambiguous even with a fully-read body: there the gateway stopped waiting while the
 * backend may still have processed the send.
 */
async function readEnvelope<T>(
  response: Response,
  opts: SendOptions,
): Promise<TelegramEnvelope<T>> {
  try {
    return (await response.json()) as TelegramEnvelope<T>;
  } catch (err) {
    if (opts.ambiguous && response.status === GATEWAY_TIMEOUT_STATUS) {
      throw new AppError('TELEGRAM_AMBIGUOUS', `telegram ${opts.method} gateway timeout`);
    }
    if (opts.ambiguous && response.ok && !(err instanceof SyntaxError)) {
      throw new AppError(
        'TELEGRAM_AMBIGUOUS',
        `telegram ${opts.method} ${String(response.status)} body was cut off`,
      );
    }
    throw new AppError(
      'TELEGRAM_ERROR',
      `telegram ${opts.method} returned a non-JSON ${String(response.status)} body`,
    );
  }
}

/**
 * True when the failure proves the send never left this process, so retrying it cannot
 * duplicate. `fetch` wraps transport failures in a `TypeError` whose `cause` carries the real
 * errno, so walk the cause chain rather than inspecting only the outermost error.
 */
function definitelyNotDelivered(err: unknown): boolean {
  let current: unknown = err;
  while (current instanceof Error) {
    const code: unknown = (current as { code?: unknown }).code;
    if (typeof code === 'string' && NOT_SENT_ERROR_CODES.has(code)) return true;
    current = (current as { cause?: unknown }).cause;
  }
  return false;
}
