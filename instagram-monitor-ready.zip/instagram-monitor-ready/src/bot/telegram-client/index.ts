/** Telegram client barrel: HTTP + mock implementations and command configuration. */

import type { TelegramClient } from '../../domain';
import { VISIBLE_COMMANDS } from '../../domain';

export { HttpTelegramClient } from './http-client';
export type { HttpTelegramClientOptions } from './http-client';
export { MockTelegramClient } from './mock-client';

/** Register the bot's visible command menu (the four {@link VISIBLE_COMMANDS}). */
export async function configureCommands(client: TelegramClient): Promise<void> {
  await client.setMyCommands([...VISIBLE_COMMANDS]);
}
