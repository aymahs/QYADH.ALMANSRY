/**
 * In-memory {@link TelegramClient} for tests. Records every outgoing call and lets tests
 * seed update batches and simulate failed / ambiguous sends.
 */

import type {
  BotCommand,
  ChatInfo,
  SendMessageParams,
  SendPhotoParams,
  SentMessage,
  SetWebhookParams,
  TelegramClient,
  TelegramUpdate,
} from '../../domain';

interface RecordedCall {
  method: string;
  params: unknown;
}

const FIRST_MESSAGE_ID = 1000;

export class MockTelegramClient implements TelegramClient {
  /** Every call in order, including its params. */
  readonly calls: RecordedCall[] = [];

  private nextMessageId = FIRST_MESSAGE_ID;
  private readonly updateBatches: TelegramUpdate[][] = [];
  private failNextSend: Error | undefined;
  private readonly methodFailures = new Map<string, Error>();
  private readonly chatInfo = new Map<number, ChatInfo>();

  /** Seed a getChat result for a chat id (tests). Unseeded chats resolve to null. */
  seedChat(chatId: number, info: ChatInfo): void {
    this.chatInfo.set(chatId, info);
  }

  /** Params of every `sendMessage` call. */
  get sentMessages(): SendMessageParams[] {
    return this.calls
      .filter((c) => c.method === 'sendMessage')
      .map((c) => c.params as SendMessageParams);
  }

  /** Params of every `sendPhoto` call. */
  get sentPhotos(): SendPhotoParams[] {
    return this.calls
      .filter((c) => c.method === 'sendPhoto')
      .map((c) => c.params as SendPhotoParams);
  }

  /** Params of every `setWebhook` call. */
  get webhookCalls(): SetWebhookParams[] {
    return this.calls
      .filter((c) => c.method === 'setWebhook')
      .map((c) => c.params as SetWebhookParams);
  }

  /** Command arrays of every `setMyCommands` call. */
  get commandCalls(): BotCommand[][] {
    return this.calls
      .filter((c) => c.method === 'setMyCommands')
      .map((c) => c.params as BotCommand[]);
  }

  /** Seed a batch of updates; each `getUpdates` call consumes the next batch. */
  enqueueUpdates(updates: TelegramUpdate[]): void {
    this.updateBatches.push(updates);
  }

  /** Make the next `sendMessage` or `sendPhoto` reject with `error`, then clear. */
  failNextSendWith(error: Error): void {
    this.failNextSend = error;
  }

  /** Make every call to `method` reject with `error` until cleared. */
  failMethod(method: string, error: Error): void {
    this.methodFailures.set(method, error);
  }

  async getMe(): Promise<{ id: number; username?: string }> {
    this.guard('getMe');
    this.calls.push({ method: 'getMe', params: undefined });
    return { id: 42, username: 'test_bot' };
  }

  async getChat(chatId: number): Promise<ChatInfo | null> {
    this.guard('getChat');
    this.calls.push({ method: 'getChat', params: { chatId } });
    return this.chatInfo.get(chatId) ?? null;
  }

  async sendMessage(params: SendMessageParams): Promise<SentMessage> {
    this.guard('sendMessage');
    this.calls.push({ method: 'sendMessage', params });
    return { message_id: this.nextMessageId++ };
  }

  async sendPhoto(params: SendPhotoParams): Promise<SentMessage> {
    this.guard('sendPhoto');
    this.calls.push({ method: 'sendPhoto', params });
    return { message_id: this.nextMessageId++ };
  }

  async setWebhook(params: SetWebhookParams): Promise<boolean> {
    this.guard('setWebhook');
    this.calls.push({ method: 'setWebhook', params });
    return true;
  }

  async deleteWebhook(dropPendingUpdates?: boolean): Promise<boolean> {
    this.guard('deleteWebhook');
    this.calls.push({ method: 'deleteWebhook', params: { dropPendingUpdates } });
    return true;
  }

  async setMyCommands(commands: BotCommand[]): Promise<boolean> {
    this.guard('setMyCommands');
    this.calls.push({ method: 'setMyCommands', params: commands });
    return true;
  }

  async getUpdates(
    offset: number,
    timeoutSeconds: number,
    allowedUpdates?: readonly string[],
  ): Promise<TelegramUpdate[]> {
    this.guard('getUpdates');
    this.calls.push({ method: 'getUpdates', params: { offset, timeoutSeconds, allowedUpdates } });
    return this.updateBatches.shift() ?? [];
  }

  /** Throw a seeded failure (per-method, then per-next-send) before recording success. */
  private guard(method: string): void {
    const methodFailure = this.methodFailures.get(method);
    if (methodFailure) {
      throw methodFailure;
    }
    if ((method === 'sendMessage' || method === 'sendPhoto') && this.failNextSend) {
      const err = this.failNextSend;
      this.failNextSend = undefined;
      throw err;
    }
  }
}
