/** Telegram command-text parsing: `/cmd`, `/cmd@BotName`, with trailing arguments. */

/** `/command` or `/command@BotName`, optionally followed by whitespace and arguments. */
const COMMAND_RE = /^\/([a-z0-9_]+)(?:@[a-z0-9_]+)?(?:\s+([\s\S]*))?$/i;

/**
 * Parse a message text into a command + argument string. Returns the lowercase
 * command without the slash and the trimmed argument tail. Non-commands => null.
 */
export function parseCommand(text: string): { command: string; args: string } | null {
  const match = COMMAND_RE.exec(text.trim());
  if (match === null) return null;
  const command = match[1];
  if (command === undefined) return null;
  return { command: command.toLowerCase(), args: (match[2] ?? '').trim() };
}
