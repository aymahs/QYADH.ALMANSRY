/**
 * Command router: turns deduplicated private-chat Telegram updates into repository
 * and detector calls, replying with the shared formatter copy. Never throws out —
 * every failure is logged safely and answered with a generic error (owner only).
 */

import type {
  Classification,
  DetectorErrorCode,
  CaseStatus,
  Clock,
  Database,
  Detector,
  Repositories,
  SendMessageParams,
  TelegramClient,
  TelegramMessage,
  TelegramUpdate,
  RawBusinessConnection,
  BusinessConnection,
  ClientChatLink,
} from '../../domain';
import type { ClientIdentity } from '../../domain';
import { ACTIVE_SIGNALS, ACTIVE_STATUSES, LISTED_STATUSES, isAppError } from '../../domain';
import {
  parseBackdatedTimestamp,
  parseUsernameInput,
  formatDuration,
  durationMsBetween,
} from '../../core';
import type {
  FormattedMessage,
  MonitoredItem,
  MonitoredStatus,
  ClientGroup,
} from '../../notifications/formatter';
import {
  alreadyMonitoring,
  bulkMonitoringStarted,
  clientsView,
  checkInProgress,
  checkDiagnostic,
  businessMonitoringStarted,
  businessMonitorLinkedElsewhere,
  businessConnectionUnrecognised,
  ownerBusinessCommandFailed,
  ownerBusinessPrecheckUnverified,
  ownerClientLinkConflict,
  businessDeletionWatchStarted,
  listView,
  monitoringRemoved,
  monitoringStarted,
  monitoringStartedUnverified,
  notAuthorized,
  notFound,
  pairedOk,
  pairingInvalid,
  pingHealthy,
  pingUnhealthy,
  fastTierLine,
  browserBudgetLines,
  startGuide,
} from '../../notifications/formatter';
import type { BrowserBudgetLine } from '../../notifications/formatter';
import { schedulingParamsFrom } from '../../monitoring/scheduler';
import { applyCheckResult } from '../../monitoring/state-machine';
import { egressStatus, egressSwitchResult } from '../../notifications/formatter/messages';
import type { AppConfig } from '../../config';
import type { Logger } from '../../logging';
import type { ProxySwitch } from '../../instagram/proxy-switch';
// The /proxy decision (switch -> verify the new route -> revert or warn) is shared verbatim with
// the Discord surface rather than reimplemented: two copies of "is this route blind?" would
// drift, and the answer is what stands between a client and a recovery nobody notices.
import { parseEgressRoute, switchEgressRoute } from '../../instagram/proxy-switch';
// Deep import (not the detector barrel) so the router never pulls Playwright into scope.
import { detectorDiagnostics } from '../../instagram/detector/tiered-detector';
import type { FastTierReport, TieredProbeOptions } from '../../instagram/detector/tiered-detector';
import type { OwnerAuthorizer } from '../authorization';
import { parseCommand } from './parse';

/** Everything the router needs, injected for deterministic tests. */
export interface CommandDeps {
  client: TelegramClient;
  repos: Repositories;
  db: Database;
  detector: Detector;
  auth: OwnerAuthorizer;
  config: AppConfig;
  clock: Clock;
  logger: Logger;
  rand?: () => number;
  /** Runtime egress switch, so /proxy can move traffic without a restart. */
  proxySwitch?: ProxySwitch;
  /** Overrides for the /bulkunban pre-check bounds. Tests only. */
  bulkPrecheckLimits?: Partial<BulkPrecheckLimits>;
}

const HEALTH_SCHEDULER_KEY = 'scheduler';

/**
 * The commands the business branch actually acts on inside a client chat. Anything else typed
 * there is simply not a business command, so it must never be reported to the owner as a
 * connection problem — that would be a confident, wrong diagnosis.
 */
const BUSINESS_COMMANDS: readonly string[] = ['unban', 'ban', 'check'];

/**
 * Fold the governor's report and the configured baseline into the shape /ping renders.
 *
 * The CONFIGURED interval has to come from config rather than from the governor, because the whole
 * point of the line is to show the owner the gap between what they set and what the fleet is
 * actually doing.
 */
function budgetLine(
  budget: {
    capacity: number;
    routineAllowance: number;
    used: number;
    deferred: number;
    intervalMultiplier: number;
    throttling: boolean;
    reason: string;
  },
  config: AppConfig,
): BrowserBudgetLine {
  return {
    capacity: budget.capacity,
    routineAllowance: budget.routineAllowance,
    used: budget.used,
    deferred: budget.deferred,
    intervalMultiplier: budget.intervalMultiplier,
    baselineIntervalSeconds: config.scheduling.baselineIntervalSeconds,
    throttling: budget.throttling,
    reason: budget.reason,
  };
}

/** Hard cap on how many usernames one /bulkunban may enrol. Shared with the Discord surface. */
export const BULK_MAX = 50;

/**
 * Bounds on the bulk live pre-check. Only tests override these; production uses the defaults.
 *
 * `spacingMs` paces probe STARTS rather than relying on concurrency alone: at ~0.3s per fast
 * probe, three in flight would issue ~10 requests/second against a single residential IP whose
 * whole budget is ~200 page loads an hour. `deadlineMs` is kept well under Discord's 15-minute
 * interaction token so the summary always lands.
 */
export interface BulkPrecheckLimits {
  concurrency: number;
  spacingMs: number;
  deadlineMs: number;
}

export const BULK_PRECHECK_LIMITS: BulkPrecheckLimits = {
  concurrency: 3,
  spacingMs: 200,
  deadlineMs: 90_000,
};

/** What a live pre-check concluded about one username. */
export type PrecheckVerdict = 'active' | 'not-active' | 'unverified';

export interface BulkPrecheckOutcome {
  verdicts: Map<string, PrecheckVerdict>;
  /** Non-null when verification stopped early; shown verbatim to the owner. */
  stoppedReason: string | null;
}

const BREAKER_REASON =
  'Instagram traffic is in fleet-wide back-off (circuit breaker open), so no live check was possible.';
const DEADLINE_REASON = 'The live pre-check hit its time limit.';

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Live pre-check for a bulk enrolment.
 *
 * Shared by the Telegram and Discord surfaces — deliberately, unlike the rest of the two command
 * layers. The bounds below are what stop a 50-account burst from burning the egress budget, and
 * two drifting copies of that logic is not a risk worth taking.
 *
 * Three things are bounded: how many probes run at once, how fast they start, and how long the
 * whole phase may take. The fourth guard is the important one — if the shared CircuitBreaker is
 * (or goes) OPEN, probing STOPS. It would otherwise self-cancel at scale: the burst trips the
 * breaker, every remaining probe returns UNKNOWN without touching the network, and the tail of
 * the batch gets enrolled with no pre-check at all — recreating the exact false "ACCOUNT
 * UNBANNED" alert the pre-check exists to prevent, while also halting every scheduled check.
 *
 * Anything not decided comes back as 'unverified'. The caller MUST report those separately: an
 * unverified account is still enrolled (a missed recovery is worse than a false one), so the
 * owner has to be told which ones were never actually looked at.
 */
export async function runBulkPrecheck(
  usernames: string[],
  deps: {
    detector: Detector;
    logger: Logger;
    limits?: Partial<BulkPrecheckLimits>;
    /** Wall clock for pacing and the deadline — real time, not the domain clock. */
    now?: () => number;
  },
): Promise<BulkPrecheckOutcome> {
  const limits = { ...BULK_PRECHECK_LIMITS, ...deps.limits };
  const now = deps.now ?? Date.now;
  const verdicts = new Map<string, PrecheckVerdict>();
  const diagnostics = detectorDiagnostics(deps.detector);
  const breakerOpen = (): boolean => {
    const state = diagnostics?.breakerSnapshot().state;
    return state !== undefined && state !== 'CLOSED';
  };

  if (usernames.length === 0) return { verdicts, stoppedReason: null };
  if (breakerOpen()) {
    for (const username of usernames) verdicts.set(username, 'unverified');
    return { verdicts, stoppedReason: BREAKER_REASON };
  }

  const deadlineAt = now() + limits.deadlineMs;
  let stoppedReason: string | null = null;
  let nextIndex = 0;
  let nextStartAt = 0;

  const worker = async (): Promise<void> => {
    for (;;) {
      if (stoppedReason !== null) return;
      const index = nextIndex;
      nextIndex += 1;
      if (index >= usernames.length) return;
      const username = usernames[index]!;

      if (now() >= deadlineAt) {
        stoppedReason = DEADLINE_REASON;
        return;
      }
      if (breakerOpen()) {
        stoppedReason = BREAKER_REASON;
        return;
      }

      // Reserve this probe's start slot before awaiting, so concurrent workers queue up behind
      // each other instead of all computing the same delay.
      const startAt = Math.max(now(), nextStartAt);
      nextStartAt = startAt + limits.spacingMs;
      const wait = startAt - now();
      if (wait > 0) await sleep(wait);

      try {
        // ROUTINE, even though a bulk enrolment IS an owner command. Up to 50 accounts probed
        // back-to-back is the one owner path with the shape of a storm — if the fast tier is
        // degraded every one of them is a full Chromium load — and it already degrades gracefully
        // when a probe cannot be made: an undecided account comes back 'unverified', is still
        // enrolled, and is reported to the owner as never actually looked at. Every SINGLE-account
        // command (/check, /unban, /ban, /ping) keeps the never-deferred default.
        const options: TieredProbeOptions = { loadPriority: 'ROUTINE' };
        const probe = await deps.detector.probe(username, options);
        // UNKNOWN is a FAILED OBSERVATION, not "not public": a login wall, a challenge, a
        // navigation timeout or an off-network breaker result all land here without throwing.
        // Collapsing it into 'not-active' would enrol the account and report it under "confirmed
        // not currently public" — so an account that was already public gets confirmed ACTIVE by
        // the scheduler within a minute and fires a false "ACCOUNT UNBANNED" at the client, with
        // the owner having been told it was checked.
        verdicts.set(
          username,
          probe.result.classification === 'ACTIVE'
            ? 'active'
            : probe.result.classification === 'GONE'
              ? 'not-active'
              : 'unverified',
        );
      } catch (err) {
        deps.logger.warn('bulk pre-check probe threw', {
          username,
          error: err instanceof Error ? err.message : String(err),
        });
        verdicts.set(username, 'unverified');
      }
    }
  };

  await Promise.all(
    Array.from({ length: Math.min(limits.concurrency, usernames.length) }, () => worker()),
  );
  for (const username of usernames) {
    if (!verdicts.has(username)) verdicts.set(username, 'unverified');
  }
  return { verdicts, stoppedReason };
}

/**
 * What a SINGLE-account `/unban` pre-check concluded.
 *
 * A union rather than a verdict plus an optional reason, so a caller that has narrowed to
 * 'unverified' always has the sentence to print and can never fall back to a default that would
 * quietly describe the wrong cause.
 */
export type UnbanPrecheckOutcome =
  | { verdict: 'active' | 'not-active' }
  | {
      verdict: 'unverified';
      /** Why nothing was observed. Shown verbatim to the owner, like `stoppedReason` above. */
      reason: string;
    };

const UNVERIFIED_REASON = 'The live check before starting could not be completed';

/**
 * Live pre-check for ONE `/unban`, shared by all three surfaces (owner DM, client business chat,
 * Discord) for the same reason {@link runBulkPrecheck} is: three copies of this judgement would
 * drift, and the judgement is what stands between a client and a false recovery alert.
 *
 * The distinction this exists to preserve is UNKNOWN vs GONE. A login wall, a challenge, a
 * navigation timeout, and a request the open circuit breaker refused WITHOUT TOUCHING THE NETWORK
 * all answer UNKNOWN, and none of them observed anything — so they come back 'unverified' with a
 * reason, never 'not-active'. The caller MUST still enrol (a missed recovery is worse than a
 * false one) and MUST report the account apart from the pre-checked ones, exactly as the bulk
 * path does: if the page was in fact already public, three ACTIVE confirmations later a client is
 * told their profile recovered when nothing ever happened.
 */
export async function runUnbanPrecheck(
  username: string,
  deps: {
    detector: Detector;
    logger: Logger;
    /** Prefixes the warn log, so each surface stays greppable as before. */
    logLabel: string;
  },
): Promise<UnbanPrecheckOutcome> {
  // OPEN answers off-network, so probing would learn nothing — but the owner still has to be told
  // WHY it was never checked.
  //
  // OPEN *only*, deliberately narrower than runBulkPrecheck's `!== 'CLOSED'`. HALF_OPEN admits
  // exactly ONE trial prober ({@link CircuitBreaker.allowRequest}), which is precisely what a
  // single-account /unban needs and what a 50-account burst must not be allowed to start. Refusing
  // it here would skip the live check in a state where the check WAS available — the one guard
  // that stops an already-public page being enrolled and then confirmed into a false "ACCOUNT
  // UNBANNED" at a paying client — and would then blame a back-off that would have let it through.
  // HALF_OPEN is not a rare race either: CircuitBreaker.rehydrate() sets it at boot whenever a
  // stored cooldown has already elapsed.
  const breakerState = detectorDiagnostics(deps.detector)?.breakerSnapshot().state;
  if (breakerState === 'OPEN') {
    return { verdict: 'unverified', reason: BREAKER_REASON };
  }
  try {
    const { classification, evidence } = (await deps.detector.probe(username)).result;
    if (classification === 'ACTIVE') return { verdict: 'active' };
    if (classification === 'GONE') return { verdict: 'not-active' };
    return {
      verdict: 'unverified',
      reason:
        evidence.errorCode !== null
          ? `${UNVERIFIED_REASON} (${evidence.errorCode}).`
          : `${UNVERIFIED_REASON}.`,
    };
  } catch (err) {
    deps.logger.warn(`${deps.logLabel} precheck threw`, {
      error: err instanceof Error ? err.message : String(err),
    });
    return { verdict: 'unverified', reason: `${UNVERIFIED_REASON} (the probe failed).` };
  }
}

function isListedStatus(status: CaseStatus): status is MonitoredStatus {
  return (
    status === 'MONITORING' ||
    status === 'CONFIRMING' ||
    status === 'ERROR_BACKOFF' ||
    status === 'UNKNOWN_BACKOFF'
  );
}

export class CommandRouter {
  private readonly lastCheckByChat = new Map<number, number>();
  /**
   * Tail of the detached work queue. Chained rather than parallel so two /bulkunbans in a row
   * cannot double the probe rate against the egress budget.
   */
  private background: Promise<void> = Promise.resolve();

  constructor(private readonly deps: CommandDeps) {}

  /** Queue detached work. Never rejects — a failure is logged, like any other handler failure. */
  private track(task: () => Promise<void>): void {
    this.background = this.background.then(task).catch((err: unknown) => {
      this.deps.logger.error('background command work failed', {
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
    });
  }

  /** Resolves once all detached work has finished. For tests and graceful shutdown. */
  async whenIdle(): Promise<void> {
    await this.background;
  }

  /** Handle one Telegram update. Never throws; never logs full update bodies. */
  async handleUpdate(update: TelegramUpdate): Promise<void> {
    const { repos, clock, logger, auth } = this.deps;
    let message: TelegramMessage | undefined;
    try {
      const nowIso = clock.now().toISOString();

      // Dedup FIRST: Telegram retries deliveries, so a seen update_id is dropped silently.
      const isNew = await repos.updates.registerIfNew(update.update_id, nowIso);
      if (!isNew) return;

      // Telegram Business connected-bot updates (owner acting inside a client's chat).
      if (update.business_connection !== undefined) {
        await this.handleBusinessConnection(update.business_connection, nowIso);
        return;
      }
      // This branch returns BEFORE `message` is assigned below, so the outer catch's
      // bestEffortErrorReply had nothing to answer and every failure inside a client chat was
      // completely silent: the owner saw "🔎 Checking @x…" and then nothing, and assumed it had
      // worked. Report to the owner here, then rethrow so the failure is still logged with the
      // update id by the same catch as every other handler.
      const businessMessage = update.business_message;
      if (businessMessage !== undefined) {
        try {
          await this.handleBusinessMessage(businessMessage, nowIso);
        } catch (err) {
          await this.reportBusinessFailure(businessMessage, err);
          throw err;
        }
        return;
      }

      message = update.message;
      if (message === undefined) return;
      if (message.chat.type !== 'private') return;
      const from = message.from;
      if (from === undefined || from.is_bot) return;
      const text = message.text;
      if (typeof text !== 'string') return;

      const parsed = parseCommand(text);
      if (parsed === null) return;
      const chatId = message.chat.id;

      if (parsed.command === 'start') {
        await this.handleStart(chatId, from.id, parsed.args, nowIso);
        return;
      }

      if (
        parsed.command === 'unban' ||
        parsed.command === 'bulkunban' ||
        parsed.command === 'check' ||
        parsed.command === 'list' ||
        parsed.command === 'clear' ||
        parsed.command === 'ping' ||
        parsed.command === 'ban' ||
        parsed.command === 'banlist' ||
        parsed.command === 'unwatch' ||
        parsed.command === 'proxy' ||
        parsed.command === 'clients'
      ) {
        const owner = await auth.isOwner(from.id);
        if (!owner) {
          logger.warn('unauthorized command rejected', {
            command: parsed.command,
            userId: from.id,
          });
          // Unclaimed bot: guide the (future) owner to pair instead of a flat rejection.
          // The pairing secret itself is never revealed here.
          if ((await repos.owner.getOwnerTelegramId()) === null) {
            await this.replyText(
              chatId,
              '🔐 This bot has no owner yet.\n\nPair first by sending:\n/start <your pairing secret>',
            );
          } else {
            await this.reply(chatId, notAuthorized());
          }
          return;
        }
        switch (parsed.command) {
          case 'unban':
            await this.handleUnban(chatId, parsed.args);
            return;
          case 'bulkunban':
            await this.handleBulkUnban(chatId, parsed.args);
            return;
          case 'check':
            await this.handleCheck(chatId, parsed.args);
            return;
          case 'list':
            await this.handleList(chatId, parsed.args);
            return;
          case 'clear':
            await this.handleClear(chatId, parsed.args);
            return;
          case 'ping':
            await this.handlePing(chatId);
            return;
          case 'ban':
            await this.handleBan(chatId, parsed.args);
            return;
          case 'banlist':
            await this.handleBanList(chatId);
            return;
          case 'unwatch':
            await this.handleUnwatch(chatId, parsed.args);
            return;
          case 'proxy':
            await this.handleProxy(chatId, parsed.args);
            return;
          case 'clients':
            await this.handleClients(chatId, parsed.args);
            return;
          default:
            return;
        }
      }

      // Unknown command: brief help, owner only.
      if (await auth.isOwner(from.id)) {
        await this.replyText(
          chatId,
          'Unknown command. Available: /unban, /bulkunban, /check, /list, /clear, /ping, /ban, /banlist, /unwatch, /clients.',
        );
      }
    } catch (err) {
      logger.error('command handling failed', {
        updateId: update.update_id,
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
      await this.bestEffortErrorReply(message);
    }
  }

  private async handleStart(
    chatId: number,
    userId: number,
    args: string,
    nowIso: string,
  ): Promise<void> {
    const { auth } = this.deps;
    const outcome = await auth.tryPair(userId, args.trim(), nowIso);
    if (outcome === 'paired') {
      await this.reply(chatId, pairedOk());
      await this.reply(chatId, startGuide());
      return;
    }
    // 'no_secret' (a bare /start — Telegram sends one automatically the moment anyone opens the
    // chat), 'throttled' and 'invalid' deliberately share ONE ambiguous reply. They differ only
    // in how much brute-force budget they spend; a bare /start spends none. Answering "this bot
    // has no owner yet" would hand every casual visitor the single fact worth hiding — that the
    // pairing endpoint is real and still claimable — un-throttled and uncounted.
    if (outcome === 'no_secret' || outcome === 'throttled' || outcome === 'invalid') {
      await this.reply(chatId, pairingInvalid());
      return;
    }
    // already_paired: the owner gets the guide; anyone else is turned away.
    if (await auth.isOwner(userId)) {
      await this.reply(chatId, startGuide());
    } else {
      await this.reply(chatId, notAuthorized());
    }
  }

  /** Store/refresh a Telegram Business connection when the owner (dis)connects the bot. */
  private async handleBusinessConnection(
    raw: RawBusinessConnection,
    nowIso: string,
  ): Promise<void> {
    const { repos, logger } = this.deps;
    const rights = raw.rights ?? {};
    const connection: BusinessConnection = {
      id: raw.id,
      userId: raw.user.id,
      userChatId: raw.user_chat_id ?? null,
      isEnabled: raw.is_enabled,
      rights: {
        canReply: rights.can_reply ?? raw.can_reply ?? false,
        canReadMessages: rights.can_read_messages ?? false,
        canDeleteSentMessages: rights.can_delete_sent_messages ?? false,
        canDeleteAllMessages: rights.can_delete_all_messages ?? false,
      },
      createdAtUtc: nowIso,
      updatedAtUtc: nowIso,
    };
    await repos.businessConnections.upsert(connection);
    logger.info('business connection updated', {
      enabled: connection.isEnabled,
      canReply: connection.rights.canReply,
    });
  }

  /**
   * Resolve a `business_message` that arrived on a connection id we have never stored.
   *
   * Telegram emits the `business_connection` update ONLY on connect / change / disconnect —
   * never on startup. So a fresh volume, a reset database, or the bot simply being down at the
   * moment the owner (re)connected leaves no row for a connection that is perfectly live on
   * Telegram's side. Every `/unban`, `/ban` and `/check` the owner then typed inside a client
   * chat was discarded with no reply, no owner ping and not even a log line: the owner assumed
   * it had worked and the client's account was never monitored at all — the worst failure this
   * system has.
   *
   * Returns the connection to act on, or null when the command must not run — having told the
   * owner what to do, so that outcome is never silent again.
   *
   * AUTHORISATION IS NOT WIDENED. The stored-connection path demands two things of the sender:
   * that they are the business-account owner, and — once the bot is paired — that they are the
   * paired owner. Both still hold here. The paired owner id deliberately takes PRECEDENCE over
   * the surviving connection's, so a stale row can never out-rank the pairing; the set of people
   * who can drive the bot is therefore still exactly "the paired owner", falling back to "an
   * owner of a connection this bot genuinely holds" only while the bot is unpaired — which is
   * the same rule the stored path already applies. Everyone else, a client included, is ignored
   * in silence, which also stops this path being used to make the bot message the owner.
   */
  private async recoverBusinessConnection(
    bcid: string,
    senderId: number,
    clientChatId: number,
    command: string,
    nowIso: string,
  ): Promise<BusinessConnection | null> {
    const { repos, logger } = this.deps;
    const fallback = await repos.businessConnections.findLatestEnabled();
    const ownerId = await repos.owner.getOwnerTelegramId();
    const authorizedUserId = ownerId ?? fallback?.userId ?? null;
    if (authorizedUserId === null || senderId !== authorizedUserId) {
      logger.warn('business command on an unknown connection ignored (not the owner)', { command });
      return null;
    }

    // Same business account, new connection id: adopt it under the id the message ACTUALLY
    // arrived on, because that is the id the in-chat reply, the client link and the later
    // recovery delivery all key off — the outbox worker refuses to deliver through a connection
    // it cannot find. Rights are copied rather than assumed, and `canReply` is required up
    // front: adopting a connection we cannot answer through would only move the silence one
    // step later, into a send that throws after the owner was shown nothing.
    if (fallback !== null && fallback.userId === authorizedUserId && fallback.rights.canReply) {
      const adopted: BusinessConnection = {
        ...fallback,
        id: bcid,
        createdAtUtc: nowIso,
        updatedAtUtc: nowIso,
      };
      await repos.businessConnections.upsert(adopted);
      logger.warn('adopted an unknown business connection from the latest enabled one', {
        command,
      });
      return adopted;
    }

    // Nothing safe to adopt. The command cannot run, so the owner is told how to restore the
    // connection — this is the branch whose silence let a paying client go unmonitored.
    try {
      await this.reply(authorizedUserId, businessConnectionUnrecognised({ command, clientChatId }));
    } catch (err) {
      logger.error('failed to tell the owner about an unrecognised business connection', {
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
    }
    return null;
  }

  /**
   * A message inside a managed client chat. Only a command the BUSINESS OWNER typed
   * (from.id === the connection owner) is honored — a client's `/unban` is ignored.
   */
  private async handleBusinessMessage(message: TelegramMessage, nowIso: string): Promise<void> {
    const { repos } = this.deps;
    const bcid = message.business_connection_id;
    const from = message.from;
    const text = message.text;
    if (bcid === undefined || from === undefined || typeof text !== 'string') return;

    const parsed = parseCommand(text);
    if (parsed === null) return;

    // A MISSING row does NOT mean the connection is gone — see recoverBusinessConnection.
    let connection = await repos.businessConnections.findById(bcid);
    if (connection === null && BUSINESS_COMMANDS.includes(parsed.command)) {
      connection = await this.recoverBusinessConnection(
        bcid,
        from.id,
        message.chat.id,
        parsed.command,
        nowIso,
      );
    }
    if (connection === null || !connection.isEnabled) return;
    // Authorization: the sender must BE the business-account owner (not the client).
    if (from.id !== connection.userId) return;
    const ownerId = await repos.owner.getOwnerTelegramId();
    if (ownerId !== null && ownerId !== connection.userId) return;

    // Capture/refresh the client's display identity (for /clients) from the chat this command
    // landed in. Best-effort — a capture failure must never block the command.
    await repos.clients
      .upsert(
        {
          clientChatId: message.chat.id,
          businessConnectionId: bcid,
          username: message.chat.username ?? null,
          firstName: message.chat.first_name ?? null,
          lastName: message.chat.last_name ?? null,
        },
        nowIso,
      )
      .catch(() => undefined);

    if (parsed.command === 'unban') {
      await this.handleBusinessUnban(
        message.chat.id,
        bcid,
        from.id,
        message.message_id,
        parsed.args,
        nowIso,
      );
    } else if (parsed.command === 'ban') {
      await this.handleBusinessBan(
        message.chat.id,
        bcid,
        from.id,
        message.message_id,
        parsed.args,
        nowIso,
      );
    } else if (parsed.command === 'check') {
      await this.handleBusinessCheck(message.chat.id, bcid, parsed.args);
    }
    // /status, /clear inside business chats: follow-up work.
  }

  /**
   * Tell the owner that a command they typed inside a client chat threw and did NOT finish.
   *
   * Nothing here is cosmetic. The dangerous aftermath is a HALF-CREATED enrolment: the case and
   * the client link are two separate writes, and the repository layer offers no transaction to
   * join them — {@link Database} exposes only migrate/repositories/ping/close and
   * {@link Repositories} hands out per-table repositories, with no unit of work — so they cannot
   * be made atomic from this layer. The partial state is therefore handled EXPLICITLY instead of
   * being left implicit: when an active monitor (`/unban`) or deletion watch (`/ban`) exists for
   * the username but carries no link to this chat, the owner is told precisely that — and told the
   * repair that actually works for THAT command — because on recovery or deletion the delivery
   * path finds no link, treats the alert as owner-only, and the paying client is never told.
   *
   * The monitor is deliberately NOT torn down as compensation. A monitor with no link still
   * alerts the owner, who can then forward it by hand; deleting it would mean the recovery is
   * never noticed by anyone.
   *
   * Never throws — the caller rethrows the original error so it is still logged with the update
   * id, and a failure to report must not replace the failure being reported.
   */
  private async reportBusinessFailure(message: TelegramMessage, err: unknown): Promise<void> {
    const { repos, logger } = this.deps;
    const parsed = typeof message.text === 'string' ? parseCommand(message.text) : null;
    const command = parsed?.command ?? 'command';
    const clientChatId = message.chat.id;
    logger.error('business command failed inside a client chat', {
      command,
      clientChatId,
      error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
    });

    try {
      // Only ever DM the authorized owner, and only when THEY typed the command. The same rule
      // recoverBusinessConnection applies: the paired owner id wins, falling back to an owner of
      // a connection this bot genuinely holds only while unpaired. Falling back to the sender
      // would turn this into a way to make the bot message a client, and telling the owner "your
      // command failed" for a command a client typed would simply be untrue.
      const ownerId = await repos.owner.getOwnerTelegramId();
      const authorizedId =
        ownerId ?? (await repos.businessConnections.findLatestEnabled())?.userId ?? null;
      if (authorizedId === null || message.from?.id !== authorizedId) return;

      // BOTH enrolling commands are two non-atomic writes into different tables, and both end in
      // the SAME client_chat_links row: /unban writes monitoring_cases then the link, /ban writes
      // deletion_watches then the link. Either can therefore leave a live row with no route back
      // to the client, and the delivery paths are symmetrical too — DeletionWorker.deliverToClient
      // treats a missing link as an owner-only watch exactly as the recovery path does. Only
      // /check writes nothing and cannot strand anything.
      let unlinked: { username: string; kind: 'monitor' | 'watch' } | undefined;
      if (parsed !== null && (parsed.command === 'unban' || parsed.command === 'ban')) {
        const token = parsed.args.trim().split(/\s+/, 1)[0] ?? '';
        const user = parseUsernameInput(token);
        if (!('error' in user)) {
          const kind = parsed.command === 'unban' ? 'monitor' : 'watch';
          // The enrichment is best-effort ON ITS OWN, separately from the send below. These reads
          // hit the very tables whose failure caused the throw being reported — a DB-wide fault is
          // the dominant cause — and on the Postgres driver EVERY deletionWatches method throws by
          // design. Letting that escape would take the owner's ping with it and restore the exact
          // silence this reporter exists to end. A generic ping is worth incomparably more than
          // none, so a failed lookup only costs the extra detail.
          try {
            const row =
              kind === 'monitor'
                ? await repos.cases.findActiveByNormalizedUsername(user.username)
                : await repos.deletionWatches.findActiveByNormalizedUsername(user.username);
            // NO link at all is the half-created state, and the only one a throw can create: a
            // link owned by a different chat comes back from `create` rather than throwing, and
            // is already refused (and reported to the owner) by refuseLinkedElsewhere. Claiming
            // "not linked" for that one would be a second, less accurate story about the same page.
            if (row !== null && (await repos.clientLinks.findByMonitorId(row.id)) === null) {
              unlinked = { username: user.username, kind };
            }
          } catch (lookupErr) {
            logger.warn('could not check for a half-created enrolment', {
              command,
              error: lookupErr instanceof Error ? lookupErr.message : String(lookupErr),
            });
          }
        }
      }

      await this.reply(
        authorizedId,
        ownerBusinessCommandFailed({
          command,
          clientChatId,
          // Bounded: an owner DM is not a log sink, and Telegram caps message length.
          detail: (err instanceof Error ? `${err.name}: ${err.message}` : String(err)).slice(
            0,
            300,
          ),
          ...(unlinked !== undefined ? { unlinked } : {}),
        }),
      );
    } catch (reportErr) {
      logger.error('failed to tell the owner about a failed business command', {
        error:
          reportErr instanceof Error
            ? { name: reportErr.name, message: reportErr.message }
            : String(reportErr),
      });
    }
  }

  /**
   * /check inside a client business chat: one-off live probe (same shared detector), replied
   * INTO that chat via business_connection_id — diagnostic text plus the captured screenshot as
   * visual proof. Never changes monitoring state; owner-only (the caller is already authorized
   * as the business-account owner in handleBusinessMessage).
   */
  private async handleBusinessCheck(chatId: number, bcid: string, args: string): Promise<void> {
    const { client, detector, logger, clock } = this.deps;
    const usernameToken = args.trim().split(/\s+/, 1)[0] ?? '';
    if (usernameToken.length === 0) {
      await this.replyBusiness(chatId, bcid, { text: 'Please use /check instagramusername' });
      return;
    }
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await this.replyBusiness(chatId, bcid, { text: parsed.error });
      return;
    }
    const username = parsed.username;

    // Light per-chat rate limit, mirroring the owner /check.
    const nowMs = clock.nowMs();
    const last = this.lastCheckByChat.get(chatId);
    if (last !== undefined && nowMs - last < 15_000) {
      await this.replyBusiness(chatId, bcid, {
        text: 'Please wait a few seconds before another /check.',
      });
      return;
    }
    this.lastCheckByChat.set(chatId, nowMs);

    await this.replyBusiness(chatId, bcid, checkInProgress(username));

    let classification: Classification = 'UNKNOWN';
    let errorCode: DetectorErrorCode | null = null;
    let screenshotBuffer: Buffer | null = null;
    let profileMatch = false;
    let unavailable = false;
    let durationMs = 0;
    try {
      const probe = await detector.probe(username, { captureScreenshot: true });
      classification = probe.result.classification;
      errorCode = probe.result.evidence.errorCode;
      durationMs = probe.result.durationMs;
      profileMatch = probe.result.evidence.identitySignalMatched;
      unavailable = probe.result.evidence.goneSignals.length > 0;
      if (probe.screenshot !== null && probe.screenshot.buffer.length > 0) {
        screenshotBuffer = probe.screenshot.buffer;
      }
    } catch (err) {
      logger.warn('business check probe threw', {
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
    }

    await this.replyBusiness(
      chatId,
      bcid,
      checkDiagnostic({
        username,
        classification,
        profileMatch,
        unavailable,
        loginWall: errorCode === 'LOGIN_WALL',
        screenshotOk: screenshotBuffer !== null,
        durationMs,
        action:
          classification === 'UNKNOWN' && errorCode !== null
            ? `No monitoring state changed (${errorCode})`
            : 'No monitoring state changed',
      }),
    );

    // Send the captured screenshot into the client chat as visual proof (best-effort).
    if (screenshotBuffer !== null) {
      try {
        await client.sendPhoto({
          chat_id: chatId,
          photo: screenshotBuffer,
          caption: `📸 @${username} — live check`,
          business_connection_id: bcid,
        });
      } catch (err) {
        logger.warn('business check: failed to send screenshot', {
          error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
        });
      }
    }
  }

  private async handleBusinessUnban(
    chatId: number,
    bcid: string,
    ownerUserId: number,
    sourceMessageId: number,
    args: string,
    nowIso: string,
  ): Promise<void> {
    const { repos, config, clock } = this.deps;
    const trimmed = args.trim();
    const spaceIdx = trimmed.search(/\s/);
    const usernameToken = spaceIdx === -1 ? trimmed : trimmed.slice(0, spaceIdx);
    const timestampText = spaceIdx === -1 ? '' : trimmed.slice(spaceIdx).trim();

    if (usernameToken.length === 0) {
      await this.replyBusiness(chatId, bcid, { text: 'Please use /unban instagramusername' });
      return;
    }
    const parsedUser = parseUsernameInput(usernameToken);
    if ('error' in parsedUser) {
      await this.replyBusiness(chatId, bcid, { text: parsedUser.error });
      return;
    }
    const username = parsedUser.username;
    if (username === config.controlUsername) {
      await this.replyBusiness(chatId, bcid, {
        text: `ℹ️ @${username} is the control account and cannot be monitored.`,
      });
      return;
    }

    const now = clock.now();
    let monitorId: string;
    let startedAtUtc: string;
    // Null when this chat joined an EXISTING monitor: nothing was pre-checked here, and nothing
    // new was started, so there is no unchecked enrolment to disclose.
    let precheck: UnbanPrecheckOutcome | null = null;
    const existing = await repos.cases.findActiveByNormalizedUsername(username);
    if (existing !== null) {
      monitorId = existing.id;
      startedAtUtc = existing.startedAtUtc;
    } else {
      // Check before monitoring (same rule as the owner /unban). Starting a monitor on a live
      // account would confirm ACTIVE 3x and deliver a false "YOUR PROFILE IS ACTIVE AGAIN"
      // message to THIS CLIENT for an account that was never down.
      await this.replyBusiness(chatId, bcid, { text: `🔎 Checking @${username}…` });
      precheck = await runUnbanPrecheck(username, {
        detector: this.deps.detector,
        logger: this.deps.logger,
        logLabel: 'business unban',
      });
      if (precheck.verdict === 'active') {
        await this.replyBusiness(chatId, bcid, {
          text: `✅ @${username} is already active on Instagram — nothing to recover, so no monitoring was started.`,
        });
        return;
      }
      startedAtUtc = nowIso;
      if (timestampText.length > 0) {
        const back = parseBackdatedTimestamp(timestampText, config.displayTimezone, now);
        if ('error' in back) {
          await this.replyBusiness(chatId, bcid, { text: back.error });
          return;
        }
        startedAtUtc = back.iso;
      }
      try {
        const created = await repos.cases.create(
          {
            normalizedUsername: username,
            originalInput: usernameToken,
            startedAtUtc,
            nextCheckAtUtc: nowIso,
          },
          nowIso,
        );
        monitorId = created.id;
        startedAtUtc = created.startedAtUtc;
      } catch (err) {
        if (isAppError(err) && err.code === 'DUPLICATE_CASE') {
          const raced = await repos.cases.findActiveByNormalizedUsername(username);
          if (raced === null) throw err;
          monitorId = raced.id;
          startedAtUtc = raced.startedAtUtc;
        } else {
          throw err;
        }
      }
    }

    // One monitor carries ONE client chat id. `/unban @x` typed in a SECOND client's chat reuses
    // the same case (one active case per username), so linking unconditionally re-pointed the
    // link at whoever ran the command last — the first client, already told "MONITORING STARTED",
    // silently lost the only route back to them and would never hear about their own recovery.
    // Refuse; the owner is the only one who can decide which client should receive the alert.
    const ownedLink = await repos.clientLinks.findByMonitorId(monitorId);
    if (ownedLink !== null && ownedLink.clientChatId !== chatId) {
      await this.refuseLinkedElsewhere(chatId, bcid, ownerUserId, username, ownedLink);
      return;
    }

    // Link this client conversation to the monitor and mark client delivery as expected.
    const link = await repos.clientLinks.create(
      {
        monitorId,
        sourceType: 'BUSINESS_CHAT',
        clientChatId: chatId,
        businessConnectionId: bcid,
        ownerTelegramUserId: ownerUserId,
        sourceMessageId,
      },
      nowIso,
    );
    // Lost race with a concurrent /unban in another chat: the repository never re-points an
    // existing link, so it handed back the OTHER chat's row. Nothing was overwritten — but this
    // chat must not be told monitoring started here, because its alert will not come.
    if (link.clientChatId !== chatId) {
      await this.refuseLinkedElsewhere(chatId, bcid, ownerUserId, username, link);
      return;
    }
    await repos.clientLinks.updateDeliveryStatus(monitorId, 'BUSINESS_DELIVERY_PENDING', nowIso);

    await this.replyBusiness(
      chatId,
      bcid,
      businessMonitoringStarted(username, startedAtUtc, config.displayTimezone),
    );

    // The client now has a confirmation that reads as "we checked, it is down, we are watching".
    // If nothing actually checked it, the owner is the only one who can catch that before a false
    // recovery reaches this same chat — so they are told, privately, AFTER the client's message,
    // which must never be delayed or endangered by a diagnostic DM.
    if (precheck !== null && precheck.verdict === 'unverified') {
      await this.reportUnverifiedPrecheck(ownerUserId, chatId, username, precheck.reason);
    }
  }

  /**
   * Owner DM: a client-chat `/unban` started monitoring on a pre-check that never happened.
   *
   * Never throws. The monitor exists and the client has been told — failing to file the warning
   * must not undo either, so it is logged and swallowed like every other owner-notification
   * best effort in this file.
   */
  private async reportUnverifiedPrecheck(
    ownerUserId: number,
    clientChatId: number,
    username: string,
    reason: string,
  ): Promise<void> {
    const { logger } = this.deps;
    logger.warn('business unban enrolled without a completed pre-check', {
      username,
      clientChatId,
      reason,
    });
    try {
      await this.reply(
        ownerUserId,
        ownerBusinessPrecheckUnverified({ username, clientChatId, reason }),
      );
    } catch (err) {
      logger.error('failed to tell the owner about an unverified pre-check', {
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
    }
  }

  /**
   * `/ban` inside a client business chat — the deletion-watch mirror of {@link handleBusinessUnban}.
   * Starts the watch, LINKS it to this conversation, and confirms in-chat. When the deletion is
   * later confirmed, {@link DeletionWorker} delivers the alert into this same chat.
   *
   * Reuses `client_chat_links` keyed by the watch id: deletion-watch and monitor ids are both
   * UUIDs from separate tables, so they never collide and no schema change is needed.
   */
  private async handleBusinessBan(
    chatId: number,
    bcid: string,
    ownerUserId: number,
    sourceMessageId: number,
    args: string,
    nowIso: string,
  ): Promise<void> {
    const { repos, config, detector, logger } = this.deps;
    const usernameToken = args.trim().split(/\s+/, 1)[0] ?? '';
    if (usernameToken.length === 0) {
      await this.replyBusiness(chatId, bcid, { text: 'Please use /ban instagramusername' });
      return;
    }
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await this.replyBusiness(chatId, bcid, { text: parsed.error });
      return;
    }
    const username = parsed.username;
    if (username === config.controlUsername) {
      await this.replyBusiness(chatId, bcid, {
        text: `ℹ️ @${username} is the control account and cannot be watched.`,
      });
      return;
    }

    const existing = await repos.deletionWatches.findActiveByNormalizedUsername(username);
    if (existing !== null) {
      await this.replyBusiness(chatId, bcid, {
        text: `ℹ️ @${username} is already being watched.`,
      });
      return;
    }

    // A deletion watch only makes sense for a page that is live RIGHT NOW — an already-gone
    // account has no active->gone transition to observe.
    await this.replyBusiness(chatId, bcid, { text: `🔎 Checking @${username}…` });
    let classification: Classification = 'UNKNOWN';
    try {
      classification = (await detector.probe(username)).result.classification;
    } catch (err) {
      logger.warn('business ban probe threw', {
        error: err instanceof Error ? err.message : String(err),
      });
    }
    if (classification === 'GONE') {
      await this.replyBusiness(chatId, bcid, {
        text: `ℹ️ @${username} is already unavailable on Instagram — there is nothing to watch for.`,
      });
      return;
    }
    if (classification !== 'ACTIVE') {
      await this.replyBusiness(chatId, bcid, {
        text: `⚠️ Couldn't confirm @${username} is active right now. Please try again in a moment.`,
      });
      return;
    }

    let watchId: string;
    try {
      const created = await repos.deletionWatches.create(
        {
          normalizedUsername: username,
          originalInput: usernameToken,
          startedAtUtc: nowIso,
          nextCheckAtUtc: nowIso,
        },
        nowIso,
      );
      watchId = created.id;
    } catch (err) {
      if (isAppError(err) && err.code === 'DUPLICATE_CASE') {
        const raced = await repos.deletionWatches.findActiveByNormalizedUsername(username);
        if (raced === null) throw err;
        watchId = raced.id;
      } else {
        throw err;
      }
    }

    await repos.clientLinks.create(
      {
        monitorId: watchId,
        sourceType: 'BUSINESS_CHAT',
        clientChatId: chatId,
        businessConnectionId: bcid,
        ownerTelegramUserId: ownerUserId,
        sourceMessageId,
      },
      nowIso,
    );
    await repos.clientLinks.updateDeliveryStatus(watchId, 'BUSINESS_DELIVERY_PENDING', nowIso);

    await this.replyBusiness(
      chatId,
      bcid,
      businessDeletionWatchStarted(username, nowIso, config.displayTimezone),
    );
  }

  /**
   * A `/unban` whose monitor is already linked to a DIFFERENT client chat: keep the first link and
   * make the owner able to act.
   *
   * Two recipients on purpose. The client chat gets a refusal that names nothing about the other
   * customer — it is a different paying client's conversation. The owner gets a DM naming the chat
   * that owns the link, because that detail is what they need and it must not be posted into a
   * client chat. The DM goes first: it is the actionable half, and it must survive a failure of
   * the business send.
   */
  private async refuseLinkedElsewhere(
    chatId: number,
    bcid: string,
    ownerUserId: number,
    username: string,
    ownedLink: ClientChatLink,
  ): Promise<void> {
    const { repos, logger } = this.deps;
    logger.warn('business unban refused: monitor already linked to another client chat', {
      username,
      requestedChatId: chatId,
      linkedChatId: ownedLink.clientChatId,
    });
    // Best-effort label so the owner sees a name, not just a number (same source as /clients).
    const identity = await repos.clients.findByChatId(ownedLink.clientChatId).catch(() => null);
    try {
      await this.reply(
        ownerUserId,
        ownerClientLinkConflict({
          username,
          existingChatId: ownedLink.clientChatId,
          existingIdentity: identity,
          attemptedChatId: chatId,
        }),
      );
    } catch (err) {
      logger.error('failed to tell the owner about a client-link conflict', {
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
    }
    await this.replyBusiness(chatId, bcid, businessMonitorLinkedElsewhere(username));
  }

  private async replyBusiness(
    chatId: number,
    businessConnectionId: string,
    message: FormattedMessage,
  ): Promise<void> {
    const params: SendMessageParams = {
      chat_id: chatId,
      text: message.text,
      business_connection_id: businessConnectionId,
    };
    if (message.replyMarkup) params.reply_markup = message.replyMarkup;
    await this.deps.client.sendMessage(params);
  }

  private async handleUnban(chatId: number, args: string): Promise<void> {
    const { repos, config, clock } = this.deps;
    const trimmed = args.trim();
    const spaceIdx = trimmed.search(/\s/);
    const usernameToken = spaceIdx === -1 ? trimmed : trimmed.slice(0, spaceIdx);
    const timestampText = spaceIdx === -1 ? '' : trimmed.slice(spaceIdx).trim();

    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await this.replyText(chatId, parsed.error);
      return;
    }
    const username = parsed.username;

    if (username === config.controlUsername) {
      await this.replyText(
        chatId,
        `ℹ️ @${username} is the control account used for health checks and cannot be monitored.`,
      );
      return;
    }

    const now = clock.now();
    const nowIso = now.toISOString();

    const existing = await repos.cases.findActiveByNormalizedUsername(username);
    if (existing !== null) {
      await this.reply(chatId, alreadyMonitoring(username, existing.startedAtUtc, now));
      return;
    }

    let startedAtUtc = nowIso;
    if (timestampText.length > 0) {
      const back = parseBackdatedTimestamp(timestampText, config.displayTimezone, now);
      if ('error' in back) {
        await this.replyText(chatId, back.error);
        return;
      }
      startedAtUtc = back.iso;
    }

    // Check the page BEFORE monitoring it, mirroring /ban. Monitoring an already-live account
    // is not just pointless: it would confirm ACTIVE 3x within a minute and fire a
    // "ACCOUNT UNBANNED" alert for an account that was never banned — and in a client chat that
    // alert would go to the client. An inconclusive result still starts monitoring, since the
    // account may genuinely be banned and we must not refuse on a transient failure — but it is
    // then reported as NOT pre-checked, because "Monitoring Started" reads as "we looked, and it
    // is down" and an unchecked live page becomes a false recovery alert within minutes.
    await this.replyText(chatId, `🔎 Checking @${username}…`);
    const precheck = await runUnbanPrecheck(username, {
      detector: this.deps.detector,
      logger: this.deps.logger,
      logLabel: 'unban',
    });
    if (precheck.verdict === 'active') {
      await this.replyText(
        chatId,
        `✅ @${username} is ALREADY ACTIVE on Instagram — there is nothing to recover, so no monitor was started.\n\nIf you want to be told when it goes DOWN, use:  /ban ${username}`,
      );
      return;
    }

    try {
      // nextCheckAt = now: the scheduler picks the case up for its immediate initial
      // check — the detector is never called inline from a command.
      const created = await repos.cases.create(
        {
          normalizedUsername: username,
          originalInput: usernameToken,
          startedAtUtc,
          nextCheckAtUtc: nowIso,
        },
        nowIso,
      );
      await this.reply(
        chatId,
        precheck.verdict === 'unverified'
          ? monitoringStartedUnverified(
              username,
              created.startedAtUtc,
              config.displayTimezone,
              precheck.reason,
            )
          : monitoringStarted(username, created.startedAtUtc, config.displayTimezone),
      );
    } catch (err) {
      if (isAppError(err) && err.code === 'DUPLICATE_CASE') {
        const raced = await repos.cases.findActiveByNormalizedUsername(username);
        await this.reply(
          chatId,
          alreadyMonitoring(username, raced?.startedAtUtc ?? startedAtUtc, now),
        );
        return;
      }
      throw err;
    }
  }

  /**
   * /bulkunban: start monitoring MANY usernames at once (space / comma / newline separated).
   * Sends ONE consolidated summary instead of a per-account confirmation. Recovery alerts
   * still fire individually. No backdate support — use /unban for a single backdated account.
   *
   * The command ACKNOWLEDGES and returns; the pre-check runs detached. {@link PollingLoop} awaits
   * update handlers one at a time, so doing 50 live probes inline froze ALL Telegram ingress for
   * as long as they took — on a degraded egress route, tens of minutes during which the owner
   * could not even run /ping to find out why.
   */
  private async handleBulkUnban(chatId: number, args: string): Promise<void> {
    const { config } = this.deps;
    const tokens = args
      .split(/[\s,]+/)
      .map((t) => t.trim())
      .filter((t) => t.length > 0);
    if (tokens.length === 0) {
      await this.replyText(
        chatId,
        'Usage: /bulkunban user1 user2 user3 …  (space, comma, or newline separated)',
      );
      return;
    }
    const capped = tokens.slice(0, BULK_MAX);

    const invalid: string[] = [];
    const candidates: { token: string; username: string }[] = [];
    const seen = new Set<string>();
    for (const token of capped) {
      const parsed = parseUsernameInput(token);
      if ('error' in parsed || parsed.username === config.controlUsername) {
        invalid.push(token);
        continue;
      }
      if (seen.has(parsed.username)) continue; // de-dupe within the batch
      seen.add(parsed.username);
      candidates.push({ token, username: parsed.username });
    }

    await this.replyText(
      chatId,
      `🔎 Checking ${candidates.length} account${candidates.length === 1 ? '' : 's'} before monitoring — I'll post one summary when it's done.\n\nOther commands still work in the meantime.`,
    );
    this.track(() => this.runBulkUnban(chatId, candidates, invalid, tokens.length > BULK_MAX));
  }

  /** The detached half of /bulkunban: pre-check, enrol, then one consolidated summary. */
  private async runBulkUnban(
    chatId: number,
    candidates: { token: string; username: string }[],
    invalid: string[],
    truncated: boolean,
  ): Promise<void> {
    const { repos, detector, clock, logger } = this.deps;
    const nowIso = clock.now().toISOString();

    const started: string[] = [];
    const already: string[] = [];
    const alreadyLive: string[] = [];
    const unverified: string[] = [];
    const failed: string[] = [];

    const toProbe: { token: string; username: string }[] = [];
    for (const candidate of candidates) {
      try {
        if ((await repos.cases.findActiveByNormalizedUsername(candidate.username)) !== null) {
          already.push(candidate.username);
          continue;
        }
        toProbe.push(candidate);
      } catch (err) {
        failed.push(candidate.username);
        logger.warn('bulkunban: lookup failed', {
          username: candidate.username,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }

    const precheck = await runBulkPrecheck(
      toProbe.map((c) => c.username),
      {
        detector,
        logger,
        ...(this.deps.bulkPrecheckLimits !== undefined
          ? { limits: this.deps.bulkPrecheckLimits }
          : {}),
      },
    );

    for (const candidate of toProbe) {
      const verdict = precheck.verdicts.get(candidate.username) ?? 'unverified';
      // Already public: monitoring it would confirm ACTIVE 3x within a minute and fire a false
      // "ACCOUNT UNBANNED" — in a client chat, straight to the client.
      if (verdict === 'active') {
        alreadyLive.push(candidate.username);
        continue;
      }
      try {
        await repos.cases.create(
          {
            normalizedUsername: candidate.username,
            originalInput: candidate.token,
            startedAtUtc: nowIso,
            nextCheckAtUtc: nowIso,
          },
          nowIso,
        );
        // An unverified account IS enrolled — a missed recovery is the worst failure there is —
        // but it is reported apart from the verified ones so the owner is never left believing
        // it was checked.
        (verdict === 'not-active' ? started : unverified).push(candidate.username);
      } catch (err) {
        // A DB blip on ONE username must never abort the batch, and must not be mislabeled
        // as invalid input — surface it as a retryable failure so the owner can re-add it.
        if (isAppError(err) && err.code === 'DUPLICATE_CASE') {
          already.push(candidate.username);
        } else {
          failed.push(candidate.username);
          logger.warn('bulkunban: failed to process username', {
            username: candidate.username,
            error: err instanceof Error ? err.message : String(err),
          });
        }
      }
    }

    await this.reply(
      chatId,
      bulkMonitoringStarted({
        started,
        already,
        alreadyLive,
        unverified,
        ...(precheck.stoppedReason !== null ? { unverifiedReason: precheck.stoppedReason } : {}),
        invalid,
        failed,
        truncated,
      }),
    );
  }

  /**
   * /check: one-off probe through the SAME shared detector. Never creates a
   * monitoring case. ACTIVE gets a fresh screenshot as visual proof.
   */
  private async handleCheck(chatId: number, args: string): Promise<void> {
    const { client, detector, logger, repos, clock, config } = this.deps;
    const usernameToken = args.trim().split(/\s+/, 1)[0] ?? '';
    if (usernameToken.length === 0) {
      await this.replyText(chatId, 'Usage: /check <username>');
      return;
    }
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await this.replyText(chatId, parsed.error);
      return;
    }
    const username = parsed.username;
    const nowMs = clock.nowMs();
    const last = this.lastCheckByChat.get(chatId);
    if (last !== undefined && nowMs - last < 15_000) {
      await this.replyText(chatId, 'Please wait a few seconds before another /check.');
      return;
    }
    this.lastCheckByChat.set(chatId, nowMs);

    // The browser probe takes several seconds — acknowledge first.
    await this.reply(chatId, checkInProgress(username));

    let classification: Classification = 'UNKNOWN';
    let errorCode: DetectorErrorCode | null = null;
    let screenshotOk = false;
    let screenshotBuffer: Buffer | null = null;
    let profileMatch = false;
    let unavailable = false;
    let action = 'No monitoring state changed';
    let durationMs = 0;
    try {
      const probe = await detector.probe(username, { captureScreenshot: true });
      classification = probe.result.classification;
      errorCode = probe.result.evidence.errorCode;
      durationMs = probe.result.durationMs;
      profileMatch = probe.result.evidence.identitySignalMatched;
      unavailable = probe.result.evidence.goneSignals.length > 0;
      screenshotOk = probe.screenshot !== null && probe.screenshot.buffer.length > 0;
      screenshotBuffer = screenshotOk ? (probe.screenshot?.buffer ?? null) : null;

      // A live check may start a normal confirmation burst for an existing monitor,
      // but it never advances a burst already in progress and never sends an alert.
      const existing = await repos.cases.findActiveByNormalizedUsername(username);
      if (classification === 'ACTIVE' && existing !== null && existing.status !== 'CONFIRMING') {
        const now = clock.now();
        const activeCount = await repos.cases.countByStatuses(ACTIVE_STATUSES);
        const transition = applyCheckResult({
          current: existing,
          classification,
          now,
          params: { ...schedulingParamsFrom(config), activeCount, unknownThreshold: 3 },
        });
        await repos.checks.insert({
          caseId: existing.id,
          checkedAtUtc: now.toISOString(),
          classification,
          finalUrl: probe.result.evidence.finalUrl,
          responseStatus: probe.result.evidence.responseStatus,
          durationMs,
          activeSignals: probe.result.evidence.activeSignals,
          goneSignals: probe.result.evidence.goneSignals,
          errorCode,
          confirmationSeq: 1,
        });
        // Compare-and-save guard: /check holds no job lease, so re-read right before saving.
        // If a /clear (or the scheduler) changed the case since we read it, drop this write
        // so a live check can never resurrect a cleared case or clobber a concurrent update.
        const fresh = await repos.cases.findById(existing.id);
        if (fresh !== null && fresh.status === existing.status && fresh.clearedAtUtc === null) {
          await repos.cases.save(transition.next);
          action =
            transition.next.status === 'CONFIRMING'
              ? 'Confirmation 1/3 started'
              : 'Monitor updated';
        } else {
          action = 'No monitoring state changed';
        }
      } else if (classification === 'ACTIVE' && existing?.status === 'CONFIRMING') {
        action = `Confirmation ${existing.confirmationCount}/3 remains scheduled`;
      }
    } catch (err) {
      logger.warn('check probe threw', {
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
    }

    await this.reply(
      chatId,
      checkDiagnostic({
        username,
        classification,
        profileMatch,
        unavailable,
        loginWall: errorCode === 'LOGIN_WALL',
        screenshotOk,
        durationMs,
        action:
          classification === 'UNKNOWN' && errorCode !== null
            ? `No monitoring state changed (${errorCode})`
            : action,
      }),
    );

    // Send the actual captured screenshot as visual proof (not just "Working" in the text).
    // Best-effort: a photo-send failure must never fail the command.
    if (screenshotBuffer !== null) {
      try {
        await client.sendPhoto({
          chat_id: chatId,
          photo: screenshotBuffer,
          caption: `📸 @${username} — live check`,
        });
      } catch (err) {
        logger.warn('check: failed to send screenshot', {
          error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
        });
      }
    }
  }

  private async handleList(chatId: number, _args = ''): Promise<void> {
    const { repos, clock } = this.deps;
    const cases = await repos.cases.listByStatuses(LISTED_STATUSES);
    const sorted = [...cases].sort((a, b) => a.startedAtUtc.localeCompare(b.startedAtUtc));
    const items: MonitoredItem[] = [];
    for (const c of sorted) {
      if (isListedStatus(c.status)) {
        items.push({
          username: c.normalizedUsername,
          status: c.status,
          confirmationCount: c.confirmationCount,
          startedIso: c.startedAtUtc,
          lastResult: c.lastResult,
          consecutiveUnknownCount: c.consecutiveUnknownCount,
          nextCheckAtIso: c.nextCheckAtUtc,
          lastCheckedAtIso: c.lastCheckedAtUtc,
        });
      }
    }
    await this.reply(chatId, listView(items, clock.now()));
  }

  private async handleClear(chatId: number, args: string): Promise<void> {
    const { repos, clock } = this.deps;
    const usernameToken = args.trim().split(/\s+/, 1)[0] ?? '';
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await this.replyText(chatId, parsed.error);
      return;
    }
    const cleared = await repos.cases.clearByNormalizedUsername(
      parsed.username,
      clock.now().toISOString(),
    );
    if (cleared !== null) {
      await this.reply(chatId, monitoringRemoved(parsed.username));
      return;
    }
    // Not a recovery monitor — if it's a deletion watch (/ban), point the owner at /unwatch
    // instead of a dead-end "not found".
    const watch = await repos.deletionWatches.findActiveByNormalizedUsername(parsed.username);
    if (watch !== null) {
      await this.replyText(
        chatId,
        `ℹ️ @${parsed.username} isn't a recovery monitor — it's a deletion watch (/ban).\nTo stop that, use:  /unwatch ${parsed.username}`,
      );
      return;
    }
    await this.reply(chatId, notFound(parsed.username));
  }

  /**
   * /ban: start a SEPARATE deletion watch (ACTIVE -> GONE). Independent of /unban — the same
   * username can be recovery-watched and deletion-watched at once. Owner-only (guarded above).
   */
  private async handleBan(chatId: number, args: string): Promise<void> {
    const { repos, config, clock, detector, logger } = this.deps;
    const usernameToken = args.trim().split(/\s+/, 1)[0] ?? '';
    if (usernameToken.length === 0) {
      await this.replyText(chatId, 'Usage: /ban <username>');
      return;
    }
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await this.replyText(chatId, parsed.error);
      return;
    }
    const username = parsed.username;
    if (username === config.controlUsername) {
      await this.replyText(chatId, `ℹ️ @${username} is the control account and cannot be watched.`);
      return;
    }
    const nowIso = clock.now().toISOString();
    const existing = await repos.deletionWatches.findActiveByNormalizedUsername(username);
    if (existing !== null) {
      await this.replyText(chatId, `ℹ️ Already watching @${username} for deletion.`);
      return;
    }

    // A deletion watch only makes sense for a page that is CURRENTLY live. Verify the
    // account is ACTIVE right now — an already-gone (404) account has no active->gone
    // transition to detect, so reject it rather than firing a meaningless "deletion".
    await this.replyText(chatId, `🔎 Checking @${username}…`);
    let classification: Classification = 'UNKNOWN';
    try {
      classification = (await detector.probe(username)).result.classification;
    } catch (err) {
      logger.warn('ban probe threw', {
        error: err instanceof Error ? err.message : String(err),
      });
    }
    if (classification === 'GONE') {
      await this.replyText(
        chatId,
        `ℹ️ @${username} is already inactive/unavailable on Instagram — there's nothing to watch for deletion.`,
      );
      return;
    }
    if (classification !== 'ACTIVE') {
      await this.replyText(
        chatId,
        `⚠️ Couldn't confirm @${username} is active right now (login wall or a temporary error). Try /ban again in a moment.`,
      );
      return;
    }

    try {
      await repos.deletionWatches.create(
        {
          normalizedUsername: username,
          originalInput: usernameToken,
          startedAtUtc: nowIso,
          nextCheckAtUtc: nowIso,
        },
        nowIso,
      );
    } catch (err) {
      if (isAppError(err) && err.code === 'DUPLICATE_CASE') {
        await this.replyText(chatId, `ℹ️ Already watching @${username} for deletion.`);
        return;
      }
      throw err;
    }
    await this.replyText(
      chatId,
      `🔎 DELETION WATCH STARTED\n\nInstagram: @${username}\nStatus: Watching (currently active)\n\nI'll alert you here if it goes inactive, deleted, or banned.`,
    );
  }

  /** /banlist: show accounts currently watched for deletion (separate from /list). */
  private async handleBanList(chatId: number): Promise<void> {
    const { repos, clock, config } = this.deps;
    const target = config.scheduling.confirmationRequiredCount;
    const watches = await repos.deletionWatches.listActive();
    if (watches.length === 0) {
      await this.replyText(
        chatId,
        '🚫 Deletion Watches\n\nNo accounts are being watched for deletion.',
      );
      return;
    }
    const nowIso = clock.now().toISOString();
    const lines = [`🚫 Deletion Watches — ${watches.length}`, ''];
    watches.forEach((w, i) => {
      const status =
        w.status === 'CONFIRMING'
          ? `Confirming ${w.confirmationCount}/${target}`
          : w.status === 'BACKOFF'
            ? 'Retrying'
            : 'Watching';
      lines.push(`${i + 1}. @${w.normalizedUsername}`);
      lines.push(`   Status: ${status}`);
      lines.push(`   Time: ${formatDuration(durationMsBetween(w.startedAtUtc, nowIso))}`);
      lines.push('');
    });
    await this.replyText(chatId, lines.join('\n').trimEnd());
  }

  /** /unwatch: stop a deletion watch (the /clear of the deletion feature). */
  private async handleUnwatch(chatId: number, args: string): Promise<void> {
    const { repos, clock } = this.deps;
    const usernameToken = args.trim().split(/\s+/, 1)[0] ?? '';
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await this.replyText(chatId, parsed.error);
      return;
    }
    const cleared = await repos.deletionWatches.clearByNormalizedUsername(
      parsed.username,
      clock.now().toISOString(),
    );
    if (cleared !== null) {
      await this.replyText(chatId, `🗑 Stopped watching @${parsed.username} for deletion.`);
      return;
    }
    // Not a deletion watch — if it's a recovery monitor (/unban), point the owner at /clear
    // instead of a dead-end "not being watched for deletion".
    const recovery = await repos.cases.findActiveByNormalizedUsername(parsed.username);
    if (recovery !== null) {
      await this.replyText(
        chatId,
        `ℹ️ @${parsed.username} isn't a deletion watch — it's being monitored for recovery (/unban).\nTo stop that, use:  /clear ${parsed.username}`,
      );
      return;
    }
    await this.replyText(chatId, `ℹ️ @${parsed.username} is not being watched for deletion.`);
  }

  /**
   * /clients: monitored pages grouped by the client business chat they were started in.
   * Owner-only. Identity comes from the stored `clients` table (captured from business
   * messages); unknown ones are backfilled via getChat (best-effort). Pages started in the
   * owner's own DM (no client link) are grouped under "Direct".
   */
  private async handleClients(chatId: number, args: string): Promise<void> {
    const { repos, client, clock, logger } = this.deps;
    const page = Number.parseInt(args.trim(), 10);
    const cases = await repos.cases.listByStatuses(LISTED_STATUSES);
    const links = await repos.clientLinks.listAll();
    const chatByMonitor = new Map<string, number>();
    const bcidByChat = new Map<number, string>();
    for (const l of links) {
      chatByMonitor.set(l.monitorId, l.clientChatId);
      bcidByChat.set(l.clientChatId, l.businessConnectionId);
    }

    // Group active monitors by client chat; unlinked monitors -> "direct".
    const pagesByChat = new Map<number, string[]>();
    const direct: string[] = [];
    for (const c of cases) {
      const clientChatId = chatByMonitor.get(c.id);
      if (clientChatId === undefined) {
        direct.push(c.normalizedUsername);
      } else {
        const arr = pagesByChat.get(clientChatId) ?? [];
        arr.push(c.normalizedUsername);
        pagesByChat.set(clientChatId, arr);
      }
    }

    // Identities we already have (incl. null "attempted" markers). Only chats with NO row get
    // a getChat attempt; the attempt is upserted (even a miss, as a null marker) so a failed
    // lookup is NOT retried on every /clients — auto-capture from business messages fills it
    // later. Backfills run in PARALLEL so one slow/unreachable client can't block the rest.
    const stored = new Map<number, ClientIdentity>();
    for (const c of await repos.clients.listAll()) stored.set(c.clientChatId, c);
    const unknown = [...pagesByChat.keys()].filter((c) => !stored.has(c));
    const nowIso = clock.now().toISOString();
    await Promise.all(
      unknown.map(async (clientChatId) => {
        try {
          const info = await client.getChat(clientChatId);
          const identity: ClientIdentity = {
            clientChatId,
            businessConnectionId: bcidByChat.get(clientChatId) ?? null,
            username: info?.username ?? null,
            firstName: info?.first_name ?? null,
            lastName: info?.last_name ?? null,
            updatedAtUtc: nowIso,
          };
          await repos.clients.upsert(identity, nowIso);
          stored.set(clientChatId, identity);
        } catch (err) {
          logger.warn('clients: getChat backfill failed', {
            error: err instanceof Error ? err.message : String(err),
          });
        }
      }),
    );

    const groups: ClientGroup[] = [...pagesByChat.entries()].map(([clientChatId, pages]) => ({
      clientChatId,
      identity: stored.get(clientChatId) ?? null,
      pages,
    }));

    await this.reply(chatId, clientsView(groups, direct, Number.isNaN(page) ? 1 : page));
  }

  /**
   * /proxy [home|mobile] — show or switch where Instagram traffic exits.
   *
   *   direct (alias: home) = this machine's own connection
   *   mobile               = the configured proxy (BROWSER_PROXY_*)
   *
   * Takes effect on the next check: the browser relaunches and the HTTP dispatcher is rebuilt.
   * Credentials are never echoed — only host:port.
   *
   * This handler deliberately owns almost nothing. Parsing, switching, VERIFYING the new route
   * against the control account, the auto-revert decision and the wording all live in
   * {@link switchEgressRoute} / {@link egressSwitchResult}, shared verbatim with the Discord
   * surface — the two must never be able to disagree about what happened or how loudly to say it.
   */
  private async handleProxy(chatId: number, args: string): Promise<void> {
    const { proxySwitch, logger, config } = this.deps;
    if (proxySwitch === undefined) {
      await this.replyText(chatId, 'ℹ️ Egress switching is not enabled on this instance.');
      return;
    }
    const want = args.trim();

    if (want === '') {
      await this.reply(
        chatId,
        egressStatus({
          current: proxySwitch.describe(),
          configured: proxySwitch.state().configured,
        }),
      );
      return;
    }

    const route = parseEgressRoute(want);
    if (route === null) {
      await this.replyText(chatId, 'Usage: /proxy home  |  /proxy vps');
      return;
    }

    const outcome = await switchEgressRoute(route, {
      proxySwitch,
      detector: this.deps.detector,
      logger,
    });
    await this.reply(chatId, egressSwitchResult(outcome, config.controlUsername));
  }

  /** Genuine end-to-end health check via the SAME injected detector as the monitor. */
  private async handlePing(chatId: number): Promise<void> {
    const { clock, config, detector, db, repos, logger } = this.deps;

    const t0 = clock.nowMs();
    // Ask the detector about its OWN fast tier instead of probing through it.
    //
    // A second `detector.probe()` could not answer the question: the tiered detector returns the
    // BROWSER's verdict on every fast-tier failure, so a dead fast tier still classified the
    // (live) control account ACTIVE and printed "Fast probe: Working". Worse, that probe matched
    // identity and escalated, so /ping cost TWO full Chromium loads and recorded two breaker
    // outcomes — halving how many /pings the ~200 page-loads/hour egress budget allows. The
    // report costs at most one cheap HTTP request, so /ping is back to a single browser load.
    const diagnostics = detectorDiagnostics(detector);
    let fast: FastTierReport | null = null;
    if (diagnostics !== null) {
      try {
        fast = await diagnostics.fastTierReport();
      } catch (err) {
        logger.warn('ping fast-tier report threw', {
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }

    let classification: Classification = 'UNKNOWN';
    let screenshotCaptured = false;
    // Whether the ACTIVE control page was actually rendered (so a screenshot was genuinely
    // possible). Instagram frequently serves the control profile as a login redirect that still
    // carries the account's identity metadata: that classifies ACTIVE (correctly) but has no
    // visible profile to capture, so probe.screenshot is null BY DESIGN — not a broken subsystem.
    let pageRendered = false;
    try {
      const probe = await detector.probe(config.controlUsername, { captureScreenshot: true });
      classification = probe.result.classification;
      screenshotCaptured = probe.screenshot !== null && probe.screenshot.buffer.length > 0;
      const signals = probe.result.evidence.activeSignals;
      pageRendered =
        signals.includes(ACTIVE_SIGNALS.PROFILE_STRUCTURES_RENDERED) &&
        signals.includes(ACTIVE_SIGNALS.NOT_REDIRECTED_AWAY);
    } catch (err) {
      logger.warn('ping probe threw', {
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
    }
    const probeSeconds = (clock.nowMs() - t0) / 1000;

    const failures: string[] = [];
    if (classification !== 'ACTIVE') {
      failures.push(`Instagram detector: ${classification}`);
    }
    // A degraded fast tier still detects correctly (the browser answers everything), but it is an
    // operational emergency on a ~200 page-loads/hour budget: every routine check silently becomes
    // a full browser load. Reporting "healthy" here is how it stays unnoticed until the IP burns.
    if (fast !== null && fast.state === 'degraded') {
      failures.push(fastTierLine(fast.state, fast.detail, fast.answered));
    }
    // Routine polling being DEFERRED is not a fault — the governor is doing exactly its job — but
    // it is never allowed to be silent: the fleet is checking less often than the owner configured,
    // and that has to be visible without having to notice slow alerts.
    const budget = fast?.browserBudget ?? null;
    if (budget !== null && budget.deferred > 0) {
      failures.push(`Browser-load budget: ${budget.reason}`);
    }
    if (fast !== null && fast.state === 'blocked') {
      const retrySeconds = Math.round(fast.breakerRetryAfterMs / 1000);
      failures.push(
        `Egress back-off: ${fast.detail}${retrySeconds > 0 ? ` — retrying in ${retrySeconds}s` : ''}`,
      );
    }
    // A missing screenshot is only a genuine fault when the control page actually rendered but
    // capture still produced nothing. A login-gated control page legitimately yields no
    // screenshot; the capture mechanism is fine and real (rendered) profiles still capture.
    if (classification === 'ACTIVE' && pageRendered && !screenshotCaptured) {
      failures.push('Screenshot capture');
    }

    let dbOk = false;
    try {
      dbOk = await db.ping();
    } catch {
      dbOk = false;
    }
    if (!dbOk) {
      failures.push('Database');
    }

    const health = await repos.health.get(HEALTH_SCHEDULER_KEY);
    const staleAfterMs = (2 * config.scheduling.baselineIntervalSeconds + 60) * 1000;
    const lastRun = health?.lastSchedulerRunUtc ?? null;
    if (lastRun === null || clock.nowMs() - new Date(lastRun).getTime() > staleAfterMs) {
      failures.push('Scheduler');
    }

    const activeCount = await repos.cases.countByStatuses(ACTIVE_STATUSES);

    if (failures.length === 0) {
      // Healthy: report screenshot honestly — captured, or "limited" when the control page is
      // login-gated (expected; live profiles still capture). Either way the system is healthy.
      await this.reply(
        chatId,
        pingHealthy({
          accounts: activeCount,
          probeSeconds,
          screenshot: screenshotCaptured ? 'working' : 'limited',
          // Omit the keys entirely when there is no fast tier to report on — exactOptionalPropertyTypes
          // forbids passing `undefined` to an optional property. `answered` goes with it: without
          // the tier split, "Fast probe: Working" is a claim about the control account only.
          ...(fast !== null
            ? {
                fastTier: { state: fast.state, detail: fast.detail, answered: fast.answered },
                canaryHealthy: fast.canaryHealthy,
              }
            : {}),
          ...(budget !== null ? { browserBudget: budgetLine(budget, config) } : {}),
        }),
      );
    } else {
      await this.reply(
        chatId,
        pingUnhealthy(
          failures,
          budget !== null ? browserBudgetLines(budgetLine(budget, config)) : [],
        ),
      );
    }
  }

  private async reply(chatId: number, message: FormattedMessage): Promise<void> {
    const params: SendMessageParams = { chat_id: chatId, text: message.text };
    if (message.replyMarkup) {
      params.reply_markup = message.replyMarkup;
    }
    await this.deps.client.sendMessage(params);
  }

  private async replyText(chatId: number, text: string): Promise<void> {
    await this.reply(chatId, { text });
  }

  /** Generic failure reply, sent only to the paired owner and never allowed to throw. */
  private async bestEffortErrorReply(message: TelegramMessage | undefined): Promise<void> {
    try {
      if (
        message !== undefined &&
        message.chat.type === 'private' &&
        message.from !== undefined &&
        (await this.deps.auth.isOwner(message.from.id))
      ) {
        await this.replyText(message.chat.id, 'Something went wrong. Please try again.');
      }
    } catch {
      // Best effort only — the original error has already been logged.
    }
  }
}
