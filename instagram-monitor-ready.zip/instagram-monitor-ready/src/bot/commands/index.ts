/** Barrel for the Telegram command layer. */

export { CommandRouter } from './router';
export type { CommandDeps } from './router';
export { parseCommand } from './parse';
