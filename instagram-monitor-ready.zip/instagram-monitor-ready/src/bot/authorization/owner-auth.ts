/**
 * Owner pairing and authorization. The bot serves exactly one owner: the first user
 * to present the correct pairing secret. The secret is single-use — once an owner is
 * stored it never pairs anyone again, even with the correct code.
 */

import { createHash, timingSafeEqual } from 'node:crypto';

import type { OwnerRepository } from '../../domain';
import type { Logger } from '../../logging';

export type PairingOutcome =
  | 'paired'
  | 'already_paired'
  | 'invalid'
  | 'throttled'
  /** No secret was supplied at all — a bare `/start`. Never counted as a guess. */
  | 'no_secret';

export interface OwnerAuthorizerOptions {
  owner: OwnerRepository;
  pairingSecret: string;
  logger: Logger;
  /** Injectable clock for deterministic throttle tests. */
  now?: () => number;
}

/**
 * Brute-force throttle for pairing.
 *
 * The window is small but real: while the bot is unclaimed, ANY Telegram user who finds it can
 * guess `/start <secret>` unlimited times. Guessing the secret hands over full owner access —
 * including `/clients`, which lists client identities. Attempts are counted globally as well as
 * per user: the global window is what TRIGGERS the reserve lane, so rotating Telegram accounts
 * still slow every guesser down, while the lane itself is metered per user (below).
 *
 * Counters are in-memory and per-process, so a restart also clears them — that is the documented
 * operator escape hatch, but it must never be the ONLY one (see the reserve lane below).
 */
const MAX_ATTEMPTS_PER_USER = 5;
const MAX_ATTEMPTS_GLOBAL = 20;
/** How long a lockout lasts, and the window over which attempts accumulate. */
const LOCKOUT_MS = 15 * 60 * 1000;
/**
 * Once the global budget is spent the limiter does NOT hard-deny — it drops into a reserve lane
 * that spaces each CALLER's attempts by this interval.
 *
 * A hard global deny is a trivial denial of service: 20 messages every 15 minutes from throwaway
 * accounts would keep the real owner permanently unable to pair. A SHARED global admission is no
 * better — whoever polls fastest takes it every time, and a refused poll costs the attacker
 * nothing, so a script polling every second consumes every admission forever while the owner,
 * holding the correct secret, is told "pairing failed" indefinitely.
 *
 * So the reserve is keyed per user. The owner's route back cannot be consumed by anyone else:
 * an id with no recent failed guess of its own is admitted immediately. The price is that the
 * aggregate guess rate now scales with the number of distinct Telegram accounts an attacker
 * controls — each still capped at {@link MAX_ATTEMPTS_PER_USER} per window and spaced by this
 * interval. That is unavoidable: the limiter cannot tell the owner from an attacker before the
 * secret is compared, so any bound it shares between them is a bound the attacker can take.
 */
const RESERVE_INTERVAL_MS = 60 * 1000;
/** Hard bound on tracked users, so a flood of distinct ids cannot grow the map without limit. */
const MAX_TRACKED_USERS = 5000;

function sha256(value: string): Buffer {
  return createHash('sha256').update(value, 'utf8').digest();
}

/** Constant-time secret comparison: hash both sides so lengths never leak. */
function secretsEqual(provided: string, expected: string): boolean {
  return timingSafeEqual(sha256(provided), sha256(expected));
}

export class OwnerAuthorizer {
  private readonly owner: OwnerRepository;
  private readonly pairingSecret: string;
  private readonly logger: Logger;
  private readonly now: () => number;
  /**
   * Failed attempts per user within the rolling window. `lastAtMs` is what the reserve lane
   * meters on, so a caller can only be delayed by their OWN previous guess.
   */
  private readonly attempts = new Map<
    number,
    { count: number; firstAtMs: number; lastAtMs: number }
  >();
  /** Timestamps of recent global failures — a true sliding window, not a fixed bucket. */
  private globalFailures: number[] = [];

  constructor(options: OwnerAuthorizerOptions) {
    this.owner = options.owner;
    this.pairingSecret = options.pairingSecret;
    this.logger = options.logger;
    this.now = options.now ?? Date.now;
  }

  /**
   * Is this user (or the bot as a whole) currently locked out of pairing? Windows expire, so a
   * legitimate owner who fat-fingers the code is only delayed, never permanently locked out.
   *
   * Nothing here is metered globally except the trigger: an attacker's traffic can make everyone
   * slower, but it can never consume the admission belonging to a specific caller. That is what
   * stops a fast-polling script from permanently starving the real owner.
   */
  private throttled(userId: number): boolean {
    const nowMs = this.now();
    this.sweep(nowMs);

    const entry = this.attempts.get(userId);
    if (entry !== undefined && entry.count >= MAX_ATTEMPTS_PER_USER) return true;

    if (this.globalFailures.length < MAX_ATTEMPTS_GLOBAL) return false;
    // Budget spent: space each caller's own guesses rather than denying outright. A caller with
    // no recent failure of its own — the owner arriving for the first time — is admitted now.
    return entry !== undefined && nowMs - entry.lastAtMs < RESERVE_INTERVAL_MS;
  }

  private recordFailure(userId: number): void {
    const nowMs = this.now();
    const entry = this.attempts.get(userId);
    if (entry === undefined) {
      this.evictIfFull();
      this.attempts.set(userId, { count: 1, firstAtMs: nowMs, lastAtMs: nowMs });
    } else {
      entry.count += 1;
      entry.lastAtMs = nowMs;
    }
    this.globalFailures.push(nowMs);
  }

  /**
   * Drop everything that has aged out of the window. Without this the per-user map grows for
   * every distinct Telegram id that ever messages an unclaimed bot.
   */
  private sweep(nowMs: number): void {
    const cutoff = nowMs - LOCKOUT_MS;
    if (this.globalFailures.length > 0 && this.globalFailures[0]! <= cutoff) {
      this.globalFailures = this.globalFailures.filter((at) => at > cutoff);
    }
    for (const [id, entry] of this.attempts) {
      if (entry.firstAtMs <= cutoff) this.attempts.delete(id);
    }
  }

  /**
   * Last-resort bound: if the map is still at capacity after a sweep, drop the oldest entry. That
   * user regains a fresh per-user budget and reserve clock, but reaching this point at all costs
   * an attacker {@link MAX_TRACKED_USERS} distinct real Telegram accounts inside one window —
   * memory is never allowed to grow without limit, which is the failure this actually prevents.
   */
  private evictIfFull(): void {
    if (this.attempts.size < MAX_TRACKED_USERS) return;
    let oldestId: number | null = null;
    let oldestAt = Number.POSITIVE_INFINITY;
    for (const [id, entry] of this.attempts) {
      if (entry.firstAtMs < oldestAt) {
        oldestAt = entry.firstAtMs;
        oldestId = id;
      }
    }
    if (oldestId !== null) this.attempts.delete(oldestId);
  }

  /** True when `userId` is the paired owner. */
  async isOwner(userId: number): Promise<boolean> {
    const ownerId = await this.owner.getOwnerTelegramId();
    return ownerId !== null && ownerId === userId;
  }

  /**
   * Attempt to pair `userId` with the provided secret. Once any owner exists the
   * secret never works again ('already_paired'). Wrong secret => 'invalid'.
   */
  async tryPair(userId: number, provided: string, nowIso: string): Promise<PairingOutcome> {
    const existing = await this.owner.getOwnerTelegramId();
    if (existing !== null) {
      return 'already_paired';
    }
    // A bare `/start` carries no guess, and Telegram sends one AUTOMATICALLY the moment anyone
    // opens the bot. Counting that as a failed attempt lets ordinary curiosity traffic spend the
    // brute-force budget and lock the real owner out of pairing. It is answered before the
    // throttle is consulted so it can neither be counted nor consume a reserve admission.
    if (provided.length === 0) {
      return 'no_secret';
    }
    // Throttle BEFORE comparing, so a locked-out attacker learns nothing about the secret.
    if (this.throttled(userId)) {
      this.logger.warn('pairing attempt throttled', { userId });
      return 'throttled';
    }
    if (!secretsEqual(provided, this.pairingSecret)) {
      this.recordFailure(userId);
      this.logger.warn('pairing attempt with invalid secret', { userId });
      return 'invalid';
    }
    const claimed = await this.owner.claimOwner(userId, nowIso);
    if (!claimed) {
      // Lost a race: someone else claimed ownership between the check and the write.
      return 'already_paired';
    }
    this.logger.info('owner paired', { userId });
    return 'paired';
  }
}
