/**
 * Discord integration entrypoint. Fully optional: {@link buildDiscordIntegration} returns null
 * unless a bot token is configured, so the rest of the app wires it in unconditionally and the
 * Telegram bot is never affected.
 *
 * Two independent capabilities:
 *  - {@link DiscordNotifier} — best-effort REST mirror of recovery/deletion/health alerts.
 *  - {@link DiscordGateway}  — owner slash commands over the gateway (at Telegram parity).
 */

import type { ChatInfo, Clock, Database, Detector, Repositories } from '../../domain';
import type { ProxySwitch } from '../../instagram/proxy-switch';
import type { AppConfig } from '../../config';
import type { Logger } from '../../logging';
import { DiscordNotifier } from './discord-notifier';
import { DiscordCommands } from './discord-commands';
import { DiscordGateway } from './discord-gateway';

export { DiscordNotifier } from './discord-notifier';
export type { DiscordImage } from './discord-notifier';

export interface DiscordIntegrationDeps {
  config: AppConfig;
  repos: Repositories;
  db: Database;
  detector: Detector;
  clock: Clock;
  logger: Logger;
  /** Best-effort Telegram getChat for /clients identity backfill. */
  getChat?: (chatId: number) => Promise<ChatInfo | null>;
  /** Shared runtime egress switch, so /proxy works from Discord too. */
  proxySwitch?: ProxySwitch;
}

export interface DiscordIntegration {
  /** Mirror used by the notification workers. */
  notifier: DiscordNotifier;
  /** Connect the gateway and register slash commands. */
  start(): Promise<void>;
  /** Disconnect the gateway. */
  stop(): Promise<void>;
}

/** Build the Discord integration, or null when no bot token is configured. */
export function buildDiscordIntegration(deps: DiscordIntegrationDeps): DiscordIntegration | null {
  const { config, repos, db, detector, clock, logger, getChat, proxySwitch } = deps;
  const dc = config.discord;
  if (dc.botToken === null) return null;

  const notifier = new DiscordNotifier({
    botToken: dc.botToken,
    channels: {
      unbans: dc.channels.unbans,
      deletions: dc.channels.deletions,
      status: dc.channels.status,
    },
    logger,
  });

  const commands = new DiscordCommands({
    repos,
    db,
    detector,
    config,
    clock,
    logger,
    ...(getChat ? { getChat } : {}),
    ...(proxySwitch ? { proxySwitch } : {}),
  });

  const gateway = new DiscordGateway({
    token: dc.botToken,
    ownerUserId: dc.ownerUserId,
    guildId: dc.guildId,
    commandsChannelId: dc.channels.commands,
    commands,
    notifier,
    logger,
  });

  return {
    notifier,
    start: () => gateway.start(),
    stop: () => gateway.stop(),
  };
}
