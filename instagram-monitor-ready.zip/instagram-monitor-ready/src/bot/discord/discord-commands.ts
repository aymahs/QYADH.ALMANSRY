/**
 * Discord owner command surface.
 *
 * This mirrors the Telegram command handlers (see `src/bot/commands/router.ts`) so Discord has
 * full command parity, but it is a SEPARATE implementation on purpose: the Telegram router is the
 * production-critical path and must not be touched. Parity is kept by reusing the exact same
 * repositories, detector, state machine, and message formatters — so the wording and behaviour
 * match without coupling the two transports.
 *
 * No `discord.js` import here: this layer is transport-neutral. The gateway adapts a discord.js
 * interaction into {@link DiscordCommandInvocation} + {@link DiscordResponder} and calls `execute`.
 */

import type {
  Classification,
  DetectorErrorCode,
  CaseStatus,
  ChatInfo,
  ClientIdentity,
  Clock,
  Database,
  Detector,
  Repositories,
} from '../../domain';
import { ACTIVE_SIGNALS, ACTIVE_STATUSES, LISTED_STATUSES, isAppError } from '../../domain';
import { parseBackdatedTimestamp, parseUsernameInput } from '../../core';
import type { MonitoredItem, MonitoredStatus, ClientGroup } from '../../notifications/formatter';
import {
  alreadyMonitoring,
  bulkMonitoringStarted,
  checkDiagnostic,
  monitoringStarted,
  monitoringStartedUnverified,
  monitoringRemoved,
  notFound,
  pingHealthy,
  pingUnhealthy,
  fastTierLine,
} from '../../notifications/formatter';
import { egressStatus, egressSwitchResult } from '../../notifications/formatter/messages';
import { listEmbed, clientsEmbed, banlistEmbed, type DiscordEmbed } from './discord-embeds';
import { schedulingParamsFrom } from '../../monitoring/scheduler';
import { applyCheckResult } from '../../monitoring/state-machine';
import type { AppConfig } from '../../config';
import type { Logger } from '../../logging';
import type { ProxySwitch } from '../../instagram/proxy-switch';
// Shared with the Telegram router, not reimplemented: two copies of "is this route blind?" would
// drift, and the answer is what stands between a client and a recovery nobody notices.
import { parseEgressRoute, switchEgressRoute } from '../../instagram/proxy-switch';
import { detectorDiagnostics } from '../../instagram/detector/tiered-detector';
import type { FastTierReport } from '../../instagram/detector/tiered-detector';
// The pre-check bounds are shared with the Telegram router rather than reimplemented: they are
// what stop a 50-account burst from burning the egress budget, and two copies would drift.
import {
  BULK_MAX,
  runBulkPrecheck,
  runUnbanPrecheck,
  type BulkPrecheckLimits,
} from '../commands/router';

const HEALTH_SCHEDULER_KEY = 'scheduler';
const CHECK_COOLDOWN_MS = 15_000;

/** A slash-command option, described transport-neutrally (mapped to discord.js in the gateway). */
export interface DiscordCommandOption {
  name: string;
  description: string;
  type: 'string' | 'integer';
  required?: boolean;
}

/** A slash-command definition used both for registration and dispatch. */
export interface DiscordCommandSpec {
  name: string;
  description: string;
  options?: DiscordCommandOption[];
}

/** The owner command surface, at parity with the Telegram visible commands. */
export const DISCORD_COMMAND_SPECS: DiscordCommandSpec[] = [
  {
    name: 'unban',
    description: 'Monitor an Instagram username until it is publicly active again',
    options: [
      {
        name: 'username',
        description: 'Instagram username or profile URL',
        type: 'string',
        required: true,
      },
      {
        name: 'start',
        description: 'Optional backdated start (YYYY-MM-DD HH:MM, IST)',
        type: 'string',
      },
    ],
  },
  {
    name: 'bulkunban',
    description: 'Start monitoring many usernames at once (space/comma separated)',
    options: [
      {
        name: 'usernames',
        description: 'Usernames separated by spaces or commas',
        type: 'string',
        required: true,
      },
    ],
  },
  {
    name: 'check',
    description: 'One-off live check: is this account active right now?',
    options: [
      {
        name: 'username',
        description: 'Instagram username or profile URL',
        type: 'string',
        required: true,
      },
    ],
  },
  {
    name: 'list',
    description: 'Show accounts currently being monitored',
  },
  {
    name: 'clear',
    description: 'Stop monitoring an account (recovery watch)',
    options: [
      {
        name: 'username',
        description: 'Instagram username or profile URL',
        type: 'string',
        required: true,
      },
    ],
  },
  { name: 'ping', description: 'Test that the monitoring system is healthy' },
  {
    name: 'ban',
    description: 'Watch a currently-active account for deletion (ACTIVE → gone)',
    options: [
      {
        name: 'username',
        description: 'Instagram username or profile URL',
        type: 'string',
        required: true,
      },
    ],
  },
  { name: 'banlist', description: 'Show accounts currently watched for deletion' },
  {
    name: 'unwatch',
    description: 'Stop a deletion watch',
    options: [
      {
        name: 'username',
        description: 'Instagram username or profile URL',
        type: 'string',
        required: true,
      },
    ],
  },
  {
    name: 'clients',
    description: 'List clients and the pages monitored in each chat',
  },
  {
    name: 'proxy',
    description: 'Show or switch the egress route',
    options: [
      {
        name: 'route',
        description: 'direct = this machine’s own connection, mobile = the configured proxy',
        type: 'string',
      },
    ],
  },
];

/** Everything a command needs. Transport-neutral — no discord.js types. */
export interface DiscordCommandDeps {
  repos: Repositories;
  db: Database;
  detector: Detector;
  config: AppConfig;
  clock: Clock;
  logger: Logger;
  /** Best-effort Telegram getChat, for /clients identity backfill. Optional. */
  getChat?: (chatId: number) => Promise<ChatInfo | null>;
  /** Runtime egress switch, shared with the Telegram router so both see one state. */
  proxySwitch?: ProxySwitch;
  /** Overrides for the /bulkunban pre-check bounds. Tests only. */
  bulkPrecheckLimits?: Partial<BulkPrecheckLimits>;
}

/** One invocation's inputs (the gateway pulls these from the discord.js interaction). */
export interface DiscordCommandInvocation {
  name: string;
  /** Discord user id of the caller — used as the /check rate-limit key. */
  userId: string;
  getString(name: string): string | null;
  getInteger(name: string): number | null;
}

/** Sink for a command's reply. The gateway binds this to the deferred interaction. */
export interface DiscordResponder {
  /** The primary textual result (edits the deferred reply). */
  reply(text: string): Promise<void>;
  /** Reply with a rich embed (the single-message look for list-style commands). */
  replyEmbed(embed: DiscordEmbed): Promise<void>;
  /** A follow-up image (e.g. the /check screenshot). */
  sendPhoto(buffer: Buffer, caption: string): Promise<void>;
}

function isListedStatus(status: CaseStatus): status is MonitoredStatus {
  return (
    status === 'MONITORING' ||
    status === 'CONFIRMING' ||
    status === 'ERROR_BACKOFF' ||
    status === 'UNKNOWN_BACKOFF'
  );
}

export class DiscordCommands {
  /** Per-user cooldown for the browser-heavy /check, mirroring the Telegram rate limit. */
  private readonly lastCheck = new Map<string, number>();

  constructor(private readonly deps: DiscordCommandDeps) {}

  /** Dispatch one owner command. The caller (gateway) has already deferred the reply. */
  async execute(input: DiscordCommandInvocation, res: DiscordResponder): Promise<void> {
    switch (input.name) {
      case 'unban':
        return this.unban(input, res);
      case 'bulkunban':
        return this.bulkunban(input, res);
      case 'check':
        return this.check(input, res);
      case 'list':
        return this.list(res);
      case 'clear':
        return this.clear(input, res);
      case 'ping':
        return this.ping(res);
      case 'ban':
        return this.ban(input, res);
      case 'banlist':
        return this.banlist(res);
      case 'unwatch':
        return this.unwatch(input, res);
      case 'clients':
        return this.clients(res);
      case 'proxy':
        return this.proxy(input, res);
      default:
        await res.reply('Unknown command.');
        return;
    }
  }

  private async unban(input: DiscordCommandInvocation, res: DiscordResponder): Promise<void> {
    const { repos, config, clock, detector, logger } = this.deps;
    const usernameToken = (input.getString('username') ?? '').trim();
    const timestampText = (input.getString('start') ?? '').trim();

    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await res.reply(parsed.error);
      return;
    }
    const username = parsed.username;
    if (username === config.controlUsername) {
      await res.reply(
        `ℹ️ @${username} is the control account used for health checks and cannot be monitored.`,
      );
      return;
    }

    const now = clock.now();
    const nowIso = now.toISOString();
    const existing = await repos.cases.findActiveByNormalizedUsername(username);
    if (existing !== null) {
      await res.reply(alreadyMonitoring(username, existing.startedAtUtc, now).text);
      return;
    }

    let startedAtUtc = nowIso;
    if (timestampText.length > 0) {
      const back = parseBackdatedTimestamp(timestampText, config.displayTimezone, now);
      if ('error' in back) {
        await res.reply(back.error);
        return;
      }
      startedAtUtc = back.iso;
    }

    // Same live pre-check as the Telegram surfaces — literally the same function, so the
    // judgement cannot drift. Monitoring an already-active account would confirm ACTIVE 3x within
    // a minute and fire a false "ACCOUNT UNBANNED" alert for an account that was never banned. An
    // inconclusive result still starts monitoring — never refuse on a transient failure — but it
    // is reported as NOT pre-checked, at the same wording as Telegram.
    const precheck = await runUnbanPrecheck(username, {
      detector,
      logger,
      logLabel: 'discord unban',
    });
    if (precheck.verdict === 'active') {
      await res.reply(
        `✅ @${username} is ALREADY ACTIVE on Instagram — there is nothing to recover, so no monitor was started.\n\n` +
          `If you want to be told when it goes DOWN, use \`/ban ${username}\`.`,
      );
      return;
    }

    try {
      const created = await repos.cases.create(
        {
          normalizedUsername: username,
          originalInput: usernameToken,
          startedAtUtc,
          nextCheckAtUtc: nowIso,
        },
        nowIso,
      );
      await res.reply(
        (precheck.verdict === 'unverified'
          ? monitoringStartedUnverified(
              username,
              created.startedAtUtc,
              config.displayTimezone,
              precheck.reason,
            )
          : monitoringStarted(username, created.startedAtUtc, config.displayTimezone)
        ).text,
      );
    } catch (err) {
      if (isAppError(err) && err.code === 'DUPLICATE_CASE') {
        const raced = await repos.cases.findActiveByNormalizedUsername(username);
        await res.reply(alreadyMonitoring(username, raced?.startedAtUtc ?? startedAtUtc, now).text);
        return;
      }
      throw err;
    }
  }

  /**
   * Acknowledges first, then pre-checks under {@link runBulkPrecheck}'s bounds.
   *
   * The deadline there is what keeps the summary deliverable: an unbounded batch could outlive
   * Discord's 15-minute interaction token, and the owner would then get NO summary at all — no
   * record of what was enrolled, what was skipped, or what was never checked.
   */
  private async bulkunban(input: DiscordCommandInvocation, res: DiscordResponder): Promise<void> {
    const { repos, config, clock, logger, detector } = this.deps;
    const tokens = (input.getString('usernames') ?? '')
      .split(/[\s,]+/)
      .map((t) => t.trim())
      .filter((t) => t.length > 0);
    if (tokens.length === 0) {
      await res.reply('Usage: /bulkunban user1 user2 user3 …  (space or comma separated)');
      return;
    }
    const capped = tokens.slice(0, BULK_MAX);
    const nowIso = clock.now().toISOString();

    const started: string[] = [];
    const already: string[] = [];
    const alreadyLive: string[] = [];
    const unverified: string[] = [];
    const invalid: string[] = [];
    const failed: string[] = [];
    const seen = new Set<string>();
    const candidates: { token: string; username: string }[] = [];

    for (const token of capped) {
      const parsed = parseUsernameInput(token);
      if ('error' in parsed || parsed.username === config.controlUsername) {
        invalid.push(token);
        continue;
      }
      if (seen.has(parsed.username)) continue;
      seen.add(parsed.username);
      candidates.push({ token, username: parsed.username });
    }

    await res.reply(
      `🔎 Checking ${candidates.length} account${candidates.length === 1 ? '' : 's'} before monitoring…`,
    );

    const toProbe: { token: string; username: string }[] = [];
    for (const candidate of candidates) {
      try {
        if ((await repos.cases.findActiveByNormalizedUsername(candidate.username)) !== null) {
          already.push(candidate.username);
          continue;
        }
        toProbe.push(candidate);
      } catch (err) {
        failed.push(candidate.username);
        logger.warn('discord bulkunban: lookup failed', {
          username: candidate.username,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }

    const precheck = await runBulkPrecheck(
      toProbe.map((c) => c.username),
      {
        detector,
        logger,
        ...(this.deps.bulkPrecheckLimits !== undefined
          ? { limits: this.deps.bulkPrecheckLimits }
          : {}),
      },
    );

    for (const candidate of toProbe) {
      const verdict = precheck.verdicts.get(candidate.username) ?? 'unverified';
      if (verdict === 'active') {
        alreadyLive.push(candidate.username);
        continue;
      }
      try {
        await repos.cases.create(
          {
            normalizedUsername: candidate.username,
            originalInput: candidate.token,
            startedAtUtc: nowIso,
            nextCheckAtUtc: nowIso,
          },
          nowIso,
        );
        // Unverified accounts are still enrolled, but reported apart from the verified ones —
        // never let the owner believe an unchecked account was checked.
        (verdict === 'not-active' ? started : unverified).push(candidate.username);
      } catch (err) {
        if (isAppError(err) && err.code === 'DUPLICATE_CASE') {
          already.push(candidate.username);
        } else {
          failed.push(candidate.username);
          logger.warn('discord bulkunban: failed to process username', {
            username: candidate.username,
            error: err instanceof Error ? err.message : String(err),
          });
        }
      }
    }

    await res.reply(
      bulkMonitoringStarted({
        started,
        already,
        alreadyLive,
        unverified,
        ...(precheck.stoppedReason !== null ? { unverifiedReason: precheck.stoppedReason } : {}),
        invalid,
        failed,
        truncated: tokens.length > BULK_MAX,
      }).text,
    );
  }

  private async check(input: DiscordCommandInvocation, res: DiscordResponder): Promise<void> {
    const { detector, logger, repos, clock, config } = this.deps;
    const usernameToken = (input.getString('username') ?? '').trim().split(/\s+/, 1)[0] ?? '';
    if (usernameToken.length === 0) {
      await res.reply('Usage: /check <username>');
      return;
    }
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await res.reply(parsed.error);
      return;
    }
    const username = parsed.username;
    const nowMs = clock.nowMs();
    const last = this.lastCheck.get(input.userId);
    if (last !== undefined && nowMs - last < CHECK_COOLDOWN_MS) {
      await res.reply('Please wait a few seconds before another /check.');
      return;
    }
    this.lastCheck.set(input.userId, nowMs);

    let classification: Classification = 'UNKNOWN';
    let errorCode: DetectorErrorCode | null = null;
    let screenshotOk = false;
    let screenshotBuffer: Buffer | null = null;
    let profileMatch = false;
    let unavailable = false;
    let action = 'No monitoring state changed';
    let durationMs = 0;
    try {
      const probe = await detector.probe(username, { captureScreenshot: true });
      classification = probe.result.classification;
      errorCode = probe.result.evidence.errorCode;
      durationMs = probe.result.durationMs;
      profileMatch = probe.result.evidence.identitySignalMatched;
      unavailable = probe.result.evidence.goneSignals.length > 0;
      screenshotOk = probe.screenshot !== null && probe.screenshot.buffer.length > 0;
      screenshotBuffer = screenshotOk ? (probe.screenshot?.buffer ?? null) : null;

      const existing = await repos.cases.findActiveByNormalizedUsername(username);
      if (classification === 'ACTIVE' && existing !== null && existing.status !== 'CONFIRMING') {
        const now = clock.now();
        const activeCount = await repos.cases.countByStatuses(ACTIVE_STATUSES);
        const transition = applyCheckResult({
          current: existing,
          classification,
          now,
          params: { ...schedulingParamsFrom(config), activeCount, unknownThreshold: 3 },
        });
        await repos.checks.insert({
          caseId: existing.id,
          checkedAtUtc: now.toISOString(),
          classification,
          finalUrl: probe.result.evidence.finalUrl,
          responseStatus: probe.result.evidence.responseStatus,
          durationMs,
          activeSignals: probe.result.evidence.activeSignals,
          goneSignals: probe.result.evidence.goneSignals,
          errorCode,
          confirmationSeq: 1,
        });
        // Compare-and-save guard: no job lease is held here, so re-read right before saving and
        // drop the write if a /clear (or the scheduler) changed the case in the meantime.
        const fresh = await repos.cases.findById(existing.id);
        if (fresh !== null && fresh.status === existing.status && fresh.clearedAtUtc === null) {
          await repos.cases.save(transition.next);
          action =
            transition.next.status === 'CONFIRMING'
              ? 'Confirmation 1/3 started'
              : 'Monitor updated';
        } else {
          action = 'No monitoring state changed';
        }
      } else if (classification === 'ACTIVE' && existing?.status === 'CONFIRMING') {
        action = `Confirmation ${existing.confirmationCount}/3 remains scheduled`;
      }
    } catch (err) {
      logger.warn('discord check probe threw', {
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
    }

    await res.reply(
      checkDiagnostic({
        username,
        classification,
        profileMatch,
        unavailable,
        loginWall: errorCode === 'LOGIN_WALL',
        screenshotOk,
        durationMs,
        action:
          classification === 'UNKNOWN' && errorCode !== null
            ? `No monitoring state changed (${errorCode})`
            : action,
      }).text,
    );

    if (screenshotBuffer !== null) {
      // Best-effort, mirroring the Telegram handler: a screenshot-send failure must never fail
      // the command — the diagnostic already succeeded and a state change may have been persisted.
      try {
        await res.sendPhoto(screenshotBuffer, `📸 @${username} — live check`);
      } catch (err) {
        this.deps.logger.warn('discord check: failed to send screenshot', {
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
  }

  private async list(res: DiscordResponder): Promise<void> {
    const { repos, clock } = this.deps;
    const cases = await repos.cases.listByStatuses(LISTED_STATUSES);
    const sorted = [...cases].sort((a, b) => a.startedAtUtc.localeCompare(b.startedAtUtc));
    const items: MonitoredItem[] = [];
    for (const c of sorted) {
      if (isListedStatus(c.status)) {
        items.push({
          username: c.normalizedUsername,
          status: c.status,
          confirmationCount: c.confirmationCount,
          startedIso: c.startedAtUtc,
          lastResult: c.lastResult,
          consecutiveUnknownCount: c.consecutiveUnknownCount,
          nextCheckAtIso: c.nextCheckAtUtc,
          lastCheckedAtIso: c.lastCheckedAtUtc,
        });
      }
    }
    await res.replyEmbed(listEmbed(items, clock.now()));
  }

  private async clear(input: DiscordCommandInvocation, res: DiscordResponder): Promise<void> {
    const { repos, clock } = this.deps;
    const usernameToken = (input.getString('username') ?? '').trim().split(/\s+/, 1)[0] ?? '';
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await res.reply(parsed.error);
      return;
    }
    const cleared = await repos.cases.clearByNormalizedUsername(
      parsed.username,
      clock.now().toISOString(),
    );
    if (cleared !== null) {
      await res.reply(monitoringRemoved(parsed.username).text);
      return;
    }
    const watch = await repos.deletionWatches.findActiveByNormalizedUsername(parsed.username);
    if (watch !== null) {
      await res.reply(
        `ℹ️ @${parsed.username} isn't a recovery monitor — it's a deletion watch (/ban).\nTo stop that, use:  /unwatch ${parsed.username}`,
      );
      return;
    }
    await res.reply(notFound(parsed.username).text);
  }

  private async ping(res: DiscordResponder): Promise<void> {
    const { clock, config, detector, db, repos, logger } = this.deps;

    const t0 = clock.nowMs();
    // Mirrors the Telegram /ping: ask the detector about its own fast tier rather than probing
    // through it. A probe cannot see a fast-tier failure — the tiered detector answers with the
    // browser's verdict either way — and it would cost a second full browser page load.
    const diagnostics = detectorDiagnostics(detector);
    let fast: FastTierReport | null = null;
    if (diagnostics !== null) {
      try {
        fast = await diagnostics.fastTierReport();
      } catch (err) {
        logger.warn('discord ping fast-tier report threw', {
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }

    let classification: Classification = 'UNKNOWN';
    let screenshotCaptured = false;
    let pageRendered = false;
    try {
      const probe = await detector.probe(config.controlUsername, { captureScreenshot: true });
      classification = probe.result.classification;
      screenshotCaptured = probe.screenshot !== null && probe.screenshot.buffer.length > 0;
      const signals = probe.result.evidence.activeSignals;
      pageRendered =
        signals.includes(ACTIVE_SIGNALS.PROFILE_STRUCTURES_RENDERED) &&
        signals.includes(ACTIVE_SIGNALS.NOT_REDIRECTED_AWAY);
    } catch (err) {
      logger.warn('discord ping probe threw', {
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
    }
    const probeSeconds = (clock.nowMs() - t0) / 1000;

    const failures: string[] = [];
    if (classification !== 'ACTIVE') {
      failures.push(`Instagram detector: ${classification}`);
    }
    if (fast !== null && fast.state === 'degraded') {
      failures.push(fastTierLine(fast.state, fast.detail, fast.answered));
    }
    if (fast !== null && fast.state === 'blocked') {
      const retrySeconds = Math.round(fast.breakerRetryAfterMs / 1000);
      failures.push(
        `Egress back-off: ${fast.detail}${retrySeconds > 0 ? ` — retrying in ${retrySeconds}s` : ''}`,
      );
    }
    if (classification === 'ACTIVE' && pageRendered && !screenshotCaptured) {
      failures.push('Screenshot capture');
    }

    let dbOk = false;
    try {
      dbOk = await db.ping();
    } catch {
      dbOk = false;
    }
    if (!dbOk) {
      failures.push('Database');
    }

    const health = await repos.health.get(HEALTH_SCHEDULER_KEY);
    const staleAfterMs = (2 * config.scheduling.baselineIntervalSeconds + 60) * 1000;
    const lastRun = health?.lastSchedulerRunUtc ?? null;
    if (lastRun === null || clock.nowMs() - new Date(lastRun).getTime() > staleAfterMs) {
      failures.push('Scheduler');
    }

    const activeCount = await repos.cases.countByStatuses(ACTIVE_STATUSES);

    if (failures.length === 0) {
      await res.reply(
        pingHealthy({
          accounts: activeCount,
          probeSeconds,
          screenshot: screenshotCaptured ? 'working' : 'limited',
          ...(fast !== null
            ? {
                fastTier: { state: fast.state, detail: fast.detail, answered: fast.answered },
                canaryHealthy: fast.canaryHealthy,
              }
            : {}),
        }).text,
      );
    } else {
      await res.reply(pingUnhealthy(failures).text);
    }
  }

  private async ban(input: DiscordCommandInvocation, res: DiscordResponder): Promise<void> {
    const { repos, config, clock, detector, logger } = this.deps;
    const usernameToken = (input.getString('username') ?? '').trim().split(/\s+/, 1)[0] ?? '';
    if (usernameToken.length === 0) {
      await res.reply('Usage: /ban <username>');
      return;
    }
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await res.reply(parsed.error);
      return;
    }
    const username = parsed.username;
    if (username === config.controlUsername) {
      await res.reply(`ℹ️ @${username} is the control account and cannot be watched.`);
      return;
    }
    const nowIso = clock.now().toISOString();
    const existing = await repos.deletionWatches.findActiveByNormalizedUsername(username);
    if (existing !== null) {
      await res.reply(`ℹ️ Already watching @${username} for deletion.`);
      return;
    }

    let classification: Classification = 'UNKNOWN';
    try {
      classification = (await detector.probe(username)).result.classification;
    } catch (err) {
      logger.warn('discord ban probe threw', {
        error: err instanceof Error ? err.message : String(err),
      });
    }
    if (classification === 'GONE') {
      await res.reply(
        `ℹ️ @${username} is already inactive/unavailable on Instagram — there's nothing to watch for deletion.`,
      );
      return;
    }
    if (classification !== 'ACTIVE') {
      await res.reply(
        `⚠️ Couldn't confirm @${username} is active right now (login wall or a temporary error). Try /ban again in a moment.`,
      );
      return;
    }

    try {
      await repos.deletionWatches.create(
        {
          normalizedUsername: username,
          originalInput: usernameToken,
          startedAtUtc: nowIso,
          nextCheckAtUtc: nowIso,
        },
        nowIso,
      );
    } catch (err) {
      if (isAppError(err) && err.code === 'DUPLICATE_CASE') {
        await res.reply(`ℹ️ Already watching @${username} for deletion.`);
        return;
      }
      throw err;
    }
    await res.reply(
      `🔎 DELETION WATCH STARTED\n\nInstagram: @${username}\nStatus: Watching (currently active)\n\nI'll alert you if it goes inactive, deleted, or banned.`,
    );
  }

  private async banlist(res: DiscordResponder): Promise<void> {
    const { repos, clock, config } = this.deps;
    const watches = await repos.deletionWatches.listActive();
    await res.replyEmbed(
      banlistEmbed(watches, config.scheduling.confirmationRequiredCount, clock.now()),
    );
  }

  private async unwatch(input: DiscordCommandInvocation, res: DiscordResponder): Promise<void> {
    const { repos, clock } = this.deps;
    const usernameToken = (input.getString('username') ?? '').trim().split(/\s+/, 1)[0] ?? '';
    const parsed = parseUsernameInput(usernameToken);
    if ('error' in parsed) {
      await res.reply(parsed.error);
      return;
    }
    const cleared = await repos.deletionWatches.clearByNormalizedUsername(
      parsed.username,
      clock.now().toISOString(),
    );
    if (cleared !== null) {
      await res.reply(`🗑 Stopped watching @${parsed.username} for deletion.`);
      return;
    }
    const recovery = await repos.cases.findActiveByNormalizedUsername(parsed.username);
    if (recovery !== null) {
      await res.reply(
        `ℹ️ @${parsed.username} isn't a deletion watch — it's being monitored for recovery (/unban).\nTo stop that, use:  /clear ${parsed.username}`,
      );
      return;
    }
    await res.reply(`ℹ️ @${parsed.username} is not being watched for deletion.`);
  }

  /**
   * /proxy [route] — show or switch where Instagram traffic exits. Shares one ProxySwitch with
   * the Telegram router, so switching on either platform moves both. Credentials never echoed.
   *
   * PARITY IS STRUCTURAL, not maintained by hand: the parse, the switch, the control-account
   * verification, the auto-revert decision and the wording are all the shared
   * {@link switchEgressRoute} / {@link egressSwitchResult} used by the Telegram router. Discord
   * gets the same plain text — including the same alarm when the fleet has gone blind, which is
   * the one message that must never be softer on one surface than on the other. (No Discord
   * markdown here for that reason; `/ping` already replies in the shared plain text too.)
   */
  private async proxy(input: DiscordCommandInvocation, res: DiscordResponder): Promise<void> {
    const { proxySwitch, logger, config } = this.deps;
    if (proxySwitch === undefined) {
      await res.reply('ℹ️ Egress switching is not enabled on this instance.');
      return;
    }
    const want = (input.getString('route') ?? '').trim();

    if (want === '') {
      await res.reply(
        egressStatus({
          current: proxySwitch.describe(),
          configured: proxySwitch.state().configured,
        }).text,
      );
      return;
    }

    const route = parseEgressRoute(want);
    if (route === null) {
      await res.reply('Usage: /proxy home  |  /proxy vps');
      return;
    }

    const outcome = await switchEgressRoute(route, {
      proxySwitch,
      detector: this.deps.detector,
      logger,
    });
    await res.reply(egressSwitchResult(outcome, config.controlUsername).text);
  }

  private async clients(res: DiscordResponder): Promise<void> {
    const { repos, clock, logger, getChat } = this.deps;
    const cases = await repos.cases.listByStatuses(LISTED_STATUSES);
    const links = await repos.clientLinks.listAll();
    const chatByMonitor = new Map<string, number>();
    const bcidByChat = new Map<number, string>();
    for (const l of links) {
      chatByMonitor.set(l.monitorId, l.clientChatId);
      bcidByChat.set(l.clientChatId, l.businessConnectionId);
    }

    const pagesByChat = new Map<number, string[]>();
    const direct: string[] = [];
    for (const c of cases) {
      const clientChatId = chatByMonitor.get(c.id);
      if (clientChatId === undefined) {
        direct.push(c.normalizedUsername);
      } else {
        const arr = pagesByChat.get(clientChatId) ?? [];
        arr.push(c.normalizedUsername);
        pagesByChat.set(clientChatId, arr);
      }
    }

    const stored = new Map<number, ClientIdentity>();
    for (const c of await repos.clients.listAll()) stored.set(c.clientChatId, c);
    const nowIso = clock.now().toISOString();
    // Identity backfill via Telegram getChat is best-effort and only runs when available. Discord
    // cannot query Telegram chats independently, so a total Telegram outage simply leaves unknown
    // clients labelled by id; auto-capture from business messages fills them in over time.
    if (getChat !== undefined) {
      const unknown = [...pagesByChat.keys()].filter((c) => !stored.has(c));
      await Promise.all(
        unknown.map(async (clientChatId) => {
          try {
            const info = await getChat(clientChatId);
            const identity: ClientIdentity = {
              clientChatId,
              businessConnectionId: bcidByChat.get(clientChatId) ?? null,
              username: info?.username ?? null,
              firstName: info?.first_name ?? null,
              lastName: info?.last_name ?? null,
              updatedAtUtc: nowIso,
            };
            await repos.clients.upsert(identity, nowIso);
            stored.set(clientChatId, identity);
          } catch (err) {
            logger.warn('discord clients: getChat backfill failed', {
              error: err instanceof Error ? err.message : String(err),
            });
          }
        }),
      );
    }

    const groups: ClientGroup[] = [...pagesByChat.entries()].map(([clientChatId, pages]) => ({
      clientChatId,
      identity: stored.get(clientChatId) ?? null,
      pages,
    }));

    await res.replyEmbed(clientsEmbed(groups, direct));
  }
}
