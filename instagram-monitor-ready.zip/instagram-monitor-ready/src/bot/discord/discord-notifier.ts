/**
 * Best-effort Discord notification mirror.
 *
 * Posts alerts to dedicated channels using the BOT TOKEN via the Discord REST API. This is
 * deliberately independent of the gateway (the command side): even if the gateway WebSocket is
 * reconnecting, REST posts still deliver. Every method is best-effort — it NEVER throws and NEVER
 * blocks the primary Telegram delivery. When a channel id is not configured the corresponding
 * call is a silent no-op, so the mirror is fully opt-in per channel.
 *
 * No `discord.js` import here on purpose: the notification workers depend on this type, and keeping
 * it dependency-free (plain `fetch`) means importing it never pulls the gateway library into their
 * module graph.
 */

import type { Logger } from '../../logging';
import { alertEmbed, EMBED_COLORS, type DiscordEmbed } from './discord-embeds';

const DEFAULT_TIMEOUT_MS = 15000;
const API_BASE = 'https://discord.com/api/v10';

export interface DiscordImage {
  buffer: Buffer;
  filename: string;
}

export interface DiscordChannelIds {
  unbans: string | null;
  deletions: string | null;
  status: string | null;
}

export interface DiscordNotifierOptions {
  botToken: string;
  channels: DiscordChannelIds;
  logger: Logger;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}

export class DiscordNotifier {
  private readonly botToken: string;
  private readonly channels: DiscordChannelIds;
  private readonly logger: Logger;
  private readonly fetchImpl: typeof fetch;
  private readonly timeoutMs: number;

  constructor(options: DiscordNotifierOptions) {
    this.botToken = options.botToken;
    this.channels = options.channels;
    this.logger = options.logger;
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  }

  /** Recovery alert (green, + optional screenshot inside the embed) → #unbans. */
  async unban(text: string, image?: DiscordImage): Promise<boolean> {
    return this.post(
      this.channels.unbans,
      alertEmbed(text, EMBED_COLORS.green, image?.filename),
      image,
    );
  }

  /** Deletion-confirmed alert (red) → #deletions. Returns true iff Discord accepted it. */
  async deletion(text: string): Promise<boolean> {
    return this.post(this.channels.deletions, alertEmbed(text, EMBED_COLORS.red));
  }

  /** Health / liveness alert (amber) → #status. Returns true iff Discord accepted it. */
  async status(text: string): Promise<boolean> {
    return this.post(this.channels.status, alertEmbed(text, EMBED_COLORS.amber));
  }

  /**
   * Post one embed (optionally with an image attachment the embed references) to a channel.
   * No-op (returns false) when the channel id is null. Never throws; returns true only when
   * Discord accepted the message (2xx), false on any failure.
   */
  private async post(
    channelId: string | null,
    embed: DiscordEmbed,
    image?: DiscordImage,
  ): Promise<boolean> {
    if (channelId === null) return false;
    const url = `${API_BASE}/channels/${channelId}/messages`;
    const payload = { embeds: [embed] };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const headers: Record<string, string> = { Authorization: `Bot ${this.botToken}` };
      let body: string | FormData;
      if (image !== undefined) {
        const form = new FormData();
        form.append('payload_json', JSON.stringify(payload));
        form.append('files[0]', new Blob([new Uint8Array(image.buffer)]), image.filename);
        body = form;
      } else {
        headers['Content-Type'] = 'application/json';
        body = JSON.stringify(payload);
      }
      const res = await this.fetchImpl(url, {
        method: 'POST',
        headers,
        body,
        signal: controller.signal,
      });
      if (!res.ok) {
        this.logger.warn('discord mirror: non-2xx response', { status: res.status });
        return false;
      }
      return true;
    } catch (err) {
      this.logger.warn('discord mirror: post failed', {
        error: err instanceof Error ? err.message : String(err),
      });
      return false;
    } finally {
      clearTimeout(timer);
    }
  }
}
