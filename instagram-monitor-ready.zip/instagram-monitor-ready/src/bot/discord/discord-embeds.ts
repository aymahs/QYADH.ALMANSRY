/**
 * Discord embed builders — the "rich", single-message look for list-style commands and the
 * colour-coded notification channels. Transport-neutral (no discord.js): the gateway sends these
 * as `embeds: [...]` and the REST notifier serialises them directly. Embeds allow ~4096 chars in
 * the description (vs 2000 for plain content), so a whole fleet fits in ONE message — no pagination.
 */

import type { MonitoredItem, ClientGroup } from '../../notifications/formatter';
import type { DeletionWatch } from '../../domain';

/** A Discord embed object (subset we use). Serialised straight to the Discord API shape. */
export interface DiscordEmbed {
  title?: string;
  description?: string;
  color?: number;
  image?: { url: string };
  footer?: { text: string };
  fields?: { name: string; value: string; inline?: boolean }[];
}

/** Discord brand-ish colours (decimal ints). */
export const EMBED_COLORS = {
  green: 0x57f287,
  red: 0xed4245,
  amber: 0xfee75c,
  blurple: 0x5865f2,
} as const;

const DESC_LIMIT = 4096;
const TITLE_LIMIT = 256;

export function clamp(text: string, max: number): string {
  return text.length > max ? text.slice(0, max - 1) + '…' : text;
}

/** Compact duration for dense lists: "2d 04h" / "4h 21m" / "21m 09s" / "9s". */
function compactDuration(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(s / 86400);
  const hours = Math.floor((s % 86400) / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;
  if (days > 0) return `${days}d ${String(hours).padStart(2, '0')}h`;
  if (hours > 0) return `${hours}h ${String(mins).padStart(2, '0')}m`;
  if (mins > 0) return `${mins}m ${String(secs).padStart(2, '0')}s`;
  return `${secs}s`;
}

function retryLabel(nextIso: string | null | undefined, now: Date): string {
  if (!nextIso) return 'retry pending';
  const delta = new Date(nextIso).getTime() - now.getTime();
  return delta <= 0 ? `overdue ${compactDuration(-delta)}` : `retry in ${compactDuration(delta)}`;
}

/** '@user (First Last)' / '@user' / 'First Last' / 'Client #id'. */
function clientLabel(g: ClientGroup): string {
  const id = g.identity;
  if (id !== null) {
    const name = [id.firstName, id.lastName]
      .filter((p): p is string => !!p)
      .join(' ')
      .trim();
    if (id.username !== null && name !== '') return `@${id.username} (${name})`;
    if (id.username !== null) return `@${id.username}`;
    if (name !== '') return name;
  }
  return `Client #${g.clientChatId}`;
}

/**
 * `/list` as ONE embed: every monitored page grouped by status, no pagination. Colour is green
 * when nothing is degraded, amber when any account is in backoff.
 */
export function listEmbed(items: MonitoredItem[], now: Date): DiscordEmbed {
  if (items.length === 0) {
    return {
      title: '👀 Monitored accounts',
      description: 'No Instagram accounts are currently being monitored.',
      color: EMBED_COLORS.blurple,
    };
  }
  const monitoring: string[] = [];
  const confirming: string[] = [];
  const backoff: string[] = [];
  for (const it of items) {
    const elapsed = compactDuration(now.getTime() - new Date(it.startedIso).getTime());
    if (it.status === 'CONFIRMING') {
      confirming.push(`\`@${it.username}\` · ${it.confirmationCount}/3 · ${elapsed}`);
    } else if (it.status === 'ERROR_BACKOFF' || it.status === 'UNKNOWN_BACKOFF') {
      const last = it.lastResult ? ` · ${it.lastResult}` : '';
      backoff.push(`\`@${it.username}\` · ${retryLabel(it.nextCheckAtIso, now)}${last}`);
    } else {
      monitoring.push(`\`@${it.username}\` · ${elapsed}`);
    }
  }
  const parts: string[] = [];
  if (monitoring.length)
    parts.push(`🟢 **Monitoring · ${monitoring.length}**\n${monitoring.join('\n')}`);
  if (confirming.length)
    parts.push(`🟡 **Confirming · ${confirming.length}**\n${confirming.join('\n')}`);
  if (backoff.length) parts.push(`🔴 **Backoff · ${backoff.length}**\n${backoff.join('\n')}`);
  return {
    title: `👀 Monitored accounts — ${items.length}`,
    description: clamp(parts.join('\n\n'), DESC_LIMIT),
    color: backoff.length > 0 ? EMBED_COLORS.amber : EMBED_COLORS.green,
  };
}

/** `/clients` as ONE embed: pages grouped by the client chat they were started in, plus Direct. */
export function clientsEmbed(groups: ClientGroup[], direct: string[]): DiscordEmbed {
  if (groups.length === 0 && direct.length === 0) {
    return {
      title: '👥 Clients',
      description: 'No monitored accounts yet.',
      color: EMBED_COLORS.blurple,
    };
  }
  const lines: string[] = [];
  for (const g of groups) {
    lines.push(`👤 **${clientLabel(g)}**`);
    for (const p of g.pages) lines.push(` \`@${p}\``);
    lines.push('');
  }
  if (direct.length > 0) {
    lines.push(`📥 **Direct (your DM) — ${direct.length}**`);
    for (const p of direct) lines.push(` \`@${p}\``);
  }
  return {
    title: `👥 Clients — ${groups.length}`,
    description: clamp(lines.join('\n').trim(), DESC_LIMIT),
    color: EMBED_COLORS.blurple,
  };
}

/** `/banlist` as ONE embed: every deletion watch, one line each. */
export function banlistEmbed(watches: DeletionWatch[], target: number, now: Date): DiscordEmbed {
  if (watches.length === 0) {
    return {
      title: '🚫 Deletion watches',
      description: 'No accounts are being watched for deletion.',
      color: EMBED_COLORS.red,
    };
  }
  const lines = watches.map((w) => {
    const status =
      w.status === 'CONFIRMING'
        ? `confirming ${w.confirmationCount}/${target}`
        : w.status === 'BACKOFF'
          ? 'retrying'
          : 'watching';
    const elapsed = compactDuration(now.getTime() - new Date(w.startedAtUtc).getTime());
    return `\`@${w.normalizedUsername}\` · ${status} · ${elapsed}`;
  });
  return {
    title: `🚫 Deletion watches — ${watches.length}`,
    description: clamp(lines.join('\n'), DESC_LIMIT),
    color: EMBED_COLORS.red,
  };
}

/**
 * Turn a pre-formatted alert (e.g. recoveryCaption) into a coloured embed: the first block
 * (up to the first blank line) becomes the title, the rest the description. Used by the
 * notification mirror so #unbans/#deletions/#status render as colour-coded cards.
 */
export function alertEmbed(text: string, color: number, imageFilename?: string): DiscordEmbed {
  const idx = text.indexOf('\n\n');
  const embed: DiscordEmbed = { color };
  if (idx === -1) {
    embed.description = clamp(text, DESC_LIMIT);
  } else {
    embed.title = clamp(text.slice(0, idx).trim(), TITLE_LIMIT);
    embed.description = clamp(text.slice(idx + 2).trim(), DESC_LIMIT);
  }
  if (imageFilename !== undefined) embed.image = { url: `attachment://${imageFilename}` };
  return embed;
}
