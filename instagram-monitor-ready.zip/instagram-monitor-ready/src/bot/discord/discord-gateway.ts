/**
 * Discord gateway: receives the owner's slash commands over a persistent WebSocket and dispatches
 * them to {@link DiscordCommands}. This is the ONLY file that imports `discord.js`.
 *
 * A home-hosted bot has no public HTTPS endpoint, so interactions arrive over the gateway (not an
 * HTTP interactions webhook). Slash commands are used (not message-content parsing), so no
 * privileged intents are required — only `Guilds`.
 *
 * Every command is owner-gated by Discord user id. The reply is deferred immediately (browser
 * probes take seconds, well past Discord's 3s ack deadline) and edited with the result.
 */

import {
  Client,
  Events,
  GatewayIntentBits,
  ApplicationCommandOptionType,
  MessageFlags,
  type ApplicationCommandDataResolvable,
  type ApplicationCommandOptionData,
} from 'discord.js';
import type { Logger } from '../../logging';
import type { DiscordNotifier } from './discord-notifier';
import {
  DISCORD_COMMAND_SPECS,
  type DiscordCommands,
  type DiscordCommandInvocation,
  type DiscordCommandSpec,
  type DiscordResponder,
} from './discord-commands';

/** Discord hard limit on message `content`. */
const CONTENT_LIMIT = 2000;

export interface DiscordGatewayOptions {
  token: string;
  ownerUserId: string | null;
  guildId: string | null;
  commandsChannelId: string | null;
  commands: DiscordCommands;
  notifier: DiscordNotifier;
  logger: Logger;
}

function clampContent(text: string): string {
  const trimmed = text.length === 0 ? '(no output)' : text;
  return trimmed.length > CONTENT_LIMIT ? trimmed.slice(0, CONTENT_LIMIT - 1) + '…' : trimmed;
}

function specToDiscord(spec: DiscordCommandSpec): ApplicationCommandDataResolvable {
  const options: ApplicationCommandOptionData[] = (spec.options ?? []).map((o) =>
    o.type === 'string'
      ? {
          name: o.name,
          description: o.description,
          type: ApplicationCommandOptionType.String,
          required: o.required ?? false,
        }
      : {
          name: o.name,
          description: o.description,
          type: ApplicationCommandOptionType.Integer,
          required: o.required ?? false,
        },
  );
  return { name: spec.name, description: spec.description, options };
}

export class DiscordGateway {
  private client: Client | null = null;

  constructor(private readonly opts: DiscordGatewayOptions) {}

  /** Connect and register slash commands. Best-effort: a login failure is logged, never thrown. */
  async start(): Promise<void> {
    const { token, logger } = this.opts;
    if (this.client !== null) return;
    if (this.opts.ownerUserId === null) {
      logger.warn('discord gateway: DISCORD_OWNER_USER_ID not set — every command will be refused');
    }

    const client = new Client({ intents: [GatewayIntentBits.Guilds] });
    this.client = client;

    client.once(Events.ClientReady, (ready) => {
      void this.onReady(ready).catch((err: unknown) => {
        logger.error('discord gateway: ready handler failed', {
          error: err instanceof Error ? err.message : String(err),
        });
      });
    });
    client.on(Events.InteractionCreate, (interaction) => {
      void this.onInteraction(interaction).catch((err: unknown) => {
        logger.error('discord gateway: interaction handler failed', {
          error: err instanceof Error ? err.message : String(err),
        });
      });
    });
    client.on(Events.Error, (err: Error) => {
      logger.warn('discord gateway: client error', { error: err.message });
    });

    try {
      await client.login(token);
    } catch (err) {
      logger.error('discord gateway: login failed — Discord disabled for this run', {
        error: err instanceof Error ? err.message : String(err),
      });
      this.client = null;
    }
  }

  /** Disconnect. Safe to call when never started. */
  async stop(): Promise<void> {
    const client = this.client;
    this.client = null;
    if (client !== null) {
      await client.destroy();
    }
  }

  private async onReady(ready: Client<true>): Promise<void> {
    const { guildId, logger, notifier } = this.opts;
    const data = DISCORD_COMMAND_SPECS.map(specToDiscord);
    try {
      if (guildId !== null) {
        await ready.application.commands.set(data, guildId);
      } else {
        await ready.application.commands.set(data);
      }
      logger.info('discord gateway: ready', {
        user: ready.user.tag,
        commands: data.length,
        scope: guildId !== null ? 'guild' : 'global',
      });
    } catch (err) {
      logger.error('discord gateway: command registration failed', {
        error: err instanceof Error ? err.message : String(err),
      });
    }
    await notifier.status(
      '🟢 Monitor connected to Discord — notification channels and slash commands are live.',
    );
  }

  private async onInteraction(interaction: unknown): Promise<void> {
    const { logger, ownerUserId, commandsChannelId, commands } = this.opts;
    // Narrow via the discord.js type guard.
    if (!isChatInputCommand(interaction)) return;

    // Owner gate: only the configured owner may run commands.
    if (ownerUserId === null || interaction.user.id !== ownerUserId) {
      const msg =
        ownerUserId === null
          ? '🚫 This bot has no owner configured. Set DISCORD_OWNER_USER_ID to your Discord user id.'
          : '🚫 Not authorized. This is a private bot.';
      await interaction
        .reply({ content: msg, flags: MessageFlags.Ephemeral })
        .catch(() => undefined);
      logger.warn('discord gateway: unauthorized command', {
        command: interaction.commandName,
        userId: interaction.user.id,
      });
      return;
    }

    // Optional: keep commands in the designated channel.
    if (commandsChannelId !== null && interaction.channelId !== commandsChannelId) {
      await interaction
        .reply({
          content: `Please run commands in the designated commands channel (<#${commandsChannelId}>).`,
          flags: MessageFlags.Ephemeral,
        })
        .catch(() => undefined);
      return;
    }

    // Ephemeral: command output (client PII in /clients, monitored usernames, /check screenshots)
    // is owner-only data. On Telegram it lives in a private 1:1 chat; ephemeral replies keep it
    // visible ONLY to the invoking owner even if the channel has other readers. editReply and
    // followUp both inherit this ephemeral visibility (fixed at defer time).
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const invocation: DiscordCommandInvocation = {
      name: interaction.commandName,
      userId: interaction.user.id,
      getString: (name: string) => interaction.options.getString(name),
      getInteger: (name: string) => interaction.options.getInteger(name),
    };
    const responder: DiscordResponder = {
      reply: async (text: string): Promise<void> => {
        await interaction.editReply({ content: clampContent(text) });
      },
      replyEmbed: async (embed): Promise<void> => {
        await interaction.editReply({ embeds: [embed] });
      },
      sendPhoto: async (buffer: Buffer, caption: string): Promise<void> => {
        await interaction.followUp({
          content: clampContent(caption),
          files: [{ attachment: buffer, name: 'screenshot.png' }],
          flags: MessageFlags.Ephemeral,
        });
      },
    };

    try {
      await commands.execute(invocation, responder);
    } catch (err) {
      logger.error('discord gateway: command execution failed', {
        command: interaction.commandName,
        error: err instanceof Error ? { name: err.name, message: err.message } : String(err),
      });
      await interaction
        .editReply({ content: 'Something went wrong. Please try again.' })
        .catch(() => undefined);
    }
  }
}

/** discord.js ChatInputCommandInteraction, structurally narrowed without importing the type. */
interface ChatInputInteraction {
  isChatInputCommand(): boolean;
  commandName: string;
  channelId: string | null;
  user: { id: string };
  options: {
    getString(name: string): string | null;
    getInteger(name: string): number | null;
  };
  reply(options: unknown): Promise<unknown>;
  editReply(options: unknown): Promise<unknown>;
  followUp(options: unknown): Promise<unknown>;
  deferReply(options?: unknown): Promise<unknown>;
}

function isChatInputCommand(interaction: unknown): interaction is ChatInputInteraction {
  return (
    typeof interaction === 'object' &&
    interaction !== null &&
    'isChatInputCommand' in interaction &&
    typeof (interaction as { isChatInputCommand: unknown }).isChatInputCommand === 'function' &&
    (interaction as ChatInputInteraction).isChatInputCommand()
  );
}
