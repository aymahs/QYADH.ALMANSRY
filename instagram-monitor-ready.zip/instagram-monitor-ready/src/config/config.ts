/** Runtime configuration: parse + validate environment into a typed AppConfig. */

import { z } from 'zod';
import { AppError } from '../domain';
import type { LogLevel } from '../logging';

export type TelegramMode = 'webhook' | 'polling';
export type DbDriver = 'sqlite' | 'postgres';

/** Budgets that apply ONLY to a page load whose purpose is to photograph the profile. */
export interface CaptureSettings {
  /**
   * Navigation ceiling for a CAPTURE load (`page.goto` + the settle selector).
   *
   * Measured to domcontentloaded through the mobile proxy: instagram 7.6s cold / 7.4s warm,
   * trymaven 76.6s cold / 56.7s warm — one blocking resource from static.cdninstagram.com took
   * 107s on its own. 120s clears the slowest measured cold load with headroom, and the outer
   * `SCREENSHOT_BUDGET_MS` (150s) in the monitor worker remains the thing that actually ends a
   * hopeless attempt.
   */
  timeoutMs: number;
  /**
   * Bounded extra window, AFTER the text paint predicate holds, for the header's own images
   * (the avatar and the story-highlight thumbnails) to finish.
   *
   * Measured gap between text paint and all-header-images-settled: instagram 70.2s cold /
   * 8.1s warm, trymaven 16.0s cold / 18.0s warm. Three of the four runs land in an 8-18s band,
   * so 25s buys the avatar in the common case; the one 70s outlier is exactly the cold-connection
   * case that warm context reuse and post-grid blocking exist to remove. When it expires the
   * capture proceeds anyway — a correct card with a grey avatar beats no proof at all.
   */
  headerImageWaitMs: number;
  /**
   * How many image requests a capture load may send to the network before the rest are served a
   * local 1x1 placeholder.
   *
   * The delivered image is a CROPPED HEADER CARD: the post grid is discarded, yet every pending
   * image at capture time was measured to be a post-grid thumbnail. Blocking by hostname is not
   * possible — the same fbcdn hosts serve the avatar AND the thumbnails — so the discriminator is
   * REQUEST ORDER, which the same measurement supports: the header's images had already settled
   * while the grid's were still in flight. 32 covers an avatar plus a full highlight tray plus UI
   * sprites, against a page that pulls 92-157 resources.
   */
  maxImages: number;
}

/** Production defaults, used whenever `AppConfig.capture` is absent. */
export const DEFAULT_CAPTURE_SETTINGS: CaptureSettings = {
  timeoutMs: 120_000,
  headerImageWaitMs: 25_000,
  maxImages: 32,
};

/**
 * Read the capture budgets from a config that may predate them (test fixtures, `{} as AppConfig`).
 * Always use this rather than `config.capture`, so a missing section degrades to the shipped
 * defaults instead of throwing on the capture path.
 */
export function captureSettings(config: AppConfig): CaptureSettings {
  return config.capture ?? DEFAULT_CAPTURE_SETTINGS;
}

export interface AppConfig {
  telegram: {
    botToken: string;
    webhookSecret: string;
    mode: TelegramMode;
    publicBaseUrl: string | null;
  };
  ownerPairingSecret: string;
  controlUsername: string;
  browserWsEndpoint: string | null;
  /**
   * Optional path to a Playwright `storageState` file (e.g. ./instagram-auth.json) created by
   * the OWNER logging in manually. When set and the file exists, every browser context runs
   * with that logged-in session. Opt-in and local-only — a datacenter login gets banned fast.
   * The file IS the login: keep it out of git and treat it as a secret.
   */
  igStorageState: string | null;
  /**
   * Optional outbound proxy for the BROWSER only (not Telegram/Discord traffic). Set this to a
   * residential / ISP / mobile proxy so Instagram sees a non-datacenter IP, which is what makes
   * cloud hosting viable — a datacenter IP gets served a login wall. Credentials are secrets.
   * Example: http://user:pass@gate.provider.com:7000 (or set PROXY_USERNAME/PROXY_PASSWORD).
   */
  browserProxy: { server: string; username: string | null; password: string | null } | null;
  /**
   * Which egress route to START on. The proxy credentials can be configured while still
   * defaulting to the machine's own connection — that is what lets `/proxy home|mobile` switch
   * at runtime on a host that normally runs direct. Defaults to using the proxy when one is
   * configured, preserving prior behaviour.
   */
  proxyMode: 'direct' | 'proxy';
  /**
   * Optional Discord integration. Fully dormant unless `botToken` is set. When active it (a)
   * mirrors recovery/deletion/health alerts into dedicated channels and (b) exposes the owner
   * command surface as slash commands over the gateway. The bot token is a secret; channel IDs
   * and the owner user id are not. Entirely separate from the Telegram bot, which is unaffected.
   */
  discord: {
    botToken: string | null;
    ownerUserId: string | null;
    guildId: string | null;
    channels: {
      unbans: string | null;
      deletions: string | null;
      status: string | null;
      commands: string | null;
    };
  };
  db: {
    driver: DbDriver;
    sqlitePath: string;
    databaseUrl: string | null;
  };
  displayTimezone: string;
  scheduling: {
    baselineIntervalSeconds: number;
    /**
     * Baseline interval for a DELETION watch, which is browser-only by design and therefore
     * cannot share a recovery monitor's cadence. See DELETION_INTERVAL_SECONDS.
     */
    deletionIntervalSeconds: number;
    baselineJitterMaxSeconds: number;
    confirmationIntervalSeconds: number;
    confirmationRequiredCount: number;
    confirmationDeadlineSeconds: number;
    maxBrowserConcurrency: number;
    jobLeaseSeconds: number;
    checkTimeoutMs: number;
    retryDelaysSeconds: number[];
    unknownBackoffBaseSeconds: number;
    unknownBackoffMaxSeconds: number;
    errorBackoffInitialSeconds: number;
    errorBackoffMaxSeconds: number;
  };
  /**
   * Capture-path budgets, deliberately SEPARATE from `scheduling.checkTimeoutMs`.
   *
   * One timeout used to govern both jobs, and they need opposite numbers. Classification only
   * needs the identity metadata Instagram SERVER-renders into <head> (og:url / og:title /
   * canonical), which is present at domcontentloaded — measured 7.4-76.6s through the mobile
   * proxy, and far faster than that on the classify path because it aborts images/CSS/fonts.
   * A capture needs full paint PLUS the header's images — measured 18.5-130.7s. With one knob,
   * a value tight enough to keep routine checks honest (45s on the VPS) aborted the page load of
   * a slow profile outright, so @trymaven and @odpcompetitions could not even be CLASSIFIED.
   *
   * OPTIONAL so every existing `AppConfig` literal (and the `{} as AppConfig` casts in tests)
   * keeps compiling; read it through {@link captureSettings}, never directly.
   */
  capture?: CaptureSettings;
  /**
   * Fast path + fleet-wide protection.
   *
   * `fastProbe` swaps routine "is it still gone?" polling from a full Chromium page load
   * (~4-12s, 20-50 requests) to a single HTTP GET (~0.3s, 1 request). Recovery detection is
   * unchanged: an ACTIVE result is ALWAYS re-verified in the browser, which is also what
   * captures the screenshot. The breaker stops a throttled IP being hammered by every account
   * at once — the failure that burned a residential IP in production.
   */
  detection: {
    fastProbe: boolean;
    breakerThreshold: number;
    breakerCooldownSeconds: number;
    breakerMaxCooldownSeconds: number;
    /**
     * Rolling-hour ceiling on CHROMIUM PAGE LOADS across the whole fleet — the actual scarce
     * resource. See BROWSER_LOADS_PER_HOUR for how the number was chosen.
     */
    browserLoadsPerHour: number;
    /** Fraction of that ceiling routine polling may spend; the rest is priority headroom. */
    browserLoadRoutineFraction: number;
  };
  server: { port: number };
  logLevel: LogLevel;
}

const emptyToUndef = (v: unknown): unknown =>
  typeof v === 'string' && v.trim() === '' ? undefined : v;

const optionalString = z.preprocess(emptyToUndef, z.string().min(1).optional());

const rawSchema = z.object({
  TELEGRAM_BOT_TOKEN: z.string().min(10, 'TELEGRAM_BOT_TOKEN is required'),
  TELEGRAM_WEBHOOK_SECRET: z.preprocess(emptyToUndef, z.string().min(8).optional()),
  OWNER_PAIRING_SECRET: z.string().min(8, 'OWNER_PAIRING_SECRET is required (min 8 chars)'),
  TELEGRAM_MODE: z.enum(['webhook', 'polling']).default('polling'),
  PUBLIC_BASE_URL: z.preprocess(emptyToUndef, z.string().url().optional()),

  CONTROL_USERNAME: z.string().min(1).default('instagram'),
  BROWSER_WS_ENDPOINT: optionalString,
  IG_STORAGE_STATE: optionalString,

  // Outbound proxy for the browser (residential/ISP/mobile) — makes cloud hosting viable.
  BROWSER_PROXY_SERVER: optionalString,
  BROWSER_PROXY_USERNAME: optionalString,
  BROWSER_PROXY_PASSWORD: optionalString,
  // 'direct' keeps the proxy configured-but-unused, so /proxy mobile can turn it on later.
  PROXY_MODE: z.preprocess(emptyToUndef, z.enum(['direct', 'proxy']).optional()),

  // Discord integration (optional; all dormant unless DISCORD_BOT_TOKEN is set).
  DISCORD_BOT_TOKEN: optionalString,
  DISCORD_OWNER_USER_ID: optionalString,
  DISCORD_GUILD_ID: optionalString,
  DISCORD_UNBANS_CHANNEL_ID: optionalString,
  DISCORD_DELETIONS_CHANNEL_ID: optionalString,
  DISCORD_STATUS_CHANNEL_ID: optionalString,
  DISCORD_COMMANDS_CHANNEL_ID: optionalString,

  DB_DRIVER: z.enum(['sqlite', 'postgres']).default('sqlite'),
  SQLITE_PATH: z.string().min(1).default('./data/monitor.sqlite'),
  DATABASE_URL: optionalString,

  DISPLAY_TIMEZONE: z.string().min(1).default('Asia/Kolkata'),

  BASELINE_INTERVAL_SECONDS: z.coerce.number().int().positive().default(15),
  // DELETION WATCHES GET THEIR OWN CADENCE, and must: a deletion alert may never rest on an
  // INFERRED gone, so the deletion watcher runs the detector with the fast path OFF and EVERY
  // probe it makes is a full Chromium page load. Sharing BASELINE_INTERVAL_SECONDS (15s) meant
  // 3600/~16 = ~225 page loads per hour PER WATCH — two watches on their own exceeded the ~200
  // loads/hour the single residential IP tolerates, before the recovery fleet had run at all.
  //
  // 300s costs 12 loads/hour/watch: two watches are 24, a fifth of the 120/hour ceiling, and even
  // ten watches (120/hour) only fill it — beyond which the governor defers rather than burning the
  // IP, so the default degrades safely instead of cliff-edging.
  //
  // The latency traded away is the right one to trade. A deletion is permanent and nobody is
  // waiting on it minute-by-minute; a RECOVERY is what a paying client is waiting for, and its
  // cadence is untouched at 15s because routine recovery polling costs 1 HTTP request, not a
  // browser load.
  DELETION_INTERVAL_SECONDS: z.coerce.number().int().positive().default(300),
  // De-synchronisation only, NOT rate control. On a fleet of ~20 accounts a couple of seconds
  // spreads the sweep completely; anything larger is pure added latency on every recovery,
  // paid on every poll of every account. Keep this small.
  BASELINE_JITTER_MAX_SECONDS: z.coerce.number().min(0).default(2),
  // Gap between the checks of ONE confirmation burst. It is spent inside a recovery that has
  // already happened, so it is latency the client feels directly. The cost of shortening it is
  // (CONFIRMATION_REQUIRED_COUNT - 1) extra probes per recovery EVENT — not per poll — which is
  // negligible against the IP's request ceiling.
  CONFIRMATION_INTERVAL_SECONDS: z.coerce.number().int().positive().default(2),
  CONFIRMATION_REQUIRED_COUNT: z.coerce.number().int().min(1).default(3),
  // Ceiling on a WHOLE confirmation burst (see MonitorWorker.burstElapsedMs), not on the gap
  // between two checks. Sized so a genuinely slow recovery is never discarded: a browser
  // confirmation leg was measured at 85-96s through the mobile proxy, and if the fast tier is
  // degraded every check in the burst pays that — ~292s worst case for 3 checks. 300s covers it
  // and still guarantees a wedged burst is abandoned within five minutes.
  //
  // Raising it is safe; LOWERING it is not. Below the slowest browser leg it silently discards
  // real recoveries and re-arms the case at a fresh baseline, forever.
  CONFIRMATION_DEADLINE_SECONDS: z.coerce.number().int().positive().default(300),
  // NOT a parallelism knob, despite the name — say what it actually does, because assuming
  // otherwise is how a "shrinks a fleet sweep almost linearly" claim got written for a loop that
  // is serial. Two real effects: (1) how many due cases ONE tick claims, and (2) the ceiling of
  // the BrowserManager semaphore shared by the monitor, the deletion watcher and inline /check.
  // MonitorWorker and DeletionWorker each still process their claimed batch one case at a time,
  // so raising this parallelises nothing within a worker; it only lets a backlog drain in fewer
  // ticks and keeps an owner's /check from queueing behind a long capture. 4 matches the
  // production .env, so the shipped default and the box agree.
  MAX_BROWSER_CONCURRENCY: z.coerce.number().int().positive().default(4),
  JOB_LEASE_SECONDS: z.coerce.number().int().positive().default(120),
  // Governs the CLASSIFICATION load only. Keep it tight: that path aborts images/CSS/fonts, so
  // domcontentloaded arrives quickly, and a routine UNKNOWN simply retries in seconds.
  CHECK_TIMEOUT_MS: z.coerce.number().int().positive().default(25000),
  // Capture-only budgets. See CaptureSettings for how each number was derived from the
  // production measurements through the mobile proxy.
  CAPTURE_TIMEOUT_MS: z.coerce
    .number()
    .int()
    .positive()
    .default(DEFAULT_CAPTURE_SETTINGS.timeoutMs),
  // 0 disables the wait entirely (capture the instant text paints, avatar or no avatar).
  HEADER_IMAGE_WAIT_MS: z.coerce
    .number()
    .int()
    .min(0)
    .default(DEFAULT_CAPTURE_SETTINGS.headerImageWaitMs),
  // Raise this if avatars start coming back blank; lower it to spend less mobile-proxy
  // bandwidth. It can never suppress a capture, only the pixels outside the crop.
  CAPTURE_MAX_IMAGES: z.coerce
    .number()
    .int()
    .positive()
    .default(DEFAULT_CAPTURE_SETTINGS.maxImages),
  RETRY_DELAYS_SECONDS: z.string().default('5,10,15,30'),
  UNKNOWN_BACKOFF_BASE_SECONDS: z.coerce.number().int().positive().default(60),
  UNKNOWN_BACKOFF_MAX_SECONDS: z.coerce.number().int().positive().default(1800),
  ERROR_BACKOFF_INITIAL_SECONDS: z.coerce.number().int().positive().default(15),
  ERROR_BACKOFF_MAX_SECONDS: z.coerce.number().int().positive().default(30),

  // Fast HTTP probe + circuit breaker.
  // Kill switch for the fast path. Accepts the usual falsey spellings — treating anything but
  // the literal "false" as true would make the switch silently fail to disable it.
  FAST_PROBE: z
    .preprocess((v) => {
      if (typeof v !== 'string') return v;
      const s = v.trim().toLowerCase();
      if (s === '') return true;
      return !['false', '0', 'no', 'off', 'disabled'].includes(s);
    }, z.boolean())
    .default(true),
  BREAKER_THRESHOLD: z.coerce.number().int().positive().default(5),
  BREAKER_COOLDOWN_SECONDS: z.coerce.number().int().positive().default(600),
  BREAKER_MAX_COOLDOWN_SECONDS: z.coerce.number().int().positive().default(3600),

  // THE RATE GOVERNOR. A rolling-hour ceiling on Chromium page loads, fleet-wide.
  //
  // 120 was chosen against a measured burn threshold of ~200 loads/hour on the single
  // residential/mobile IP (exceeding it burned the first one and blinded the whole fleet for
  // hours). The 80-load gap is not slack — it is the headroom that lets PRIORITY traffic through
  // unconditionally: a recovery confirmation (1 load), its screenshot (up to 3), a deletion
  // confirmation burst (3), and every /check, /unban and /ping the owner runs. Those are admitted
  // even once routine polling has been cut off, because losing a confirmation is harm rank 1 while
  // delaying a routine poll is not.
  //
  // Raising it trades IP safety for polling speed and should be done only with fresh measurement.
  // LOWERING it is always safe: routine polling simply defers further, and every recovery path
  // still runs.
  BROWSER_LOADS_PER_HOUR: z.coerce.number().int().positive().default(120),
  // How much of the ceiling routine polling may spend before it starts being deferred. 0.75 of
  // 120 = 90 routine loads/hour, leaving 30 of explicit reserve on top of the 80 above the
  // ceiling. Routine admission is gated on TOTAL consumption, so a busy recovery hour squeezes
  // routine polling rather than the reverse.
  BROWSER_LOAD_ROUTINE_FRACTION: z.coerce.number().min(0.1).max(1).default(0.75),

  PORT: z.coerce.number().int().positive().default(8080),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
});

/** Parse and validate an env-like record. Throws AppError('CONFIG_INVALID') on failure. */
export function loadConfig(env: Record<string, string | undefined>): AppConfig {
  const parsed = rawSchema.safeParse(env);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((i) => `${i.path.join('.') || '(root)'}: ${i.message}`)
      .join('; ');
    throw new AppError('CONFIG_INVALID', `Invalid configuration: ${issues}`, issues);
  }
  const e = parsed.data;

  if (e.TELEGRAM_MODE === 'webhook') {
    const missing: string[] = [];
    if (!e.TELEGRAM_WEBHOOK_SECRET) missing.push('TELEGRAM_WEBHOOK_SECRET');
    if (!e.PUBLIC_BASE_URL) missing.push('PUBLIC_BASE_URL');
    if (missing.length > 0) {
      const detail = `webhook mode requires ${missing.join(', ')}`;
      throw new AppError('CONFIG_INVALID', `Invalid configuration: ${detail}`, detail);
    }
  }
  if (e.DB_DRIVER === 'postgres' && !e.DATABASE_URL) {
    const detail = 'postgres driver requires DATABASE_URL';
    throw new AppError('CONFIG_INVALID', `Invalid configuration: ${detail}`, detail);
  }

  return {
    telegram: {
      botToken: e.TELEGRAM_BOT_TOKEN,
      // In polling/dev the webhook secret is optional; default to a non-empty placeholder
      // so the type stays string. It is only consumed in webhook mode.
      webhookSecret: e.TELEGRAM_WEBHOOK_SECRET ?? 'unused-in-polling-mode',
      mode: e.TELEGRAM_MODE,
      publicBaseUrl: e.PUBLIC_BASE_URL ?? null,
    },
    ownerPairingSecret: e.OWNER_PAIRING_SECRET,
    controlUsername: e.CONTROL_USERNAME.toLowerCase(),
    browserWsEndpoint: e.BROWSER_WS_ENDPOINT ?? null,
    igStorageState: e.IG_STORAGE_STATE ?? null,
    browserProxy: e.BROWSER_PROXY_SERVER
      ? {
          server: e.BROWSER_PROXY_SERVER,
          username: e.BROWSER_PROXY_USERNAME ?? null,
          password: e.BROWSER_PROXY_PASSWORD ?? null,
        }
      : null,
    proxyMode: e.PROXY_MODE ?? (e.BROWSER_PROXY_SERVER ? 'proxy' : 'direct'),
    discord: {
      botToken: e.DISCORD_BOT_TOKEN ?? null,
      ownerUserId: e.DISCORD_OWNER_USER_ID ?? null,
      guildId: e.DISCORD_GUILD_ID ?? null,
      channels: {
        unbans: e.DISCORD_UNBANS_CHANNEL_ID ?? null,
        deletions: e.DISCORD_DELETIONS_CHANNEL_ID ?? null,
        status: e.DISCORD_STATUS_CHANNEL_ID ?? null,
        commands: e.DISCORD_COMMANDS_CHANNEL_ID ?? null,
      },
    },
    db: {
      driver: e.DB_DRIVER,
      sqlitePath: e.SQLITE_PATH,
      databaseUrl: e.DATABASE_URL ?? null,
    },
    displayTimezone: e.DISPLAY_TIMEZONE,
    scheduling: {
      baselineIntervalSeconds: e.BASELINE_INTERVAL_SECONDS,
      deletionIntervalSeconds: e.DELETION_INTERVAL_SECONDS,
      baselineJitterMaxSeconds: e.BASELINE_JITTER_MAX_SECONDS,
      confirmationIntervalSeconds: e.CONFIRMATION_INTERVAL_SECONDS,
      confirmationRequiredCount: e.CONFIRMATION_REQUIRED_COUNT,
      confirmationDeadlineSeconds: e.CONFIRMATION_DEADLINE_SECONDS,
      maxBrowserConcurrency: e.MAX_BROWSER_CONCURRENCY,
      jobLeaseSeconds: e.JOB_LEASE_SECONDS,
      checkTimeoutMs: e.CHECK_TIMEOUT_MS,
      retryDelaysSeconds: e.RETRY_DELAYS_SECONDS.split(',')
        .map((s) => Number.parseInt(s.trim(), 10))
        .filter((n) => Number.isFinite(n) && n > 0),
      unknownBackoffBaseSeconds: e.UNKNOWN_BACKOFF_BASE_SECONDS,
      unknownBackoffMaxSeconds: e.UNKNOWN_BACKOFF_MAX_SECONDS,
      errorBackoffInitialSeconds: e.ERROR_BACKOFF_INITIAL_SECONDS,
      errorBackoffMaxSeconds: e.ERROR_BACKOFF_MAX_SECONDS,
    },
    capture: {
      timeoutMs: e.CAPTURE_TIMEOUT_MS,
      headerImageWaitMs: e.HEADER_IMAGE_WAIT_MS,
      maxImages: e.CAPTURE_MAX_IMAGES,
    },
    detection: {
      fastProbe: e.FAST_PROBE,
      breakerThreshold: e.BREAKER_THRESHOLD,
      breakerCooldownSeconds: e.BREAKER_COOLDOWN_SECONDS,
      breakerMaxCooldownSeconds: e.BREAKER_MAX_COOLDOWN_SECONDS,
      browserLoadsPerHour: e.BROWSER_LOADS_PER_HOUR,
      browserLoadRoutineFraction: e.BROWSER_LOAD_ROUTINE_FRACTION,
    },
    server: { port: e.PORT },
    logLevel: e.LOG_LEVEL,
  };
}

/** Secret values to hand to the logger's redactor. */
export function collectSecrets(config: AppConfig): string[] {
  const secrets = [
    config.telegram.botToken,
    config.telegram.webhookSecret,
    config.ownerPairingSecret,
  ];
  if (config.db.databaseUrl) secrets.push(config.db.databaseUrl);
  if (config.browserWsEndpoint) secrets.push(config.browserWsEndpoint);
  if (config.browserProxy) {
    secrets.push(config.browserProxy.server);
    if (config.browserProxy.password) secrets.push(config.browserProxy.password);
    if (config.browserProxy.username) secrets.push(config.browserProxy.username);
  }
  if (config.discord.botToken) secrets.push(config.discord.botToken);
  return secrets.filter((s) => typeof s === 'string' && s.length >= 6);
}
