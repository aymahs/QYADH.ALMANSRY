/**
 * A {@link Clock} that corrects for local system-clock skew using a trusted HTTPS
 * server's `Date` header (default: Telegram's API host, which the bot already talks to).
 *
 * Motivation: displayed/stored times are only as good as the host clock. A skewed host
 * (observed: a dev machine 4.5h fast) silently corrupts every "Started/Confirmed" time.
 * `sync()` measures `serverTime - localTime` at the request midpoint and applies the
 * offset to `now()`. Small offsets (< 30s) are ignored — the Date header only has 1s
 * resolution and NTP-synced hosts need no correction.
 */

import type { Clock } from '../domain';

const TIME_SOURCE_URL = 'https://api.telegram.org';
/** Below this, trust the local clock (header resolution is 1s; avoid jitter). */
const IGNORE_BELOW_MS = 30_000;
/**
 * Reject absurd deltas (> 24h) as almost certainly a broken source rather than real skew.
 * A cached HTTP Date is only seconds-to-minutes stale, so a multi-hour delta is a genuinely
 * wrong host clock and MUST be corrected (observed: a dev box 4.5h fast).
 */
const MAX_SAFE_CORRECTION_MS = 24 * 60 * 60 * 1000;

export class NetworkCorrectedClock implements Clock {
  private offsetMs = 0;

  constructor(private readonly fetchImpl: typeof fetch = fetch) {}

  now(): Date {
    return new Date(Date.now() + this.offsetMs);
  }

  nowMs(): number {
    return Date.now() + this.offsetMs;
  }

  /** Current correction being applied, in milliseconds (0 = trusting local clock). */
  get appliedOffsetMs(): number {
    return this.offsetMs;
  }

  /**
   * Measure and apply the clock offset. Best-effort: on any failure the previous
   * offset is kept and the error is swallowed into the return value.
   */
  async sync(url: string = TIME_SOURCE_URL): Promise<{ ok: boolean; offsetMs: number }> {
    try {
      const t0 = Date.now();
      const res = await this.fetchImpl(url, { method: 'HEAD' });
      const t1 = Date.now();
      const header = res.headers.get('date');
      if (header === null) return { ok: false, offsetMs: this.offsetMs };
      const serverMs = Date.parse(header);
      if (Number.isNaN(serverMs)) return { ok: false, offsetMs: this.offsetMs };
      // Header resolution is 1s: use its midpoint against the request midpoint.
      const measured = serverMs + 500 - (t0 + t1) / 2;
      if (Math.abs(measured) > MAX_SAFE_CORRECTION_MS) {
        return { ok: false, offsetMs: this.offsetMs };
      }
      this.offsetMs = Math.abs(measured) < IGNORE_BELOW_MS ? 0 : Math.round(measured);
      return { ok: true, offsetMs: this.offsetMs };
    } catch {
      return { ok: false, offsetMs: this.offsetMs };
    }
  }
}
