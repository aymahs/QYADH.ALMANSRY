/**
 * Instagram username handling: normalization, validation, and safe URL building.
 *
 * `profileUrl` is the single choke point for building an Instagram URL. It refuses
 * anything that is not a validated username so no attacker-controlled string can be
 * turned into an arbitrary navigation target (SSRF guard).
 */

import { AppError } from '../domain';

/**
 * Instagram reserved paths that live at the same URL level as a profile. They must
 * never be treated as monitorable usernames.
 */
const RESERVED_USERNAMES: ReadonlySet<string> = new Set([
  'explore',
  'reels',
  'reel',
  'stories',
  'p',
  'accounts',
  'about',
  'directory',
  'direct',
  'login',
  'signup',
  'challenge',
]);

/** Valid characters and shape for an Instagram username (already lowercased). */
const USERNAME_CHARS_RE = /^[a-z0-9._]+$/;

/**
 * Reduce free-form input to a bare Instagram username. Lowercases, strips a leading
 * `@`, protocol, `www.`, the `instagram.com/` host, query string, fragment, and any
 * trailing path/slashes — keeping only the first path segment.
 */
export function normalizeUsername(input: string): string {
  let s = input.trim().toLowerCase();
  s = s.replace(/^https?:\/\//, '');
  s = s.replace(/^www\./, '');
  s = s.replace(/^instagram\.com\//, '');
  s = s.replace(/^@+/, '');

  const hashIndex = s.indexOf('#');
  if (hashIndex !== -1) s = s.slice(0, hashIndex);
  const queryIndex = s.indexOf('?');
  if (queryIndex !== -1) s = s.slice(0, queryIndex);

  const firstSegment = s.split('/').find((segment) => segment.length > 0);
  return (firstSegment ?? '').trim();
}

/**
 * Validate an already-normalized username against Instagram's rules: 1–30 chars of
 * `[a-z0-9._]`, no leading/trailing dot, no consecutive dots, and not a reserved path.
 */
export function isValidUsername(u: string): boolean {
  if (u.length < 1 || u.length > 30) return false;
  if (!USERNAME_CHARS_RE.test(u)) return false;
  if (u.startsWith('.') || u.endsWith('.')) return false;
  if (u.includes('..')) return false;
  if (RESERVED_USERNAMES.has(u)) return false;
  return true;
}

/** Normalize then validate raw input, returning either the username or a safe error. */
export function parseUsernameInput(raw: string): { username: string } | { error: string } {
  const username = normalizeUsername(raw);
  if (username.length === 0) {
    return { error: 'Please provide an Instagram username, e.g. /unban natgeo.' };
  }
  if (!isValidUsername(username)) {
    return {
      error:
        'That does not look like a valid Instagram username. Use 1–30 letters, ' +
        'numbers, periods, or underscores (no spaces, and not starting or ending with a dot).',
    };
  }
  return { username };
}

/**
 * Build the canonical public profile URL for an ALREADY-VALIDATED username. Throws
 * `AppError('INVALID_USERNAME')` for anything invalid so this can never be used to
 * navigate to an arbitrary host.
 */
export function profileUrl(username: string): string {
  if (!isValidUsername(username)) {
    throw new AppError(
      'INVALID_USERNAME',
      'profileUrl called with an invalid username',
      'invalid username',
    );
  }
  return `https://www.instagram.com/${username}/`;
}
