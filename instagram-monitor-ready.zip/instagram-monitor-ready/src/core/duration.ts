/** Human-readable elapsed-time formatting for monitoring and recovery durations. */

function pad2(n: number): string {
  return n.toString().padStart(2, '0');
}

/**
 * Format a duration in milliseconds as `D days HH hours MM minutes SS seconds`.
 * Days are an unpadded integer; hours/minutes/seconds are zero-padded. Negative
 * (and sub-zero) inputs clamp to zero.
 */
export function formatDuration(ms: number): string {
  const clamped = ms > 0 ? Math.floor(ms) : 0;
  const totalSeconds = Math.floor(clamped / 1000);
  const days = Math.floor(totalSeconds / 86_400);
  const hours = Math.floor((totalSeconds % 86_400) / 3_600);
  const minutes = Math.floor((totalSeconds % 3_600) / 60);
  const seconds = totalSeconds % 60;
  return `${days} days ${pad2(hours)} hours ${pad2(minutes)} minutes ${pad2(seconds)} seconds`;
}

/** Raw millisecond difference `end - start` between two UTC ISO strings. */
export function durationMsBetween(startIso: string, endIso: string): number {
  return new Date(endIso).getTime() - new Date(startIso).getTime();
}

/** Convenience: `formatDuration(end - start)` for two UTC ISO strings. */
export function durationBetween(startIso: string, endIso: string): string {
  return formatDuration(durationMsBetween(startIso, endIso));
}
