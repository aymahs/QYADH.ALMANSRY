/**
 * Timestamp parsing (backdated `/unban`) and IST-style display formatting.
 *
 * Internally the app stores UTC ISO-8601 strings. Display uses the configured IANA
 * timezone (default `Asia/Kolkata`). Timezone maths are done via `Intl.DateTimeFormat`
 * so no timezone database dependency is needed.
 */

/** `YYYY-MM-DD HH:mm`, optional `:ss`, optional trailing `Z` or `±HH:MM`/`±HHMM`. */
const TIMESTAMP_RE =
  /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?\s*(Z|[+-]\d{2}:?\d{2})?$/;

interface ZonedParts {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
}

function pad2(n: number): string {
  return n.toString().padStart(2, '0');
}

/** Wall-clock components of `instantMs` as observed in `tz`. */
function getZonedParts(instantMs: number, tz: string): ZonedParts {
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    hourCycle: 'h23',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
  const out: ZonedParts = { year: 0, month: 0, day: 0, hour: 0, minute: 0, second: 0 };
  for (const part of dtf.formatToParts(new Date(instantMs))) {
    switch (part.type) {
      case 'year':
        out.year = Number(part.value);
        break;
      case 'month':
        out.month = Number(part.value);
        break;
      case 'day':
        out.day = Number(part.value);
        break;
      case 'hour':
        out.hour = Number(part.value);
        break;
      case 'minute':
        out.minute = Number(part.value);
        break;
      case 'second':
        out.second = Number(part.value);
        break;
      default:
        break;
    }
  }
  return out;
}

/** Signed offset in ms such that `wallClockAsUtc - instant = offset` for `tz`. */
function tzOffsetMs(instantMs: number, tz: string): number {
  const p = getZonedParts(instantMs, tz);
  const asUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  return asUtc - instantMs;
}

/**
 * Convert a wall-clock time in `tz` to a UTC epoch-ms value. Returns null if the
 * components do not round-trip (e.g. an impossible calendar date like Feb 30).
 */
function wallClockToUtc(
  year: number,
  month: number,
  day: number,
  hour: number,
  minute: number,
  second: number,
  tz: string,
): number | null {
  const asUtc = Date.UTC(year, month - 1, day, hour, minute, second);
  // Two-pass offset resolution so timezones with DST still land on the right instant.
  const utc = asUtc - tzOffsetMs(asUtc - tzOffsetMs(asUtc, tz), tz);
  const rt = getZonedParts(utc, tz);
  if (
    rt.year !== year ||
    rt.month !== month ||
    rt.day !== day ||
    rt.hour !== hour ||
    rt.minute !== minute ||
    rt.second !== second
  ) {
    return null;
  }
  return utc;
}

/** Normalize a matched offset token to `Z` or `±HH:MM`. */
function normalizeOffset(offset: string): string {
  if (offset === 'Z') return 'Z';
  if (offset.includes(':')) return offset;
  return `${offset.slice(0, 3)}:${offset.slice(3)}`;
}

/**
 * Parse a backdated timestamp typed by the owner. Interprets `YYYY-MM-DD HH:mm[:ss]`
 * in `tz` unless the text carries an explicit offset (`Z`/`±HH:MM`), which is honored
 * as-is. Rejects unparseable input and any instant after `now`.
 */
export function parseBackdatedTimestamp(
  text: string,
  tz: string,
  now: Date,
): { iso: string } | { error: string } {
  const match = TIMESTAMP_RE.exec(text.trim());
  if (match === null) {
    return { error: 'Use the format YYYY-MM-DD HH:mm (24-hour), e.g. 2026-07-15 18:30.' };
  }

  const yStr = match[1];
  const moStr = match[2];
  const dStr = match[3];
  const hStr = match[4];
  const miStr = match[5];
  const sStr = match[6];
  const offStr = match[7];
  if (
    yStr === undefined ||
    moStr === undefined ||
    dStr === undefined ||
    hStr === undefined ||
    miStr === undefined
  ) {
    return { error: 'Could not read that timestamp.' };
  }

  const year = Number(yStr);
  const month = Number(moStr);
  const day = Number(dStr);
  const hour = Number(hStr);
  const minute = Number(miStr);
  const second = sStr !== undefined ? Number(sStr) : 0;

  if (month < 1 || month > 12 || day < 1 || day > 31 || hour > 23 || minute > 59 || second > 59) {
    return { error: 'That timestamp has an out-of-range field.' };
  }

  let utcMs: number;
  if (offStr !== undefined) {
    const iso = `${yStr}-${moStr}-${dStr}T${hStr}:${miStr}:${pad2(second)}${normalizeOffset(offStr)}`;
    const parsed = Date.parse(iso);
    if (Number.isNaN(parsed)) {
      return { error: 'That timestamp could not be parsed.' };
    }
    utcMs = parsed;
  } else {
    const resolved = wallClockToUtc(year, month, day, hour, minute, second, tz);
    if (resolved === null) {
      return { error: 'That is not a real calendar date and time.' };
    }
    utcMs = resolved;
  }

  if (utcMs > now.getTime()) {
    return { error: 'That timestamp is in the future.' };
  }
  return { iso: new Date(utcMs).toISOString() };
}

/** Short zone label: `IST` for Asia/Kolkata, otherwise a locale short name. */
function zoneLabel(date: Date, tz: string): string {
  if (tz === 'Asia/Kolkata') return 'IST';
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    hour: '2-digit',
    timeZoneName: 'short',
  });
  for (const part of dtf.formatToParts(date)) {
    if (part.type === 'timeZoneName') return part.value;
  }
  return tz;
}

/**
 * Format a UTC ISO string for display, e.g. `17 July 2026, 10:30:15 PM IST`
 * (day, full month, year, 12-hour clock with seconds and AM/PM, then zone label).
 */
export function formatIstDateTime(iso: string, tz: string): string {
  const date = new Date(iso);
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
  const m: Record<string, string> = {};
  for (const part of dtf.formatToParts(date)) {
    if (part.type !== 'literal') m[part.type] = part.value;
  }
  const day = m.day ?? '';
  const month = m.month ?? '';
  const year = m.year ?? '';
  const hour = m.hour ?? '';
  const minute = m.minute ?? '';
  const second = m.second ?? '';
  const period = m.dayPeriod ?? '';
  return `${day} ${month} ${year}, ${hour}:${minute}:${second} ${period} ${zoneLabel(date, tz)}`;
}

/** Format a UTC ISO string as a time only, e.g. `10:31:00 PM IST`. */
export function formatIstTime(iso: string, tz: string): string {
  const date = new Date(iso);
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
  const m: Record<string, string> = {};
  for (const part of dtf.formatToParts(date)) {
    if (part.type !== 'literal') m[part.type] = part.value;
  }
  const hour = m.hour ?? '';
  const minute = m.minute ?? '';
  const second = m.second ?? '';
  const period = m.dayPeriod ?? '';
  return `${hour}:${minute}:${second} ${period} ${zoneLabel(date, tz)}`;
}
