/** Executable entry: run database migrations then exit. */

import { loadConfig, collectSecrets } from '../config';
import { createLogger } from '../logging';
import { createDatabase } from './create-database';

async function main(): Promise<void> {
  const config = loadConfig(process.env);
  const logger = createLogger({ level: config.logLevel, secrets: collectSecrets(config) });
  const db = createDatabase(config);
  try {
    await db.migrate();
    logger.info('migrations applied', { driver: config.db.driver });
  } finally {
    await db.close();
  }
}

main().catch((err: unknown) => {
  createLogger().error('migration failed', { err });
  process.exitCode = 1;
});
