/** Barrel for the persistence layer. */

export { createDatabase } from './create-database';
export { SqliteDatabase } from './sqlite-database';
export { PostgresDatabase } from './postgres-database';
export { ddlStatements } from './migrations/schema';
export type { DbDriver } from './migrations/schema';
export {
  generateId,
  serializeJsonArray,
  boolToDb,
  rowToCase,
  rowToCheck,
  rowToOutbox,
  rowToHealth,
} from './repositories/mappers';
export type { Row } from './repositories/mappers';
