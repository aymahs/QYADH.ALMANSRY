/**
 * SQLite implementation of the persistence {@link Database} contract (better-sqlite3).
 *
 * better-sqlite3 is synchronous and single-connection, so "atomic" multi-statement
 * operations (claim, clear, enqueue, claim-next) are wrapped in `db.transaction(...)`.
 * Every method returns a Promise to satisfy the async contract even though the work
 * is synchronous.
 */

import Database from 'better-sqlite3';

import type {
  Database as PersistenceDatabase,
  Repositories,
  OwnerRepository,
  CaseRepository,
  ClaimDueParams,
  CheckRepository,
  TelegramUpdateRepository,
  EnqueueOutbox,
  OutboxRepository,
  SchedulerHealthRepository,
  BreakerStateRecord,
  BreakerStateRepository,
  BusinessConnectionRepository,
  ClientChatLinkRepository,
  DeletionWatchRepository,
  DeletionClaimParams,
  ClientsRepository,
} from '../domain/repositories';
import type { DeletionWatch, NewDeletionWatchInput } from '../domain/deletion';
import type { NewClientIdentity, ClientIdentity } from '../domain/clients';
import type {
  MonitoringCase,
  NewCaseInput,
  CaseStatus,
  CheckRecord,
  NewCheckInput,
  OutboxItem,
  OutboxKind,
  SchedulerHealth,
} from '../domain/case';
import type {
  BusinessConnection,
  ClientChatLink,
  NewClientChatLink,
  BusinessDeliveryStatus,
} from '../domain/business';
import { AppError } from '../domain/errors';
import { ddlStatements } from './migrations/schema';
import {
  generateId,
  serializeJsonArray,
  boolToDb,
  rowToCase,
  rowToOutbox,
  rowToHealth,
  rowToBreakerState,
  rowToBusinessConnection,
  rowToClientLink,
  rowToDeletionWatch,
  rowToClientIdentity,
  type Row,
} from './repositories/mappers';

type SqliteConnection = Database.Database;

const CASE_COLUMNS = `id, normalized_username, original_input, started_at_utc, status,
  confirmation_count, next_check_at_utc, last_checked_at_utc, last_result,
  consecutive_unknown_count, error_backoff_until_utc, confirmed_at_utc, cleared_at_utc,
  notification_claimed_at_utc, notification_sent_at_utc, telegram_message_id,
  screenshot_status, lease_owner, lease_expires_at_utc, created_at_utc, updated_at_utc`;

const CASE_VALUES = `:id, :normalized_username, :original_input, :started_at_utc, :status,
  :confirmation_count, :next_check_at_utc, :last_checked_at_utc, :last_result,
  :consecutive_unknown_count, :error_backoff_until_utc, :confirmed_at_utc, :cleared_at_utc,
  :notification_claimed_at_utc, :notification_sent_at_utc, :telegram_message_id,
  :screenshot_status, :lease_owner, :lease_expires_at_utc, :created_at_utc, :updated_at_utc`;

const CASE_UPDATE_SET = `normalized_username=:normalized_username,
  original_input=:original_input, started_at_utc=:started_at_utc, status=:status,
  confirmation_count=:confirmation_count, next_check_at_utc=:next_check_at_utc,
  last_checked_at_utc=:last_checked_at_utc, last_result=:last_result,
  consecutive_unknown_count=:consecutive_unknown_count,
  error_backoff_until_utc=:error_backoff_until_utc, confirmed_at_utc=:confirmed_at_utc,
  cleared_at_utc=:cleared_at_utc, notification_claimed_at_utc=:notification_claimed_at_utc,
  notification_sent_at_utc=:notification_sent_at_utc, telegram_message_id=:telegram_message_id,
  screenshot_status=:screenshot_status, lease_owner=:lease_owner,
  lease_expires_at_utc=:lease_expires_at_utc, created_at_utc=:created_at_utc,
  updated_at_utc=:updated_at_utc`;

const ACTIVE_FILTER = `status NOT IN ('NOTIFIED','CLEARED')`;

const DELETION_COLUMNS = `id, normalized_username, original_input, started_at_utc, status,
  confirmation_count, consecutive_unknown_count, next_check_at_utc, last_checked_at_utc,
  last_result, confirmed_at_utc, cleared_at_utc, notified_at_utc, telegram_message_id,
  lease_owner, lease_expires_at_utc, created_at_utc, updated_at_utc`;

const DELETION_VALUES = `:id, :normalized_username, :original_input, :started_at_utc, :status,
  :confirmation_count, :consecutive_unknown_count, :next_check_at_utc, :last_checked_at_utc,
  :last_result, :confirmed_at_utc, :cleared_at_utc, :notified_at_utc, :telegram_message_id,
  :lease_owner, :lease_expires_at_utc, :created_at_utc, :updated_at_utc`;

const DELETION_UPDATE_SET = `normalized_username=:normalized_username,
  original_input=:original_input, started_at_utc=:started_at_utc, status=:status,
  confirmation_count=:confirmation_count, consecutive_unknown_count=:consecutive_unknown_count,
  next_check_at_utc=:next_check_at_utc, last_checked_at_utc=:last_checked_at_utc,
  last_result=:last_result, confirmed_at_utc=:confirmed_at_utc, cleared_at_utc=:cleared_at_utc,
  notified_at_utc=:notified_at_utc, telegram_message_id=:telegram_message_id,
  lease_owner=:lease_owner, lease_expires_at_utc=:lease_expires_at_utc,
  created_at_utc=:created_at_utc, updated_at_utc=:updated_at_utc`;

function deletionBind(w: DeletionWatch): Record<string, unknown> {
  return {
    id: w.id,
    normalized_username: w.normalizedUsername,
    original_input: w.originalInput,
    started_at_utc: w.startedAtUtc,
    status: w.status,
    confirmation_count: w.confirmationCount,
    consecutive_unknown_count: w.consecutiveUnknownCount,
    next_check_at_utc: w.nextCheckAtUtc,
    last_checked_at_utc: w.lastCheckedAtUtc,
    last_result: w.lastResult,
    confirmed_at_utc: w.confirmedAtUtc,
    cleared_at_utc: w.clearedAtUtc,
    notified_at_utc: w.notifiedAtUtc,
    telegram_message_id: w.telegramMessageId,
    lease_owner: w.leaseOwner,
    lease_expires_at_utc: w.leaseExpiresAtUtc,
    created_at_utc: w.createdAtUtc,
    updated_at_utc: w.updatedAtUtc,
  };
}

function newDeletionWatchFrom(input: NewDeletionWatchInput, nowUtc: string): DeletionWatch {
  return {
    id: generateId(),
    normalizedUsername: input.normalizedUsername,
    originalInput: input.originalInput,
    startedAtUtc: input.startedAtUtc,
    status: 'WATCHING',
    confirmationCount: 0,
    consecutiveUnknownCount: 0,
    nextCheckAtUtc: input.nextCheckAtUtc,
    lastCheckedAtUtc: null,
    lastResult: null,
    confirmedAtUtc: null,
    clearedAtUtc: null,
    notifiedAtUtc: null,
    telegramMessageId: null,
    leaseOwner: null,
    leaseExpiresAtUtc: null,
    createdAtUtc: nowUtc,
    updatedAtUtc: nowUtc,
  };
}

function caseBind(c: MonitoringCase): Record<string, unknown> {
  return {
    id: c.id,
    normalized_username: c.normalizedUsername,
    original_input: c.originalInput,
    started_at_utc: c.startedAtUtc,
    status: c.status,
    confirmation_count: c.confirmationCount,
    next_check_at_utc: c.nextCheckAtUtc,
    last_checked_at_utc: c.lastCheckedAtUtc,
    last_result: c.lastResult,
    consecutive_unknown_count: c.consecutiveUnknownCount,
    error_backoff_until_utc: c.errorBackoffUntilUtc,
    confirmed_at_utc: c.confirmedAtUtc,
    cleared_at_utc: c.clearedAtUtc,
    notification_claimed_at_utc: c.notificationClaimedAtUtc,
    notification_sent_at_utc: c.notificationSentAtUtc,
    telegram_message_id: c.telegramMessageId,
    screenshot_status: c.screenshotStatus,
    lease_owner: c.leaseOwner,
    lease_expires_at_utc: c.leaseExpiresAtUtc,
    created_at_utc: c.createdAtUtc,
    updated_at_utc: c.updatedAtUtc,
  };
}

function newCaseFrom(input: NewCaseInput, nowUtc: string): MonitoringCase {
  return {
    id: generateId(),
    normalizedUsername: input.normalizedUsername,
    originalInput: input.originalInput,
    startedAtUtc: input.startedAtUtc,
    status: 'MONITORING',
    confirmationCount: 0,
    nextCheckAtUtc: input.nextCheckAtUtc,
    lastCheckedAtUtc: null,
    lastResult: null,
    consecutiveUnknownCount: 0,
    errorBackoffUntilUtc: null,
    confirmedAtUtc: null,
    clearedAtUtc: null,
    notificationClaimedAtUtc: null,
    notificationSentAtUtc: null,
    telegramMessageId: null,
    screenshotStatus: 'NONE',
    leaseOwner: null,
    leaseExpiresAtUtc: null,
    createdAtUtc: nowUtc,
    updatedAtUtc: nowUtc,
  };
}

function isUniqueViolation(err: unknown): boolean {
  if (typeof err !== 'object' || err === null || !('code' in err)) return false;
  const code = String((err as { code: unknown }).code);
  return code.startsWith('SQLITE_CONSTRAINT');
}

export class SqliteDatabase implements PersistenceDatabase {
  private readonly db: SqliteConnection;
  private repos: Repositories | null = null;

  constructor(path: string) {
    this.db = new Database(path);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('foreign_keys = ON');
  }

  async migrate(): Promise<void> {
    for (const stmt of ddlStatements('sqlite')) {
      this.db.exec(stmt);
    }
    // NOTE: no data-migration UPDATE here. A blanket ERROR_BACKOFF -> UNKNOWN_BACKOFF
    // reclassify has no way to distinguish a genuine operational ERROR_BACKOFF (which also
    // carries last_result='UNKNOWN') from a legacy row, so running it on every startup
    // silently demoted new operational-failure cases. Both backoff states now share the
    // same short retry ladder, so any legacy row simply retries promptly on its own.
  }

  async ping(): Promise<boolean> {
    const ts = new Date().toISOString();
    this.db
      .prepare(
        `INSERT INTO scheduler_health
           (name, recent_unknown_rate, browser_restarts, detector_unhealthy, updated_at_utc)
         VALUES ('__ping__', 0, 0, 0, :ts)
         ON CONFLICT(name) DO UPDATE SET updated_at_utc = excluded.updated_at_utc`,
      )
      .run({ ts });
    const row = this.db
      .prepare(`SELECT updated_at_utc FROM scheduler_health WHERE name = '__ping__'`)
      .get() as Row | undefined;
    return row !== undefined && row['updated_at_utc'] === ts;
  }

  repositories(): Repositories {
    if (this.repos === null) {
      this.repos = {
        owner: this.makeOwnerRepo(),
        cases: this.makeCaseRepo(),
        checks: this.makeCheckRepo(),
        updates: this.makeUpdateRepo(),
        outbox: this.makeOutboxRepo(),
        health: this.makeHealthRepo(),
        breakerState: this.makeBreakerStateRepo(),
        businessConnections: this.makeBusinessConnectionRepo(),
        clientLinks: this.makeClientLinkRepo(),
        clients: this.makeClientsRepo(),
        deletionWatches: this.makeDeletionWatchRepo(),
      };
    }
    return this.repos;
  }

  async close(): Promise<void> {
    this.db.close();
  }

  private makeBusinessConnectionRepo(): BusinessConnectionRepository {
    const db = this.db;
    return {
      async upsert(c: BusinessConnection): Promise<void> {
        db.prepare(
          `INSERT INTO business_connections
             (id, owner_telegram_user_id, user_chat_id, is_enabled, can_reply,
              can_read_messages, can_delete_sent_messages, can_delete_all_messages,
              created_at_utc, updated_at_utc)
           VALUES (:id, :owner, :chat, :enabled, :reply, :read, :dels, :dela, :now, :now)
           ON CONFLICT(id) DO UPDATE SET
             owner_telegram_user_id = excluded.owner_telegram_user_id,
             user_chat_id = excluded.user_chat_id,
             is_enabled = excluded.is_enabled,
             can_reply = excluded.can_reply,
             can_read_messages = excluded.can_read_messages,
             can_delete_sent_messages = excluded.can_delete_sent_messages,
             can_delete_all_messages = excluded.can_delete_all_messages,
             updated_at_utc = excluded.updated_at_utc`,
        ).run({
          id: c.id,
          owner: c.userId,
          chat: c.userChatId,
          enabled: boolToDb(c.isEnabled, 'sqlite'),
          reply: boolToDb(c.rights.canReply, 'sqlite'),
          read: boolToDb(c.rights.canReadMessages, 'sqlite'),
          dels: boolToDb(c.rights.canDeleteSentMessages, 'sqlite'),
          dela: boolToDb(c.rights.canDeleteAllMessages, 'sqlite'),
          now: c.updatedAtUtc,
        });
      },
      async findById(id: string): Promise<BusinessConnection | null> {
        const row = db.prepare(`SELECT * FROM business_connections WHERE id = ?`).get(id) as
          Row | undefined;
        return row === undefined ? null : rowToBusinessConnection(row);
      },
      async findLatestEnabled(): Promise<BusinessConnection | null> {
        const row = db
          .prepare(
            `SELECT * FROM business_connections WHERE is_enabled = 1
             ORDER BY updated_at_utc DESC LIMIT 1`,
          )
          .get() as Row | undefined;
        return row === undefined ? null : rowToBusinessConnection(row);
      },
    };
  }

  private makeClientLinkRepo(): ClientChatLinkRepository {
    const db = this.db;
    return {
      async create(input: NewClientChatLink, nowUtc: string): Promise<ClientChatLink> {
        const id = generateId();
        // The upsert deliberately never rewrites client_chat_id. The WHERE guard turns a link
        // that belongs to a DIFFERENT client chat into a no-op instead of a silent steal, and the
        // SELECT below then hands the caller the stored row so it can refuse. Kept byte-for-byte
        // in meaning with the Postgres driver.
        db.prepare(
          `INSERT INTO client_chat_links
             (id, monitor_id, source_type, client_chat_id, business_connection_id,
              owner_telegram_user_id, source_message_id, client_delivery_status,
              created_at_utc, updated_at_utc)
           VALUES (:id, :mon, :src, :chat, :bcid, :owner, :msg, 'BUSINESS_DELIVERY_NOT_REQUIRED',
                   :now, :now)
           ON CONFLICT(monitor_id) DO UPDATE SET
             source_type = excluded.source_type,
             business_connection_id = excluded.business_connection_id,
             owner_telegram_user_id = excluded.owner_telegram_user_id,
             source_message_id = excluded.source_message_id,
             updated_at_utc = excluded.updated_at_utc
           WHERE client_chat_links.client_chat_id = excluded.client_chat_id`,
        ).run({
          id,
          mon: input.monitorId,
          src: input.sourceType,
          chat: input.clientChatId,
          bcid: input.businessConnectionId,
          owner: input.ownerTelegramUserId,
          msg: input.sourceMessageId,
          now: nowUtc,
        });
        const row = db
          .prepare(`SELECT * FROM client_chat_links WHERE monitor_id = ?`)
          .get(input.monitorId) as Row;
        return rowToClientLink(row);
      },
      async findByMonitorId(monitorId: string): Promise<ClientChatLink | null> {
        const row = db
          .prepare(`SELECT * FROM client_chat_links WHERE monitor_id = ?`)
          .get(monitorId) as Row | undefined;
        return row === undefined ? null : rowToClientLink(row);
      },
      async listAll(): Promise<ClientChatLink[]> {
        const rows = db
          .prepare(`SELECT * FROM client_chat_links ORDER BY created_at_utc ASC`)
          .all() as Row[];
        return rows.map(rowToClientLink);
      },
      async updateDeliveryStatus(
        monitorId: string,
        status: BusinessDeliveryStatus,
        nowUtc: string,
      ): Promise<void> {
        db.prepare(
          `UPDATE client_chat_links SET client_delivery_status = :status, updated_at_utc = :now
           WHERE monitor_id = :mon`,
        ).run({ status, now: nowUtc, mon: monitorId });
      },
    };
  }

  private makeOwnerRepo(): OwnerRepository {
    const db = this.db;
    return {
      async getOwnerTelegramId(): Promise<number | null> {
        const row = db.prepare(`SELECT telegram_user_id FROM owner WHERE id = 1`).get() as
          Row | undefined;
        if (row === undefined) return null;
        return Number(row['telegram_user_id']);
      },
      async claimOwner(telegramUserId: number, pairedAtUtc: string): Promise<boolean> {
        const info = db
          .prepare(
            `INSERT OR IGNORE INTO owner (id, telegram_user_id, paired_at_utc)
             VALUES (1, :tid, :paired)`,
          )
          .run({ tid: telegramUserId, paired: pairedAtUtc });
        return info.changes > 0;
      },
    };
  }

  private makeCaseRepo(): CaseRepository {
    const db = this.db;
    return {
      async create(input: NewCaseInput, nowUtc: string): Promise<MonitoringCase> {
        const record = newCaseFrom(input, nowUtc);
        try {
          db.prepare(`INSERT INTO monitoring_cases (${CASE_COLUMNS}) VALUES (${CASE_VALUES})`).run(
            caseBind(record),
          );
        } catch (err) {
          if (isUniqueViolation(err)) {
            throw new AppError(
              'DUPLICATE_CASE',
              `A case for @${input.normalizedUsername} is already being monitored.`,
              input.normalizedUsername,
            );
          }
          throw new AppError('DB_ERROR', `Failed to create case: ${String(err)}`);
        }
        return record;
      },

      async findById(id: string): Promise<MonitoringCase | null> {
        const row = db.prepare(`SELECT * FROM monitoring_cases WHERE id = :id`).get({ id }) as
          Row | undefined;
        return row === undefined ? null : rowToCase(row);
      },

      async findActiveByNormalizedUsername(username: string): Promise<MonitoringCase | null> {
        const row = db
          .prepare(
            `SELECT * FROM monitoring_cases
             WHERE normalized_username = :u AND ${ACTIVE_FILTER}
             LIMIT 1`,
          )
          .get({ u: username }) as Row | undefined;
        return row === undefined ? null : rowToCase(row);
      },

      async listByStatuses(statuses: readonly CaseStatus[]): Promise<MonitoringCase[]> {
        if (statuses.length === 0) return [];
        const placeholders = statuses.map(() => '?').join(',');
        const rows = db
          .prepare(
            `SELECT * FROM monitoring_cases
             WHERE status IN (${placeholders})
             ORDER BY created_at_utc ASC`,
          )
          .all(...statuses) as Row[];
        return rows.map(rowToCase);
      },

      async countByStatuses(statuses: readonly CaseStatus[]): Promise<number> {
        if (statuses.length === 0) return 0;
        const placeholders = statuses.map(() => '?').join(',');
        const row = db
          .prepare(`SELECT COUNT(*) AS n FROM monitoring_cases WHERE status IN (${placeholders})`)
          .get(...statuses) as Row;
        return Number(row['n']);
      },

      async claimDueCases(params: ClaimDueParams): Promise<MonitoringCase[]> {
        const selectDue = db.prepare(
          `SELECT * FROM monitoring_cases
           WHERE status IN ('MONITORING','CONFIRMING','ERROR_BACKOFF','UNKNOWN_BACKOFF')
             AND next_check_at_utc IS NOT NULL
             AND next_check_at_utc <= :now
             AND (lease_owner IS NULL OR lease_expires_at_utc <= :now)
           ORDER BY (status = 'CONFIRMING') DESC, next_check_at_utc ASC
           LIMIT :limit`,
        );
        const updateLease = db.prepare(
          `UPDATE monitoring_cases
             SET lease_owner = :owner, lease_expires_at_utc = :exp, updated_at_utc = :now
           WHERE id = :id`,
        );
        const claim = db.transaction((p: ClaimDueParams): MonitoringCase[] => {
          const rows = selectDue.all({ now: p.nowUtc, limit: p.limit }) as Row[];
          for (const row of rows) {
            updateLease.run({
              id: String(row['id']),
              owner: p.leaseOwner,
              exp: p.leaseExpiresUtc,
              now: p.nowUtc,
            });
          }
          return rows.map((row) => ({
            ...rowToCase(row),
            leaseOwner: p.leaseOwner,
            leaseExpiresAtUtc: p.leaseExpiresUtc,
            updatedAtUtc: p.nowUtc,
          }));
        });
        return claim(params);
      },

      async save(next: MonitoringCase): Promise<void> {
        db.prepare(`UPDATE monitoring_cases SET ${CASE_UPDATE_SET} WHERE id = :id`).run(
          caseBind(next),
        );
      },

      async releaseLease(id: string, nowUtc: string): Promise<void> {
        db.prepare(
          `UPDATE monitoring_cases
             SET lease_owner = NULL, lease_expires_at_utc = NULL, updated_at_utc = :now
           WHERE id = :id`,
        ).run({ id, now: nowUtc });
      },

      async clearByNormalizedUsername(
        username: string,
        clearedAtUtc: string,
      ): Promise<MonitoringCase | null> {
        const selectActive = db.prepare(
          `SELECT * FROM monitoring_cases
           WHERE normalized_username = :u AND ${ACTIVE_FILTER}
           LIMIT 1`,
        );
        const clear = db.prepare(
          `UPDATE monitoring_cases
             SET status = 'CLEARED', cleared_at_utc = :t, next_check_at_utc = NULL,
                 lease_owner = NULL, lease_expires_at_utc = NULL, updated_at_utc = :t
           WHERE id = :id`,
        );
        const run = db.transaction((): MonitoringCase | null => {
          const row = selectActive.get({ u: username }) as Row | undefined;
          if (row === undefined) return null;
          const id = String(row['id']);
          clear.run({ t: clearedAtUtc, id });
          return {
            ...rowToCase(row),
            status: 'CLEARED',
            clearedAtUtc,
            nextCheckAtUtc: null,
            leaseOwner: null,
            leaseExpiresAtUtc: null,
            updatedAtUtc: clearedAtUtc,
          };
        });
        return run();
      },

      async claimNotification(caseId: string, claimedAtUtc: string): Promise<boolean> {
        const info = db
          .prepare(
            `UPDATE monitoring_cases
               SET notification_claimed_at_utc = :t, updated_at_utc = :t
             WHERE id = :id AND notification_claimed_at_utc IS NULL`,
          )
          .run({ id: caseId, t: claimedAtUtc });
        return info.changes > 0;
      },
    };
  }

  private makeClientsRepo(): ClientsRepository {
    const db = this.db;
    return {
      async upsert(identity: NewClientIdentity, nowUtc: string): Promise<void> {
        db.prepare(
          `INSERT INTO clients
             (client_chat_id, business_connection_id, username, first_name, last_name, updated_at_utc)
           VALUES (:chat, :bcid, :username, :first, :last, :now)
           ON CONFLICT(client_chat_id) DO UPDATE SET
             business_connection_id = excluded.business_connection_id,
             username = excluded.username,
             first_name = excluded.first_name,
             last_name = excluded.last_name,
             updated_at_utc = excluded.updated_at_utc`,
        ).run({
          chat: identity.clientChatId,
          bcid: identity.businessConnectionId,
          username: identity.username,
          first: identity.firstName,
          last: identity.lastName,
          now: nowUtc,
        });
      },
      async findByChatId(clientChatId: number): Promise<ClientIdentity | null> {
        const row = db
          .prepare(`SELECT * FROM clients WHERE client_chat_id = ?`)
          .get(clientChatId) as Row | undefined;
        return row === undefined ? null : rowToClientIdentity(row);
      },
      async listAll(): Promise<ClientIdentity[]> {
        const rows = db.prepare(`SELECT * FROM clients`).all() as Row[];
        return rows.map(rowToClientIdentity);
      },
    };
  }

  private makeDeletionWatchRepo(): DeletionWatchRepository {
    const db = this.db;
    return {
      async create(input: NewDeletionWatchInput, nowUtc: string): Promise<DeletionWatch> {
        const record = newDeletionWatchFrom(input, nowUtc);
        try {
          db.prepare(
            `INSERT INTO deletion_watches (${DELETION_COLUMNS}) VALUES (${DELETION_VALUES})`,
          ).run(deletionBind(record));
        } catch (err) {
          if (isUniqueViolation(err)) {
            throw new AppError(
              'DUPLICATE_CASE',
              `A deletion watch for @${input.normalizedUsername} already exists.`,
              input.normalizedUsername,
            );
          }
          throw new AppError('DB_ERROR', `Failed to create deletion watch: ${String(err)}`);
        }
        return record;
      },

      async findById(id: string): Promise<DeletionWatch | null> {
        const row = db.prepare(`SELECT * FROM deletion_watches WHERE id = :id`).get({ id }) as
          Row | undefined;
        return row === undefined ? null : rowToDeletionWatch(row);
      },

      async findActiveByNormalizedUsername(username: string): Promise<DeletionWatch | null> {
        const row = db
          .prepare(
            `SELECT * FROM deletion_watches
             WHERE normalized_username = :u AND ${ACTIVE_FILTER}
             LIMIT 1`,
          )
          .get({ u: username }) as Row | undefined;
        return row === undefined ? null : rowToDeletionWatch(row);
      },

      async listActive(): Promise<DeletionWatch[]> {
        const rows = db
          .prepare(
            `SELECT * FROM deletion_watches WHERE ${ACTIVE_FILTER} ORDER BY created_at_utc ASC`,
          )
          .all() as Row[];
        return rows.map(rowToDeletionWatch);
      },

      async countActive(): Promise<number> {
        const row = db
          .prepare(`SELECT COUNT(*) AS n FROM deletion_watches WHERE ${ACTIVE_FILTER}`)
          .get() as Row;
        return Number(row['n']);
      },

      async claimDue(params: DeletionClaimParams): Promise<DeletionWatch[]> {
        const selectDue = db.prepare(
          `SELECT * FROM deletion_watches
           WHERE status IN ('WATCHING','CONFIRMING','BACKOFF')
             AND next_check_at_utc IS NOT NULL
             AND next_check_at_utc <= :now
             AND (lease_owner IS NULL OR lease_expires_at_utc <= :now)
           ORDER BY (status = 'CONFIRMING') DESC, next_check_at_utc ASC
           LIMIT :limit`,
        );
        const updateLease = db.prepare(
          `UPDATE deletion_watches
             SET lease_owner = :owner, lease_expires_at_utc = :exp, updated_at_utc = :now
           WHERE id = :id`,
        );
        const claim = db.transaction((p: DeletionClaimParams): DeletionWatch[] => {
          const rows = selectDue.all({ now: p.nowUtc, limit: p.limit }) as Row[];
          for (const row of rows) {
            updateLease.run({
              id: String(row['id']),
              owner: p.leaseOwner,
              exp: p.leaseExpiresUtc,
              now: p.nowUtc,
            });
          }
          return rows.map((row) => ({
            ...rowToDeletionWatch(row),
            leaseOwner: p.leaseOwner,
            leaseExpiresAtUtc: p.leaseExpiresUtc,
            updatedAtUtc: p.nowUtc,
          }));
        });
        return claim(params);
      },

      async save(next: DeletionWatch): Promise<void> {
        db.prepare(`UPDATE deletion_watches SET ${DELETION_UPDATE_SET} WHERE id = :id`).run(
          deletionBind(next),
        );
      },

      async releaseLease(id: string, nowUtc: string): Promise<void> {
        db.prepare(
          `UPDATE deletion_watches
             SET lease_owner = NULL, lease_expires_at_utc = NULL, updated_at_utc = :now
           WHERE id = :id`,
        ).run({ id, now: nowUtc });
      },

      async clearByNormalizedUsername(
        username: string,
        clearedAtUtc: string,
      ): Promise<DeletionWatch | null> {
        const selectActive = db.prepare(
          `SELECT * FROM deletion_watches
           WHERE normalized_username = :u AND ${ACTIVE_FILTER}
           LIMIT 1`,
        );
        const clear = db.prepare(
          `UPDATE deletion_watches
             SET status = 'CLEARED', cleared_at_utc = :t, next_check_at_utc = NULL,
                 lease_owner = NULL, lease_expires_at_utc = NULL, updated_at_utc = :t
           WHERE id = :id`,
        );
        const run = db.transaction((): DeletionWatch | null => {
          const row = selectActive.get({ u: username }) as Row | undefined;
          if (row === undefined) return null;
          const id = String(row['id']);
          clear.run({ t: clearedAtUtc, id });
          return {
            ...rowToDeletionWatch(row),
            status: 'CLEARED',
            clearedAtUtc,
            nextCheckAtUtc: null,
            leaseOwner: null,
            leaseExpiresAtUtc: null,
            updatedAtUtc: clearedAtUtc,
          };
        });
        return run();
      },
    };
  }

  private makeCheckRepo(): CheckRepository {
    const db = this.db;
    return {
      async insert(input: NewCheckInput): Promise<CheckRecord> {
        const record: CheckRecord = { id: generateId(), ...input };
        db.prepare(
          `INSERT INTO monitoring_checks
             (id, case_id, checked_at_utc, classification, final_url, response_status,
              duration_ms, active_signals, gone_signals, error_code, confirmation_seq)
           VALUES
             (:id, :case_id, :checked_at_utc, :classification, :final_url, :response_status,
              :duration_ms, :active_signals, :gone_signals, :error_code, :confirmation_seq)`,
        ).run({
          id: record.id,
          case_id: record.caseId,
          checked_at_utc: record.checkedAtUtc,
          classification: record.classification,
          final_url: record.finalUrl,
          response_status: record.responseStatus,
          duration_ms: record.durationMs,
          active_signals: serializeJsonArray(record.activeSignals),
          gone_signals: serializeJsonArray(record.goneSignals),
          error_code: record.errorCode,
          confirmation_seq: record.confirmationSeq,
        });
        return record;
      },

      async countByCase(caseId: string): Promise<number> {
        const row = db
          .prepare(`SELECT COUNT(*) AS n FROM monitoring_checks WHERE case_id = :id`)
          .get({ id: caseId }) as Row;
        return Number(row['n']);
      },
    };
  }

  private makeUpdateRepo(): TelegramUpdateRepository {
    const db = this.db;
    return {
      async registerIfNew(updateId: number, receivedAtUtc: string): Promise<boolean> {
        const info = db
          .prepare(
            `INSERT OR IGNORE INTO telegram_updates (update_id, received_at_utc)
             VALUES (:id, :t)`,
          )
          .run({ id: updateId, t: receivedAtUtc });
        return info.changes > 0;
      },
    };
  }

  private makeOutboxRepo(): OutboxRepository {
    const db = this.db;
    return {
      async enqueue(item: EnqueueOutbox): Promise<OutboxItem> {
        const insert = db.prepare(
          `INSERT INTO notification_outbox
             (id, case_id, kind, status, attempts, claimed_at_utc, sent_at_utc,
              last_error, telegram_message_id, created_at_utc, updated_at_utc)
           VALUES
             (:id, :case_id, :kind, 'PENDING', 0, NULL, NULL, NULL, NULL, :created, :created)
           ON CONFLICT(case_id, kind) DO NOTHING`,
        );
        const select = db.prepare(
          `SELECT * FROM notification_outbox WHERE case_id = :case_id AND kind = :kind`,
        );
        const run = db.transaction((): OutboxItem => {
          insert.run({
            id: generateId(),
            case_id: item.caseId,
            kind: item.kind,
            created: item.createdAtUtc,
          });
          const row = select.get({ case_id: item.caseId, kind: item.kind }) as Row;
          return rowToOutbox(row);
        });
        return run();
      },

      async findByCase(caseId: string): Promise<OutboxItem[]> {
        const rows = db
          .prepare(
            `SELECT * FROM notification_outbox WHERE case_id = :id ORDER BY created_at_utc ASC`,
          )
          .all({ id: caseId }) as Row[];
        return rows.map(rowToOutbox);
      },

      async claimNextPending(nowUtc: string): Promise<OutboxItem | null> {
        const selectNext = db.prepare(
          `SELECT * FROM notification_outbox
           WHERE status = 'PENDING'
           ORDER BY created_at_utc ASC
           LIMIT 1`,
        );
        const claim = db.prepare(
          `UPDATE notification_outbox
             SET status = 'CLAIMED', attempts = attempts + 1,
                 claimed_at_utc = :now, updated_at_utc = :now
           WHERE id = :id`,
        );
        const run = db.transaction((now: string): OutboxItem | null => {
          const row = selectNext.get() as Row | undefined;
          if (row === undefined) return null;
          claim.run({ id: String(row['id']), now });
          return {
            ...rowToOutbox(row),
            status: 'CLAIMED',
            attempts: rowToOutbox(row).attempts + 1,
            claimedAtUtc: now,
            updatedAtUtc: now,
          };
        });
        return run(nowUtc);
      },

      async markSent(
        id: string,
        sentAtUtc: string,
        telegramMessageId: number | null,
      ): Promise<void> {
        db.prepare(
          `UPDATE notification_outbox
             SET status = 'SENT', sent_at_utc = :sent,
                 telegram_message_id = :mid, updated_at_utc = :sent
           WHERE id = :id`,
        ).run({ id, sent: sentAtUtc, mid: telegramMessageId });
      },

      async markFailed(id: string, error: string, nowUtc: string): Promise<void> {
        // NEVER demote a SENT row. SENT is the durable proof that the alert reached Telegram,
        // and a step that runs AFTER the send (the case close-out, the client delivery, the
        // screenshot cleanup) can still throw and land here. The stranded-notification sweep
        // reads SENT as "already delivered"; without this guard it would find a FAILED row
        // instead, re-open it, and the owner would get the same recovery alert twice.
        db.prepare(
          `UPDATE notification_outbox
             SET status = 'FAILED', last_error = :err, updated_at_utc = :now
           WHERE id = :id AND status <> 'SENT'`,
        ).run({ id, err: error, now: nowUtc });
      },

      async reopenFailed(caseId: string, kind: OutboxKind, nowUtc: string): Promise<boolean> {
        // created_at_utc is refreshed so the revived row queues (and ages) from now — otherwise
        // `oldestPendingAgeMs` would report the original, long-past timestamp as backlog age.
        const info = db
          .prepare(
            `UPDATE notification_outbox
               SET status = 'PENDING', attempts = 0, claimed_at_utc = NULL, last_error = NULL,
                   created_at_utc = :now, updated_at_utc = :now
             WHERE case_id = :case_id AND kind = :kind AND status = 'FAILED'`,
          )
          .run({ case_id: caseId, kind, now: nowUtc });
        return info.changes > 0;
      },

      async requeueStale(olderThanUtc: string, nowUtc: string): Promise<number> {
        const info = db
          .prepare(
            `UPDATE notification_outbox
               SET status = 'PENDING', updated_at_utc = :now
             WHERE status = 'CLAIMED'
               AND claimed_at_utc IS NOT NULL
               AND claimed_at_utc <= :older`,
          )
          .run({ now: nowUtc, older: olderThanUtc });
        return info.changes;
      },

      async countPending(): Promise<number> {
        const row = db
          .prepare(`SELECT COUNT(*) AS n FROM notification_outbox WHERE status = 'PENDING'`)
          .get() as Row;
        return Number(row['n']);
      },

      async oldestPendingAgeMs(nowUtc: string): Promise<number | null> {
        const row = db
          .prepare(
            `SELECT MIN(created_at_utc) AS oldest FROM notification_outbox WHERE status = 'PENDING'`,
          )
          .get() as Row;
        const oldest = row['oldest'];
        if (oldest === null || oldest === undefined) return null;
        const ageMs = Date.parse(nowUtc) - Date.parse(String(oldest));
        return Number.isNaN(ageMs) ? null : Math.max(0, ageMs);
      },
    };
  }

  private makeBreakerStateRepo(): BreakerStateRepository {
    const db = this.db;
    return {
      async get(name: string): Promise<BreakerStateRecord | null> {
        const row = db.prepare(`SELECT * FROM breaker_state WHERE name = :name`).get({ name }) as
          Row | undefined;
        return row === undefined ? null : rowToBreakerState(row);
      },

      async save(record: BreakerStateRecord): Promise<void> {
        db.prepare(
          `INSERT INTO breaker_state
             (name, state, opened_at_utc, cooldown_ms, consecutive, egress_route, updated_at_utc)
           VALUES (:name, :state, :opened, :cooldown, :consecutive, :route, :now)
           ON CONFLICT(name) DO UPDATE SET
             state = excluded.state,
             opened_at_utc = excluded.opened_at_utc,
             cooldown_ms = excluded.cooldown_ms,
             consecutive = excluded.consecutive,
             egress_route = excluded.egress_route,
             updated_at_utc = excluded.updated_at_utc`,
        ).run({
          name: record.name,
          state: record.state,
          opened: record.openedAtUtc,
          cooldown: record.cooldownMs,
          consecutive: record.consecutive,
          route: record.egressRoute,
          now: record.updatedAtUtc,
        });
      },
    };
  }

  private makeHealthRepo(): SchedulerHealthRepository {
    const db = this.db;
    return {
      async get(name: string): Promise<SchedulerHealth | null> {
        const row = db
          .prepare(`SELECT * FROM scheduler_health WHERE name = :name`)
          .get({ name }) as Row | undefined;
        return row === undefined ? null : rowToHealth(row);
      },

      async upsert(health: SchedulerHealth): Promise<void> {
        db.prepare(
          `INSERT INTO scheduler_health
             (name, last_scheduler_run_utc, last_successful_check_utc, last_control_ok_utc,
              recent_unknown_rate, browser_restarts, detector_unhealthy,
              last_warning_sent_utc, updated_at_utc)
           VALUES
             (:name, :last_scheduler_run_utc, :last_successful_check_utc, :last_control_ok_utc,
              :recent_unknown_rate, :browser_restarts, :detector_unhealthy,
              :last_warning_sent_utc, :updated_at_utc)
           ON CONFLICT(name) DO UPDATE SET
             last_scheduler_run_utc = excluded.last_scheduler_run_utc,
             last_successful_check_utc = excluded.last_successful_check_utc,
             last_control_ok_utc = excluded.last_control_ok_utc,
             recent_unknown_rate = excluded.recent_unknown_rate,
             browser_restarts = excluded.browser_restarts,
             detector_unhealthy = excluded.detector_unhealthy,
             last_warning_sent_utc = excluded.last_warning_sent_utc,
             updated_at_utc = excluded.updated_at_utc`,
        ).run({
          name: health.name,
          last_scheduler_run_utc: health.lastSchedulerRunUtc,
          last_successful_check_utc: health.lastSuccessfulCheckUtc,
          last_control_ok_utc: health.lastControlOkUtc,
          recent_unknown_rate: health.recentUnknownRate,
          browser_restarts: health.browserRestarts,
          detector_unhealthy: boolToDb(health.detectorUnhealthy, 'sqlite'),
          last_warning_sent_utc: health.lastWarningSentUtc,
          updated_at_utc: health.updatedAtUtc,
        });
      },
    };
  }
}
