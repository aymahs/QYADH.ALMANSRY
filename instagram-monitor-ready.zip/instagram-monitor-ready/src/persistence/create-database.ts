/** Factory that builds the configured {@link Database} implementation. */

import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

import type { AppConfig } from '../config';
import type { Database } from '../domain';
import { AppError } from '../domain';
import { SqliteDatabase } from './sqlite-database';
import { PostgresDatabase } from './postgres-database';

export function createDatabase(cfg: AppConfig): Database {
  if (cfg.db.driver === 'postgres') {
    if (cfg.db.databaseUrl === null) {
      throw new AppError('CONFIG_INVALID', 'postgres driver requires DATABASE_URL');
    }
    return new PostgresDatabase(cfg.db.databaseUrl);
  }

  const path = cfg.db.sqlitePath;
  if (path !== ':memory:') {
    // Ensure the parent directory for the sqlite file exists.
    mkdirSync(dirname(path), { recursive: true });
  }
  return new SqliteDatabase(path);
}
