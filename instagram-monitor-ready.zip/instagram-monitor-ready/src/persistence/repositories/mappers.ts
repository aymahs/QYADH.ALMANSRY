/**
 * Pure row <-> model mappers, shared by both drivers.
 *
 * DB rows are `Record<string, unknown>` because sqlite and postgres return slightly
 * different runtime types (sqlite: booleans as INTEGER 0/1, bigints as number;
 * postgres: booleans as boolean, bigints as string). The coercion helpers below
 * normalize both into the domain model shape. Nullable columns always map to `null`,
 * never `undefined` (exactOptionalPropertyTypes).
 */

import { randomUUID } from 'node:crypto';

import type {
  MonitoringCase,
  CaseStatus,
  ScreenshotStatus,
  CheckRecord,
  OutboxItem,
  OutboxKind,
  OutboxStatus,
  SchedulerHealth,
} from '../../domain/case';
import type { BreakerPhase, BreakerStateRecord } from '../../domain/repositories';
import type { Classification, DetectorErrorCode } from '../../domain/classification';
import type { DeletionWatch, DeletionWatchStatus } from '../../domain/deletion';
import type { ClientIdentity } from '../../domain/clients';
import type {
  BusinessConnection,
  ClientChatLink,
  MonitorSourceType,
  BusinessDeliveryStatus,
} from '../../domain/business';

export type Row = Record<string, unknown>;

/** New random id for a persisted entity. */
export function generateId(): string {
  return randomUUID();
}

function asString(value: unknown): string {
  if (typeof value === 'string') return value;
  if (typeof value === 'number' || typeof value === 'bigint') return String(value);
  throw new TypeError(`expected string column, got ${typeof value}`);
}

function asStringOrNull(value: unknown): string | null {
  if (value === null || value === undefined) return null;
  return asString(value);
}

function asNumber(value: unknown): number {
  if (typeof value === 'number') return value;
  if (typeof value === 'bigint') return Number(value);
  if (typeof value === 'string' && value.trim() !== '') return Number(value);
  throw new TypeError(`expected numeric column, got ${typeof value}`);
}

function asNumberOrNull(value: unknown): number | null {
  if (value === null || value === undefined) return null;
  return asNumber(value);
}

/** Booleans are 0/1 (sqlite) or true/false (postgres); accept both. */
function asBool(value: unknown): boolean {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value !== 0;
  if (typeof value === 'bigint') return value !== 0n;
  if (typeof value === 'string') return value === '1' || value === 't' || value === 'true';
  return false;
}

/** Arrays are stored as TEXT JSON. */
function parseJsonArray(value: unknown): string[] {
  if (value === null || value === undefined) return [];
  if (Array.isArray(value)) return value.map((v) => String(v));
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (trimmed === '') return [];
    const parsed: unknown = JSON.parse(trimmed);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((v) => String(v));
  }
  return [];
}

export function serializeJsonArray(value: readonly string[]): string {
  return JSON.stringify(value);
}

/** SQLite has no boolean type; store true/false as 1/0. Postgres binds booleans directly. */
export function boolToDb(value: boolean, driver: 'sqlite' | 'postgres'): boolean | number {
  return driver === 'postgres' ? value : value ? 1 : 0;
}

export function rowToCase(row: Row): MonitoringCase {
  return {
    id: asString(row['id']),
    normalizedUsername: asString(row['normalized_username']),
    originalInput: asString(row['original_input']),
    startedAtUtc: asString(row['started_at_utc']),
    status: asString(row['status']) as CaseStatus,
    confirmationCount: asNumber(row['confirmation_count']),
    nextCheckAtUtc: asStringOrNull(row['next_check_at_utc']),
    lastCheckedAtUtc: asStringOrNull(row['last_checked_at_utc']),
    lastResult: asStringOrNull(row['last_result']) as Classification | null,
    consecutiveUnknownCount: asNumber(row['consecutive_unknown_count']),
    errorBackoffUntilUtc: asStringOrNull(row['error_backoff_until_utc']),
    confirmedAtUtc: asStringOrNull(row['confirmed_at_utc']),
    clearedAtUtc: asStringOrNull(row['cleared_at_utc']),
    notificationClaimedAtUtc: asStringOrNull(row['notification_claimed_at_utc']),
    notificationSentAtUtc: asStringOrNull(row['notification_sent_at_utc']),
    telegramMessageId: asNumberOrNull(row['telegram_message_id']),
    screenshotStatus: asString(row['screenshot_status']) as ScreenshotStatus,
    leaseOwner: asStringOrNull(row['lease_owner']),
    leaseExpiresAtUtc: asStringOrNull(row['lease_expires_at_utc']),
    createdAtUtc: asString(row['created_at_utc']),
    updatedAtUtc: asString(row['updated_at_utc']),
  };
}

export function rowToCheck(row: Row): CheckRecord {
  return {
    id: asString(row['id']),
    caseId: asString(row['case_id']),
    checkedAtUtc: asString(row['checked_at_utc']),
    classification: asString(row['classification']) as Classification,
    finalUrl: asStringOrNull(row['final_url']),
    responseStatus: asNumberOrNull(row['response_status']),
    durationMs: asNumber(row['duration_ms']),
    activeSignals: parseJsonArray(row['active_signals']),
    goneSignals: parseJsonArray(row['gone_signals']),
    errorCode: asStringOrNull(row['error_code']) as DetectorErrorCode | null,
    confirmationSeq: asNumberOrNull(row['confirmation_seq']),
  };
}

export function rowToOutbox(row: Row): OutboxItem {
  return {
    id: asString(row['id']),
    caseId: asString(row['case_id']),
    kind: asString(row['kind']) as OutboxKind,
    status: asString(row['status']) as OutboxStatus,
    attempts: asNumber(row['attempts']),
    claimedAtUtc: asStringOrNull(row['claimed_at_utc']),
    sentAtUtc: asStringOrNull(row['sent_at_utc']),
    lastError: asStringOrNull(row['last_error']),
    telegramMessageId: asNumberOrNull(row['telegram_message_id']),
    createdAtUtc: asString(row['created_at_utc']),
    updatedAtUtc: asString(row['updated_at_utc']),
  };
}

export function rowToBusinessConnection(row: Row): BusinessConnection {
  return {
    id: asString(row['id']),
    userId: asNumber(row['owner_telegram_user_id']),
    userChatId: asNumberOrNull(row['user_chat_id']),
    isEnabled: asBool(row['is_enabled']),
    rights: {
      canReply: asBool(row['can_reply']),
      canReadMessages: asBool(row['can_read_messages']),
      canDeleteSentMessages: asBool(row['can_delete_sent_messages']),
      canDeleteAllMessages: asBool(row['can_delete_all_messages']),
    },
    createdAtUtc: asString(row['created_at_utc']),
    updatedAtUtc: asString(row['updated_at_utc']),
  };
}

export function rowToClientLink(row: Row): ClientChatLink {
  return {
    id: asString(row['id']),
    monitorId: asString(row['monitor_id']),
    sourceType: asString(row['source_type']) as MonitorSourceType,
    clientChatId: asNumber(row['client_chat_id']),
    businessConnectionId: asString(row['business_connection_id']),
    ownerTelegramUserId: asNumber(row['owner_telegram_user_id']),
    sourceMessageId: asNumberOrNull(row['source_message_id']),
    clientDeliveryStatus: asString(row['client_delivery_status']) as BusinessDeliveryStatus,
    createdAtUtc: asString(row['created_at_utc']),
    updatedAtUtc: asString(row['updated_at_utc']),
  };
}

export function rowToDeletionWatch(row: Row): DeletionWatch {
  return {
    id: asString(row['id']),
    normalizedUsername: asString(row['normalized_username']),
    originalInput: asString(row['original_input']),
    startedAtUtc: asString(row['started_at_utc']),
    status: asString(row['status']) as DeletionWatchStatus,
    confirmationCount: asNumber(row['confirmation_count']),
    consecutiveUnknownCount: asNumber(row['consecutive_unknown_count']),
    nextCheckAtUtc: asStringOrNull(row['next_check_at_utc']),
    lastCheckedAtUtc: asStringOrNull(row['last_checked_at_utc']),
    lastResult: asStringOrNull(row['last_result']) as Classification | null,
    confirmedAtUtc: asStringOrNull(row['confirmed_at_utc']),
    clearedAtUtc: asStringOrNull(row['cleared_at_utc']),
    notifiedAtUtc: asStringOrNull(row['notified_at_utc']),
    telegramMessageId: asNumberOrNull(row['telegram_message_id']),
    leaseOwner: asStringOrNull(row['lease_owner']),
    leaseExpiresAtUtc: asStringOrNull(row['lease_expires_at_utc']),
    createdAtUtc: asString(row['created_at_utc']),
    updatedAtUtc: asString(row['updated_at_utc']),
  };
}

export function rowToClientIdentity(row: Row): ClientIdentity {
  return {
    clientChatId: asNumber(row['client_chat_id']),
    businessConnectionId: asStringOrNull(row['business_connection_id']),
    username: asStringOrNull(row['username']),
    firstName: asStringOrNull(row['first_name']),
    lastName: asStringOrNull(row['last_name']),
    updatedAtUtc: asString(row['updated_at_utc']),
  };
}

/**
 * The phase is cast, not validated, in line with every other status column here — the breaker's
 * own `rehydrate` treats an unknown phase as "nothing stored" and starts CLOSED.
 */
export function rowToBreakerState(row: Row): BreakerStateRecord {
  return {
    name: asString(row['name']),
    state: asString(row['state']) as BreakerPhase,
    openedAtUtc: asStringOrNull(row['opened_at_utc']),
    cooldownMs: asNumber(row['cooldown_ms']),
    consecutive: asNumber(row['consecutive']),
    egressRoute: asString(row['egress_route']),
    updatedAtUtc: asString(row['updated_at_utc']),
  };
}

export function rowToHealth(row: Row): SchedulerHealth {
  return {
    name: asString(row['name']),
    lastSchedulerRunUtc: asStringOrNull(row['last_scheduler_run_utc']),
    lastSuccessfulCheckUtc: asStringOrNull(row['last_successful_check_utc']),
    lastControlOkUtc: asStringOrNull(row['last_control_ok_utc']),
    recentUnknownRate: asNumber(row['recent_unknown_rate']),
    browserRestarts: asNumber(row['browser_restarts']),
    detectorUnhealthy: asBool(row['detector_unhealthy']),
    lastWarningSentUtc: asStringOrNull(row['last_warning_sent_utc']),
    updatedAtUtc: asString(row['updated_at_utc']),
  };
}
