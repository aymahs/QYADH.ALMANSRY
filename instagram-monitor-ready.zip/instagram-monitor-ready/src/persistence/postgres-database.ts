/**
 * PostgreSQL implementation of the persistence {@link Database} contract (pg Pool).
 *
 * Concurrency-safe claims use `FOR UPDATE SKIP LOCKED` inside a CTE so two workers
 * never lease the same row. Idempotent inserts use `ON CONFLICT`. This driver is
 * validated by types/compile; the integration tests run against sqlite.
 */

import { Pool } from 'pg';

import type {
  Database as PersistenceDatabase,
  Repositories,
  OwnerRepository,
  CaseRepository,
  ClaimDueParams,
  CheckRepository,
  TelegramUpdateRepository,
  EnqueueOutbox,
  OutboxRepository,
  SchedulerHealthRepository,
  BreakerStateRecord,
  BreakerStateRepository,
  BusinessConnectionRepository,
  ClientChatLinkRepository,
} from '../domain/repositories';
import type {
  MonitoringCase,
  NewCaseInput,
  CaseStatus,
  CheckRecord,
  NewCheckInput,
  OutboxItem,
  OutboxKind,
  SchedulerHealth,
} from '../domain/case';
import type {
  BusinessConnection,
  ClientChatLink,
  NewClientChatLink,
  BusinessDeliveryStatus,
} from '../domain/business';
import type { DeletionWatchRepository, ClientsRepository } from '../domain/repositories';
import type { NewClientIdentity, ClientIdentity } from '../domain/clients';
import { AppError } from '../domain/errors';
import { ddlStatements } from './migrations/schema';
import {
  generateId,
  serializeJsonArray,
  boolToDb,
  rowToCase,
  rowToOutbox,
  rowToHealth,
  rowToBreakerState,
  rowToBusinessConnection,
  rowToClientLink,
  rowToClientIdentity,
  type Row,
} from './repositories/mappers';

const CASE_COLUMNS = `id, normalized_username, original_input, started_at_utc, status,
  confirmation_count, next_check_at_utc, last_checked_at_utc, last_result,
  consecutive_unknown_count, error_backoff_until_utc, confirmed_at_utc, cleared_at_utc,
  notification_claimed_at_utc, notification_sent_at_utc, telegram_message_id,
  screenshot_status, lease_owner, lease_expires_at_utc, created_at_utc, updated_at_utc`;

const ACTIVE_FILTER = `status NOT IN ('NOTIFIED','CLEARED')`;

function caseValues(c: MonitoringCase): unknown[] {
  return [
    c.id,
    c.normalizedUsername,
    c.originalInput,
    c.startedAtUtc,
    c.status,
    c.confirmationCount,
    c.nextCheckAtUtc,
    c.lastCheckedAtUtc,
    c.lastResult,
    c.consecutiveUnknownCount,
    c.errorBackoffUntilUtc,
    c.confirmedAtUtc,
    c.clearedAtUtc,
    c.notificationClaimedAtUtc,
    c.notificationSentAtUtc,
    c.telegramMessageId,
    c.screenshotStatus,
    c.leaseOwner,
    c.leaseExpiresAtUtc,
    c.createdAtUtc,
    c.updatedAtUtc,
  ];
}

function newCaseFrom(input: NewCaseInput, nowUtc: string): MonitoringCase {
  return {
    id: generateId(),
    normalizedUsername: input.normalizedUsername,
    originalInput: input.originalInput,
    startedAtUtc: input.startedAtUtc,
    status: 'MONITORING',
    confirmationCount: 0,
    nextCheckAtUtc: input.nextCheckAtUtc,
    lastCheckedAtUtc: null,
    lastResult: null,
    consecutiveUnknownCount: 0,
    errorBackoffUntilUtc: null,
    confirmedAtUtc: null,
    clearedAtUtc: null,
    notificationClaimedAtUtc: null,
    notificationSentAtUtc: null,
    telegramMessageId: null,
    screenshotStatus: 'NONE',
    leaseOwner: null,
    leaseExpiresAtUtc: null,
    createdAtUtc: nowUtc,
    updatedAtUtc: nowUtc,
  };
}

function isUniqueViolation(err: unknown): boolean {
  return (
    typeof err === 'object' &&
    err !== null &&
    'code' in err &&
    String((err as { code: unknown }).code) === '23505'
  );
}

/** Confirmation cases first, then earliest next-check first. */
function orderClaimed(cases: MonitoringCase[]): MonitoringCase[] {
  return [...cases].sort((a, b) => {
    const aConf = a.status === 'CONFIRMING' ? 1 : 0;
    const bConf = b.status === 'CONFIRMING' ? 1 : 0;
    if (aConf !== bConf) return bConf - aConf;
    return (a.nextCheckAtUtc ?? '').localeCompare(b.nextCheckAtUtc ?? '');
  });
}

export class PostgresDatabase implements PersistenceDatabase {
  private readonly pool: Pool;
  private repos: Repositories | null = null;

  constructor(connectionString: string) {
    this.pool = new Pool({ connectionString });
  }

  private readonly query = async (
    text: string,
    values: readonly unknown[] = [],
  ): Promise<Row[]> => {
    const result = await this.pool.query<Row>(text, values as unknown[]);
    return result.rows;
  };

  private readonly run = async (text: string, values: readonly unknown[] = []): Promise<number> => {
    const result = await this.pool.query(text, values as unknown[]);
    return result.rowCount ?? 0;
  };

  async migrate(): Promise<void> {
    for (const stmt of ddlStatements('postgres')) {
      await this.pool.query(stmt);
    }
    // No blanket ERROR_BACKOFF -> UNKNOWN_BACKOFF reclassify — it re-fires on every startup
    // and cannot distinguish a genuine operational ERROR_BACKOFF from a legacy row. Both
    // backoff states share the same short retry ladder, so legacy rows retry promptly.
  }

  async ping(): Promise<boolean> {
    const rows = await this.query(`SELECT 1 AS ok`);
    return rows.length === 1;
  }

  repositories(): Repositories {
    if (this.repos === null) {
      this.repos = {
        owner: this.makeOwnerRepo(),
        cases: this.makeCaseRepo(),
        checks: this.makeCheckRepo(),
        updates: this.makeUpdateRepo(),
        outbox: this.makeOutboxRepo(),
        health: this.makeHealthRepo(),
        breakerState: this.makeBreakerStateRepo(),
        businessConnections: this.makeBusinessConnectionRepo(),
        clientLinks: this.makeClientLinkRepo(),
        clients: this.makeClientsRepo(),
        deletionWatches: this.makeDeletionWatchRepo(),
      };
    }
    return this.repos;
  }

  async close(): Promise<void> {
    await this.pool.end();
  }

  private makeClientsRepo(): ClientsRepository {
    const { query, run } = this;
    return {
      async upsert(identity: NewClientIdentity, nowUtc: string): Promise<void> {
        await run(
          `INSERT INTO clients
             (client_chat_id, business_connection_id, username, first_name, last_name, updated_at_utc)
           VALUES ($1, $2, $3, $4, $5, $6)
           ON CONFLICT (client_chat_id) DO UPDATE SET
             business_connection_id = EXCLUDED.business_connection_id,
             username = EXCLUDED.username,
             first_name = EXCLUDED.first_name,
             last_name = EXCLUDED.last_name,
             updated_at_utc = EXCLUDED.updated_at_utc`,
          [
            identity.clientChatId,
            identity.businessConnectionId,
            identity.username,
            identity.firstName,
            identity.lastName,
            nowUtc,
          ],
        );
      },
      async findByChatId(clientChatId: number): Promise<ClientIdentity | null> {
        const rows = await query(`SELECT * FROM clients WHERE client_chat_id = $1`, [clientChatId]);
        const row = rows[0];
        return row === undefined ? null : rowToClientIdentity(row);
      },
      async listAll(): Promise<ClientIdentity[]> {
        const rows = await query(`SELECT * FROM clients`);
        return rows.map(rowToClientIdentity);
      },
    };
  }

  /**
   * The deletion-watch feature (/ban) is implemented for the SQLite driver only — the bot
   * runs on SQLite locally and the Postgres/cloud path is unused (a logged-in Instagram
   * session can only run on a residential IP, never a datacenter host). If Postgres is ever
   * revived, port `makeDeletionWatchRepo` from sqlite-database.ts here. Until then these
   * methods fail loudly rather than silently no-op, so a misconfiguration is obvious.
   */
  private makeDeletionWatchRepo(): DeletionWatchRepository {
    const fail = async (): Promise<never> => {
      throw new AppError(
        'DB_ERROR',
        'Deletion watches (/ban) require the SQLite driver; the Postgres path is unused.',
      );
    };
    return {
      create: fail,
      findById: fail,
      findActiveByNormalizedUsername: fail,
      listActive: fail,
      countActive: fail,
      claimDue: fail,
      save: fail,
      releaseLease: fail,
      clearByNormalizedUsername: fail,
    };
  }

  private makeBusinessConnectionRepo(): BusinessConnectionRepository {
    const { query, run } = this;
    return {
      async upsert(c: BusinessConnection): Promise<void> {
        await run(
          `INSERT INTO business_connections
             (id, owner_telegram_user_id, user_chat_id, is_enabled, can_reply,
              can_read_messages, can_delete_sent_messages, can_delete_all_messages,
              created_at_utc, updated_at_utc)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9)
           ON CONFLICT (id) DO UPDATE SET
             owner_telegram_user_id = EXCLUDED.owner_telegram_user_id,
             user_chat_id = EXCLUDED.user_chat_id,
             is_enabled = EXCLUDED.is_enabled,
             can_reply = EXCLUDED.can_reply,
             can_read_messages = EXCLUDED.can_read_messages,
             can_delete_sent_messages = EXCLUDED.can_delete_sent_messages,
             can_delete_all_messages = EXCLUDED.can_delete_all_messages,
             updated_at_utc = EXCLUDED.updated_at_utc`,
          [
            c.id,
            c.userId,
            c.userChatId,
            boolToDb(c.isEnabled, 'postgres'),
            boolToDb(c.rights.canReply, 'postgres'),
            boolToDb(c.rights.canReadMessages, 'postgres'),
            boolToDb(c.rights.canDeleteSentMessages, 'postgres'),
            boolToDb(c.rights.canDeleteAllMessages, 'postgres'),
            c.updatedAtUtc,
          ],
        );
      },
      async findById(id: string): Promise<BusinessConnection | null> {
        const rows = await query(`SELECT * FROM business_connections WHERE id = $1`, [id]);
        const row = rows[0];
        return row === undefined ? null : rowToBusinessConnection(row);
      },
      async findLatestEnabled(): Promise<BusinessConnection | null> {
        const rows = await query(
          `SELECT * FROM business_connections WHERE is_enabled = TRUE
           ORDER BY updated_at_utc DESC LIMIT 1`,
        );
        const row = rows[0];
        return row === undefined ? null : rowToBusinessConnection(row);
      },
    };
  }

  private makeClientLinkRepo(): ClientChatLinkRepository {
    const { query, run } = this;
    return {
      async create(input: NewClientChatLink, nowUtc: string): Promise<ClientChatLink> {
        // The upsert deliberately never rewrites client_chat_id. The WHERE guard turns a link
        // that belongs to a DIFFERENT client chat into a no-op instead of a silent steal, and the
        // SELECT below then hands the caller the stored row so it can refuse. Kept byte-for-byte
        // in meaning with the SQLite driver.
        await run(
          `INSERT INTO client_chat_links
             (id, monitor_id, source_type, client_chat_id, business_connection_id,
              owner_telegram_user_id, source_message_id, client_delivery_status,
              created_at_utc, updated_at_utc)
           VALUES ($1,$2,$3,$4,$5,$6,$7,'BUSINESS_DELIVERY_NOT_REQUIRED',$8,$8)
           ON CONFLICT (monitor_id) DO UPDATE SET
             source_type = EXCLUDED.source_type,
             business_connection_id = EXCLUDED.business_connection_id,
             owner_telegram_user_id = EXCLUDED.owner_telegram_user_id,
             source_message_id = EXCLUDED.source_message_id,
             updated_at_utc = EXCLUDED.updated_at_utc
           WHERE client_chat_links.client_chat_id = EXCLUDED.client_chat_id`,
          [
            generateId(),
            input.monitorId,
            input.sourceType,
            input.clientChatId,
            input.businessConnectionId,
            input.ownerTelegramUserId,
            input.sourceMessageId,
            nowUtc,
          ],
        );
        const rows = await query(`SELECT * FROM client_chat_links WHERE monitor_id = $1`, [
          input.monitorId,
        ]);
        return rowToClientLink(rows[0] as Row);
      },
      async findByMonitorId(monitorId: string): Promise<ClientChatLink | null> {
        const rows = await query(`SELECT * FROM client_chat_links WHERE monitor_id = $1`, [
          monitorId,
        ]);
        const row = rows[0];
        return row === undefined ? null : rowToClientLink(row);
      },
      async listAll(): Promise<ClientChatLink[]> {
        const rows = await query(`SELECT * FROM client_chat_links ORDER BY created_at_utc ASC`);
        return rows.map(rowToClientLink);
      },
      async updateDeliveryStatus(
        monitorId: string,
        status: BusinessDeliveryStatus,
        nowUtc: string,
      ): Promise<void> {
        await run(
          `UPDATE client_chat_links SET client_delivery_status = $1, updated_at_utc = $2
           WHERE monitor_id = $3`,
          [status, nowUtc, monitorId],
        );
      },
    };
  }

  private makeOwnerRepo(): OwnerRepository {
    const { query, run } = this;
    return {
      async getOwnerTelegramId(): Promise<number | null> {
        const rows = await query(`SELECT telegram_user_id FROM owner WHERE id = 1`);
        const row = rows[0];
        return row === undefined ? null : Number(row['telegram_user_id']);
      },
      async claimOwner(telegramUserId: number, pairedAtUtc: string): Promise<boolean> {
        const changed = await run(
          `INSERT INTO owner (id, telegram_user_id, paired_at_utc)
           VALUES (1, $1, $2)
           ON CONFLICT (id) DO NOTHING`,
          [telegramUserId, pairedAtUtc],
        );
        return changed > 0;
      },
    };
  }

  private makeCaseRepo(): CaseRepository {
    const { query, run } = this;
    return {
      async create(input: NewCaseInput, nowUtc: string): Promise<MonitoringCase> {
        const record = newCaseFrom(input, nowUtc);
        const placeholders = caseValues(record)
          .map((_, i) => `$${i + 1}`)
          .join(', ');
        try {
          await run(
            `INSERT INTO monitoring_cases (${CASE_COLUMNS}) VALUES (${placeholders})`,
            caseValues(record),
          );
        } catch (err) {
          if (isUniqueViolation(err)) {
            throw new AppError(
              'DUPLICATE_CASE',
              `A case for @${input.normalizedUsername} is already being monitored.`,
              input.normalizedUsername,
            );
          }
          throw new AppError('DB_ERROR', `Failed to create case: ${String(err)}`);
        }
        return record;
      },

      async findById(id: string): Promise<MonitoringCase | null> {
        const rows = await query(`SELECT * FROM monitoring_cases WHERE id = $1`, [id]);
        const row = rows[0];
        return row === undefined ? null : rowToCase(row);
      },

      async findActiveByNormalizedUsername(username: string): Promise<MonitoringCase | null> {
        const rows = await query(
          `SELECT * FROM monitoring_cases
           WHERE normalized_username = $1 AND ${ACTIVE_FILTER}
           LIMIT 1`,
          [username],
        );
        const row = rows[0];
        return row === undefined ? null : rowToCase(row);
      },

      async listByStatuses(statuses: readonly CaseStatus[]): Promise<MonitoringCase[]> {
        if (statuses.length === 0) return [];
        const rows = await query(
          `SELECT * FROM monitoring_cases
           WHERE status = ANY($1::text[])
           ORDER BY created_at_utc ASC`,
          [statuses as readonly string[]],
        );
        return rows.map(rowToCase);
      },

      async countByStatuses(statuses: readonly CaseStatus[]): Promise<number> {
        if (statuses.length === 0) return 0;
        const rows = await query(
          `SELECT COUNT(*) AS n FROM monitoring_cases WHERE status = ANY($1::text[])`,
          [statuses as readonly string[]],
        );
        const row = rows[0];
        return row === undefined ? 0 : Number(row['n']);
      },

      async claimDueCases(params: ClaimDueParams): Promise<MonitoringCase[]> {
        const rows = await query(
          `WITH due AS (
             SELECT id FROM monitoring_cases
           WHERE status IN ('MONITORING','CONFIRMING','ERROR_BACKOFF','UNKNOWN_BACKOFF')
               AND next_check_at_utc IS NOT NULL
               AND next_check_at_utc <= $1
               AND (lease_owner IS NULL OR lease_expires_at_utc <= $1)
             ORDER BY (status = 'CONFIRMING') DESC, next_check_at_utc ASC
             LIMIT $2
             FOR UPDATE SKIP LOCKED
           )
           UPDATE monitoring_cases c
             SET lease_owner = $3, lease_expires_at_utc = $4, updated_at_utc = $1
           FROM due
           WHERE c.id = due.id
           RETURNING c.*`,
          [params.nowUtc, params.limit, params.leaseOwner, params.leaseExpiresUtc],
        );
        return orderClaimed(rows.map(rowToCase));
      },

      async save(next: MonitoringCase): Promise<void> {
        const cols = [
          'normalized_username',
          'original_input',
          'started_at_utc',
          'status',
          'confirmation_count',
          'next_check_at_utc',
          'last_checked_at_utc',
          'last_result',
          'consecutive_unknown_count',
          'error_backoff_until_utc',
          'confirmed_at_utc',
          'cleared_at_utc',
          'notification_claimed_at_utc',
          'notification_sent_at_utc',
          'telegram_message_id',
          'screenshot_status',
          'lease_owner',
          'lease_expires_at_utc',
          'created_at_utc',
          'updated_at_utc',
        ];
        // caseValues() puts id first; the remaining values line up with `cols`.
        const values = caseValues(next);
        const setClause = cols.map((c, i) => `${c} = $${i + 1}`).join(', ');
        await run(`UPDATE monitoring_cases SET ${setClause} WHERE id = $${cols.length + 1}`, [
          ...values.slice(1),
          next.id,
        ]);
      },

      async releaseLease(id: string, nowUtc: string): Promise<void> {
        await run(
          `UPDATE monitoring_cases
             SET lease_owner = NULL, lease_expires_at_utc = NULL, updated_at_utc = $2
           WHERE id = $1`,
          [id, nowUtc],
        );
      },

      async clearByNormalizedUsername(
        username: string,
        clearedAtUtc: string,
      ): Promise<MonitoringCase | null> {
        const rows = await query(
          `UPDATE monitoring_cases
             SET status = 'CLEARED', cleared_at_utc = $2, next_check_at_utc = NULL,
                 lease_owner = NULL, lease_expires_at_utc = NULL, updated_at_utc = $2
           WHERE id = (
             SELECT id FROM monitoring_cases
             WHERE normalized_username = $1 AND ${ACTIVE_FILTER}
             LIMIT 1
           )
           RETURNING *`,
          [username, clearedAtUtc],
        );
        const row = rows[0];
        return row === undefined ? null : rowToCase(row);
      },

      async claimNotification(caseId: string, claimedAtUtc: string): Promise<boolean> {
        const changed = await run(
          `UPDATE monitoring_cases
             SET notification_claimed_at_utc = $2, updated_at_utc = $2
           WHERE id = $1 AND notification_claimed_at_utc IS NULL`,
          [caseId, claimedAtUtc],
        );
        return changed > 0;
      },
    };
  }

  private makeCheckRepo(): CheckRepository {
    const { query, run } = this;
    return {
      async insert(input: NewCheckInput): Promise<CheckRecord> {
        const record: CheckRecord = { id: generateId(), ...input };
        await run(
          `INSERT INTO monitoring_checks
             (id, case_id, checked_at_utc, classification, final_url, response_status,
              duration_ms, active_signals, gone_signals, error_code, confirmation_seq)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
          [
            record.id,
            record.caseId,
            record.checkedAtUtc,
            record.classification,
            record.finalUrl,
            record.responseStatus,
            record.durationMs,
            serializeJsonArray(record.activeSignals),
            serializeJsonArray(record.goneSignals),
            record.errorCode,
            record.confirmationSeq,
          ],
        );
        return record;
      },

      async countByCase(caseId: string): Promise<number> {
        const rows = await query(`SELECT COUNT(*) AS n FROM monitoring_checks WHERE case_id = $1`, [
          caseId,
        ]);
        const row = rows[0];
        return row === undefined ? 0 : Number(row['n']);
      },
    };
  }

  private makeUpdateRepo(): TelegramUpdateRepository {
    const { run } = this;
    return {
      async registerIfNew(updateId: number, receivedAtUtc: string): Promise<boolean> {
        const changed = await run(
          `INSERT INTO telegram_updates (update_id, received_at_utc)
           VALUES ($1, $2)
           ON CONFLICT (update_id) DO NOTHING`,
          [updateId, receivedAtUtc],
        );
        return changed > 0;
      },
    };
  }

  private makeOutboxRepo(): OutboxRepository {
    const { query, run } = this;
    return {
      async enqueue(item: EnqueueOutbox): Promise<OutboxItem> {
        const rows = await query(
          `INSERT INTO notification_outbox
             (id, case_id, kind, status, attempts, created_at_utc, updated_at_utc)
           VALUES ($1, $2, $3, 'PENDING', 0, $4, $4)
           ON CONFLICT (case_id, kind) DO UPDATE SET case_id = EXCLUDED.case_id
           RETURNING *`,
          [generateId(), item.caseId, item.kind, item.createdAtUtc],
        );
        const row = rows[0];
        if (row === undefined) {
          throw new AppError('DB_ERROR', 'enqueue returned no row');
        }
        return rowToOutbox(row);
      },

      async findByCase(caseId: string): Promise<OutboxItem[]> {
        const rows = await query(
          `SELECT * FROM notification_outbox WHERE case_id = $1 ORDER BY created_at_utc ASC`,
          [caseId],
        );
        return rows.map(rowToOutbox);
      },

      async claimNextPending(nowUtc: string): Promise<OutboxItem | null> {
        const rows = await query(
          `UPDATE notification_outbox
             SET status = 'CLAIMED', attempts = attempts + 1,
                 claimed_at_utc = $1, updated_at_utc = $1
           WHERE id = (
             SELECT id FROM notification_outbox
             WHERE status = 'PENDING'
             ORDER BY created_at_utc ASC
             LIMIT 1
             FOR UPDATE SKIP LOCKED
           )
           RETURNING *`,
          [nowUtc],
        );
        const row = rows[0];
        return row === undefined ? null : rowToOutbox(row);
      },

      async markSent(
        id: string,
        sentAtUtc: string,
        telegramMessageId: number | null,
      ): Promise<void> {
        await run(
          `UPDATE notification_outbox
             SET status = 'SENT', sent_at_utc = $2,
                 telegram_message_id = $3, updated_at_utc = $2
           WHERE id = $1`,
          [id, sentAtUtc, telegramMessageId],
        );
      },

      async markFailed(id: string, error: string, nowUtc: string): Promise<void> {
        // NEVER demote a SENT row — see the SQLite implementation for why: a post-send step that
        // throws would otherwise turn delivered into FAILED, and the sweep would re-send it.
        await run(
          `UPDATE notification_outbox
             SET status = 'FAILED', last_error = $2, updated_at_utc = $3
           WHERE id = $1 AND status <> 'SENT'`,
          [id, error, nowUtc],
        );
      },

      async reopenFailed(caseId: string, kind: OutboxKind, nowUtc: string): Promise<boolean> {
        // created_at_utc is refreshed so the revived row queues (and ages) from now — otherwise
        // `oldestPendingAgeMs` would report the original, long-past timestamp as backlog age.
        const changed = await run(
          `UPDATE notification_outbox
             SET status = 'PENDING', attempts = 0, claimed_at_utc = NULL, last_error = NULL,
                 created_at_utc = $3, updated_at_utc = $3
           WHERE case_id = $1 AND kind = $2 AND status = 'FAILED'`,
          [caseId, kind, nowUtc],
        );
        return changed > 0;
      },

      async requeueStale(olderThanUtc: string, nowUtc: string): Promise<number> {
        return run(
          `UPDATE notification_outbox
             SET status = 'PENDING', updated_at_utc = $2
           WHERE status = 'CLAIMED'
             AND claimed_at_utc IS NOT NULL
             AND claimed_at_utc <= $1`,
          [olderThanUtc, nowUtc],
        );
      },

      async countPending(): Promise<number> {
        const rows = await query(
          `SELECT COUNT(*) AS n FROM notification_outbox WHERE status = 'PENDING'`,
        );
        const row = rows[0];
        return row === undefined ? 0 : Number(row['n']);
      },

      async oldestPendingAgeMs(nowUtc: string): Promise<number | null> {
        const rows = await query(
          `SELECT MIN(created_at_utc) AS oldest FROM notification_outbox WHERE status = 'PENDING'`,
        );
        const row = rows[0];
        const oldest = row === undefined ? null : row['oldest'];
        if (oldest === null || oldest === undefined) return null;
        const ageMs = Date.parse(nowUtc) - Date.parse(String(oldest));
        return Number.isNaN(ageMs) ? null : Math.max(0, ageMs);
      },
    };
  }

  private makeBreakerStateRepo(): BreakerStateRepository {
    const { query, run } = this;
    return {
      async get(name: string): Promise<BreakerStateRecord | null> {
        const rows = await query(`SELECT * FROM breaker_state WHERE name = $1`, [name]);
        const row = rows[0];
        return row === undefined ? null : rowToBreakerState(row);
      },

      async save(record: BreakerStateRecord): Promise<void> {
        await run(
          `INSERT INTO breaker_state
             (name, state, opened_at_utc, cooldown_ms, consecutive, egress_route, updated_at_utc)
           VALUES ($1,$2,$3,$4,$5,$6,$7)
           ON CONFLICT (name) DO UPDATE SET
             state = EXCLUDED.state,
             opened_at_utc = EXCLUDED.opened_at_utc,
             cooldown_ms = EXCLUDED.cooldown_ms,
             consecutive = EXCLUDED.consecutive,
             egress_route = EXCLUDED.egress_route,
             updated_at_utc = EXCLUDED.updated_at_utc`,
          [
            record.name,
            record.state,
            record.openedAtUtc,
            record.cooldownMs,
            record.consecutive,
            record.egressRoute,
            record.updatedAtUtc,
          ],
        );
      },
    };
  }

  private makeHealthRepo(): SchedulerHealthRepository {
    const { query, run } = this;
    return {
      async get(name: string): Promise<SchedulerHealth | null> {
        const rows = await query(`SELECT * FROM scheduler_health WHERE name = $1`, [name]);
        const row = rows[0];
        return row === undefined ? null : rowToHealth(row);
      },

      async upsert(health: SchedulerHealth): Promise<void> {
        await run(
          `INSERT INTO scheduler_health
             (name, last_scheduler_run_utc, last_successful_check_utc, last_control_ok_utc,
              recent_unknown_rate, browser_restarts, detector_unhealthy,
              last_warning_sent_utc, updated_at_utc)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
           ON CONFLICT (name) DO UPDATE SET
             last_scheduler_run_utc = EXCLUDED.last_scheduler_run_utc,
             last_successful_check_utc = EXCLUDED.last_successful_check_utc,
             last_control_ok_utc = EXCLUDED.last_control_ok_utc,
             recent_unknown_rate = EXCLUDED.recent_unknown_rate,
             browser_restarts = EXCLUDED.browser_restarts,
             detector_unhealthy = EXCLUDED.detector_unhealthy,
             last_warning_sent_utc = EXCLUDED.last_warning_sent_utc,
             updated_at_utc = EXCLUDED.updated_at_utc`,
          [
            health.name,
            health.lastSchedulerRunUtc,
            health.lastSuccessfulCheckUtc,
            health.lastControlOkUtc,
            health.recentUnknownRate,
            health.browserRestarts,
            boolToDb(health.detectorUnhealthy, 'postgres'),
            health.lastWarningSentUtc,
            health.updatedAtUtc,
          ],
        );
      },
    };
  }
}
