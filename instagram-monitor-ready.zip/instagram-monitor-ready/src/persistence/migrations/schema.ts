/**
 * Database schema. `ddlStatements(driver)` returns idempotent CREATE TABLE / INDEX
 * statements for the given driver. Column semantics are identical across drivers;
 * only physical types differ (sqlite: TEXT/INTEGER/REAL; postgres: TEXT/BIGINT/BOOLEAN/REAL).
 *
 * Storage conventions (both drivers):
 *  - every `*_utc` column is a TEXT ISO-8601 UTC string
 *  - `active_signals` / `gone_signals` are TEXT JSON arrays
 *  - booleans are INTEGER 0/1 in sqlite and BOOLEAN in postgres
 */

export type DbDriver = 'sqlite' | 'postgres';

interface Types {
  /** 64-bit id (telegram ids, message ids). */
  bigint: string;
  /** boolean column type. */
  bool: string;
  /** default literal for a false boolean. */
  boolFalse: string;
}

function typesFor(driver: DbDriver): Types {
  if (driver === 'postgres') {
    return { bigint: 'BIGINT', bool: 'BOOLEAN', boolFalse: 'FALSE' };
  }
  return { bigint: 'INTEGER', bool: 'INTEGER', boolFalse: '0' };
}

export function ddlStatements(driver: DbDriver): string[] {
  const t = typesFor(driver);

  return [
    // Single-owner pairing table. A fixed id=1 row enforces "at most one owner".
    `CREATE TABLE IF NOT EXISTS owner (
      id INTEGER PRIMARY KEY,
      telegram_user_id ${t.bigint} NOT NULL UNIQUE,
      paired_at_utc TEXT
    )`,

    // One monitored account and its full lifecycle state.
    `CREATE TABLE IF NOT EXISTS monitoring_cases (
      id TEXT PRIMARY KEY,
      normalized_username TEXT NOT NULL,
      original_input TEXT NOT NULL,
      started_at_utc TEXT NOT NULL,
      status TEXT NOT NULL,
      confirmation_count INTEGER NOT NULL DEFAULT 0,
      next_check_at_utc TEXT,
      last_checked_at_utc TEXT,
      last_result TEXT,
      consecutive_unknown_count INTEGER NOT NULL DEFAULT 0,
      error_backoff_until_utc TEXT,
      confirmed_at_utc TEXT,
      cleared_at_utc TEXT,
      notification_claimed_at_utc TEXT,
      notification_sent_at_utc TEXT,
      telegram_message_id ${t.bigint},
      screenshot_status TEXT NOT NULL DEFAULT 'NONE',
      lease_owner TEXT,
      lease_expires_at_utc TEXT,
      created_at_utc TEXT NOT NULL,
      updated_at_utc TEXT NOT NULL
    )`,

    // At most one *active* (non-terminal) case per username. Partial index is
    // supported by both sqlite and postgres.
    `CREATE UNIQUE INDEX IF NOT EXISTS ux_active_username
      ON monitoring_cases (normalized_username)
      WHERE status NOT IN ('NOTIFIED','CLEARED')`,

    // Scheduler scan: due cases by status + next check time.
    `CREATE INDEX IF NOT EXISTS ix_cases_status_next
      ON monitoring_cases (status, next_check_at_utc)`,

    // Append-only audit of every browser check.
    `CREATE TABLE IF NOT EXISTS monitoring_checks (
      id TEXT PRIMARY KEY,
      case_id TEXT NOT NULL,
      checked_at_utc TEXT NOT NULL,
      classification TEXT NOT NULL,
      final_url TEXT,
      response_status INTEGER,
      duration_ms INTEGER NOT NULL,
      active_signals TEXT NOT NULL DEFAULT '[]',
      gone_signals TEXT NOT NULL DEFAULT '[]',
      error_code TEXT,
      confirmation_seq INTEGER
    )`,

    `CREATE INDEX IF NOT EXISTS ix_checks_case
      ON monitoring_checks (case_id)`,

    // Telegram update dedup ledger.
    `CREATE TABLE IF NOT EXISTS telegram_updates (
      update_id ${t.bigint} PRIMARY KEY,
      received_at_utc TEXT NOT NULL
    )`,

    // Durable notification send queue; one row per (case, kind).
    `CREATE TABLE IF NOT EXISTS notification_outbox (
      id TEXT PRIMARY KEY,
      case_id TEXT NOT NULL,
      kind TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING',
      attempts INTEGER NOT NULL DEFAULT 0,
      claimed_at_utc TEXT,
      sent_at_utc TEXT,
      last_error TEXT,
      telegram_message_id ${t.bigint},
      created_at_utc TEXT NOT NULL,
      updated_at_utc TEXT NOT NULL,
      UNIQUE (case_id, kind)
    )`,

    // Scheduler / detector health snapshot, keyed by name.
    `CREATE TABLE IF NOT EXISTS scheduler_health (
      name TEXT PRIMARY KEY,
      last_scheduler_run_utc TEXT,
      last_successful_check_utc TEXT,
      last_control_ok_utc TEXT,
      recent_unknown_rate REAL NOT NULL DEFAULT 0,
      browser_restarts INTEGER NOT NULL DEFAULT 0,
      detector_unhealthy ${t.bool} NOT NULL DEFAULT ${t.boolFalse},
      last_warning_sent_utc TEXT,
      updated_at_utc TEXT NOT NULL
    )`,

    // Durable fleet-wide back-off, one row per breaker. Deliberately NOT folded into
    // scheduler_health: that row has no column able to carry a phase, an open-time, a cooldown
    // or a streak, and the health monitor rewrites every one of its columns on each pass.
    // Written on breaker state transitions only, never on the probe hot path.
    `CREATE TABLE IF NOT EXISTS breaker_state (
      name TEXT PRIMARY KEY,
      state TEXT NOT NULL,
      opened_at_utc TEXT,
      cooldown_ms INTEGER NOT NULL,
      consecutive INTEGER NOT NULL DEFAULT 0,
      egress_route TEXT NOT NULL DEFAULT '',
      updated_at_utc TEXT NOT NULL
    )`,

    // Telegram Business connections (owner connected the bot to their Business account).
    `CREATE TABLE IF NOT EXISTS business_connections (
      id TEXT PRIMARY KEY,
      owner_telegram_user_id ${t.bigint} NOT NULL,
      user_chat_id ${t.bigint},
      is_enabled ${t.bool} NOT NULL DEFAULT ${t.boolFalse},
      can_reply ${t.bool} NOT NULL DEFAULT ${t.boolFalse},
      can_read_messages ${t.bool} NOT NULL DEFAULT ${t.boolFalse},
      can_delete_sent_messages ${t.bool} NOT NULL DEFAULT ${t.boolFalse},
      can_delete_all_messages ${t.bool} NOT NULL DEFAULT ${t.boolFalse},
      created_at_utc TEXT NOT NULL,
      updated_at_utc TEXT NOT NULL
    )`,

    // SEPARATE deletion-watch feature (/ban): watch an ACTIVE account for going GONE.
    // Independent of monitoring_cases so both can watch the same username at once.
    `CREATE TABLE IF NOT EXISTS deletion_watches (
      id TEXT PRIMARY KEY,
      normalized_username TEXT NOT NULL,
      original_input TEXT NOT NULL,
      started_at_utc TEXT NOT NULL,
      status TEXT NOT NULL,
      confirmation_count INTEGER NOT NULL DEFAULT 0,
      consecutive_unknown_count INTEGER NOT NULL DEFAULT 0,
      next_check_at_utc TEXT,
      last_checked_at_utc TEXT,
      last_result TEXT,
      confirmed_at_utc TEXT,
      cleared_at_utc TEXT,
      notified_at_utc TEXT,
      telegram_message_id ${t.bigint},
      lease_owner TEXT,
      lease_expires_at_utc TEXT,
      created_at_utc TEXT NOT NULL,
      updated_at_utc TEXT NOT NULL
    )`,

    // At most one *active* deletion watch per username.
    `CREATE UNIQUE INDEX IF NOT EXISTS ux_active_deletion_username
      ON deletion_watches (normalized_username)
      WHERE status NOT IN ('NOTIFIED','CLEARED')`,

    // Scheduler scan for due deletion watches.
    `CREATE INDEX IF NOT EXISTS ix_deletion_status_next
      ON deletion_watches (status, next_check_at_utc)`,

    // Client display-identity for the /clients view, keyed by the client's chat id.
    // Captured from business messages and backfilled via getChat; owner-facing labelling only.
    `CREATE TABLE IF NOT EXISTS clients (
      client_chat_id ${t.bigint} PRIMARY KEY,
      business_connection_id TEXT,
      username TEXT,
      first_name TEXT,
      last_name TEXT,
      updated_at_utc TEXT NOT NULL
    )`,

    // Links a monitor (case) to the client conversation it was started from. One per monitor.
    `CREATE TABLE IF NOT EXISTS client_chat_links (
      id TEXT PRIMARY KEY,
      monitor_id TEXT NOT NULL UNIQUE,
      source_type TEXT NOT NULL,
      client_chat_id ${t.bigint} NOT NULL,
      business_connection_id TEXT NOT NULL,
      owner_telegram_user_id ${t.bigint} NOT NULL,
      source_message_id ${t.bigint},
      client_delivery_status TEXT NOT NULL DEFAULT 'BUSINESS_DELIVERY_NOT_REQUIRED',
      created_at_utc TEXT NOT NULL,
      updated_at_utc TEXT NOT NULL
    )`,
  ];
}
