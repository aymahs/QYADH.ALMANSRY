/**
 * Application composition root.
 *
 * `buildApp(config)` wires every module together — persistence, browser detector,
 * Telegram client, command router, ingress (webhook or polling), background workers,
 * and the health monitor — and returns a lifecycle handle with `start()` / `stop()`.
 */

import type { AppConfig } from '../config/config';
import { collectSecrets } from '../config/config';
import { AppError, VISIBLE_COMMANDS, ALLOWED_UPDATES } from '../domain';
import type { MonitoringCase, TelegramUpdate } from '../domain';
import { NetworkCorrectedClock } from '../core/network-clock';
import { createLogger } from '../logging/logger';
import { createDatabase } from '../persistence';
import {
  BrowserManager,
  PlaywrightDetector,
  TieredDetector,
  CircuitBreaker,
  ProxySwitch,
  EGRESS_BREAKER_NAME,
  backOffForRoute,
} from '../instagram';
import type { DurableBreakerState } from '../instagram';
// Deep imports: the governor is deliberately not part of the instagram barrel, so nothing that
// only needs a budget reading has to pull Playwright into scope.
import { BrowserLoadGovernor } from '../instagram/load-governor';
import {
  ensureGovernorStateDir,
  fileGovernorStore,
  governorStatePath,
} from '../instagram/load-governor-store';
import { HttpTelegramClient } from '../bot/telegram-client';
import { CommandRouter } from '../bot/commands';
import { OwnerAuthorizer } from '../bot/authorization';
import { buildDiscordIntegration, type DiscordIntegration } from '../bot/discord';
import { MonitorWorker } from '../monitoring/scheduler';
import { DeletionWorker } from '../monitoring/deletion';
import { OutboxWorker } from '../notifications/outbox';
import { HealthMonitor } from '../health';
import { recoverOnStartup } from '../monitoring/state-machine/recovery';
import { createWalletFeature, walletSecrets, type WalletFeature } from '../wallets';
import { createWebhookServer } from './webhook-server';
import type { FastifyInstance } from 'fastify';
import { PollingLoop } from './polling';

export interface App {
  start(): Promise<void>;
  stop(): Promise<void>;
}

/** Statuses that must be passed through startup recovery. */
const RECOVERABLE_STATUSES = [
  'MONITORING',
  'CONFIRMING',
  'ERROR_BACKOFF',
  'UNKNOWN_BACKOFF',
  'CONFIRMED',
  'NOTIFYING',
] as const;

const OUTBOX_STALE_CLAIM_MS = 10 * 60 * 1000;
const MONITOR_INTERVAL_MS = 1000;
/**
 * How long a confirmed recovery sits in the queue before anyone is told. It is pure dead time on
 * the client's critical path, and an idle tick costs one indexed claim query and zero Telegram
 * calls — the worker only ever sends what the queue actually holds.
 */
const OUTBOX_INTERVAL_MS = 300;
const HEALTH_INTERVAL_MS = 5 * 60 * 1000;
/** How long shutdown waits for detached command work (/bulkunban) before abandoning it. */
const COMMAND_DRAIN_TIMEOUT_MS = 30 * 1000;

/** True when recovery changed anything beyond the always-refreshed updatedAtUtc. */
function recoveryChanged(before: MonitoringCase, after: MonitoringCase): boolean {
  return (
    before.leaseOwner !== after.leaseOwner ||
    before.leaseExpiresAtUtc !== after.leaseExpiresAtUtc ||
    before.status !== after.status ||
    before.confirmationCount !== after.confirmationCount ||
    before.nextCheckAtUtc !== after.nextCheckAtUtc
  );
}

export function buildApp(config: AppConfig): App {
  // Wallet-feature secrets join the scrub list even though that feature loads its own config:
  // the keys living in the same process's env is what makes them scrubbable-worthy.
  const logger = createLogger({
    level: config.logLevel,
    secrets: [...collectSecrets(config), ...walletSecrets(process.env)],
  });
  // Corrects a skewed host clock (observed: a dev box 4.5h fast) against a trusted network
  // Date header so every Started/Confirmed/Last-check time is real. Startup recovery clamps
  // any future-dated started_at and pulls far-future next_check_at to now, so the correction
  // (or any clock discontinuity) can never strand a monitor or show a zero timer.
  const clock = new NetworkCorrectedClock();
  let clockTimer: NodeJS.Timeout | null = null;
  // Optional crypto-wallet tracker (its own bot, its own DB connection). Constructed in start()
  // so a misconfiguration degrades to an error log, never a crashed monitor.
  let wallets: WalletFeature | null = null;
  const db = createDatabase(config);
  const client = new HttpTelegramClient({ token: config.telegram.botToken, logger });
  // One shared egress switch: the browser, the HTTP probe, and both command surfaces all read
  // it, so /proxy on either platform moves all traffic together.
  const proxySwitch = new ProxySwitch(config);
  const browser = new BrowserManager({ config, logger, proxySwitch });
  const browserDetector = new PlaywrightDetector({ browser, config, logger });
  // ONE breaker for the whole process, shared by every detector, so back-off is genuinely
  // fleet-wide. A worker holding its own detector outside this would keep hammering a throttled
  // IP while everything else backed off — which is how the first residential IP was burned.
  //
  // Its state is DURABLE (wired to the store in start(), once repositories exist): a restart
  // mid-cooldown must resume the remaining back-off, not resume full-rate checking. Nothing
  // probes before start(), so transitions cannot be lost while this is still null.
  let persistBreaker: ((state: DurableBreakerState) => void) | null = null;
  // Writes are chained, never fired in parallel: two transitions in quick succession landing out
  // of order could leave a stale CLOSED row behind an OPEN one — the exact state that resumes
  // full-rate traffic against a throttled IP after the next restart.
  let breakerWrites: Promise<void> = Promise.resolve();
  const breaker = new CircuitBreaker({
    threshold: config.detection.breakerThreshold,
    initialCooldownMs: config.detection.breakerCooldownSeconds * 1000,
    maxCooldownMs: config.detection.breakerMaxCooldownSeconds * 1000,
    // The corrected clock, so a stored open-time is comparable with every other timestamp the
    // app writes (a skewed host clock is a known hazard here).
    now: () => clock.now().getTime(),
    onTransition: (state) => persistBreaker?.(state),
  });
  // ONE governor for the whole process, shared by every detector exactly like the breaker — and
  // for the same reason. The breaker is a reactive brake on THROTTLING; this is a budget on
  // VOLUME, which is the thing that actually burns the IP, and which the breaker is structurally
  // unable to see (an escalated browser probe SUCCEEDS, so it reports success and the breaker
  // never opens while load is 20-50x normal).
  //
  // DURABLE for the same reason the breaker is: an in-memory window resets on every boot, so a
  // crash loop would hand each incarnation a fresh full budget and the governor would become a
  // load amplifier in exactly the situation it exists for. Rehydrated here, before anything can
  // probe.
  const governorPath = governorStatePath(config.db.sqlitePath);
  ensureGovernorStateDir(governorPath, logger);
  const governor = new BrowserLoadGovernor({
    capacity: config.detection.browserLoadsPerHour,
    routineFraction: config.detection.browserLoadRoutineFraction,
    now: () => clock.now().getTime(),
    logger,
    store: fileGovernorStore(governorPath, logger),
  });
  governor.rehydrate();

  // Fast HTTP polling with browser escalation for anything that must be trusted or captured,
  // behind a fleet-wide circuit breaker AND the fleet-wide browser-load budget.
  //
  // When the fast path is switched off this is still a TieredDetector (with `fastPath: false`)
  // rather than the bare browser detector. That is not cosmetic: the bare detector is not behind
  // the breaker OR the governor, so `FAST_PROBE=false` used to turn every routine check into an
  // ungoverned Chromium page load — the single most expensive configuration in the system, and
  // the only one with no brake on it at all.
  const detector = new TieredDetector({
    browserDetector,
    config,
    logger,
    proxySwitch,
    breaker,
    governor,
    fastPath: config.detection.fastProbe,
  });

  // The deletion watcher never uses the fast path — its alert fires on ACTIVE -> GONE, so an
  // INFERRED gone is not strong enough evidence. It shares the breaker AND the governor, so it
  // backs off with the rest of the fleet and its browser-only probes are counted against the same
  // hourly ceiling as everything else. Its own cadence (DELETION_INTERVAL_SECONDS) is what keeps
  // it from filling that ceiling on its own.
  const deletionDetector = new TieredDetector({
    browserDetector,
    config,
    logger,
    proxySwitch,
    breaker,
    governor,
    fastPath: false,
  });

  let server: FastifyInstance | null = null;
  let pollingLoop: PollingLoop | null = null;
  let monitorWorker: MonitorWorker | null = null;
  let deletionWorker: DeletionWorker | null = null;
  let outboxWorker: OutboxWorker | null = null;
  let healthTimer: NodeJS.Timeout | null = null;
  let discord: DiscordIntegration | null = null;
  let commandRouter: CommandRouter | null = null;
  let stopPromise: Promise<void> | null = null;

  async function start(): Promise<void> {
    // 0. Correct clock skew before any timestamp is written; resync hourly.
    const sync = await clock.sync();
    logger.info('clock synced', { ok: sync.ok, offsetMs: sync.offsetMs });
    clockTimer = setInterval(
      () => {
        void clock.sync().then((s) => logger.debug('clock resynced', { offsetMs: s.offsetMs }));
      },
      60 * 60 * 1000,
    );
    clockTimer.unref?.();

    // 1. Schema, then repositories.
    await db.migrate();
    const repos = db.repositories();

    // 1b. Optional Discord integration (dormant unless DISCORD_BOT_TOKEN is set). Purely
    //     additive: it mirrors alerts and exposes owner slash commands. The Telegram bot is
    //     unaffected. getChat is Telegram-backed and best-effort (for /clients identity backfill).
    discord = buildDiscordIntegration({
      config,
      repos,
      db,
      detector,
      clock,
      logger,
      getChat: (id: number) => client.getChat(id),
      proxySwitch,
    });

    // 2. Startup recovery: release stale leases, restart interrupted confirmation
    //    bursts, and requeue outbox items claimed by a dead process.
    const now = clock.now();
    const nowIso = now.toISOString();
    const toRecover = await repos.cases.listByStatuses(RECOVERABLE_STATUSES);
    for (const c of toRecover) {
      const recovered = recoverOnStartup(c, now);
      if (recoveryChanged(c, recovered)) {
        await repos.cases.save(recovered);
      }
    }
    const staleBeforeIso = new Date(now.getTime() - OUTBOX_STALE_CLAIM_MS).toISOString();
    const requeued = await repos.outbox.requeueStale(staleBeforeIso, nowIso);
    logger.info('startup recovery complete', {
      casesExamined: toRecover.length,
      outboxRequeued: requeued,
    });

    // 2b. Startup recovery for the FLEET-WIDE BACK-OFF. Restarts are exactly when the IP is most
    //     at risk: an in-memory breaker came back CLOSED with a zeroed streak, so a deploy or a
    //     crash loop mid-cooldown put the whole fleet back on a throttled IP at full rate.
    //     Must run before ingress and the workers — i.e. before anything can probe.
    //     Bind the breaker to the route this process is starting on before anything can probe.
    //     That baseline is what later lets a `/proxy` switch be told apart from a detector merely
    //     catching up to one; without it, a switch issued before the first probe would look like
    //     a first binding and silently carry the old route's block onto the new one.
    breaker.adoptRoute(proxySwitch.gen());
    const breakerStore = repos.breakerState ?? null;
    if (breakerStore === null) {
      logger.warn(
        'no breaker-state store on this driver; fleet-wide back-off will NOT survive a restart',
      );
    } else {
      const egressRoute = proxySwitch.describe();
      const stored = await breakerStore.get(EGRESS_BREAKER_NAME);
      const applicable = backOffForRoute(stored, egressRoute);
      if (stored !== null && applicable === null) {
        logger.info('stored back-off was earned on another egress route; starting clear', {
          storedRoute: stored.egressRoute,
          currentRoute: egressRoute,
        });
      }
      breaker.rehydrate(applicable);
      persistBreaker = (state): void => {
        breakerWrites = breakerWrites
          .then(() =>
            breakerStore.save({
              name: EGRESS_BREAKER_NAME,
              ...state,
              egressRoute: proxySwitch.describe(),
              updatedAtUtc: clock.now().toISOString(),
            }),
          )
          .catch((err: unknown) => {
            logger.error('failed to persist circuit-breaker state', {
              error: err instanceof Error ? err.message : String(err),
            });
          });
      };
      logger.info('fleet-wide back-off restored', { ...breaker.snapshot(), egressRoute });
    }

    // 3. Command handling.
    const auth = new OwnerAuthorizer({
      owner: repos.owner,
      pairingSecret: config.ownerPairingSecret,
      logger,
    });
    const router = new CommandRouter({
      client,
      repos,
      db,
      detector,
      auth,
      config,
      clock,
      logger,
      proxySwitch,
    });
    // Hoisted so shutdown can drain the router's detached work (see doStop). /bulkunban
    // acknowledges immediately and enrols in the background, so without this the browser and DB
    // close mid-batch and the enrolments — plus the summary the owner was promised — are lost.
    commandRouter = router;
    const ownerChatId = (): Promise<number | null> => repos.owner.getOwnerTelegramId();

    // 4. Best-effort command menu registration.
    try {
      await client.setMyCommands([...VISIBLE_COMMANDS]);
    } catch (err) {
      logger.warn('setMyCommands failed; continuing', {
        error: err instanceof Error ? err.message : 'unknown error',
      });
    }

    // 5. Ingress: webhook or polling — /healthz is served in both modes.
    const healthz = async (): Promise<{ ok: boolean; [k: string]: unknown }> => {
      try {
        const ok = await db.ping();
        return { ok };
      } catch {
        return { ok: false };
      }
    };
    const onUpdate = (update: TelegramUpdate): Promise<void> => router.handleUpdate(update);

    if (config.telegram.mode === 'webhook') {
      const base = config.telegram.publicBaseUrl;
      if (base === null) {
        // loadConfig guarantees this in webhook mode; guard for type safety.
        throw new AppError(
          'CONFIG_INVALID',
          'webhook mode requires PUBLIC_BASE_URL',
          'webhook mode requires PUBLIC_BASE_URL',
        );
      }
      server = createWebhookServer({
        secretToken: config.telegram.webhookSecret,
        onUpdate,
        healthz,
        logger,
      });
      await server.listen({ port: config.server.port, host: '0.0.0.0' });
      await client.setWebhook({
        url: `${base}/telegram/webhook`,
        secret_token: config.telegram.webhookSecret,
        allowed_updates: [...ALLOWED_UPDATES],
      });
    } else {
      // Best-effort: a transient Telegram failure here must not kill the service —
      // the polling loop retries with backoff and surfaces errors in the logs.
      try {
        await client.deleteWebhook();
      } catch (err) {
        logger.warn('deleteWebhook failed; continuing in polling mode', {
          error: err instanceof Error ? err.message : String(err),
        });
      }
      pollingLoop = new PollingLoop({ client, onUpdate, logger });
      pollingLoop.start();
      // Health endpoint only — the webhook route is not registered in polling mode.
      server = createWebhookServer({
        secretToken: config.telegram.webhookSecret,
        onUpdate,
        healthz,
        logger,
        webhookEnabled: false,
      });
      await server.listen({ port: config.server.port, host: '0.0.0.0' });
    }

    // 6. Background workers.
    monitorWorker = new MonitorWorker({ repos, detector, config, clock, logger });
    monitorWorker.start(MONITOR_INTERVAL_MS);
    // SEPARATE deletion-watch feature (/ban): its own worker over `deletion_watches`,
    // reusing the shared detector; notifies the owner directly (no outbox, no screenshot).
    deletionWorker = new DeletionWorker({
      repos,
      // Browser-only (no inferred GONE) but breaker-shared, so it backs off with the fleet.
      detector: deletionDetector,
      client,
      config,
      clock,
      logger,
      ownerChatId,
      ...(discord ? { discord: discord.notifier } : {}),
    });
    deletionWorker.start(MONITOR_INTERVAL_MS);
    outboxWorker = new OutboxWorker({
      repos,
      client,
      config,
      clock,
      logger,
      ownerChatId,
      ...(discord ? { discord: discord.notifier } : {}),
    });
    outboxWorker.start(OUTBOX_INTERVAL_MS);
    const healthMonitor = new HealthMonitor({
      repos,
      detector,
      client,
      ownerChatId,
      config,
      clock,
      logger,
      ...(discord ? { discord: discord.notifier } : {}),
    });
    healthTimer = setInterval(() => {
      healthMonitor.evaluate().catch((err: unknown) => {
        logger.error('health evaluation failed', {
          error: err instanceof Error ? err.message : 'unknown error',
        });
      });
    }, HEALTH_INTERVAL_MS);

    // 7. Optional Discord gateway (owner slash commands). Best-effort — a login failure is
    //    logged inside start() and never blocks the Telegram service.
    if (discord !== null) {
      await discord.start().catch((err: unknown) => {
        logger.error('discord start failed; continuing without Discord', {
          error: err instanceof Error ? err.message : String(err),
        });
      });
    }

    // 8. Optional wallet tracker — a DEDICATED bot with its own polling loop, deliberately
    //    outside the monitor bot's router so wallet traffic can never delay an /unban. Best
    //    effort at every stage: configuration errors and runtime crashes are logged and confined;
    //    Instagram monitoring must be exactly as reliable with this block failing as without it.
    //    SQLite-only, because its store rides the same database file (and its HA snapshots).
    if (config.db.driver === 'sqlite') {
      try {
        wallets = createWalletFeature({
          env: process.env,
          databasePath: config.db.sqlitePath,
          logger,
        });
      } catch (err) {
        logger.error('wallet feature misconfigured; continuing without it', {
          error: err instanceof Error ? err.message : String(err),
        });
      }
      if (wallets !== null) {
        // Floating by design: start() resolves only when the wallet bot stops.
        void wallets.start().catch((err: unknown) => {
          logger.error('wallet feature stopped unexpectedly', {
            error: err instanceof Error ? err.message : String(err),
          });
        });
      }
    }

    logger.info('app started', {
      mode: config.telegram.mode,
      port: config.server.port,
      discord: discord !== null,
      wallets: wallets !== null,
    });
  }

  async function doStop(): Promise<void> {
    const safely = async (name: string, fn: () => Promise<unknown> | unknown): Promise<void> => {
      try {
        await fn();
      } catch (err) {
        logger.error('shutdown step failed', {
          step: name,
          error: err instanceof Error ? err.message : 'unknown error',
        });
      }
    };

    if (pollingLoop) {
      await safely('polling', () => pollingLoop?.stop());
    }
    if (server) {
      await safely('server', () => server?.close());
    }
    // Ingress has stopped, so no new detached work can start. Drain what is already queued
    // BEFORE tearing down the browser and DB it depends on. Bounded: a stuck batch must not
    // hold up a systemd restart, and anything unfinished is recovered on next startup.
    if (commandRouter) {
      const drain = commandRouter.whenIdle();
      await safely('commandDrain', () =>
        Promise.race([
          drain,
          new Promise<void>((resolve) => {
            const t = setTimeout(() => {
              logger.warn('shutdown: detached command work still running; abandoning drain');
              resolve();
            }, COMMAND_DRAIN_TIMEOUT_MS);
            t.unref?.();
          }),
        ]),
      );
    }
    if (monitorWorker) {
      await safely('monitorWorker', () => monitorWorker?.stop());
    }
    if (deletionWorker) {
      await safely('deletionWorker', () => deletionWorker?.stop());
    }
    if (outboxWorker) {
      await safely('outboxWorker', () => outboxWorker?.stop());
    }
    if (discord) {
      await safely('discord', () => discord?.stop());
    }
    if (wallets) {
      await safely('wallets', () => wallets?.stop());
    }
    if (healthTimer) {
      clearInterval(healthTimer);
      healthTimer = null;
    }
    if (clockTimer) {
      clearInterval(clockTimer);
      clockTimer = null;
    }
    await safely('browser', () => browser.close());
    // Flush the browser-load window BEFORE the process goes away: the buckets this hour already
    // spent are precisely what the next boot must not be allowed to spend again. `flush()` now
    // AWAITS the store's queued write — it used to return the moment the snapshot was handed over,
    // so `process.exit(0)` in the entry point dropped it and the restart got its budget back.
    await safely('browserLoadBudget', () => governor.flush());
    // Flush any queued back-off write before the DB goes away: the last transition before a
    // shutdown is precisely the one the next startup needs, and a write racing db.close() would
    // both lose it and throw.
    await safely('breakerState', () => breakerWrites);
    await safely('db', () => db.close());
    logger.info('shutdown complete');
  }

  return {
    start,
    stop(): Promise<void> {
      // Idempotent: concurrent/repeat calls share the same shutdown pass.
      stopPromise ??= doStop();
      return stopPromise;
    },
  };
}
