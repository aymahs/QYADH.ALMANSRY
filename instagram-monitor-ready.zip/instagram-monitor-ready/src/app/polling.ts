/**
 * Long-polling ingress (dev / no-public-URL deployments).
 *
 * Repeatedly calls `getUpdates(offset, 25)`; each received update advances the offset
 * to `update_id + 1` (acknowledging it) and is dispatched to `onUpdate`. Handler
 * failures are logged per-update and never kill the loop; transport failures back
 * off 3 seconds before retrying.
 */

import type { TelegramClient, TelegramUpdate } from '../domain';
import { ALLOWED_UPDATES } from '../domain';
import type { Logger } from '../logging/logger';

export interface PollingLoopOptions {
  client: TelegramClient;
  onUpdate: (update: TelegramUpdate) => Promise<void>;
  logger: Logger;
}

const LONG_POLL_TIMEOUT_SECONDS = 25;
const TRANSPORT_ERROR_BACKOFF_MS = 3000;
/** Yield to the macrotask queue after an empty batch so shutdown/timers can run. */
const EMPTY_BATCH_YIELD_MS = 0;

export class PollingLoop {
  private readonly client: TelegramClient;
  private readonly onUpdate: (update: TelegramUpdate) => Promise<void>;
  private readonly logger: Logger;

  private running = false;
  private loopPromise: Promise<void> | null = null;
  private offset = 0;
  /** Resolver of an in-flight backoff sleep, so stop() can cut it short. */
  private wakeSleep: (() => void) | null = null;

  constructor(options: PollingLoopOptions) {
    this.client = options.client;
    this.onUpdate = options.onUpdate;
    this.logger = options.logger;
  }

  /** Begin polling in the background. Idempotent while running. */
  start(): void {
    if (this.running) {
      return;
    }
    this.running = true;
    this.loopPromise = this.run();
  }

  /** Signal the loop to stop and resolve once it has fully exited. */
  async stop(): Promise<void> {
    this.running = false;
    if (this.wakeSleep) {
      this.wakeSleep();
    }
    if (this.loopPromise) {
      await this.loopPromise;
      this.loopPromise = null;
    }
  }

  private async run(): Promise<void> {
    while (this.running) {
      let updates: TelegramUpdate[];
      try {
        updates = await this.client.getUpdates(
          this.offset,
          LONG_POLL_TIMEOUT_SECONDS,
          ALLOWED_UPDATES,
        );
      } catch (err) {
        this.logger.warn('getUpdates failed; backing off', {
          error: err instanceof Error ? err.message : 'unknown error',
        });
        await this.sleep(TRANSPORT_ERROR_BACKOFF_MS);
        continue;
      }

      for (const update of updates) {
        this.offset = update.update_id + 1;
        try {
          await this.onUpdate(update);
        } catch (err) {
          this.logger.error('update handler failed', {
            updateId: update.update_id,
            error: err instanceof Error ? err.message : 'unknown error',
          });
        }
      }

      if (updates.length === 0) {
        await this.sleep(EMPTY_BATCH_YIELD_MS);
      }
    }
    this.logger.info('polling loop stopped');
  }

  /** Interruptible sleep: stop() resolves it immediately for prompt shutdown. */
  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.wakeSleep = null;
        resolve();
      }, ms);
      this.wakeSleep = (): void => {
        clearTimeout(timer);
        this.wakeSleep = null;
        resolve();
      };
    });
  }
}
