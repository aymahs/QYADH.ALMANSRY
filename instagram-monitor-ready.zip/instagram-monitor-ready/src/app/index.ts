/**
 * Executable entrypoint: load config, build the app, install signal handlers,
 * and start. Config errors print only the safe detail (never env values).
 */

import type { AppConfig } from '../config/config';
import { collectSecrets, loadConfig } from '../config/config';
import { isAppError } from '../domain';
import { createLogger } from '../logging/logger';
import { buildApp } from './app';

async function main(): Promise<void> {
  let config: AppConfig;
  try {
    config = loadConfig(process.env);
  } catch (err) {
    if (isAppError(err) && err.code === 'CONFIG_INVALID') {
      // Only the safe detail — never any env values.
      process.stderr.write(`Invalid configuration: ${err.safeDetail ?? 'unknown'}\n`);
      process.exit(1);
    }
    throw err;
  }

  const logger = createLogger({ level: config.logLevel, secrets: collectSecrets(config) });
  const app = buildApp(config);

  let shuttingDown = false;
  const shutdown = (signal: string): void => {
    if (shuttingDown) {
      return; // Guard against a double signal triggering a second shutdown.
    }
    shuttingDown = true;
    logger.info('signal received; shutting down', { signal });
    app
      .stop()
      .then(() => {
        process.exit(0);
      })
      .catch((err: unknown) => {
        logger.error('shutdown failed', {
          error: err instanceof Error ? err.message : 'unknown error',
        });
        process.exit(1);
      });
  };
  process.on('SIGINT', () => {
    shutdown('SIGINT');
  });
  process.on('SIGTERM', () => {
    shutdown('SIGTERM');
  });

  await app.start();
  logger.info('started');
}

main().catch((err: unknown) => {
  const message = err instanceof Error ? err.message : 'unknown error';
  process.stderr.write(`fatal: ${message}\n`);
  process.exit(1);
});
