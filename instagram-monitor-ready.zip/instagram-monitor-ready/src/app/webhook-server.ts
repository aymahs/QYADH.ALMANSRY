/**
 * Fastify ingress server.
 *
 * Serves the Telegram webhook endpoint (secret-token gated) and the /healthz probe.
 * In polling mode the webhook route is disabled (`webhookEnabled: false`) and only
 * /healthz is registered, so the same factory backs both ingress modes.
 *
 * Security invariant: the received `x-telegram-bot-api-secret-token` header value is
 * never logged, echoed, or otherwise persisted — on mismatch we reply 401 and move on.
 */

import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import type { TelegramUpdate } from '../domain';
import type { Logger } from '../logging/logger';

export interface WebhookServerOptions {
  /** Expected value of the `x-telegram-bot-api-secret-token` header. */
  secretToken: string;
  /** Called for every authenticated, well-formed update. */
  onUpdate: (update: TelegramUpdate) => Promise<void>;
  /** Health probe; `ok: false` maps to HTTP 503. */
  healthz: () => Promise<{ ok: boolean; [k: string]: unknown }>;
  logger: Logger;
  /**
   * When false, the webhook route is not registered at all (polling mode still
   * serves /healthz on the same port). Defaults to true.
   */
  webhookEnabled?: boolean;
}

const BODY_LIMIT_BYTES = 1024 * 1024; // 1 MB
const SECRET_HEADER = 'x-telegram-bot-api-secret-token';

/** Minimal shape check: Telegram updates always carry a numeric `update_id`. */
function isTelegramUpdate(body: unknown): body is TelegramUpdate {
  if (typeof body !== 'object' || body === null) {
    return false;
  }
  const updateId = (body as Record<string, unknown>)['update_id'];
  return typeof updateId === 'number' && Number.isFinite(updateId);
}

export function createWebhookServer(opts: WebhookServerOptions): FastifyInstance {
  const { secretToken, onUpdate, healthz, logger } = opts;
  const webhookEnabled = opts.webhookEnabled ?? true;

  // Fastify's own request logging is disabled — the app has a structured logger.
  const app = Fastify({ logger: false, bodyLimit: BODY_LIMIT_BYTES });

  if (webhookEnabled) {
    app.post('/telegram/webhook', async (request, reply) => {
      const header = request.headers[SECRET_HEADER];
      // Strict string equality; arrays / missing values never match. The received
      // header value is deliberately never logged.
      if (typeof header !== 'string' || header !== secretToken) {
        return reply.code(401).send({ ok: false });
      }

      const body: unknown = request.body;
      if (!isTelegramUpdate(body)) {
        // Reply 200 so Telegram does not retry a permanently-malformed update.
        logger.warn('ignoring webhook body without numeric update_id');
        return reply.code(200).send({ ok: true });
      }

      try {
        await onUpdate(body);
      } catch (err) {
        // Still 200: Telegram must not retry forever on our internal failures.
        logger.error('webhook update handler failed', {
          updateId: body.update_id,
          error: err instanceof Error ? err.message : 'unknown error',
        });
      }
      return reply.code(200).send({ ok: true });
    });
  }

  app.get('/healthz', async (_request, reply) => {
    let result: { ok: boolean; [k: string]: unknown };
    try {
      result = await healthz();
    } catch (err) {
      logger.error('healthz probe failed', {
        error: err instanceof Error ? err.message : 'unknown error',
      });
      result = { ok: false };
    }
    return reply.code(result.ok ? 200 : 503).send(result);
  });

  return app;
}
