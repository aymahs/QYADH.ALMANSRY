/**
 * Test/embedding barrel for the app layer. `src/app/index.ts` stays the executable
 * entrypoint (it runs main() on import), so importable pieces live here instead.
 */

export { buildApp } from './app';
export type { App } from './app';
export { createWebhookServer } from './webhook-server';
export type { WebhookServerOptions } from './webhook-server';
export { PollingLoop } from './polling';
export type { PollingLoopOptions } from './polling';
