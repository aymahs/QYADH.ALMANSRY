/** Persistent monitoring case model and its lifecycle enums. */

import type { Classification, DetectorErrorCode } from './classification';

/** State-machine states. */
export type CaseStatus =
  | 'MONITORING'
  | 'CONFIRMING'
  | 'CONFIRMED'
  | 'NOTIFYING'
  | 'NOTIFIED'
  | 'CLEARED'
  | 'ERROR_BACKOFF'
  /** A bounded retry cadence for an inconclusive Instagram page, not an app error. */
  | 'UNKNOWN_BACKOFF';

/** Statuses shown by /list (currently-active monitoring). */
export const LISTED_STATUSES: readonly CaseStatus[] = [
  'MONITORING',
  'CONFIRMING',
  'ERROR_BACKOFF',
  'UNKNOWN_BACKOFF',
];

/** Statuses that still receive scheduled checks. */
export const ACTIVE_STATUSES: readonly CaseStatus[] = [
  'MONITORING',
  'CONFIRMING',
  'ERROR_BACKOFF',
  'UNKNOWN_BACKOFF',
];

/** Terminal statuses — never checked or notified again. */
export const TERMINAL_STATUSES: readonly CaseStatus[] = ['NOTIFIED', 'CLEARED'];

export type ScreenshotStatus =
  | 'NONE'
  | 'PENDING'
  | 'CAPTURED'
  | 'FAILED'
  | 'SENT'
  // ACTIVE but a "Restricted profile" age-gate: recovery is delivered text-only, and NO
  // screenshot follow-up is attempted (there is nothing viewable to capture).
  | 'RESTRICTED';

/** One monitored account. Times are ISO-8601 UTC strings. */
export interface MonitoringCase {
  id: string;
  normalizedUsername: string;
  originalInput: string;
  startedAtUtc: string;
  status: CaseStatus;
  confirmationCount: number;
  nextCheckAtUtc: string | null;
  lastCheckedAtUtc: string | null;
  lastResult: Classification | null;
  consecutiveUnknownCount: number;
  errorBackoffUntilUtc: string | null;
  confirmedAtUtc: string | null;
  clearedAtUtc: string | null;
  notificationClaimedAtUtc: string | null;
  notificationSentAtUtc: string | null;
  telegramMessageId: number | null;
  screenshotStatus: ScreenshotStatus;
  /** Job-lease holder id; null when free. */
  leaseOwner: string | null;
  leaseExpiresAtUtc: string | null;
  createdAtUtc: string;
  updatedAtUtc: string;
}

/** Data needed to create a new case. */
export interface NewCaseInput {
  normalizedUsername: string;
  originalInput: string;
  startedAtUtc: string;
  nextCheckAtUtc: string;
}

/** One recorded browser check (monitoring_checks). Never stores HTML or secrets. */
export interface CheckRecord {
  id: string;
  caseId: string;
  checkedAtUtc: string;
  classification: Classification;
  finalUrl: string | null;
  responseStatus: number | null;
  durationMs: number;
  activeSignals: string[];
  goneSignals: string[];
  errorCode: DetectorErrorCode | null;
  /** 1..N during a confirmation burst; null for baseline checks. */
  confirmationSeq: number | null;
}

export interface NewCheckInput {
  caseId: string;
  checkedAtUtc: string;
  classification: Classification;
  finalUrl: string | null;
  responseStatus: number | null;
  durationMs: number;
  activeSignals: string[];
  goneSignals: string[];
  errorCode: DetectorErrorCode | null;
  confirmationSeq: number | null;
}

/** Notification outbox row — durable send queue with one row per case. */
export type OutboxStatus = 'PENDING' | 'CLAIMED' | 'SENT' | 'FAILED';
export type OutboxKind = 'RECOVERY_PHOTO' | 'RECOVERY_TEXT' | 'SCREENSHOT_FOLLOWUP';

export interface OutboxItem {
  id: string;
  caseId: string;
  kind: OutboxKind;
  status: OutboxStatus;
  attempts: number;
  claimedAtUtc: string | null;
  sentAtUtc: string | null;
  lastError: string | null;
  telegramMessageId: number | null;
  createdAtUtc: string;
  updatedAtUtc: string;
}

/** Scheduler / detector health snapshot (scheduler_health, single row keyed by name). */
export interface SchedulerHealth {
  name: string;
  lastSchedulerRunUtc: string | null;
  lastSuccessfulCheckUtc: string | null;
  lastControlOkUtc: string | null;
  recentUnknownRate: number;
  browserRestarts: number;
  detectorUnhealthy: boolean;
  lastWarningSentUtc: string | null;
  updatedAtUtc: string;
}
