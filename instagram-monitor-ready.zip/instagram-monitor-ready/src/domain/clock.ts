/** Injectable clock so time-dependent logic is deterministic in tests. */

export interface Clock {
  now(): Date;
  /** Milliseconds since epoch — convenience for durations. */
  nowMs(): number;
}

export class SystemClock implements Clock {
  now(): Date {
    return new Date();
  }
  nowMs(): number {
    return Date.now();
  }
}

/** Test clock with manual advancement. */
export class FixedClock implements Clock {
  private current: number;
  constructor(start: Date | number) {
    this.current = typeof start === 'number' ? start : start.getTime();
  }
  now(): Date {
    return new Date(this.current);
  }
  nowMs(): number {
    return this.current;
  }
  advanceMs(ms: number): void {
    this.current += ms;
  }
  set(date: Date | number): void {
    this.current = typeof date === 'number' ? date : date.getTime();
  }
}
