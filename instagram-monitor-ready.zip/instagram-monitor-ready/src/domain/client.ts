/**
 * Client-notification domain: invitations, consent-based subscriptions, roles, and the
 * recipient-aware recovery-delivery outbox.
 *
 * Security invariants encoded here:
 *  - Clients are identified ONLY by numeric Telegram user id, never by @username.
 *  - Only a SHA-256 hash of an invitation token is ever stored; the raw token lives only
 *    in the deep link the owner forwards.
 *  - A subscription requires an explicit accept; opening the link is not consent.
 */

/** Coarse role used for command authorization. */
export type Role = 'OWNER' | 'CLIENT' | 'NONE';

// ---------------------------------------------------------------------------
// Invitations
// ---------------------------------------------------------------------------

export type InvitationStatus = 'PENDING' | 'ACCEPTED' | 'DECLINED' | 'REVOKED' | 'EXPIRED';

export interface ClientInvitation {
  id: string;
  monitorId: string;
  /** SHA-256 hex of the raw token. The raw token is never persisted or logged. */
  tokenHash: string;
  status: InvitationStatus;
  expiresAtUtc: string;
  createdByOwnerId: number;
  acceptedByTelegramUserId: number | null;
  acceptedAtUtc: string | null;
  declinedAtUtc: string | null;
  revokedAtUtc: string | null;
  createdAtUtc: string;
  updatedAtUtc: string;
}

export interface NewInvitationInput {
  monitorId: string;
  tokenHash: string;
  expiresAtUtc: string;
  createdByOwnerId: number;
}

// ---------------------------------------------------------------------------
// Subscriptions
// ---------------------------------------------------------------------------

export type SubscriptionStatus = 'ACTIVE' | 'UNSUBSCRIBED';

export interface ClientSubscription {
  id: string;
  monitorId: string;
  telegramUserId: number;
  status: SubscriptionStatus;
  consentedAtUtc: string;
  unsubscribedAtUtc: string | null;
  notifiedAtUtc: string | null;
  createdAtUtc: string;
  updatedAtUtc: string;
}

export interface NewSubscriptionInput {
  monitorId: string;
  telegramUserId: number;
  consentedAtUtc: string;
}

/** Derived client-notification status shown in /list and the owner recovery message. */
export type ClientNotificationStatus =
  | 'OWNER_ONLY'
  | 'INVITE_PENDING'
  | 'CLIENT_CONNECTED'
  | 'CLIENT_DECLINED'
  | 'CLIENT_UNSUBSCRIBED'
  | 'INVITE_EXPIRED'
  | 'INVITE_REVOKED'
  | 'CLIENT_DELIVERY_FAILED'
  | 'CLIENT_NOTIFIED';

// ---------------------------------------------------------------------------
// Recipient-aware recovery deliveries (per-recipient outbox)
// ---------------------------------------------------------------------------

export type RecipientType = 'OWNER' | 'CLIENT';
export type DeliveryMessageType = 'RECOVERY_PHOTO' | 'RECOVERY_TEXT' | 'SCREENSHOT_FOLLOWUP';
export type DeliveryStatus = 'PENDING' | 'CLAIMED' | 'DELIVERED' | 'FAILED' | 'CANCELLED';

export interface RecoveryDelivery {
  id: string;
  monitorId: string;
  /** Groups all deliveries for one confirmed recovery of one monitor. */
  recoveryId: string;
  recipientType: RecipientType;
  telegramUserId: number;
  messageType: DeliveryMessageType;
  status: DeliveryStatus;
  /** `monitor:{monitorId}:recovery:{recoveryId}:recipient:{telegramUserId}` — unique. */
  idempotencyKey: string;
  attemptCount: number;
  nextAttemptAtUtc: string | null;
  telegramMessageId: number | null;
  lastErrorCode: string | null;
  createdAtUtc: string;
  deliveredAtUtc: string | null;
  updatedAtUtc: string;
}

export interface NewDeliveryInput {
  monitorId: string;
  recoveryId: string;
  recipientType: RecipientType;
  telegramUserId: number;
  messageType: DeliveryMessageType;
  idempotencyKey: string;
  nextAttemptAtUtc: string;
}

/** Build the per-recipient idempotency key (single source of truth). */
export function deliveryIdempotencyKey(
  monitorId: string,
  recoveryId: string,
  telegramUserId: number,
): string {
  return `monitor:${monitorId}:recovery:${recoveryId}:recipient:${telegramUserId}`;
}
