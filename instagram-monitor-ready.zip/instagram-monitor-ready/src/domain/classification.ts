/**
 * Detection contract — the single source of truth for how a page is classified.
 *
 * Classification is a PURE function over a {@link PageSnapshot}. The browser layer
 * builds a snapshot from a live Playwright page; fixtures build the same snapshot
 * from static HTML. `/ping` and the production monitor both go through this contract,
 * so detection logic is never duplicated.
 */

/** The only three outcomes of a page check. Never a boolean. */
export type Classification = 'ACTIVE' | 'GONE' | 'UNKNOWN';

/**
 * Bump when the signal-extraction rules change so historical checks remain
 * interpretable and DOM updates are auditable.
 */
export const SIGNALS_VERSION = '2026-08-01.1';

/** Named strong signals that a profile is genuinely present. */
export const ACTIVE_SIGNALS = {
  URL_ON_USERNAME_PATH: 'url_on_username_path',
  NOT_REDIRECTED_AWAY: 'not_redirected_away',
  CANONICAL_MATCHES: 'canonical_matches_username',
  OG_URL_MATCHES: 'og_url_matches_username',
  OG_TITLE_MATCHES: 'og_title_matches_username',
  HEADER_USERNAME_MATCHES: 'header_username_matches',
  PROFILE_STRUCTURES_RENDERED: 'profile_structures_rendered',
  NO_UNAVAILABLE_MESSAGE: 'no_unavailable_message',
} as const;
export type ActiveSignal = (typeof ACTIVE_SIGNALS)[keyof typeof ACTIVE_SIGNALS];

/** Signals that a profile is confirmed unavailable. */
export const GONE_SIGNALS = {
  UNAVAILABLE_MESSAGE: 'unavailable_message_present',
  UNAVAILABLE_TITLE: 'unavailable_title_present',
} as const;
export type GoneSignal = (typeof GONE_SIGNALS)[keyof typeof GONE_SIGNALS];

/**
 * Identity signals prove the rendered page is THIS username, not a generic page.
 * ACTIVE requires at least one of these plus a second strong signal.
 */
export const IDENTITY_ACTIVE_SIGNALS: ReadonlySet<string> = new Set([
  ACTIVE_SIGNALS.CANONICAL_MATCHES,
  ACTIVE_SIGNALS.OG_URL_MATCHES,
  ACTIVE_SIGNALS.OG_TITLE_MATCHES,
  ACTIVE_SIGNALS.HEADER_USERNAME_MATCHES,
]);

/** Safe, structured error codes recorded on UNKNOWN. Never contains secrets or raw HTML. */
export type DetectorErrorCode =
  | 'TIMEOUT'
  | 'DNS'
  | 'NAVIGATION'
  /**
   * The egress PROXY never established a tunnel, so the request never reached Instagram at all —
   * most often a sticky mobile session that expired (the gateway then answers every CONNECT with
   * 502). Distinct from HTTP_5XX, which is a real response FROM Instagram: this one says nothing
   * whatever about the account or the IP's standing, and is repaired by rotating the session
   * rather than by backing the fleet off.
   */
  | 'PROXY_TUNNEL'
  | 'BROWSER_CRASH'
  | 'HTTP_403'
  | 'HTTP_429'
  | 'HTTP_5XX'
  | 'CHALLENGE'
  /** A configured owner-created login session was rejected by Instagram's security checkpoint. */
  | 'AUTH_SESSION_CHALLENGE'
  | 'LOGIN_WALL'
  | 'CONSENT_BLOCK'
  | 'EMPTY_PAGE'
  | 'UNEXPECTED_REDIRECT'
  | 'CONTRADICTORY'
  | 'UNRECOGNIZED_DOM'
  /** Instagram's "Something went wrong" interstitial — usually an IP-throttling symptom. */
  | 'ERROR_PAGE'
  | 'UNKNOWN_ERROR';

/**
 * Normalized, browser-agnostic view of a loaded page. Produced by
 * `extractSnapshot(html, meta)` (used by both live and fixture paths).
 */
export interface PageSnapshot {
  requestedUsername: string;
  finalUrl: string;
  responseStatus: number | null;

  redirectedToLogin: boolean;
  redirectedToChallenge: boolean;
  /** Redirect to Instagram's account-security flow for the configured storage state. */
  redirectedToAuthSessionChallenge: boolean;
  redirectedToExploreOrHome: boolean;

  canonicalUrl: string | null;
  ogTitle: string | null;
  ogUrl: string | null;
  headerUsername: string | null;

  hasProfileStructures: boolean;
  unavailableMessagePresent: boolean;
  unavailableTitlePresent: boolean;
  loginWallPresent: boolean;
  /**
   * Raw "a login form is present on the page" fact, independent of the og-metadata masking
   * that keeps `loginWallPresent` false so identity still classifies ACTIVE. Used by the
   * screenshot guard: Instagram serves og:type=profile even on the logged-out login wall,
   * so `hasProfileStructures` alone would wrongly let the wall be screenshotted.
   */
  loginFormPresent: boolean;
  /**
   * Instagram's age/sensitivity gate ("Restricted profile"): the account EXISTS and is
   * served (identity present -> ACTIVE), but its content is only viewable while logged in.
   * There is nothing legitimate to screenshot, so recovery is delivered as text-only.
   */
  restrictedProfilePresent: boolean;
  /**
   * Instagram's generic failure interstitial ("Something went wrong / There's an issue and the
   * page could not be loaded"). It is typically served while an IP is being rate-limited, and
   * CRITICALLY it still carries the profile's og:title/canonical — so identity matches and the
   * page would otherwise classify ACTIVE and be screenshotted as "proof" of recovery. It is not
   * a trustworthy page: treat it as UNKNOWN and never capture it.
   */
  errorPagePresent: boolean;
  challengePresent: boolean;
  consentBlockPresent: boolean;

  bodyTextLength: number;
  rawTitle: string | null;
  /** Populated only on transport/browser failure so classify() can short-circuit to UNKNOWN. */
  transportError: DetectorErrorCode | null;
}

/** Structured, non-sensitive evidence for one check. Persisted to monitoring_checks. */
export interface DetectorEvidence {
  signalsVersion: string;
  activeSignals: string[];
  goneSignals: string[];
  identitySignalMatched: boolean;
  finalUrl: string | null;
  responseStatus: number | null;
  errorCode: DetectorErrorCode | null;
}

/** Result of classifying one page snapshot. */
export interface DetectorResult {
  classification: Classification;
  evidence: DetectorEvidence;
  durationMs: number;
}

/** A validated, in-memory screenshot. */
export interface Screenshot {
  buffer: Buffer;
  format: 'png' | 'jpeg';
  width: number;
  height: number;
}

/** Options for a single probe. */
export interface ProbeOptions {
  /** Capture a validated screenshot of the verified profile. */
  captureScreenshot?: boolean;
  /**
   * Reuse a confirmation context/page across the short confirmation burst.
   * `null`/undefined => fresh isolated context (baseline default).
   */
  confirmationContextId?: string | null;
  /**
   * How long a screenshot capture may wait for the profile to finish PAINTING, in ms.
   *
   * The caller has to own this because the same detector serves two callers with opposite
   * needs. The monitor is producing the client's proof and can afford minutes (paint was
   * measured at 9.9s / 85.4s / 96.4s on the production egress), so it asks for a large budget
   * inside a deadline of its own. `/check` and `/ping` run inline on the bot's SERIAL update
   * loop, where the same wait freezes every other command, so they take the detector's much
   * shorter default. Omit to accept that default.
   */
  paintBudgetMs?: number;
  /**
   * Ceiling on the capture page LOAD (`page.goto` + the settle wait), in ms. Ignored unless
   * {@link ProbeOptions.captureScreenshot} is set, and it may only ever LOWER the configured
   * `CAPTURE_TIMEOUT_MS` — never raise it.
   *
   * It exists because a capture's navigation budget and its caller's total budget were chosen
   * INDEPENDENTLY, and that guaranteed a mismatch. `CAPTURE_TIMEOUT_MS` is a global 120s sized
   * for the slowest measured cold load; the re-capture sweep wrapped the same probe in a 90s
   * `withDeadline`. The outer deadline therefore fired mid-`goto` on every slow profile — the
   * exact profiles the sweep exists for — after which nothing cancels the probe, so it kept a
   * browser page, a capture lane and a concurrency slot for another ~70s and its result was
   * discarded. A caller that owns a hard deadline must be able to size the load inside it, so
   * the outer wrapper goes back to being a BACKSTOP rather than a cliff.
   *
   * Omit to accept the configured capture budget.
   */
  captureNavBudgetMs?: number;
}

/** Outcome of a probe: classification result plus optional screenshot. */
export interface ProbeResult {
  result: DetectorResult;
  screenshot: Screenshot | null;
  /**
   * True when the page is a "Restricted profile" age-gate (ACTIVE by identity, but no
   * viewable content). Lets the monitor deliver a text-only "restricted" recovery instead
   * of a misleading login-wall screenshot. Optional: absent => false.
   */
  restricted?: boolean;
  /**
   * True only on the first browser load that proved the configured owner-created storage state
   * unusable and caused BrowserManager to quarantine it. A tiered detector uses this as a
   * one-shot retry signal; absent means no retry is warranted.
   */
  storageStateQuarantined?: boolean;
  /**
   * True when this check NEVER TOUCHED THE NETWORK — the fleet-wide circuit breaker was open, or
   * the browser-load governor deferred it. The account was not observed at all.
   *
   * The distinction matters because such a result is UNKNOWN with `errorCode: 'HTTP_429'`, which
   * is indistinguishable by shape from Instagram genuinely rate-limiting us. Counting a check we
   * DELIBERATELY DECLINED TO MAKE as evidence that checks are failing is how a healthy fleet
   * reported itself degraded all night on 2026-08-04/05: the breaker backs off (correctly), every
   * short-circuited check pushes the rolling unknown rate toward 1.0, the health monitor sees
   * "everything is UNKNOWN" and warns — while browser loads sit at 16/160 precisely BECAUSE
   * nothing was being loaded. Self-inflicted back-off is not a fault; it is the system working.
   *
   * Absent => the check really did go out and its verdict is real evidence.
   */
  notObserved?: boolean;
}

/**
 * The shared browser detector. `/ping` and the monitor call the SAME implementation.
 * Only ever navigates to https://www.instagram.com/{validated username}/ (no SSRF).
 */
export interface Detector {
  probe(username: string, options?: ProbeOptions): Promise<ProbeResult>;
}
