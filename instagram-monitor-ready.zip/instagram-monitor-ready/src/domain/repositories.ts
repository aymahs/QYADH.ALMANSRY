/** Persistence contracts. SQL implementations must make the "atomic" methods atomic. */

import type {
  MonitoringCase,
  NewCaseInput,
  CaseStatus,
  CheckRecord,
  NewCheckInput,
  OutboxItem,
  OutboxKind,
  SchedulerHealth,
} from './case';
import type {
  ClientInvitation,
  NewInvitationInput,
  ClientSubscription,
  NewSubscriptionInput,
  RecoveryDelivery,
  NewDeliveryInput,
} from './client';
import type {
  BusinessConnection,
  ClientChatLink,
  NewClientChatLink,
  BusinessDeliveryStatus,
} from './business';
import type { DeletionWatch, NewDeletionWatchInput } from './deletion';
import type { ClientIdentity, NewClientIdentity } from './clients';

export interface OwnerRepository {
  /** Numeric Telegram id of the paired owner, or null if unpaired. */
  getOwnerTelegramId(): Promise<number | null>;
  /** First-wins pairing. Returns false if an owner is already stored. */
  claimOwner(telegramUserId: number, pairedAtUtc: string): Promise<boolean>;
}

export interface ClaimDueParams {
  nowUtc: string;
  leaseOwner: string;
  leaseExpiresUtc: string;
  limit: number;
}

export interface CaseRepository {
  create(input: NewCaseInput, nowUtc: string): Promise<MonitoringCase>;
  findById(id: string): Promise<MonitoringCase | null>;
  /** Active (non-terminal) case for a username, or null. Enforced unique by DB index. */
  findActiveByNormalizedUsername(username: string): Promise<MonitoringCase | null>;
  listByStatuses(statuses: readonly CaseStatus[]): Promise<MonitoringCase[]>;
  countByStatuses(statuses: readonly CaseStatus[]): Promise<number>;
  /**
   * Atomically claim up to `limit` active cases whose next_check_at <= now and whose
   * lease is free or expired. Sets lease owner/expiry. Two workers never claim the same row.
   * Confirmation cases (CONFIRMING) are returned before baseline cases.
   */
  claimDueCases(params: ClaimDueParams): Promise<MonitoringCase[]>;
  /** Persist a full case snapshot (caller computed the transition). */
  save(next: MonitoringCase): Promise<void>;
  /** Release the lease (owner -> null) without otherwise changing the row. */
  releaseLease(id: string, nowUtc: string): Promise<void>;
  /**
   * Atomically mark an active case CLEARED. Cancels future work: clears lease and
   * next_check_at so a late result cannot notify. Returns the updated case, or null
   * if no active case existed for the username.
   */
  clearByNormalizedUsername(username: string, clearedAtUtc: string): Promise<MonitoringCase | null>;
  /**
   * Atomically claim the sole right to notify a case: sets notification_claimed_at only
   * if currently null. Returns true if THIS caller won the claim.
   */
  claimNotification(caseId: string, claimedAtUtc: string): Promise<boolean>;
}

export interface CheckRepository {
  insert(input: NewCheckInput): Promise<CheckRecord>;
  countByCase(caseId: string): Promise<number>;
}

export interface TelegramUpdateRepository {
  /** Records the update_id; returns true if new, false if already processed (dedup). */
  registerIfNew(updateId: number, receivedAtUtc: string): Promise<boolean>;
}

export interface EnqueueOutbox {
  caseId: string;
  kind: OutboxKind;
  createdAtUtc: string;
}

export interface OutboxRepository {
  /** Idempotent per (caseId, kind) via unique constraint; returns existing on conflict. */
  enqueue(item: EnqueueOutbox): Promise<OutboxItem>;
  findByCase(caseId: string): Promise<OutboxItem[]>;
  /** Atomically claim the next PENDING item (skips items whose case was cleared). */
  claimNextPending(nowUtc: string): Promise<OutboxItem | null>;
  markSent(id: string, sentAtUtc: string, telegramMessageId: number | null): Promise<void>;
  /**
   * Record a delivery failure. MUST leave a SENT row untouched: SENT is the durable proof the
   * alert reached Telegram, and a step that runs after the send can still fail into here.
   * Demoting it to FAILED would let the stranded-notification sweep re-open and re-send it.
   */
  markFailed(id: string, error: string, nowUtc: string): Promise<void>;
  /**
   * Re-open the row for (caseId, kind) that has exhausted its attempts: FAILED -> PENDING with
   * attempts and the last error cleared, and a fresh created_at so it is queued (and aged) from
   * now. Returns true only when a row actually changed.
   *
   * This exists because {@link OutboxRepository.enqueue} is idempotent-on-conflict, so it can
   * never revive an exhausted row — the stranded-notification sweep called it and silently did
   * nothing. Scoped to FAILED on purpose: a PENDING/CLAIMED row is already in flight and a SENT
   * row was delivered, so neither may be resurrected into a duplicate alert.
   */
  reopenFailed(caseId: string, kind: OutboxKind, nowUtc: string): Promise<boolean>;
  /** Reset a stuck CLAIMED item back to PENDING (crash recovery). */
  requeueStale(olderThanUtc: string, nowUtc: string): Promise<number>;
  countPending(): Promise<number>;
  oldestPendingAgeMs(nowUtc: string): Promise<number | null>;
}

export interface SchedulerHealthRepository {
  get(name: string): Promise<SchedulerHealth | null>;
  upsert(health: SchedulerHealth): Promise<void>;
}

/** The three phases of the fleet-wide back-off breaker, as persisted. */
export type BreakerPhase = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

/**
 * A durable snapshot of the fleet-wide back-off.
 *
 * Without it the breaker lives only in process memory, so a restart (deploy, OOM, crash,
 * systemd) starts CLOSED with a zeroed streak and the whole fleet immediately resumes
 * full-rate checking against an IP that was mid-cooldown. That is how the first residential
 * IP was burned.
 *
 * Written on state TRANSITIONS only — never on the probe hot path.
 */
export interface BreakerStateRecord {
  /** Key; one row per breaker (see `EGRESS_BREAKER_NAME`). */
  name: string;
  state: BreakerPhase;
  /** When the current OPEN period began; null while CLOSED. */
  openedAtUtc: string | null;
  /** The cooldown in force, including any doubling from failed half-open probes. */
  cooldownMs: number;
  /** Consecutive throttle signals as of the last transition. */
  consecutive: number;
  /**
   * Credential-free label of the egress route this back-off was earned on. Back-off is a
   * property OF A ROUTE: a block earned by a burned proxy must not be carried onto the fresh
   * route the owner switched to in order to escape it — that would silently delay every
   * recovery alert for up to a full cooldown.
   */
  egressRoute: string;
  updatedAtUtc: string;
}

export interface BreakerStateRepository {
  get(name: string): Promise<BreakerStateRecord | null>;
  /** Upsert by name. Called only on breaker state transitions. */
  save(record: BreakerStateRecord): Promise<void>;
}

export interface InvitationRepository {
  create(input: NewInvitationInput, nowUtc: string): Promise<ClientInvitation>;
  findById(id: string): Promise<ClientInvitation | null>;
  findByTokenHash(tokenHash: string): Promise<ClientInvitation | null>;
  /** The single PENDING, unexpired invitation for a monitor, or null. */
  findActiveByMonitor(monitorId: string, nowUtc: string): Promise<ClientInvitation | null>;
  listByMonitor(monitorId: string): Promise<ClientInvitation[]>;
  /**
   * Atomically accept: set ACCEPTED + acceptor only if currently PENDING and not past
   * expiry. Returns the updated invitation, or null if it was already used/expired/revoked
   * (so a second acceptor learns nothing about the first).
   */
  accept(id: string, telegramUserId: number, nowUtc: string): Promise<ClientInvitation | null>;
  decline(id: string, nowUtc: string): Promise<ClientInvitation | null>;
  revoke(id: string, nowUtc: string): Promise<ClientInvitation | null>;
  /** Mark every PENDING invitation past its expiry EXPIRED; returns the count. */
  expireOverdue(nowUtc: string): Promise<number>;
  /** Revoke all other PENDING invitations for a monitor (replacement flow). */
  revokeOthers(monitorId: string, keepId: string, nowUtc: string): Promise<number>;
}

export interface SubscriptionRepository {
  create(input: NewSubscriptionInput, nowUtc: string): Promise<ClientSubscription>;
  findById(id: string): Promise<ClientSubscription | null>;
  findByMonitorAndUser(
    monitorId: string,
    telegramUserId: number,
  ): Promise<ClientSubscription | null>;
  /** ACTIVE subscriptions for a monitor (recipients of a recovery). */
  listActiveByMonitor(monitorId: string): Promise<ClientSubscription[]>;
  /** ACTIVE subscriptions for a client (for /stop). */
  listActiveByUser(telegramUserId: number): Promise<ClientSubscription[]>;
  unsubscribe(
    monitorId: string,
    telegramUserId: number,
    nowUtc: string,
  ): Promise<ClientSubscription | null>;
  /** Disable all ACTIVE subscriptions for a monitor (on /clear); returns count. */
  disableForMonitor(monitorId: string, nowUtc: string): Promise<number>;
  markNotified(id: string, nowUtc: string): Promise<void>;
}

export interface DeliveryRepository {
  /** Idempotent per idempotencyKey (unique). Returns existing row on conflict. */
  enqueue(input: NewDeliveryInput, nowUtc: string): Promise<RecoveryDelivery>;
  findById(id: string): Promise<RecoveryDelivery | null>;
  findByRecovery(recoveryId: string): Promise<RecoveryDelivery[]>;
  /** Atomically claim the next PENDING delivery whose next_attempt_at <= now. */
  claimNextDue(nowUtc: string): Promise<RecoveryDelivery | null>;
  markDelivered(id: string, telegramMessageId: number | null, nowUtc: string): Promise<void>;
  markFailed(
    id: string,
    errorCode: string,
    nextAttemptAtUtc: string | null,
    nowUtc: string,
  ): Promise<void>;
  /** Cancel an unclaimed delivery (e.g. client unsubscribed / monitor cleared). */
  markCancelled(id: string, nowUtc: string): Promise<void>;
  /** Cancel all PENDING (unclaimed) deliveries for a monitor; returns count. */
  cancelPendingForMonitor(monitorId: string, nowUtc: string): Promise<number>;
  requeueStale(olderThanUtc: string, nowUtc: string): Promise<number>;
  countPending(): Promise<number>;
}

export interface BusinessConnectionRepository {
  /** Insert or update a business connection by its id. */
  upsert(connection: BusinessConnection): Promise<void>;
  findById(id: string): Promise<BusinessConnection | null>;
  /** The most recently-updated enabled connection (the one we send through). */
  findLatestEnabled(): Promise<BusinessConnection | null>;
}

export interface ClientChatLinkRepository {
  /**
   * One link per monitor (case). Re-running for the SAME `clientChatId` refreshes the row
   * (idempotent — the owner re-typing `/unban` in a client's chat is normal).
   *
   * A link that already belongs to a DIFFERENT client chat is NEVER re-pointed: the stored link
   * is returned UNCHANGED, so callers MUST compare the returned `clientChatId` with what they
   * asked for. A monitor carries exactly one chat id, and re-pointing it silently deletes the
   * only route to the first client — who had already been told monitoring had started, and would
   * then never hear about their own recovery.
   */
  create(input: NewClientChatLink, nowUtc: string): Promise<ClientChatLink>;
  findByMonitorId(monitorId: string): Promise<ClientChatLink | null>;
  /** All links (used by /clients to map every monitor -> its client chat in one query). */
  listAll(): Promise<ClientChatLink[]>;
  updateDeliveryStatus(
    monitorId: string,
    status: BusinessDeliveryStatus,
    nowUtc: string,
  ): Promise<void>;
}

/** Client display-identity store for the /clients view, keyed by client chat id. */
export interface ClientsRepository {
  /** Insert or refresh a client's identity (username/name) by chat id. */
  upsert(identity: NewClientIdentity, nowUtc: string): Promise<void>;
  findByChatId(clientChatId: number): Promise<ClientIdentity | null>;
  listAll(): Promise<ClientIdentity[]>;
}

/** Lease params for claiming due deletion watches (mirror of {@link ClaimDueParams}). */
export interface DeletionClaimParams {
  nowUtc: string;
  leaseOwner: string;
  leaseExpiresUtc: string;
  limit: number;
}

/**
 * Persistence for the SEPARATE deletion-watch feature (`/ban`). Mirrors the shape of
 * {@link CaseRepository} but for the `deletion_watches` table; it never reads or writes
 * monitoring_cases, so the two features cannot interfere.
 */
export interface DeletionWatchRepository {
  create(input: NewDeletionWatchInput, nowUtc: string): Promise<DeletionWatch>;
  findById(id: string): Promise<DeletionWatch | null>;
  /** Active (non-terminal) watch for a username, or null. Enforced unique by DB index. */
  findActiveByNormalizedUsername(username: string): Promise<DeletionWatch | null>;
  /** All active watches (for /banlist), oldest first. */
  listActive(): Promise<DeletionWatch[]>;
  countActive(): Promise<number>;
  /** Atomically claim up to `limit` due watches under a lease (CONFIRMING first). */
  claimDue(params: DeletionClaimParams): Promise<DeletionWatch[]>;
  save(next: DeletionWatch): Promise<void>;
  releaseLease(id: string, nowUtc: string): Promise<void>;
  /** Atomically mark an active watch CLEARED; returns it, or null if none was active. */
  clearByNormalizedUsername(username: string, clearedAtUtc: string): Promise<DeletionWatch | null>;
}

export interface Repositories {
  owner: OwnerRepository;
  cases: CaseRepository;
  checks: CheckRepository;
  updates: TelegramUpdateRepository;
  outbox: OutboxRepository;
  health: SchedulerHealthRepository;
  /**
   * Durable fleet-wide back-off. Optional ONLY because the worker-test fakes predate it; every
   * real driver provides it and {@link Database} consumers must treat its absence as a loud
   * degradation (a restart would resume full-rate traffic), never as a silent default.
   */
  breakerState?: BreakerStateRepository;
  businessConnections: BusinessConnectionRepository;
  clientLinks: ClientChatLinkRepository;
  /** Client display-identity store for the /clients view. */
  clients: ClientsRepository;
  /** SEPARATE deletion-watch feature (/ban). Independent of `cases`. */
  deletionWatches: DeletionWatchRepository;
  // NOTE: invitations/subscriptions/deliveries land here once their persistence
  // implementations exist (client-notification feature, in progress).
}

/** Database lifecycle + repository access. */
export interface Database {
  migrate(): Promise<void>;
  repositories(): Repositories;
  /** Round-trip read/write probe for /ping. */
  ping(): Promise<boolean>;
  close(): Promise<void>;
}
