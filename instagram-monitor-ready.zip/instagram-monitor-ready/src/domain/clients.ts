/**
 * Client identity for the `/clients` view, plus the delivery policy every client-facing
 * channel shares.
 *
 * Identity: the Telegram display info of a business-chat client, keyed by their chat id.
 * Captured from business messages (auto, going forward) and backfilled via getChat. Purely
 * for the owner's own labelling — no sensitive data.
 */

import type { BusinessDeliveryStatus } from './business';
import { isAppError } from './errors';

export interface ClientIdentity {
  /** The client's Telegram chat id (= their user id for a 1:1 business chat). */
  clientChatId: number;
  businessConnectionId: string | null;
  username: string | null;
  firstName: string | null;
  lastName: string | null;
  updatedAtUtc: string;
}

export interface NewClientIdentity {
  clientChatId: number;
  businessConnectionId: string | null;
  username: string | null;
  firstName: string | null;
  lastName: string | null;
}

// ---------------------------------------------------------------------------
// Client-delivery policy (shared by the recovery outbox and the deletion watcher)
// ---------------------------------------------------------------------------

/**
 * The three things one attempt to put a message in front of a client can settle.
 *
 * `POSSIBLY_DELIVERED` is the whole reason this type exists: it is NOT a failure, it is the
 * absence of knowledge, and it must never be collapsed into either of the others.
 */
export type ClientSendOutcome = 'DELIVERED' | 'NOT_DELIVERED' | 'POSSIBLY_DELIVERED';

/**
 * Statuses meaning the client already HAS the message. Terminal for every sender.
 */
export const CLIENT_DELIVERY_DONE_STATUSES: readonly BusinessDeliveryStatus[] = [
  'BUSINESS_DELIVERED',
  'FALLBACK_BOT_DELIVERED',
];

/**
 * The durable "a message to this client is on the wire, or was, and we do not know whether it
 * landed" marker. It is written BEFORE the send and cleared by whichever outcome follows.
 *
 * Claim-then-send, the same rule as `CaseRepository.claimNotification` and the deletion
 * watcher's CONFIRMED -> ALERTING write. It is what makes the two failures that used to be
 * indistinguishable distinguishable across a process restart:
 *
 *  - crash / DB failure AFTER the send but BEFORE the "delivered" record -> the link is still
 *    parked here, so the next pass knows the client may already have been told and escalates
 *    to the owner instead of sending a second "YOUR ACCOUNT IS BACK";
 *  - crash BEFORE the send -> the link never left {@link CLIENT_DELIVERY_OWED_STATUS}, so the
 *    next pass retries, which is exactly right because nothing was sent.
 *
 * The inherited enum name reads like "a retry is in progress"; the meaning here is narrower and
 * strictly stronger — DO NOT re-send a link sitting in this state.
 */
export const CLIENT_DELIVERY_IN_FLIGHT_STATUS = 'BUSINESS_DELIVERY_RETRYING' as const;

/**
 * The retry state: a delivery is owed and provably nothing has been sent, so a sweep may
 * safely attempt it again.
 */
export const CLIENT_DELIVERY_OWED_STATUS = 'BUSINESS_DELIVERY_PENDING' as const;

/**
 * How long we keep retrying a client delivery before handing it to the owner.
 *
 * Bounded on purpose: a client waiting longer than this for the alert they pay for needs a
 * human, not another automated attempt. The sweeps that drive the retry run once a minute, so
 * this is ~15 attempts — generous enough to ride out a Telegram 429/5xx window, short enough
 * that the owner is told while the recovery is still news.
 */
export const CLIENT_DELIVERY_RETRY_WINDOW_MS = 15 * 60 * 1000;

/**
 * How long the owner's "deliver this by hand" ping keeps being RETRIED before the escalation is
 * committed regardless.
 *
 * The ping used to get exactly ONE attempt, discarded with `.catch(() => undefined)`, while the
 * status it accompanies is terminal for every sweep there is. A ping lost to a blip therefore left
 * the paying client permanently untold AND the owner permanently unaware that they had to finish
 * the job by hand — the worst failure this system has, evidenced by a single log line.
 *
 * The failure is CORRELATED, not independent: escalation is reached precisely BECAUSE Telegram
 * egress has been failing for the whole client-retry window, so that one attempt goes out over the
 * channel that just failed ~15 consecutive times.
 *
 * Deliberately LONGER than {@link CLIENT_DELIVERY_RETRY_WINDOW_MS} — the ping retry begins where
 * the client retry gave up — and deliberately BOUNDED, so an owner who is genuinely unreachable
 * (bot blocked, chat deleted, still unpaired) cannot turn one escalation into a permanent ping loop
 * against Telegram. Both anchors are timestamps written once and never rewritten, so the budget
 * survives restarts and cannot be pushed out by its own retries.
 */
export const OWNER_ESCALATION_PING_WINDOW_MS = 60 * 60 * 1000;

/**
 * True once the owner-escalation ping has been retried for {@link OWNER_ESCALATION_PING_WINDOW_MS}
 * and the escalation must be committed even though the owner could not be reached.
 */
export function ownerPingRetryExhausted(anchorUtc: string, now: Date): boolean {
  const anchorMs = new Date(anchorUtc).getTime();
  if (!Number.isFinite(anchorMs)) return true;
  return now.getTime() - anchorMs >= OWNER_ESCALATION_PING_WINDOW_MS;
}

/**
 * Classify a thrown client send.
 *
 * `HttpTelegramClient` is contractually the thing that decides this: it raises
 * TELEGRAM_AMBIGUOUS only when the outcome is genuinely unknowable (socket reset mid-send, our
 * own timeout abort, a 504, a truncated 200 body) and TELEGRAM_ERROR for everything that
 * provably never reached Telegram's backend. Anything else reaching here never got a reply from
 * Telegram at all, so it did not deliver.
 */
export function classifyClientSendFailure(err: unknown): 'NOT_DELIVERED' | 'POSSIBLY_DELIVERED' {
  return isAppError(err) && err.code === 'TELEGRAM_AMBIGUOUS'
    ? 'POSSIBLY_DELIVERED'
    : 'NOT_DELIVERED';
}

/**
 * True once the retry budget for a client delivery is spent and the owner must take over.
 *
 * Anchored on a timestamp written down ONCE (the owner alert's send time, or the confirmation),
 * never on a value a retry rewrites — otherwise every attempt would push the deadline out and
 * the "bounded" retry would loop forever. An unparseable anchor escalates rather than loops.
 */
export function clientRetryExhausted(anchorUtc: string, now: Date): boolean {
  const anchorMs = new Date(anchorUtc).getTime();
  if (!Number.isFinite(anchorMs)) return true;
  return now.getTime() - anchorMs >= CLIENT_DELIVERY_RETRY_WINDOW_MS;
}
