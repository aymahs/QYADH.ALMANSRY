/** Structured application errors with stable codes for logs and control flow. */

export type AppErrorCode =
  | 'INVALID_USERNAME'
  | 'INVALID_TIMESTAMP'
  | 'DUPLICATE_CASE'
  | 'CASE_NOT_FOUND'
  | 'NOT_AUTHORIZED'
  | 'PAIRING_FAILED'
  | 'ALREADY_PAIRED'
  | 'WEBHOOK_SECRET_MISMATCH'
  | 'CONFIG_INVALID'
  | 'DB_ERROR'
  | 'BROWSER_ERROR'
  | 'SCREENSHOT_INVALID'
  | 'TELEGRAM_ERROR'
  | 'TELEGRAM_AMBIGUOUS'
  | 'INTERNAL';

export class AppError extends Error {
  readonly code: AppErrorCode;
  /** Safe, user-facing detail (never contains secrets). */
  readonly safeDetail: string | undefined;

  constructor(code: AppErrorCode, message: string, safeDetail?: string) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.safeDetail = safeDetail;
  }
}

export function isAppError(err: unknown): err is AppError {
  return err instanceof AppError;
}
