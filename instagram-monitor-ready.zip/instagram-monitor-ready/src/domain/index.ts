/** Barrel of domain contracts. Import from '../domain' throughout the app. */

export type {
  Classification,
  ActiveSignal,
  GoneSignal,
  DetectorErrorCode,
  PageSnapshot,
  DetectorEvidence,
  DetectorResult,
  Screenshot,
  ProbeOptions,
  ProbeResult,
  Detector,
} from './classification';
export {
  SIGNALS_VERSION,
  ACTIVE_SIGNALS,
  GONE_SIGNALS,
  IDENTITY_ACTIVE_SIGNALS,
} from './classification';

export type {
  CaseStatus,
  ScreenshotStatus,
  MonitoringCase,
  NewCaseInput,
  CheckRecord,
  NewCheckInput,
  OutboxStatus,
  OutboxKind,
  OutboxItem,
  SchedulerHealth,
} from './case';
export { LISTED_STATUSES, ACTIVE_STATUSES, TERMINAL_STATUSES } from './case';

export type { DeletionWatch, DeletionWatchStatus, NewDeletionWatchInput } from './deletion';
export {
  DELETION_ACTIVE_STATUSES,
  DELETION_TERMINAL_STATUSES,
  DELETION_DECIDED_STATUSES,
  DELETION_PENDING_ALERT_STATUSES,
} from './deletion';

export type { ClientIdentity, NewClientIdentity } from './clients';

export type {
  TelegramUser,
  TelegramChat,
  TelegramChatType,
  TelegramMessage,
  TelegramUpdate,
  CallbackQuery,
  RawBusinessConnection,
  RawBusinessBotRights,
  InlineKeyboardButton,
  InlineKeyboardMarkup,
  ParseMode,
  SendMessageParams,
  SendPhotoParams,
  SentMessage,
  SetWebhookParams,
  BotCommand,
  ChatInfo,
  TelegramClient,
} from './telegram';
export { VISIBLE_COMMANDS, ALLOWED_UPDATES } from './telegram';

export type {
  BusinessConnection,
  BusinessConnectionRights,
  MonitorSourceType,
  BusinessDeliveryStatus,
  ClientChatLink,
  NewClientChatLink,
} from './business';

export type { Clock } from './clock';
export { SystemClock, FixedClock } from './clock';

export type { AppErrorCode } from './errors';
export { AppError, isAppError } from './errors';

export type {
  OwnerRepository,
  CaseRepository,
  ClaimDueParams,
  CheckRepository,
  TelegramUpdateRepository,
  EnqueueOutbox,
  OutboxRepository,
  SchedulerHealthRepository,
  BusinessConnectionRepository,
  ClientChatLinkRepository,
  ClientsRepository,
  DeletionWatchRepository,
  DeletionClaimParams,
  Repositories,
  Database,
} from './repositories';
