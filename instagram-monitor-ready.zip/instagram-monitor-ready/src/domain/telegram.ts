/** Minimal, typed Telegram Bot API surface used by the bot. */

export interface TelegramUser {
  id: number;
  is_bot: boolean;
  username?: string;
  first_name?: string;
  last_name?: string;
}

export type TelegramChatType = 'private' | 'group' | 'supergroup' | 'channel';

export interface TelegramChat {
  id: number;
  type: TelegramChatType;
  /** Present on private chats (incl. business client chats) — the client's identity. */
  username?: string;
  first_name?: string;
  last_name?: string;
}

/** Result of a getChat lookup (best-effort client-identity resolution). */
export interface ChatInfo {
  id: number;
  type?: TelegramChatType;
  username?: string;
  first_name?: string;
  last_name?: string;
}

export interface TelegramMessage {
  message_id: number;
  from?: TelegramUser;
  chat: TelegramChat;
  date: number;
  text?: string;
  /** Present on business_message/edited_business_message updates. */
  business_connection_id?: string;
}

/** Raw `business_connection` update payload. */
export interface RawBusinessBotRights {
  can_reply?: boolean;
  can_read_messages?: boolean;
  can_delete_sent_messages?: boolean;
  can_delete_all_messages?: boolean;
}

export interface RawBusinessConnection {
  id: string;
  user: TelegramUser;
  user_chat_id?: number;
  date: number;
  /** Newer Bot API groups rights here; older exposes a top-level can_reply. */
  rights?: RawBusinessBotRights;
  can_reply?: boolean;
  is_enabled: boolean;
}

export interface CallbackQuery {
  id: string;
  from: TelegramUser;
  message?: TelegramMessage;
  /** Opaque payload set on the button (callback_data). Never a secret. */
  data?: string;
}

export interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
  edited_message?: TelegramMessage;
  callback_query?: CallbackQuery;
  /** Business-connected-bot updates (require allowed_updates to be set explicitly). */
  business_connection?: RawBusinessConnection;
  business_message?: TelegramMessage;
  edited_business_message?: TelegramMessage;
}

/** Update types the bot subscribes to (Business types are NOT in the API default). */
export const ALLOWED_UPDATES: readonly string[] = [
  'message',
  'edited_message',
  'callback_query',
  'business_connection',
  'business_message',
  'edited_business_message',
];

export interface InlineKeyboardButton {
  text: string;
  url?: string;
  callback_data?: string;
}

export interface InlineKeyboardMarkup {
  inline_keyboard: InlineKeyboardButton[][];
}

export type ParseMode = 'HTML' | 'MarkdownV2';

export interface SendMessageParams {
  chat_id: number;
  text: string;
  parse_mode?: ParseMode;
  reply_markup?: InlineKeyboardMarkup;
  disable_web_page_preview?: boolean;
  reply_to_message_id?: number;
  /** Send on behalf of a connected Business account (into a managed client chat). */
  business_connection_id?: string;
}

export interface SendPhotoParams {
  chat_id: number;
  photo: Buffer;
  filename?: string;
  caption?: string;
  parse_mode?: ParseMode;
  reply_markup?: InlineKeyboardMarkup;
  reply_to_message_id?: number;
  /** Send on behalf of a connected Business account (into a managed client chat). */
  business_connection_id?: string;
}

export interface SentMessage {
  message_id: number;
}

export interface SetWebhookParams {
  url: string;
  secret_token: string;
  allowed_updates?: string[];
}

export interface BotCommand {
  command: string;
  description: string;
}

/**
 * Typed Telegram client. Implementations wrap the HTTP API; tests provide a mock
 * that records exact outgoing payloads.
 */
export interface TelegramClient {
  getMe(): Promise<{ id: number; username?: string }>;
  /** Best-effort chat lookup for a client's display info. Returns null on any failure. */
  getChat(chatId: number): Promise<ChatInfo | null>;
  sendMessage(params: SendMessageParams): Promise<SentMessage>;
  sendPhoto(params: SendPhotoParams): Promise<SentMessage>;
  setWebhook(params: SetWebhookParams): Promise<boolean>;
  deleteWebhook(dropPendingUpdates?: boolean): Promise<boolean>;
  setMyCommands(commands: BotCommand[]): Promise<boolean>;
  /** Long-polling (dev). Returns updates newer than `offset`, filtered to `allowedUpdates`. */
  getUpdates(
    offset: number,
    timeoutSeconds: number,
    allowedUpdates?: readonly string[],
  ): Promise<TelegramUpdate[]>;
}

/** The visible commands, in menu order. */
export const VISIBLE_COMMANDS: readonly BotCommand[] = [
  { command: 'unban', description: 'Monitor an Instagram username' },
  { command: 'bulkunban', description: 'Monitor many usernames at once' },
  { command: 'check', description: 'Check if an account is active right now' },
  { command: 'list', description: 'Show monitored usernames' },
  { command: 'clear', description: 'Stop monitoring a username' },
  { command: 'ping', description: 'Test the monitoring system' },
  { command: 'ban', description: 'Watch for an account to go inactive/deleted' },
  { command: 'banlist', description: 'Show accounts watched for deletion' },
  { command: 'unwatch', description: 'Stop a deletion watch' },
  { command: 'clients', description: 'List clients and the pages monitored in each chat' },
  { command: 'proxy', description: 'Show or switch the egress route (home | mobile)' },
];
