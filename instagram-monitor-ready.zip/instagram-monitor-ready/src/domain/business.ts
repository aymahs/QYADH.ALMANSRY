/**
 * Telegram Business connected-bot domain.
 *
 * The owner connects this bot to their Telegram Business account and selects which private
 * client chats it may manage. The owner then types `/unban <user>` INSIDE a client's chat;
 * the bot receives a `business_message`, links that Instagram monitor to the client chat id
 * + business connection id, and later delivers the recovery notification back INTO that same
 * conversation "on behalf of" the business account.
 *
 * Security: a monitor is only ever created/controlled from a message the BUSINESS ACCOUNT
 * (the owner) sent — never one the client sent. Identity is the numeric owner user id carried
 * on the authorized business connection, never a @username.
 */

// ---------------------------------------------------------------------------
// Business connection (Bot API: business_connection update)
// ---------------------------------------------------------------------------

/** Rights granted to the connected bot (subset the bot actually relies on). */
export interface BusinessConnectionRights {
  canReply: boolean;
  canReadMessages: boolean;
  canDeleteSentMessages: boolean;
  canDeleteAllMessages: boolean;
}

export interface BusinessConnection {
  id: string;
  /** Numeric Telegram user id of the business account owner. Must equal the paired owner. */
  userId: number;
  userChatId: number | null;
  isEnabled: boolean;
  rights: BusinessConnectionRights;
  createdAtUtc: string;
  updatedAtUtc: string;
}

// ---------------------------------------------------------------------------
// Monitor <-> client-chat link (business-sourced monitors)
// ---------------------------------------------------------------------------

export type MonitorSourceType = 'DIRECT' | 'BUSINESS_CHAT';

/** Per-recipient business delivery lifecycle (independent of the owner notification). */
export type BusinessDeliveryStatus =
  | 'BUSINESS_DELIVERY_NOT_REQUIRED'
  | 'BUSINESS_DELIVERY_PENDING'
  | 'BUSINESS_DELIVERED'
  | 'BUSINESS_REPLY_WINDOW_CLOSED'
  | 'BUSINESS_CONNECTION_DISABLED'
  | 'BUSINESS_PERMISSION_MISSING'
  | 'BUSINESS_DELIVERY_RETRYING'
  | 'OWNER_ACTION_REQUIRED'
  | 'FALLBACK_BOT_PENDING'
  | 'FALLBACK_BOT_DELIVERED';

/**
 * Links a monitoring case to the client conversation it was started from. Kept in a separate
 * table so the core MonitoringCase model stays unchanged; one link per monitor.
 */
export interface ClientChatLink {
  id: string;
  monitorId: string;
  sourceType: MonitorSourceType;
  clientChatId: number;
  businessConnectionId: string;
  ownerTelegramUserId: number;
  sourceMessageId: number | null;
  clientDeliveryStatus: BusinessDeliveryStatus;
  createdAtUtc: string;
  updatedAtUtc: string;
}

export interface NewClientChatLink {
  monitorId: string;
  sourceType: MonitorSourceType;
  clientChatId: number;
  businessConnectionId: string;
  ownerTelegramUserId: number;
  sourceMessageId: number | null;
}
