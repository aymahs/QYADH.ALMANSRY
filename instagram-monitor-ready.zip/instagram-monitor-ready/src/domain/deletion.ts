/**
 * Deletion-watch model — the mirror image of a {@link MonitoringCase}, for detecting an
 * ACTIVE profile going GONE (deleted / deactivated / banned). Fully SEPARATE from the
 * recovery pipeline: its own table (`deletion_watches`), its own worker and state machine,
 * and its own (text-only, owner) notification. Nothing here touches monitoring_cases, so a
 * username can be recovery-watched (/unban) and deletion-watched (/ban) at the same time.
 *
 * Times are ISO-8601 UTC strings.
 */

import type { Classification } from './classification';

export type DeletionWatchStatus =
  /** Profile is (presumed) ACTIVE; waiting for it to turn GONE. */
  | 'WATCHING'
  /** Saw GONE; confirming N consecutive GONE before notifying. */
  | 'CONFIRMING'
  /** Bounded retry cadence after an inconclusive UNKNOWN check. */
  | 'BACKOFF'
  /** Deletion confirmed and written down; no alert has left the process yet. */
  | 'CONFIRMED'
  /** The one-shot alerts have been dispatched; the owner's Telegram alert is still retrying. */
  | 'ALERTING'
  /** Confirmed gone and the owner was notified — terminal. */
  | 'NOTIFIED'
  /** Stopped via /unwatch — terminal. */
  | 'CLEARED';

/** Statuses that still receive scheduled work (and are shown by /banlist). */
export const DELETION_ACTIVE_STATUSES: readonly DeletionWatchStatus[] = [
  'WATCHING',
  'CONFIRMING',
  'BACKOFF',
  'CONFIRMED',
  'ALERTING',
];

/** Terminal statuses — never checked or notified again. */
export const DELETION_TERMINAL_STATUSES: readonly DeletionWatchStatus[] = ['NOTIFIED', 'CLEARED'];

/**
 * Statuses where the deletion is a settled fact. The decision is persisted BEFORE the first
 * alert leaves the process and is never taken back: by the time a watch is in one of these,
 * a paying client may already have been told their account is gone, and silently un-deciding
 * that would make the bot a liar. A late or contradicting check result cannot move them.
 */
export const DELETION_DECIDED_STATUSES: readonly DeletionWatchStatus[] = [
  'CONFIRMED',
  'ALERTING',
  'NOTIFIED',
];

/**
 * Decided, but the alert fan-out has not finished. A watch parked in one of these is waiting on
 * nothing but a delivery attempt, and `claimDue` polls only the statuses that still need a probe
 * — so these rows are reached by status, never by the due-check queue.
 */
export const DELETION_PENDING_ALERT_STATUSES: readonly DeletionWatchStatus[] = [
  'CONFIRMED',
  'ALERTING',
];

export interface DeletionWatch {
  id: string;
  normalizedUsername: string;
  originalInput: string;
  startedAtUtc: string;
  status: DeletionWatchStatus;
  confirmationCount: number;
  consecutiveUnknownCount: number;
  nextCheckAtUtc: string | null;
  lastCheckedAtUtc: string | null;
  lastResult: Classification | null;
  /** When the deletion was confirmed (3x consecutive GONE). Write-once — never cleared. */
  confirmedAtUtc: string | null;
  clearedAtUtc: string | null;
  notifiedAtUtc: string | null;
  telegramMessageId: number | null;
  /** Job-lease holder id; null when free. */
  leaseOwner: string | null;
  leaseExpiresAtUtc: string | null;
  createdAtUtc: string;
  updatedAtUtc: string;
}

/** Data needed to create a new deletion watch. */
export interface NewDeletionWatchInput {
  normalizedUsername: string;
  originalInput: string;
  startedAtUtc: string;
  nextCheckAtUtc: string;
}
