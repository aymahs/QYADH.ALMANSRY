# Instagram Unban Monitor

A **private, single-owner** Telegram bot that watches **public** Instagram profile pages and sends
you one clean notification the moment a previously-unavailable account is **confirmed publicly
accessible again**.

> `/unban <username>` means _"start monitoring this public profile and tell me when it's back."_
> The bot does **not** unban, recover, log into, or otherwise interact with Instagram accounts. It
> only loads the public profile page, unauthenticated, in a real browser and classifies what it sees.

## What it does / does not do

**Does:** load `https://www.instagram.com/{username}/` in a real Playwright Chromium, classify the
page as `ACTIVE` / `GONE` / `UNKNOWN` using multiple independent signals, require **3 consecutive
ACTIVE** checks 5 seconds apart before alerting, capture a real screenshot of the recovered profile,
and deliver one Telegram photo notification with the recovery duration and a link button.

**Never:** submits appeals · logs in · asks for or stores passwords, 2FA codes, or cookies · uses
Instagram private APIs · uses CAPTCHA solvers, stealth plugins, or residential proxies · claims it
caused the recovery. See the [design doc](docs/superpowers/specs/2026-07-17-instagram-unban-monitor-design.md).

## Commands

| Command                                            | Purpose                                                                 |
| -------------------------------------------------- | ----------------------------------------------------------------------- |
| `/unban <username\|@user\|url> [YYYY-MM-DD HH:mm]` | Start monitoring (optional backdated IST start time)                    |
| `/list`                                            | Show accounts being monitored (Monitoring / Confirming / Error backoff) |
| `/clear <username>`                                | Stop monitoring one account                                             |
| `/ping`                                            | Real end-to-end health test through the production detector             |
| `/start <pairing-secret>`                          | One-time owner pairing (not a monitoring command)                       |

## Architecture (layered, dependency-inverted)

```
src/domain        shared contracts (types, enums, interfaces) — the frozen boundary
src/config        env validation -> typed AppConfig
src/logging       structured JSON logger with secret redaction
src/persistence   Database abstraction (SQLite dev / Postgres prod), migrations, repositories
src/instagram     browser manager · ACTIVE/GONE/UNKNOWN detector · screenshot (the ONE detector)
src/monitoring    pure state machine · confirmation · adaptive scheduler · job leasing
src/bot           typed Telegram client · command parsing · owner authorization
src/notifications message formatting · durable outbox
src/health        health snapshot + warning/restored alerts
src/app           webhook server + polling loop + worker + graceful shutdown + DI wiring
```

`/ping` and the production monitor call the **exact same** detector — detection logic is never
duplicated.

## Local development

```bash
npm install
cp .env.example .env        # fill in dev values (see below); real secrets go in the host secret manager
npm run check               # format:check + lint + typecheck + tests (no live token needed)
npm run dev                 # start in polling mode
```

Node.js 20+ (developed on 22). The default dev database is SQLite; production uses Postgres.

## Testing

```bash
npm test                    # unit + integration (Vitest), fully mocked — no live Telegram token
npm run test:coverage
```

The main suite mocks the Telegram API (asserting exact outgoing payloads) and classifies against
saved HTML fixtures — no network and no real browser required.

## Environment variables

Names only (real values belong in the host's encrypted secret manager — never in git):

`TELEGRAM_BOT_TOKEN` · `TELEGRAM_WEBHOOK_SECRET` · `OWNER_PAIRING_SECRET` · `TELEGRAM_MODE` ·
`PUBLIC_BASE_URL` · `CONTROL_USERNAME` · `BROWSER_WS_ENDPOINT` · `DB_DRIVER` · `SQLITE_PATH` ·
`DATABASE_URL` · `DISPLAY_TIMEZONE` · scheduling knobs (`BASELINE_INTERVAL_SECONDS`,
`CONFIRMATION_INTERVAL_SECONDS`, `CONFIRMATION_REQUIRED_COUNT`, …) · `PORT` · `LOG_LEVEL`.

See [`.env.example`](.env.example) and [deployment docs](docs/DEPLOYMENT.md).

## Deployment

Portable multi-stage `Dockerfile` on the official Playwright image (bundled Chromium). Runs on any
host with a persistent Node process + Postgres + HTTPS webhook (Railway, Render, Fly.io), or connect
to a remote browser via `BROWSER_WS_ENDPOINT`. See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md).

## Known limitation (read this)

Instagram heavily **login-walls unauthenticated traffic**, especially from cloud IPs. Many checks
will legitimately be `UNKNOWN` (which never triggers a notification and never removes an account).
This is safe by design, but detection can be slower/rarer than "checks every minute and sees it
instantly." A remote browser with better IP reputation improves the hit-rate; the bot never uses
cookies, stealth, or proxies to force access.

## Security

Owner-only (numeric Telegram id stored once via pairing; all other users/groups/channels rejected).
Webhook requests verified via the `X-Telegram-Bot-Api-Secret-Token` header. Secrets live only in the
environment and are redacted from logs. No real secret is ever committed.
