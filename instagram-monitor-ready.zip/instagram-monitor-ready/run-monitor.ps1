# run-monitor.ps1 — 24/7 supervisor for the Instagram Unban Monitor.
# Relaunches the bot ~10s after any exit (crash, error, or clean stop) and logs to logs\bot.log.
# Launched by the "InstagramUnbanMonitor" scheduled task at log on; also runnable by hand.

$ErrorActionPreference = 'Continue'
$proj = 'C:\Users\fazea\monitor bot'

# Ensure the Node runtime resolves even under a bare scheduler environment.
$env:Path = 'C:\Users\fazea\AppData\Local\hermes\node;' + $env:Path

Set-Location $proj
$logDir = Join-Path $proj 'logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$log = Join-Path $logDir 'bot.log'
# Invoke node + the tsx CLI directly rather than the node_modules\.bin\tsx.cmd shim. The shim is
# a batch wrapper, and under this machine's Application Control policy launching it can fail in a
# way that never returns and never throws — observed 2026-07-30: the supervisor process stayed
# alive while the bot never started, so monitoring was dead for ~30 minutes with NOTHING written
# to this log. The direct invocation below is the one verified to start the bot.
$node = 'C:\Users\fazea\AppData\Local\hermes\node\node.exe'
$cli = Join-Path $proj 'node_modules\tsx\dist\cli.mjs'

while ($true) {
  "$(Get-Date -Format o) [supervisor] starting monitor" | Out-File -Append -Encoding utf8 $log
  try {
    & $node $cli --env-file=.env 'src/app/index.ts' *>> $log
  } catch {
    "$(Get-Date -Format o) [supervisor] launch error: $($_.Exception.Message)" |
      Out-File -Append -Encoding utf8 $log
  }
  "$(Get-Date -Format o) [supervisor] monitor exited; restarting in 10s" |
    Out-File -Append -Encoding utf8 $log
  Start-Sleep -Seconds 10
}
