/**
 * IP viability probe — "will Instagram monitoring actually work from HERE?"
 *
 * Run this on any candidate host (VPS, or locally with BROWSER_PROXY_SERVER set to a proxy
 * trial) to get a definitive verdict BEFORE committing money to it. It uses the REAL browser
 * manager and the REAL detector, so a PASS here means the production path works from this IP.
 *
 *   npx tsx --env-file=.env test-ip.ts
 *
 * Tests, in order:
 *   1. What IP/ASN does Instagram actually see? (datacenter vs residential/mobile)
 *   2. LOGGED-OUT probe of a known-good public profile  -> is there a login wall?
 *   3. LOGGED-IN probe (only if IG_STORAGE_STATE is present and valid) -> did the session survive?
 *
 * Exit code 0 = usable, 1 = not usable.
 */

import { loadConfig } from './src/config';
import { BrowserManager, PlaywrightDetector } from './src/instagram';
import { createLogger } from './src/logging/logger';
import { existsSync } from 'node:fs';

const CONTROL = process.argv[2] ?? 'instagram';

const base = loadConfig(process.env);
const logger = createLogger({ level: 'error', secrets: [] });

function line(): void {
  console.log('-'.repeat(66));
}

/** Ask (through the browser, so it goes via any configured proxy) what IP we exit from. */
async function exitIp(browser: BrowserManager): Promise<void> {
  try {
    const info = await browser.withPage(async (page) => {
      await page.goto('https://ipinfo.io/json', { waitUntil: 'domcontentloaded', timeout: 15000 });
      return page.locator('body').innerText();
    });
    const parsed = JSON.parse(info) as {
      ip?: string;
      org?: string;
      city?: string;
      country?: string;
    };
    const org = parsed.org ?? 'unknown';
    // Crude but effective: hosting/cloud ASNs almost always say so in the org string.
    const dcHint =
      /amazon|google|microsoft|azure|hetzner|ovh|digitalocean|linode|vultr|contabo|oracle|cloudflare|colo|hosting|datacenter|data center|leaseweb|choopa|m247|scaleway/i.test(
        org,
      );
    console.log(
      `Exit IP   : ${parsed.ip ?? '?'}  (${parsed.city ?? '?'}, ${parsed.country ?? '?'})`,
    );
    console.log(`Network   : ${org}`);
    console.log(
      `IP class  : ${dcHint ? '⚠️  DATACENTER / hosting ASN — Instagram treats this as a bot' : '✅ looks residential / mobile / ISP'}`,
    );
  } catch (err) {
    console.log(`Exit IP   : (lookup failed: ${err instanceof Error ? err.message : String(err)})`);
  }
}

async function probe(label: string, useSession: boolean): Promise<boolean> {
  const config = useSession ? base : { ...base, igStorageState: null };
  const browser = new BrowserManager({ config, logger });
  const detector = new PlaywrightDetector({ browser, config, logger });
  try {
    const t0 = Date.now();
    const r = await detector.probe(CONTROL, { captureScreenshot: true });
    const ms = Date.now() - t0;
    const ev = r.result.evidence;
    const ok = r.result.classification === 'ACTIVE';
    console.log(`\n${label}`);
    console.log(`  Result        : ${r.result.classification}  (${(ms / 1000).toFixed(1)}s)`);
    console.log(`  Profile match : ${ev.identitySignalMatched ? 'yes' : 'no'}`);
    console.log(`  Error code    : ${ev.errorCode ?? 'none'}`);
    console.log(`  Final URL     : ${ev.finalUrl}`);
    console.log(
      `  Screenshot    : ${r.screenshot ? `${r.screenshot.buffer.length} bytes` : 'none'}`,
    );
    if (ev.errorCode === 'LOGIN_WALL') {
      console.log('  ⚠️  LOGIN WALL — Instagram is gating this IP.');
    }
    return ok;
  } catch (err) {
    console.log(`\n${label}\n  FAILED: ${err instanceof Error ? err.message : String(err)}`);
    return false;
  } finally {
    await browser.close().catch(() => undefined);
  }
}

line();
console.log('  INSTAGRAM MONITORING — IP VIABILITY TEST');
line();
console.log(`Control account : @${CONTROL}`);
console.log(`Proxy           : ${base.browserProxy ? base.browserProxy.server : 'none (direct)'}`);
const hasSession = base.igStorageState !== null && existsSync(base.igStorageState);
console.log(`Session file    : ${hasSession ? 'present' : 'absent (logged-out only)'}`);
line();

const ipBrowser = new BrowserManager({ config: { ...base, igStorageState: null }, logger });
await exitIp(ipBrowser);
await ipBrowser.close().catch(() => undefined);
line();

const loggedOutOk = await probe('LOGGED-OUT probe', false);
const loggedInOk = hasSession ? await probe('LOGGED-IN probe', true) : null;

line();
console.log('  VERDICT');
line();
if (loggedOutOk) {
  console.log('✅ USABLE — logged-out detection works from this IP.');
  console.log('   This is the setup to run: no Instagram account at risk, nothing to maintain.');
} else if (loggedInOk === true) {
  console.log('⚠️  PARTIALLY USABLE — only works while logged in.');
  console.log('   Logged-out is gated here, so monitoring depends entirely on the session file.');
  console.log('   Expect Instagram to challenge the session on a datacenter IP; when it dies,');
  console.log('   detection silently degrades to UNKNOWN. Re-run this test after 24h and 72h');
  console.log('   before trusting it with client accounts.');
} else {
  console.log('❌ NOT USABLE — Instagram will not serve this IP reliably.');
  console.log('   Logged-out is gated and the session did not rescue it. Do not buy this option.');
}
line();

process.exit(loggedOutOk || loggedInOk === true ? 0 : 1);
