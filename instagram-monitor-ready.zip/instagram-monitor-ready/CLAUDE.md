# Instagram Unban Monitor — working notes for agents

## ⚠️ The Bash tool does not work on this machine. Use PowerShell.

Every `Bash` call in this environment fails before it runs:

```
/usr/bin/bash: -c: line 83: unexpected EOF while looking for matching `''
```

The line number is always 83 regardless of the command — even `echo ok` fails — so the fault is in
a preamble the harness prepends, not in anything you write. There is no `~/.bashrc`,
`~/.bash_profile` or `~/.profile` to repair.

**Run every shell command through the `PowerShell` tool instead.** This is not a style preference;
Bash calls silently produce "Failed / No output captured" and have already wasted whole
verification passes (Prettier checks, mutation runs, and test runs that never executed and were
then reported as failures).

PowerShell here is Windows PowerShell 5.1:
- No `&&` or `||`. Use `;` or `if ($?) { ... }`.
- Native-exe stderr is captured for you — do NOT add `2>&1`, it wraps output in ErrorRecords and
  makes `$?` false even on exit code 0.
- Multi-line strings: single-quoted here-strings, closing `'@` at column 0.

Verification commands that work:

```
npx tsc --noEmit
npx vitest run test/unit/<file>.test.ts
npx eslint .
npx prettier --check "src/**/*.ts"
```

## Runtime facts that are easy to get wrong

- **The bot is launched by `run-monitor.ps1`** (Windows scheduled task `InstagramUnbanMonitor`),
  which invokes `node node_modules/tsx/dist/cli.mjs` **directly**. Do not "simplify" it back to the
  `node_modules\.bin\tsx.cmd` shim — that shim fails under this machine's Application Control
  policy in a way that neither returns nor throws, and it left monitoring dead for ~30 minutes with
  nothing written to the log.
- **Python is blocked** by the same Application Control policy. VPS automation goes through
  `node` + the `ssh2` package, not paramiko.
- **`tsx`/esbuild transpiles with `keepNames`**, rewriting nested functions as `__name(fn, "fn")`.
  Playwright ships `page.evaluate` functions via `toString()`, where `__name` is undefined — so any
  nested helper inside a page function throws `ReferenceError` in the browser, gets swallowed by a
  fail-closed catch, and silently disables the feature while CI stays green. **Keep page functions
  flat.** This has already been shipped once.

## Non-negotiable product constraints

- NEVER log into Instagram programmatically. Never handle IG passwords, 2FA codes, or plaintext
  session cookies. The logged-in session is created by the OWNER by hand via `npm run login`.
- No private APIs, appeal submission, CAPTCHA-solving, or stealth/evasion tooling. Public pages only.
- **Harm ranking, worst first:** (1) a client is never told about a recovery; (2) a client is told
  twice or told something false — including a screenshot that is not the profile; (3) the single
  residential/mobile IP is burned, which blinds the whole fleet and causes (1) at scale;
  (4) owner-only annoyance.

## Testing discipline

A test must **never set up the thing it verifies**. A capture test in this repo wrote the
screenshot PNG by hand, which hid for weeks the fact that the follow-up path could not work in
production at all. If your test writes a file, sets a DB column, or stubs a value that production
code is responsible for producing, the test proves nothing — restructure it.

Green tests have repeatedly meant nothing here. Before claiming a fix works, trace the full call
path around your change (what runs *after* the line you edited?), grep every caller, and verify
that any backstop you rely on actually reaches the state you are leaving behind.
